"""Ganho (dB) de cada clipe de áudio de uma sequência do .prproj (Level do Volume do clipe) + volume das faixas.
python niveis_audio.py projeto.prproj <n da sequência>"""
import gzip,xml.etree.ElementTree as ET,sys,math,collections
sys.stdout.reconfigure(encoding='utf-8')
TK=254016000000
root=ET.fromstring(gzip.open(sys.argv[1]).read())
byid={e.attrib["ObjectID"]:e for e in root.iter() if "ObjectID" in e.attrib}
uid={e.attrib["ObjectUID"]:e for e in root.iter() if "ObjectUID" in e.attrib}
def ref(e):
    if e is None: return None
    if "ObjectRef" in e.attrib: return byid.get(e.attrib["ObjectRef"])
    if "ObjectURef" in e.attrib: return uid.get(e.attrib["ObjectURef"])
    return e
def levels(chain):
    out=[]; seen=set(); st=[chain]
    while st:
        x=st.pop()
        if x is None or id(x) in seen: continue
        seen.add(id(x))
        if x.tag=='AudioComponentParam' and x.findtext('Name')=='Level':
            v=x.findtext('StartKeyframe') or x.findtext('CurrentValue')
            try:
                val=float(v.split(',')[1]) if ',' in v else float(v)
                db=round(20*math.log10(val/0.17782794),1) if val>0 else -99  # Premiere: 0,1778 = 0 dB
            except Exception: db=v
            kf=x.findtext('Keyframes')
            out.append(f"{db}dB"+('+KF' if kf and kf.count(';')>1 else ''))
        for ch in x:
            st.append(ref(ch) if ('ObjectRef' in ch.attrib or 'ObjectURef' in ch.attrib) else ch)
    return out
seqs=[x for x in root.iter("Sequence") if x.findtext("Name")]
seq=seqs[int(sys.argv[2])]
for t in seq.find("TrackGroups"):
    g=ref(t.find("Second"))
    if g is None or g.tag!='AudioTrackGroup': continue
    for i,tt in enumerate(g.find('.//Tracks')):
        tr=ref(tt)
        agg=collections.Counter()
        for it in (tr.find('.//ClipItems/TrackItems') if tr.find('.//ClipItems/TrackItems') is not None else []):
            ti=ref(it); c=ti.find('ClipTrackItem')
            if c is None: continue
            sc=ref(c.find('SubClip')); nm=sc.findtext('Name') if sc is not None else '?'
            ch=ref(c.find('ComponentOwner/Components'))
            lv=levels(ch) if ch is not None else []
            short=nm if not nm.lower().endswith(('.mp4','.mov')) or 'EXPERT' in nm or nm.startswith('L6') or 'ML' in nm[:4] else 'INSERT(video)'
            agg[(short[:40],' '.join(lv[:1]) or '0dB')]+=1
        # volume da faixa (fader / mixer), fora dos clipes
        vol=[]; seen=set(); st=[c for c in tr if c.tag!='ClipTrack']
        st=[tr]
        while st:
            x=st.pop()
            if x is None or id(x) in seen: continue
            seen.add(id(x))
            if x.tag in ('ClipItems','TransitionItems','TrackItems'): continue
            if x.tag=='AudioComponentParam' and x.findtext('Name') in ('Volume','Level'):
                v=x.findtext('StartKeyframe') or x.findtext('CurrentValue')
                try:
                    val=float(v.split(',')[1]) if ',' in v else float(v); vol.append(round(20*math.log10(val/0.17782794),1) if val>0 else -99)
                except Exception: vol.append(v)
            for ch in x:
                st.append(ref(ch) if ('ObjectRef' in ch.attrib or 'ObjectURef' in ch.attrib) else ch)
        if agg: print(f"A{i+1} [faixa {vol[:2]}]", '; '.join(f"{k[0]} {k[1]} x{v}" for k,v in agg.most_common(12)))
