// Premiere Chat - lado ExtendScript (ES3). Carregado automaticamente pelo painel.
// Expõe PPC_run (executa código gerado pelo chat), PPC_context (estado do projeto) e
// funções usadas pelas ferramentas do painel, além do objeto global PPC com helpers.

(function () {
    var g = $.global;
    var TICKS = 254016000000; // ticks por segundo no Premiere

    // ---------- JSON.stringify mínimo (ExtendScript não tem JSON nativo) ----------
    function q(s) {
        return '"' + String(s)
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"')
            .replace(/\n/g, '\\n')
            .replace(/\r/g, '\\r')
            .replace(/\t/g, '\\t')
            .replace(/[\x00-\x1f]/g, function (c) {
                return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
            }) + '"';
    }

    function stringify(v, depth) {
        depth = depth || 0;
        if (depth > 8) return '"[...]"';
        if (v === null || v === undefined) return 'null';
        var t = typeof v;
        if (t === 'number') return isFinite(v) ? String(v) : 'null';
        if (t === 'boolean') return String(v);
        if (t === 'string') return q(v);
        if (t === 'function') return '"[function]"';
        if (v instanceof Array) {
            var a = [];
            for (var i = 0; i < v.length; i++) a.push(stringify(v[i], depth + 1));
            return '[' + a.join(',') + ']';
        }
        if (t === 'object') {
            // Objetos nativos do Premiere (ProjectItem, TrackItem...) viram uma descrição curta
            if (v.reflect && v.reflect.name && v.reflect.name !== 'Object') {
                var label = v.reflect.name;
                try { if (v.name !== undefined) label += ' "' + v.name + '"'; } catch (e) {}
                return q('[' + label + ']');
            }
            var parts = [];
            for (var k in v) {
                if (v.hasOwnProperty(k)) parts.push(q(k) + ':' + stringify(v[k], depth + 1));
            }
            return '{' + parts.join(',') + '}';
        }
        return q(String(v));
    }

    function r3(n) { return Math.round(n * 1000) / 1000; }
    function secs(timeObj) {
        try { return r3(timeObj.seconds); } catch (e) { return null; }
    }

    // ---------- Helpers disponíveis para o código gerado ----------
    var PPC = {};
    PPC.stringify = stringify;
    PPC.TICKS = TICKS;

    PPC.seq = function () { return app.project.activeSequence; };

    // Objeto Time a partir de segundos
    PPC.time = function (seconds) {
        var t = new Time();
        t.seconds = seconds;
        return t;
    };
    PPC.ticks = function (seconds) { return String(Math.round(seconds * TICKS)); };

    var EXT = {
        video: 'mp4 mov mxf avi mkv m4v mts m2ts wmv webm r3d braw mpg mpeg 3gp dv vob hevc',
        audio: 'wav mp3 aac m4a aif aiff flac ogg wma opus',
        image: 'jpg jpeg png gif tif tiff psd bmp webp heic exr dpx tga svg ai eps',
        graphic: 'mogrt aegraphic prproj aep',
        caption: 'srt vtt scc stl xml'
    };
    function extOf(p) {
        var m = String(p || '').match(/\.([A-Za-z0-9]+)$/);
        return m ? m[1].toLowerCase() : '';
    }
    function inList(list, ext) { return ext && (' ' + list + ' ').indexOf(' ' + ext + ' ') >= 0; }

    // Tipo de um ProjectItem: bin, sequence, video, audio, image, graphic, caption, other
    PPC.kind = function (item) {
        try {
            if (item.type === ProjectItemType.BIN) return 'bin';
            if (item.isSequence && item.isSequence()) return 'sequence';
        } catch (e) {}
        var p = '';
        try { p = item.getMediaPath(); } catch (e2) {}
        var ext = extOf(p) || extOf(item.name);
        if (inList(EXT.video, ext)) return 'video';
        if (inList(EXT.audio, ext)) return 'audio';
        if (inList(EXT.image, ext)) return 'image';
        if (inList(EXT.caption, ext)) return 'caption';
        if (inList(EXT.graphic, ext)) return 'graphic';
        if (!p) return 'synthetic'; // barras, matte de cor, título, adjustment layer...
        return 'other';
    };

    // Percorre todos os itens do projeto: fn(item, parentBin, path) — retorne true para parar.
    PPC.walk = function (fn, start, basePath) {
        var root = start || app.project.rootItem;
        var stop = false;
        function rec(bin, path) {
            for (var i = 0; i < bin.children.numItems && !stop; i++) {
                var it = bin.children[i];
                if (fn(it, bin, path)) { stop = true; return; }
                if (it.type === ProjectItemType.BIN) rec(it, path ? path + '/' + it.name : it.name);
            }
        }
        rec(root, basePath || '');
    };

    // Bin por caminho "Mídia/Vídeos" (cria os que faltarem se create = true)
    PPC.bin = function (path, create) {
        var parts = String(path).split('/');
        var cur = app.project.rootItem;
        for (var i = 0; i < parts.length; i++) {
            var name = parts[i];
            if (!name) continue;
            var found = null;
            for (var j = 0; j < cur.children.numItems; j++) {
                var c = cur.children[j];
                if (c.type === ProjectItemType.BIN && c.name === name) { found = c; break; }
            }
            if (!found) {
                if (!create) return null;
                found = cur.createBin(name);
            }
            cur = found;
        }
        return cur;
    };

    // Primeiro item com esse nome (qualquer profundidade)
    PPC.find = function (name) {
        var res = null;
        PPC.walk(function (it) { if (it.name === name) { res = it; return true; } });
        return res;
    };

    // Lista os clipes da sequência: [{track:'V1', type:'video', index, clip}]
    PPC.clips = function (seq) {
        seq = seq || app.project.activeSequence;
        var out = [];
        if (!seq) return out;
        var groups = [['V', seq.videoTracks, 'video'], ['A', seq.audioTracks, 'audio']];
        for (var gi = 0; gi < groups.length; gi++) {
            var tracks = groups[gi][1];
            for (var t = 0; t < tracks.numTracks; t++) {
                var tr = tracks[t];
                for (var c = 0; c < tr.clips.numItems; c++) {
                    out.push({ track: groups[gi][0] + (t + 1), type: groups[gi][2], trackIndex: t, index: c, clip: tr.clips[c] });
                }
            }
        }
        return out;
    };

    // ---------- Estado do projeto (contexto para o modelo) ----------

    function binTree(bin, depth, budget) {
        var node = { name: bin.name, bins: [], counts: {} , items: [] };
        for (var i = 0; i < bin.children.numItems; i++) {
            var it = bin.children[i];
            var k = PPC.kind(it);
            if (k === 'bin') {
                if (depth < 6) node.bins.push(binTree(it, depth + 1, budget));
                else node.bins.push({ name: it.name, truncated: true });
            } else {
                node.counts[k] = (node.counts[k] || 0) + 1;
                if (budget.left > 0) {
                    budget.left--;
                    node.items.push(it.name + ' (' + k + ')');
                }
            }
        }
        if (!node.bins.length) delete node.bins;
        if (!node.items.length) delete node.items;
        return node;
    }

    PPC.context = function () {
        var p = app.project;
        var out = {
            premiereVersion: app.version,
            projectName: p.name,
            projectPath: p.path || null,
            tree: binTree(p.rootItem, 0, { left: 250 }),
            sequences: [],
            activeSequence: null
        };
        for (var s = 0; s < p.sequences.numSequences && s < 40; s++) {
            out.sequences.push(p.sequences[s].name);
        }
        var seq = p.activeSequence;
        if (seq) {
            var info = { name: seq.name, id: seq.sequenceID, frameSize: null, fps: null, duration: null, playhead: null, inPoint: null, outPoint: null, videoTracks: [], audioTracks: [], markers: 0, selected: [] };
            try { info.frameSize = [seq.frameSizeHorizontal, seq.frameSizeVertical]; } catch (e) {}
            try { info.fps = r3(TICKS / Number(seq.timebase)); } catch (e) {}
            try { info.duration = r3(Number(seq.end) / TICKS); } catch (e) {}
            try { info.playhead = secs(seq.getPlayerPosition()); } catch (e) {}
            try { info.inPoint = r3(Number(seq.getInPoint())); info.outPoint = r3(Number(seq.getOutPoint())); } catch (e) {}
            try { info.markers = seq.markers.numMarkers; } catch (e) {}
            var budget = 150;
            var groups = [['V', seq.videoTracks, info.videoTracks], ['A', seq.audioTracks, info.audioTracks]];
            for (var gi = 0; gi < groups.length; gi++) {
                var tracks = groups[gi][1];
                for (var t = 0; t < tracks.numTracks; t++) {
                    var tr = tracks[t];
                    var ti = { track: groups[gi][0] + (t + 1), clips: [] };
                    try { if (tr.isMuted()) ti.muted = true; } catch (e) {}
                    try { if (tr.isLocked()) ti.locked = true; } catch (e) {}
                    for (var c = 0; c < tr.clips.numItems; c++) {
                        var clip = tr.clips[c];
                        if (budget-- <= 0) { ti.more = tr.clips.numItems - c; break; }
                        var ci = { i: c, name: clip.name, start: secs(clip.start), end: secs(clip.end) };
                        try { if (clip.isSelected()) ci.selected = true; } catch (e) {}
                        try { if (clip.disabled) ci.disabled = true; } catch (e) {}
                        ti.clips.push(ci);
                    }
                    groups[gi][2].push(ti);
                }
            }
            try {
                var sel = seq.getSelection();
                for (var x = 0; x < sel.length && x < 50; x++) info.selected.push(sel[x].name);
            } catch (e) {}
            out.activeSequence = info;
        }
        return out;
    };

    g.PPC = PPC;

    // ---------- Pontos de entrada chamados pelo painel via evalScript ----------

    function ok(result) { return stringify({ ok: true, result: result }); }
    function fail(e) { return stringify({ ok: false, error: String((e && e.message) || e), line: (e && e.line) || null }); }

    // Executa o código (URI-encoded) gerado pelo chat.
    g.PPC_run = function (encoded) {
        var code = decodeURIComponent(encoded);
        try {
            var value = eval(code);
            var text;
            if (value === undefined) text = 'OK (sem valor de retorno)';
            else if (typeof value === 'string') text = value;
            else text = stringify(value);
            if (text.length > 12000) text = text.substring(0, 12000) + '... [truncado]';
            return ok(text);
        } catch (e) {
            return fail(e);
        }
    };

    g.PPC_context = function () {
        try { return ok(PPC.context()); } catch (e) { return fail(e); }
    };

    // Projetos abertos e qual está ativo (para as abas do chat).
    function projInfo(p) {
        var path = '';
        try { path = p.path || ''; } catch (e) {}
        var id = '';
        try { id = p.documentID || ''; } catch (e2) {}
        return { name: String(p.name || ''), path: String(path), id: String(id) };
    }
    g.PPC_projects = function () {
        try {
            var list = [];
            var n = app.projects ? app.projects.numProjects : 0;
            for (var i = 0; i < n; i++) list.push(projInfo(app.projects[i]));
            return ok({ active: app.project ? projInfo(app.project) : null, list: list });
        } catch (e) { return fail(e); }
    };

    // Torna ativo um projeto que já está aberto (abrir de novo só traz para frente).
    g.PPC_activateProject = function (encPath) {
        try {
            var p = decodeURIComponent(encPath);
            if (app.project && app.project.path === p) return ok(true);
            app.openDocument(p, true, false, false, true);
            return ok(app.project && app.project.path === p);
        } catch (e) { return fail(e); }
    };

    // Salva o projeto e devolve o caminho do .prproj (para o backup feito pelo painel).
    g.PPC_save = function () {
        try {
            if (!app.project.path) return ok(null);
            app.project.save();
            return ok(app.project.path);
        } catch (e) { return fail(e); }
    };

    // Exporta o áudio da sequência ativa inteira para WAV (síncrono).
    g.PPC_exportAudio = function (encOutPath, encPreset) {
        try {
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta. Abra uma sequência na timeline.');
            var outPath = decodeURIComponent(encOutPath);
            var res = seq.exportAsMediaDirect(outPath, decodeURIComponent(encPreset), 0); // 0 = sequência inteira
            return ok({ path: outPath, sequence: seq.name, message: String(res) });
        } catch (e) { return fail(e); }
    };

    // Exporta o frame da sequência ativa no tempo indicado (PNG) usando o QE DOM.
    g.PPC_exportFrame = function (seconds, encOutPath) {
        try {
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta.');
            var outPath = decodeURIComponent(encOutPath);
            if (seconds !== null && seconds !== undefined && seconds !== '') {
                seq.setPlayerPosition(PPC.ticks(Number(seconds)));
            }
            app.enableQE();
            var qs = qe.project.getActiveSequence();
            qs.exportFramePNG(qs.CTI.timecode, outPath);
            return ok({ path: outPath, time: secs(seq.getPlayerPosition()) });
        } catch (e) { return fail(e); }
    };

    // ---------- Decupagem por silêncio ----------

    // Dados da sequência ativa usados pela aba Decupagem.
    g.PPC_seqInfo = function () {
        try {
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta. Abra uma sequência na timeline.');
            return ok({
                name: seq.name, id: seq.sequenceID,
                duration: secs(seq.end), frameTicks: Number(seq.timebase),
                videoTracks: seq.videoTracks.numTracks, audioTracks: seq.audioTracks.numTracks
            });
        } catch (e) { return fail(e); }
    };

    /*
     * Aplica a decupagem na sequência ativa.
     * opts (JSON URI-encoded): { cuts: [[início, fim], ...] em segundos, mode: 'ripple' | 'gap' |
     *   'disable' | 'markers', newSequence: bool }
     * ripple  = corta e fecha os buracos (todas as trilhas destravadas andam juntas)
     * gap     = corta e deixa os buracos
     * disable = corta e desativa os trechos (dá para reativar depois)
     * markers = só marca os silêncios com marcadores vermelhos, sem cortar
     */
    g.PPC_decupar = function (encOpts) {
        try {
            var opts = eval('(' + decodeURIComponent(encOpts) + ')');
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta.');
            var original = seq.name;

            // Trabalha numa cópia, para o original ficar intacto.
            if (opts.newSequence) {
                var before = {};
                for (var s0 = 0; s0 < app.project.sequences.numSequences; s0++) before[app.project.sequences[s0].sequenceID] = true;
                seq.clone();
                var copy = null;
                for (var s1 = 0; s1 < app.project.sequences.numSequences; s1++) {
                    if (!before[app.project.sequences[s1].sequenceID]) { copy = app.project.sequences[s1]; break; }
                }
                if (!copy) return fail('Não consegui duplicar a sequência.');
                copy.name = original + ' - DECUPADA';
                app.project.openSequence(copy.sequenceID);
                seq = app.project.activeSequence;
                if (!seq || seq.sequenceID !== copy.sequenceID) seq = copy;
            }

            var fr = Number(seq.timebase);
            // Corta sempre em quadro inteiro: o início arredonda para frente e o fim para trás.
            var cuts = [];
            for (var c = 0; c < opts.cuts.length; c++) {
                var a = Math.ceil(opts.cuts[c][0] * TICKS / fr - 0.001) * fr;
                var b = Math.floor(opts.cuts[c][1] * TICKS / fr + 0.001) * fr;
                if (b - a >= fr) cuts.push([a, b]);
            }
            if (!cuts.length) return ok({ sequence: seq.name, cuts: 0, removedSeconds: 0, note: 'Nenhum silêncio para cortar.' });

            if (opts.mode === 'markers') {
                for (var m = 0; m < cuts.length; m++) {
                    var mk = seq.markers.createMarker(cuts[m][0] / TICKS);
                    try { mk.end = cuts[m][1] / TICKS; } catch (eM) {}
                    try { mk.name = 'Silêncio'; } catch (eN) {}
                    try { mk.setColorByIndex(1); } catch (eC) {}
                }
                return ok({ sequence: seq.name, cuts: cuts.length, mode: 'markers', removedSeconds: 0 });
            }

            // Trilhas destravadas (as travadas ficam como estão).
            var tracks = [];
            var t;
            for (t = 0; t < seq.videoTracks.numTracks; t++) if (!seq.videoTracks[t].isLocked()) tracks.push({ track: seq.videoTracks[t], v: true, i: t });
            for (t = 0; t < seq.audioTracks.numTracks; t++) if (!seq.audioTracks[t].isLocked()) tracks.push({ track: seq.audioTracks[t], v: false, i: t });

            // 1. Lâmina (razor) no início e no fim de cada silêncio, em todas as trilhas.
            app.enableQE();
            var qs = qe.project.getActiveSequence();
            var st = seq.getSettings();
            var zero = Number(seq.zeroPoint) || 0;
            function tc(ticks) {
                var tm = new Time();
                tm.ticks = String(ticks + zero);
                return tm.getFormatted(st.videoFrameRate, st.videoDisplayFormat);
            }
            for (var k = cuts.length - 1; k >= 0; k--) {
                for (var e = 1; e >= 0; e--) {
                    var code = tc(cuts[k][e]);
                    for (var r = 0; r < tracks.length; r++) {
                        var qt = tracks[r].v ? qs.getVideoTrackAt(tracks[r].i) : qs.getAudioTrackAt(tracks[r].i);
                        try { qt.razor(code); } catch (eR) {}
                    }
                }
            }

            // Índice do silêncio que contém o tempo (busca binária), ou -1.
            function cutAt(ticks) {
                var lo = 0, hi = cuts.length - 1;
                while (lo <= hi) {
                    var mid = (lo + hi) >> 1;
                    if (ticks < cuts[mid][0]) hi = mid - 1;
                    else if (ticks >= cuts[mid][1]) lo = mid + 1;
                    else return mid;
                }
                return -1;
            }
            // Quanto foi cortado antes do tempo (para fechar os buracos).
            var acc = [0];
            for (var x = 0; x < cuts.length; x++) acc.push(acc[x] + (cuts[x][1] - cuts[x][0]));
            function removedBefore(ticks) {
                var lo = 0, hi = cuts.length - 1, n = 0;
                while (lo <= hi) {
                    var mid = (lo + hi) >> 1;
                    if (cuts[mid][1] <= ticks + fr / 2) { n = mid + 1; lo = mid + 1; } else hi = mid - 1;
                }
                return acc[n];
            }

            // 2. Tira (ou desativa) os pedaços que ficaram dentro dos silêncios.
            var affected = 0;
            for (r = 0; r < tracks.length; r++) {
                var clips = tracks[r].track.clips;
                for (var j = clips.numItems - 1; j >= 0; j--) {
                    var it = clips[j];
                    var cs = Number(it.start.ticks), ce = Number(it.end.ticks);
                    var idx = cutAt(cs + (ce - cs) / 2);
                    if (idx < 0 || cs < cuts[idx][0] - fr / 2 || ce > cuts[idx][1] + fr / 2) continue;
                    if (opts.mode === 'disable') { try { it.disabled = true; } catch (eD) {} }
                    else it.remove(false, false);
                    affected++;
                }
            }

            // 3. Fecha os buracos: cada clipe anda para trás o total cortado antes dele.
            var moved = 0, moveAbsolute = null;
            if (opts.mode === 'ripple') {
                // Destinos calculados antes de mexer: clipes vinculados (vídeo + áudio) podem andar
                // juntos, então cada um só anda o que ainda falta para chegar ao destino.
                var targets = [];
                for (r = 0; r < tracks.length; r++) {
                    var tl = [], c0 = tracks[r].track.clips;
                    for (var w = 0; w < c0.numItems; w++) {
                        var s0t = Number(c0[w].start.ticks);
                        tl.push(s0t - removedBefore(s0t));
                    }
                    targets.push(tl);
                }
                for (r = 0; r < tracks.length; r++) {
                    var cl = tracks[r].track.clips;
                    for (var u = 0; u < cl.numItems && u < targets[r].length; u++) {
                        var item = cl[u];
                        var target = targets[r][u];
                        var shift = Number(item.start.ticks) - target;
                        if (Math.abs(shift) < fr / 2) continue;
                        var off = new Time();
                        if (moveAbsolute) { off.ticks = String(target); item.move(off); continue; }
                        off.ticks = String(-shift);
                        item.move(off);
                        var after = Number(cl[u].start.ticks);
                        if (moveAbsolute === null) {
                            // Confere na primeira vez se move() desloca (esperado) ou posiciona.
                            if (Math.abs(after - target) > fr / 2) {
                                moveAbsolute = true;
                                var fix = new Time();
                                fix.ticks = String(target);
                                cl[u].move(fix);
                            } else moveAbsolute = false;
                        }
                        moved++;
                    }
                }
            }

            var removed = 0;
            for (var y = 0; y < cuts.length; y++) removed += cuts[y][1] - cuts[y][0];
            return ok({
                sequence: seq.name, original: original, cuts: cuts.length, pieces: affected, moved: moved,
                mode: opts.mode, removedSeconds: r3(removed / TICKS), duration: secs(seq.end)
            });
        } catch (e) { return fail(e); }
    };

    // A sequência é só um arquivo inteiro, sem cortes? Então as skills podem usar o arquivo original
    // (bem mais rápido que exportar). -> { single: true, path } ou { single: false, reason }
    g.PPC_seqSource = function () {
        try {
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta.');
            var vclips = [], t;
            for (t = 0; t < seq.videoTracks.numTracks; t++) {
                var tr = seq.videoTracks[t];
                for (var c = 0; c < tr.clips.numItems; c++) vclips.push(tr.clips[c]);
            }
            if (vclips.length !== 1) return ok({ single: false, reason: vclips.length + ' clipes de vídeo', duration: secs(seq.end) });
            var clip = vclips[0];
            var p = '';
            try { p = clip.projectItem.getMediaPath(); } catch (e1) {}
            if (!p) return ok({ single: false, reason: 'clipe sem arquivo', duration: secs(seq.end) });
            var speed = 1;
            try { speed = clip.getSpeed(); } catch (e2) {}
            var inS = secs(clip.inPoint), st = secs(clip.start);
            var mediaDur = null;
            try { mediaDur = Number(clip.projectItem.getOutPoint(1).seconds) - Number(clip.projectItem.getInPoint(1).seconds); } catch (e3) {}
            var full = st < 0.05 && inS < 0.05 && speed === 1 && (mediaDur === null || Math.abs(secs(clip.duration) - mediaDur) < 0.1);
            var aCount = 0;
            for (t = 0; t < seq.audioTracks.numTracks; t++) aCount += seq.audioTracks[t].clips.numItems;
            if (!full || aCount > 1) return ok({ single: false, reason: 'clipe cortado, com velocidade ou mais áudios', duration: secs(seq.end) });
            return ok({ single: true, path: p, duration: secs(seq.end) });
        } catch (e) { return fail(e); }
    };

    // ---------- Montagem em camadas (resultado das skills) ----------

    function normPath(p) { return String(p || '').replace(/\\/g, '/').toLowerCase(); }

    // ProjectItem já importado com esse caminho (qualquer bin), ou null.
    function itemByPath(p) {
        var want = normPath(p), res = null;
        PPC.walk(function (it) {
            try { if (it.type !== ProjectItemType.BIN && normPath(it.getMediaPath()) === want) { res = it; return true; } } catch (e) {}
        });
        return res;
    }

    // Garante que existam pelo menos n trilhas de vídeo / áudio na sequência ativa.
    function ensureTracks(seq, kind, n) {
        var coll = kind === 'V' ? seq.videoTracks : seq.audioTracks;
        var guard = 0;
        while (coll.numTracks < n && guard++ < 20) {
            var before = coll.numTracks;
            app.enableQE();
            var qs = qe.project.getActiveSequence();
            if (kind === 'V') qs.addTracks(1, before, 0);
            else {
                try { qs.addTracks(0, 0, 1, 1, before); } catch (e) {}
                if (coll.numTracks === before) { try { qs.addTracks(0, 0, 1, 0, before); } catch (e2) {} }
            }
            coll = kind === 'V' ? seq.videoTracks : seq.audioTracks;
            if (coll.numTracks === before) throw new Error('Não consegui criar a trilha ' + kind + n + '.');
        }
        return coll;
    }

    // A trilha está livre entre a e b (ticks)?
    function trackFree(track, a, b) {
        for (var i = 0; i < track.clips.numItems; i++) {
            var c = track.clips[i];
            var cs = Number(c.start.ticks), ce = Number(c.end.ticks);
            if (cs < b && ce > a) return false;
        }
        return true;
    }

    function levelFromDb(db) { return Math.pow(10, (db - 15) / 20); }

    function setProp(clip, compNames, propNames, value) {
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var cn = String(comp.displayName) + '|' + String(comp.matchName);
            var hitC = false;
            for (var k = 0; k < compNames.length; k++) if (cn.indexOf(compNames[k]) >= 0) hitC = true;
            if (!hitC) continue;
            for (var j = 0; j < comp.properties.numItems; j++) {
                var pr = comp.properties[j];
                var pn = String(pr.displayName);
                for (var m = 0; m < propNames.length; m++) {
                    if (pn === propNames[m]) { pr.setValue(value, true); return true; }
                }
            }
        }
        return false;
    }

    /*
     * Coloca mídia em camadas na sequência ativa (ou numa cópia dela).
     * opts (JSON URI-encoded): {
     *   target: 'active' | 'copy', copyName, bin,
     *   allowOverwrite: false,
     *   items: [{ file, track: 'V2'|'A3'|'auto-video'|'auto-audio', start, duration, in,
     *             name, fill: bool, srcW, srcH, scale, opacity, volumeDb, label }],
     *   markers: [{ time, name, comment, color }]
     * }
     */
    g.PPC_place = function (encOpts) {
        try {
            var o = eval('(' + decodeURIComponent(encOpts) + ')');
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta.');
            var original = seq.name;

            if (o.target === 'copy') {
                var before = {};
                for (var s0 = 0; s0 < app.project.sequences.numSequences; s0++) before[app.project.sequences[s0].sequenceID] = true;
                seq.clone();
                var copy = null;
                for (var s1 = 0; s1 < app.project.sequences.numSequences; s1++) {
                    if (!before[app.project.sequences[s1].sequenceID]) { copy = app.project.sequences[s1]; break; }
                }
                if (!copy) return fail('Não consegui duplicar a sequência.');
                copy.name = o.copyName || (original + ' - MONTADA');
                app.project.openSequence(copy.sequenceID);
                seq = app.project.activeSequence || copy;
            }

            var bin = PPC.bin(o.bin || 'Skills', true);
            var fr = Number(seq.timebase);
            var seqW = seq.frameSizeHorizontal, seqH = seq.frameSizeVertical;
            var placed = [], skipped = [];

            // Importa tudo de uma vez (o que ainda não estiver no projeto).
            var toImport = [], seen = {};
            for (var i = 0; i < o.items.length; i++) {
                var f = o.items[i].file;
                if (!f || seen[normPath(f)]) continue;
                seen[normPath(f)] = true;
                if (!itemByPath(f)) {
                    if (!new File(f).exists) { skipped.push({ file: f, reason: 'arquivo não existe' }); continue; }
                    toImport.push(f);
                }
            }
            if (toImport.length) app.project.importFiles(toImport, true, bin, false);

            for (var n = 0; n < o.items.length; n++) {
                var it = o.items[n];
                try {
                    var pi = itemByPath(it.file);
                    if (!pi) { skipped.push({ file: it.file, reason: 'não importou' }); continue; }
                    var a = Math.round(Number(it.start || 0) * TICKS / fr) * fr;
                    var dur = it.duration != null ? Number(it.duration) : null;
                    var b = dur != null ? a + Math.max(1, Math.round(dur * TICKS / fr)) * fr : null;
                    var spec = String(it.track || 'auto-video').toUpperCase();
                    var kind = spec.indexOf('A') === 0 || spec === 'AUTO-AUDIO' ? 'A' : 'V';
                    var idx = parseInt(spec.replace(/[^0-9]/g, ''), 10);
                    var auto = isNaN(idx);
                    if (auto) idx = kind === 'V' ? 2 : 2;

                    // Trecho da mídia: in/out na origem (vale para vídeo, áudio e imagem).
                    var srcIn = Number(it['in'] || 0);
                    try {
                        if (dur != null) {
                            pi.setInPoint(srcIn, 4);
                            pi.setOutPoint(srcIn + dur, 4);
                        } else if (srcIn) pi.setInPoint(srcIn, 4);
                    } catch (eIO) {}
                    var span = b != null ? b : a + fr; // sem duração: confere só o começo

                    // Acha a trilha: a pedida, ou a próxima livre acima (sem apagar o que já existe).
                    var coll, track, tries = 0;
                    while (true) {
                        coll = ensureTracks(seq, kind, idx);
                        track = coll[idx - 1];
                        var locked = false;
                        try { locked = track.isLocked(); } catch (eL) {}
                        if (!locked && (o.allowOverwrite || trackFree(track, a, span))) break;
                        if (!auto && o.allowOverwrite) break;
                        idx++;
                        if (++tries > 12) throw new Error('sem trilha livre');
                    }
                    track.overwriteClip(pi, a / TICKS);
                    try { pi.clearInPoint(); pi.clearOutPoint(); } catch (eC) {}

                    // O clipe recém-colocado é o que começa em a.
                    var clip = null;
                    for (var q = track.clips.numItems - 1; q >= 0; q--) {
                        if (Math.abs(Number(track.clips[q].start.ticks) - a) < fr / 2) { clip = track.clips[q]; break; }
                    }
                    if (clip) {
                        if (it.name) { try { clip.name = it.name; } catch (eNm) {} }
                        if (kind === 'V') {
                            var sc = it.scale != null ? Number(it.scale) : null;
                            if (sc == null && it.fill && it.srcW && it.srcH) sc = Math.max(seqW / it.srcW, seqH / it.srcH) * 100;
                            if (sc != null) setProp(clip, ['Movimento', 'Motion', 'AE.ADBE Motion'], ['Escala', 'Scale'], sc);
                            if (it.opacity != null) setProp(clip, ['Opacidade', 'Opacity', 'AE.ADBE Opacity'], ['Opacidade', 'Opacity'], Number(it.opacity));
                        } else if (it.volumeDb != null) {
                            setProp(clip, ['Volume', 'Audio Levels', 'ADBE Audio Levels'], ['Nível', 'Level', 'Nivel'], levelFromDb(Number(it.volumeDb)));
                        }
                        if (it.label != null) { try { clip.projectItem.setColorLabel(Number(it.label)); } catch (eLb) {} }
                    }
                    placed.push({ file: String(it.file).split(/[\\\/]/).pop(), track: kind + idx, start: r3(a / TICKS), end: clip ? secs(clip.end) : null });
                } catch (eItem) {
                    skipped.push({ file: it.file, reason: String(eItem.message || eItem) });
                }
            }

            var mk = 0;
            for (var z = 0; o.markers && z < o.markers.length; z++) {
                try {
                    var mm = seq.markers.createMarker(Number(o.markers[z].time));
                    if (o.markers[z].name) mm.name = o.markers[z].name;
                    if (o.markers[z].comment) mm.comments = o.markers[z].comment;
                    if (o.markers[z].end != null) mm.end = Number(o.markers[z].end);
                    if (o.markers[z].color != null) { try { mm.setColorByIndex(Number(o.markers[z].color)); } catch (eMc) {} }
                    mk++;
                } catch (eM) {}
            }
            return ok({ sequence: seq.name, original: original, bin: bin.name, placed: placed, skipped: skipped, markers: mk });
        } catch (e) { return fail(e); }
    };

    // Importa um XML do Premiere/Final Cut (vira sequência nova) e abre a sequência criada.
    g.PPC_importXml = function (encPath, encBin) {
        try {
            var p = decodeURIComponent(encPath);
            if (!new File(p).exists) return fail('XML não encontrado: ' + p);
            var before = {};
            for (var s0 = 0; s0 < app.project.sequences.numSequences; s0++) before[app.project.sequences[s0].sequenceID] = true;
            var bin = PPC.bin(decodeURIComponent(encBin) || 'Skills', true);
            app.project.importFiles([p], true, bin, false);
            var created = [];
            for (var s1 = 0; s1 < app.project.sequences.numSequences; s1++) {
                var sq = app.project.sequences[s1];
                if (!before[sq.sequenceID]) created.push(sq);
            }
            if (created.length) app.project.openSequence(created[created.length - 1].sequenceID);
            var names = [];
            for (var k = 0; k < created.length; k++) names.push(created[k].name);
            return ok({ sequences: names, bin: bin.name });
        } catch (e) { return fail(e); }
    };

    // Importa um .srt e cria uma trilha de legenda na sequência ativa.
    g.PPC_createCaptions = function (encSrtPath, encBinName, startSeconds) {
        try {
            var seq = app.project.activeSequence;
            if (!seq) return fail('Nenhuma sequência aberta.');
            var srtPath = decodeURIComponent(encSrtPath);
            var bin = PPC.bin(decodeURIComponent(encBinName) || 'Legendas', true);
            app.project.importFiles([srtPath], true, bin, false);
            var target = null;
            var norm = function (s) { return String(s).replace(/\\/g, '/').toLowerCase(); };
            for (var i = bin.children.numItems - 1; i >= 0; i--) {
                var it = bin.children[i];
                try { if (norm(it.getMediaPath()) === norm(srtPath)) { target = it; break; } } catch (e) {}
            }
            if (!target) return fail('O arquivo de legenda não foi importado: ' + srtPath);
            var fmt = (typeof Sequence !== 'undefined' && Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) ? Sequence.CAPTION_FORMAT_SUBTITLE : undefined;
            var created = fmt === undefined
                ? seq.createCaptionTrack(target, Number(startSeconds) || 0)
                : seq.createCaptionTrack(target, Number(startSeconds) || 0, fmt);
            return ok({ imported: target.name, bin: bin.name, captionTrackCreated: created !== false, sequence: seq.name });
        } catch (e) { return fail(e); }
    };
})();
