/* Premiere Chat — interface do painel. Usa ClaudeBridge, LocalTools e o host.jsx. */
(function () {
  "use strict";

  const Bridge = window.ClaudeBridge; // também sobe o servidor MCP local, usado pelos dois cérebros
  const GptBridge = window.CodexBridge;
  // Duas contas (Claude pelo Claude Code e ChatGPT pelo Codex), cada uma com sua chave em ⚙.
  // settings.engine = a que vai primeiro; se ela estiver desligada, sem login ou no limite, vai a outra.
  const acct = {
    claude: { exe: null, loggedIn: null },
    gpt: { exe: null, loggedIn: null },
  };
  const limitedUntil = { claude: 0, gpt: 0 };
  const LIMIT_PAUSE = 60 * 60000; // conta que bateu no limite descansa 1 h antes de ser tentada de novo
  const otherEngine = (e) => (e === "gpt" ? "claude" : "gpt");
  const engineOn = (e) => (e === "gpt" ? settings.useGpt === true : settings.useClaude !== false);
  const engineReady = (e) => engineOn(e) && acct[e].loggedIn !== false && Date.now() >= limitedUntil[e];
  function engine() {
    const pref = settings.engine === "gpt" ? "gpt" : "claude";
    if (engineReady(pref)) return pref;
    if (engineReady(otherEngine(pref))) return otherEngine(pref);
    if (engineOn(pref)) return pref;
    return engineOn(otherEngine(pref)) ? otherEngine(pref) : pref;
  }
  const bridgeOf = (e) => (e === "gpt" ? GptBridge : Bridge);
  const nameOf = (e) => (e === "gpt" ? "ChatGPT" : "Claude");
  const engineName = () => nameOf(engine());
  const isLimitError = (msg) => /usage limit|hit your (usage )?limit|limit (reached|exceeded)|rate.?limit|usage_limit|quota|too many requests|\b429\b|limite de uso|5-hour limit|weekly limit|out of (credits|usage)/i.test(String(msg || ""));
  const Local = window.LocalTools;
  const CEP = window.__adobe_cep__;
  const IN_PPRO = typeof CEP !== "undefined";

  // ------------------------------------------------------------ Premiere (ExtendScript)

  function evalScript(script) {
    return new Promise((resolve) => {
      if (!IN_PPRO) {
        resolve(JSON.stringify({ ok: true, result: "(prévia fora do Premiere — nada foi executado)" }));
        return;
      }
      CEP.evalScript(script, (res) => resolve(res));
    });
  }

  function parseHostResult(raw) {
    if (raw === "EvalScript error." || raw == null || raw === "") {
      return { ok: false, error: "O script do host (host.jsx) não respondeu. Feche e reabra o painel." };
    }
    try {
      return JSON.parse(raw);
    } catch {
      return { ok: true, result: String(raw) };
    }
  }

  const enc = (s) => JSON.stringify(encodeURIComponent(String(s == null ? "" : s)));

  async function host(fn, ...args) {
    return parseHostResult(await evalScript(`${fn}(${args.join(",")})`));
  }

  const runInPremiere = (code) => host("PPC_run", enc(code));

  async function getProjectState() {
    if (!IN_PPRO) return { ok: true, result: { preview: true } };
    return host("PPC_context");
  }

  // O CEP devolve caminhos como endereço ("file:///C:/Program%20Files/..."): vira caminho normal do Windows.
  function cepPath(type) {
    try {
      let p = decodeURI(String(CEP.getSystemPath(type) || ""));
      // "file:/C:/...", "file:///C:/..." ou "file://localhost/C:/..." -> "C:/..."
      p = p.replace(/^file:(\/\/localhost)?[\\/]*/i, "");
      if (/^\/[A-Za-z]:[\\/]/.test(p)) p = p.slice(1);
      return p ? require("path").normalize(p) : null;
    } catch {
      return null;
    }
  }

  // Pasta do painel: pelo CEP ou, se falhar, pelo endereço do próprio index.html.
  // Só vale um caminho de disco de verdade (C:\...) onde o painel está mesmo instalado.
  let extDirCache = null;
  function extensionDir() {
    if (extDirCache) return extDirCache;
    const fs = require("fs");
    const path = require("path");
    const ok = (d) => !!d && /^[A-Za-z]:[\\/]/.test(d) && fs.existsSync(path.join(d, "js", "main.js"));
    const cands = [cepPath("extension")];
    try {
      const u = decodeURIComponent(new URL(location.href).pathname).replace(/^\/([A-Za-z]:)/, "$1");
      cands.push(path.dirname(path.normalize(u)));
    } catch {}
    if (process.env.APPDATA) cands.push(path.join(process.env.APPDATA, "Adobe", "CEP", "extensions", "com.premierechat.claude"));
    extDirCache = cands.find(ok) || null;
    return extDirCache;
  }

  function hostAppPath() {
    try {
      return cepPath("hostApplication");
    } catch {
      return null;
    }
  }

  // ------------------------------------------------------------ configurações

  const SETTINGS_KEY = "premierechat.settings";
  const DEFAULTS = {
    engine: "claude",
    model: "auto",
    effort: "",
    claudePath: "",
    gptPath: "",
    gptModel: "auto",
    showCode: false,
    backup: true,
    asrModel: "onnx-community/whisper-small_timestamped",
    asrLanguage: "portuguese",
    allowSkills: true,
    writeRoots: "",
    voiceMic: "",
    voiceAutoSend: true,
    voiceAutoStop: true,
    voiceReply: "voice",
    voiceName: "",
    voiceRate: 0,
    voiceConvo: false,
    voiceEnabled: true,
    voiceGreet: "always",
    voiceFx: "nenhum",
    voiceEmo: 0.4,
    voiceRef: "",
    useClaude: true,
    useGpt: false,
    autoSwitch: true,
    soundEnabled: true,
    soundVolume: 40,
    insertsDir: "",
    insertsAsked: false,
  };

  function loadSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
      // Uma vez só: quem estava no "Padrão da conta" passa para o Automático.
      if (!saved.modelRouterMigrated) {
        if (!saved.model) saved.model = "auto";
        saved.modelRouterMigrated = true;
      }
      // Uma vez só: ao abrir um projeto, sempre oferecer retomar ou perguntar o que vamos editar.
      // Microfone só no clique: desliga o "modo conversa" que vinha ligado (dá para religar em ⚙).
  if (!saved.voiceMicManualMigrated) {
    saved.voiceConvo = false;
    saved.voiceMicManualMigrated = true;
  }
  if (!saved.voiceGreetMigrated) {
        if (!saved.voiceGreet || saved.voiceGreet === "first") saved.voiceGreet = "always";
        saved.voiceGreetMigrated = true;
      }
      // Uma vez só: a voz aprovada (natural pt-BR, sem efeito) vira a padrão, se estiver instalada.
      if (!saved.voiceNaturalMigrated && window.NaturalVoice && window.NaturalVoice.isInstalled()) {
        saved.voiceName = "natural";
        saved.voiceFx = "nenhum";
        saved.voiceNaturalMigrated = true;
      }
      // Uma vez só (1.15): o "cérebro" virou duas contas com chave. Quem usava o ChatGPT continua com ele ligado.
      if (!saved.dualAccountMigrated) {
        if (saved.engine === "gpt") saved.useGpt = true;
        saved.dualAccountMigrated = true;
      }
      return { ...DEFAULTS, ...saved };
    } catch {
      return { ...DEFAULTS };
    }
  }

  function saveSettings(s) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
    } catch {
      /* sem armazenamento: fica só em memória */
    }
  }

  let settings = loadSettings();
  // Quem só tem o ChatGPT instalado (sem Claude Code) já começa com o cérebro ChatGPT.
  try {
    if (!settings.engineChosen && window.ClaudeBridge && window.CodexBridge && !window.ClaudeBridge.findClaude(settings.claudePath) && window.CodexBridge.findExe(settings.gptPath)) {
      settings.engine = "gpt";
      settings.useGpt = true;
    }
    // ChatGPT já conectado neste PC: a conta fica disponível como segunda opção (a chave começa ligada).
    if (!settings.gptAutoEnabled && window.CodexBridge && window.CodexBridge.findExe(settings.gptPath)) {
      settings.useGpt = true;
      settings.gptAutoEnabled = true;
      saveSettings(settings);
    }
  } catch {}

  // ------------------------------------------------------------ prompt

  const SYSTEM_PROMPT = `You are Premiere Chat, an assistant embedded as a panel inside Adobe Premiere Pro. The user types requests in natural language (usually Brazilian Portuguese) and you carry them out directly in their open project, using the Premiere tools you have. Reply in the user's language, briefly: say what you did and anything they must do by hand, not how the code works. You have no terminal: everything goes through the tools listed here.

Attachments: the user can attach files to a message (copy/roteiro, briefing, reference images, screenshots, PDFs, Word documents, SRTs, media). They arrive in the message as <anexo nome tipo caminho> blocks followed by their content: images and PDFs you see directly; DOCX arrives as text with formatting marks (**bold**, ==highlight==, ~~strike~~, {cor #RRGGBB: colored text}) and its embedded images; media files come as paths only. Attachments stay in the conversation, so later messages can refer to them. The caminho (path) is a real file on disk: use it to import an attached image or video into the project. To read a document that was not attached (e.g. a copy in the project folder), use read_document.

How to work:
- Each user message comes with a <premiere_state> snapshot: project path, bin tree (with item names and kinds), sequences, and the active sequence's tracks, clips, playhead and selection. Use it to target the right things. Call get_project_state for a fresh snapshot after changes.
- Do most work with run_extendscript. Split big jobs into a few logical steps and check results. If a script fails, read the error, check the current state (earlier lines may already have run), fix and retry.
- Premiere's ExtendScript has no undo grouping: every change is a separate history step. The panel saves a backup copy of the project before each request (when enabled in settings), so mention it if the user wants to revert a big change ("há um backup em ~/.premiere-chat/backups").
- Pick sensible professional defaults instead of asking. Ask only when you truly cannot proceed.
- Never delete media, clips, sequences or bins unless the user explicitly asks. Do not save, close or open projects unless asked (the panel handles backups). Do not render/export video unless asked.

Editing skills (the user's video-editing skills in ~/.claude/skills):
- You can load any of them with the Skill tool (client skills such as impetus-upsell-*, leads-dopaminergica; motion/caption tools such as motion-director, claude-video-studio, remotion-*, hyperframes:*). When the request matches a skill's description, load it and FOLLOW it, just as Claude Code would. A <skill> block attached to the message means the user picked that skill: follow it.
- Creating or rewriting a whole skill: you cannot write in ~/.claude/skills, so write it to ~/.premiere-chat/skills-novas/<skill-id>/ (SKILL.md, references/, scripts/). After your reply the panel installs it in ~/.claude/skills by itself and adds it to clientes.json under the client whose skills share its name prefix (impetus-...). Tell the user it was installed; never ask them to copy folders. Use ~/.claude/skills/<id>/... (not C:/Users/<name>) for paths inside the skill.
- For a NEW client video, first follow the novo-projeto-edicao skill (pasta mãe, subpastas, material, which skill), as the user's global rules require. Client = the folder right after "Clientes" in the project path.
- The skills were written for a terminal. Here, map each step to the panel's tools:
  - "run python/$PY/node/npx/ffmpeg ..." -> run_command with program + args list (no shell; one program per call; no pipes, redirects or &&). $PY and the skill's python = program "python" (editing runtime). "py"/system python only if the skill says so. Use the skill's folder paths for its scripts (e.g. <user home>/.claude/skills/<id>/scripts/x.py; forward slashes work on Windows).
  - reading files and images -> Read / Glob / Grep (read-only, anywhere).
  - creating/editing text files (projeto.json, roteiro.json, planos, HTML compositions) -> write_text_file; folders -> make_folders; media into the project folders -> copy_file. Writing works only in the allowed folders (project folder and up to two above it, the Clientes folders, ~/.premiere-chat, temp, plus the user's extra folders); if a write is refused, tell the user which folder to allow in ⚙.
  - "show a test print and wait for approval" -> render/extract the stills, then show_images with ask_approval true; continue on approval, apply the requested adjustment otherwise. Don't render the full video before approval.
- Long steps (renders, transcription, matting) can take many minutes: give run_command a clear Portuguese description; the user sees the live output. If it returns "still running", call job_status to keep waiting. If the user stops the request, every job is cancelled.
- Never use paid services or APIs (e.g. Higgsfield in claude-video-studio, paid stock, HyperFrames cloud/lambda/cloudrun/publish/tts, Remotion Lambda); stay with local, free tools as the skills say. The panel also refuses these commands and strips paid-service API keys from the scripts' environment; if a skill step needs one, skip it and use the local alternative (local render, no AI voice).
- Motion engine: HyperFrames is the default for every motion, lower third, caption, overlay and transition (it is what the client skills, motion-director and claude-video-studio use). Use Remotion (remotion-* skills) ONLY when the user explicitly asks for Remotion, or for a specific transition/effect HyperFrames cannot do — and say so in one line. Never mix both engines in one deliverable without a reason. (Remotion is free only for individuals or companies of up to 3 people.)
- ONE-COMMAND EDITING ("a mágica"): when the user asks to edit a video from start to finish (e.g. "edita no padrão do cliente", "faz a lead dopaminérgica", the ✨ chip), run the whole pipeline yourself with as few questions as possible:
  1. show_plan with the steps you will run (e.g. Entender o projeto · Decupar · Preparar o vídeo · Transcrever · Planejar (skill) · Prints para aprovar · Gerar motions/legendas · Montar na timeline · Conferir). Update it as you go (done = steps finished, note = live status).
  2. Client and skill: client = folder after "Clientes" in the project path; pick that client's default skill from novo-projeto-edicao/clientes.json (or the one the user named). Follow novo-projeto-edicao, but derive the pasta mãe from the project location and create the subfolders yourself; ask only if the client or the skill is truly ambiguous, or a folder the skill needs (Musicas, SFX, Inserts) is empty — then say what's missing and continue without it if the skill allows.
  3. Decupagem: if the skill expects an already decupado video and the timeline still has long pauses, run remove_silences (preset auto, mode ripple, new_sequence true) first; skip if the user said it is already decupado.
  4. export_sequence_video to get the video file (into <pasta mãe>/Brutas), then follow the skill's steps with run_command / write_text_file.
  5. Approval: show_images with ask_approval for the test prints the skill asks for. This is the only stop; everything else runs on its own.
  6. Generate the layers (motions/LTs/legendas as transparent overlays when possible), then deliver with place_on_timeline (or import_premiere_xml) on a copy of the sequence, with markers per block.
  7. Check: view_frame at 2-4 key moments of the new sequence; fix obvious problems. Finish with a short report (what was done, where, what's left for the user, time spent).
- Deliver INSIDE Premiere, as editable layers, never only a path (the user's rule: always an editable Premiere delivery):
  - If the skill exported a Premiere/FCP XML, import it with import_premiere_xml.
  - Otherwise use place_on_timeline: one item per layer, in sequence seconds — B-roll/inserts and images (fill true) on V2+, transparent overlays (lower thirds, motions, captions rendered with alpha, transitions) on the tracks above them, music on its own audio track with volume_db around -18 to -22 under speech, SFX on the next audio track at the exact cue. Prefer rendering motions as separate transparent overlays (one file per motion) over burning everything into one MP4, so the user can move and trim each one. A fully rendered final MP4 goes in as its own item only when the skill renders the whole video, and then on a new track/sequence, never over the original footage.
  - Default target "copy" (new sequence "<nome> - MONTADA"); use "active" only if the user asks or you are continuing a sequence you built. Add markers for the blocks/cues when they help navigation.
  - Report what went where (track, time) and anything skipped.

Organizing the project (e.g. "arrume as pastas"):
- Look at the tree first. Create clear bins and move items by kind (PPC.kind): e.g. "01 Sequências", "02 Vídeos", "03 Áudios" (split "Música"/"Efeitos sonoros"/"Locução" when names make it obvious), "04 Imagens", "05 Gráficos", "06 Legendas", "07 Outros". Adapt to what the project actually has; skip empty categories. Keep bins the user clearly organized themselves unless asked to reorganize everything. Report what moved where (counts).

Captions / subtitles (e.g. "ajuste a legenda corrigindo os erros com base no vídeo"):
- Premiere's scripting API cannot read, edit or delete existing caption text. So the workflow is: build a corrected SRT and add it as a NEW caption track; then tell the user to disable or delete the old caption track by hand.
- Source of truth for what is said: call transcribe_sequence (exports the active sequence's audio and transcribes it locally with Whisper; timestamps are in sequence time, with word timings).
- If the existing captions came from an .srt in the project (a project item of kind "caption"), read it with read_text_file (path from item.getMediaPath()) and use it as the base, fixing text against the transcription. If the user exported their captions to a file, read that path. Otherwise base the captions on the transcription.
- Correct spelling, accents, punctuation, capitalization, proper names and brand names, repeated or missing words, while keeping what was actually said. When names or terms are uncertain, use view_frame to look at frames (on-screen text, logos) and the project item names for hints.
- Segmenting: 1–2 lines per caption, up to ~42 characters per line for horizontal video and ~28 for vertical (9:16); 0.8–7 s each; split at natural pauses using the word timings; no overlaps; captions shouldn't flash by faster than ~15 characters per second.
- Then call create_caption_track with the full SRT. It saves the file next to the project, imports it into the "Legendas" bin and adds a caption track to the active sequence.

Feeding the client skill (learning while editing):
- When working in a client's standard (a <skill> block was attached, or the project is under G:\Clientes\<cliente> and that client has a skill), watch for lasting preferences: the user corrects your result in a way that should apply to every future video ("sempre", "nunca", "o padrão é", "daqui pra frente"), approves a new look after iterations, or asks "salva isso na skill" / "anota na skill".
- One-off fixes for this video only are NOT recorded. If you can't tell whether it's a rule or a one-off, ask in one short question before proposing.
- To record: read the skill's references/historico-ajustes.md and/or references/estilo-aprovado.md with read_document (paths are in the <skill> block's file list, or <user home>\.claude\skills\<id>\references\), then call update_skill with a minimal, precise change in the file's own format and language (Portuguese): exact values in estilo, the request and the decision in historico (new table row when it has a table). The panel shows the change and the user approves or refuses it; respect a refusal.
- Never put project-specific facts (one video's times, file names) in the skill, only the reusable rule and why.

Editing from a copy / roteiro (the user attaches the video's copy and asks to edit "com base na copy"):
1. Read the copy closely and build a plan for yourself: the ordered list of blocks (gancho, desenvolvimento, CTA etc.), the exact lines to be spoken, and every editing instruction in it — inserts/B-roll ("INSERT:", "[B-ROLL]", "(tela de ...)", "mostrar ...", text in a different color, highlight or a side column/table), on-screen text, emphasis words, music/SFX notes, cuts. Copies often mark directions with color, highlight, brackets, parentheses, CAPS or a two-column table (fala | visual): treat those as instructions, not lines to be spoken. If something is ambiguous, pick the most reasonable reading and say so in the report.
2. Map the copy onto the footage: call transcribe_sequence (whole active sequence) and align each copy line to the spoken words by meaning, not exact wording. When the timeline holds raw takes (repeated lines, mistakes, restarts), the copy tells you which lines belong in the final cut; prefer the last complete, clean take of each line.
3. Structure ("monte a estrutura", "corte pela copy"): before changing an existing sequence, clone it (seq.clone()), rename the clone "<nome> - antes da copy" and keep editing the original, so the user can compare. Put the blocks in copy order and cut out what the copy doesn't use (bad takes, restarts, long silences) with QE razor + clip.remove(true, true) (ripple), working from the END of the timeline backwards so earlier times stay valid; re-read the state after each batch. If the user would rather build from raw clips, set source in/out on the project item (projectItem.setInPoint(seconds, 4) / setOutPoint(seconds, 4), 4 = all media types), place it with track.overwriteClip(projectItem, seconds) one after the other, then projectItem.clearInPoint()/clearOutPoint(). Add one sequence marker per copy block named after the block, so the user can navigate.
4. Inserts: for each insert in the copy, find the media: an attached file (import it from its caminho), a project item whose name matches (look at the bin tree; match loosely, e.g. "print site" ~ "Print do site.png"), or a file the user names. Place it on the lowest free video track above the talking head (V2, V3…; never overwrite clips already there), starting when the cue phrase is spoken (word timings from the transcription) and lasting until the copy says, the end of that sentence, or ~2–4 s. Images: scale to fill the frame (Motion > Scale) unless the copy says otherwise. If no free track exists, add one: app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0) and verify. Insert media you cannot find: put a red-labelled marker at that spot named "INSERT FALTANDO: <descrição>" instead of guessing.
5. Captions per the copy: timing from the transcription, wording from what was actually said, but spelling, names, brands, numbers and punctuation from the copy (the copy is the source of truth for how words are written). If the speaker clearly deviated from the copy, caption what was said unless the user asks for the copy's wording. Then create_caption_track as usual.
6. Finish with a short report: blocks and where they start (mm:ss), inserts placed (name → time, track), inserts missing, cuts made, and anything you assumed.

ExtendScript rules (ES3 engine):
- No let/const, arrow functions, template literals, classes, destructuring, default params, Array.forEach/map/filter/indexOf, Object.keys or JSON. Use var, for loops and string concatenation.
- The value of the last expression is returned to you; end scripts with a short summary string or PPC.stringify(data).
- Never use alert(), confirm(), prompt() or any modal dialog; they freeze Premiere.
- Premiere collections are 0-based: app.project.rootItem.children[0], seq.videoTracks[0] (V1), track.clips[0]. Use .numItems / .numTracks / .numSequences for lengths.
- Times: Time objects have .seconds and .ticks (254016000000 ticks per second). Many setters take seconds or ticks strings; PPC.time(s) and PPC.ticks(s) help.
- Premiere may run in Portuguese: effect and component display names can be localized. List them first (displayName/matchName) instead of guessing English names.

Helpers already loaded (global PPC):
- PPC.seq() -> active Sequence or null.
- PPC.kind(item) -> 'bin' | 'sequence' | 'video' | 'audio' | 'image' | 'graphic' | 'caption' | 'synthetic' | 'other'.
- PPC.walk(function (item, parentBin, path) { ... return true to stop; }) -> visits every project item recursively.
- PPC.bin("Mídia/Vídeos", true) -> bin by path (creates missing bins when true), or null.
- PPC.find(name) -> first project item with that name.
- PPC.clips(seq) -> [{ track: 'V1', type: 'video'|'audio', trackIndex, index, clip }] for every clip in the sequence.
- PPC.time(seconds) -> Time; PPC.ticks(seconds) -> ticks string; PPC.stringify(value) -> JSON string.

Useful API reminders:
- Project items: item.name (read/write), item.type (ProjectItemType.CLIP, BIN, ROOT, FILE), item.moveBin(targetBin), bin.createBin(name), item.getMediaPath(), item.isSequence(), item.setColorLabel(0-15), item.getColorLabel(), item.select(), item.isOffline(). Collect items into an array before moving them (moving changes the children collections while you iterate).
- Import: PPC.importFiles([path1, path2], targetBin) (never app.project.importFiles directly: the panel blocks it). MOGRT: PPC.importMGT(path, seconds, videoTrackIndex, audioTrackIndex). Files outside the project folder need request_import_approval first.
- Sequences: app.project.sequences[i], app.project.openSequence(seq.sequenceID), app.project.activeSequence = seq, app.project.createNewSequenceFromClips(name, [projectItems], targetBin), seq.getPlayerPosition(), seq.setPlayerPosition(ticksString), seq.getInPoint()/getOutPoint() (seconds strings), seq.setInPoint(seconds)/setOutPoint(seconds), seq.end (ticks string), seq.getSelection(), seq.getSettings()/setSettings(s), seq.frameSizeHorizontal/frameSizeVertical, seq.clone().
- Tracks: seq.videoTracks[i] / seq.audioTracks[i]; track.name, track.clips, track.isMuted()/setMute(1), track.isLocked()/setLocked(1), track.insertClip(projectItem, seconds), track.overwriteClip(projectItem, seconds).
- Clips (TrackItem): clip.name, clip.start/end/inPoint/outPoint/duration (Time), clip.start = PPC.time(s), clip.end = PPC.time(s), clip.projectItem, clip.isSelected(), clip.setSelected(true, true), clip.disabled, clip.remove(rippleBool, alignBool), clip.getSpeed(), clip.isAdjustmentLayer(), clip.components[i].displayName / .matchName and .properties[j].displayName with getValue()/setValue(v, true) (e.g. Motion > Scale/Position, Opacity, audio Volume > Level).
- Markers: var m = seq.markers.createMarker(seconds); m.name = "..."; m.comments = "..."; m.end = PPC.time(seconds2); seq.markers.numMarkers; seq.markers.getFirstMarker()/getNextMarker(m).
- QE DOM (unofficial, for things the main API lacks): app.enableQE(); var qs = qe.project.getActiveSequence(); qs.getVideoTrackAt(0).razor(timecode) / qs.getAudioTrackAt(0).razor(timecode) cut at a timecode string from qs.CTI.timecode format; qs.getVideoTrackAt(t).getItemAt(i) returns QE clips (addVideoEffect(qe.project.getVideoEffectByName(name)), setSpeed(...)); qe.project.getVideoEffectList() / getAudioEffectList() list names. Verify results after QE calls.`;

  // ------------------------------------------------------------ interface

  const $ = (id) => document.getElementById(id);
  const chatRoot = $("chat"); // área com rolagem; cada aba tem o seu painel dentro dela
  const inputEl = $("input");
  const sendBtn = $("btn-send");

  // Painel que recebe as mensagens agora (o da aba do pedido em andamento, ou a aba aberta).
  let chatEl = null;
  // Aba cujo histórico recebe as mensagens; `replaying` desliga o registro ao redesenhar.
  let logTab = null;
  let replaying = false;

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }

  function renderMarkdown(src) {
    return src
      .split(/```[a-zA-Z]*\n?/)
      .map((part, i) => {
        if (i % 2 === 1) return `<pre><code>${escapeHtml(part.replace(/\n$/, ""))}</code></pre>`;
        return part
          .split(/\n{2,}/)
          .filter((p) => p.trim())
          .map((p) => {
            let h = escapeHtml(p.trim())
              .replace(/`([^`]+)`/g, "<code>$1</code>")
              .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
            h = h.replace(/^#{1,4} (.*)$/gm, "<strong>$1</strong>");
            h = h.replace(/^[-*] /gm, "• ").replace(/\n/g, "<br>");
            return `<p>${h}</p>`;
          })
          .join("");
      })
      .join("");
  }

  // Registra uma entrada no histórico da aba (e agenda a gravação no disco).
  function logEntry(entry) {
    if (replaying || !logTab) return null;
    logTab.log.push(entry);
    scheduleSave(logTab);
    return entry;
  }

  const scrollDown = () => {
    if (!replaying && activeTab && chatEl === activeTab.pane) chatRoot.scrollTop = chatRoot.scrollHeight;
  };

  function hideEmpty() {
    const e = chatEl && chatEl.querySelector(".empty");
    if (e) e.remove();
  }

  function addUserBubble(text, atts) {
    hideEmpty();
    const names = (atts || []).map((a) => a.name);
    logEntry({ t: "u", text, atts: names });
    const el = document.createElement("div");
    el.className = "msg user";
    if (names.length) {
      const box = document.createElement("div");
      box.className = "atts";
      for (const n of names) {
        const s = document.createElement("span");
        s.textContent = attIcon(n) + " " + n;
        box.appendChild(s);
      }
      el.appendChild(box);
    }
    el.appendChild(document.createTextNode(text));
    chatEl.appendChild(el);
    scrollDown();
  }

  let typingEl = null;
  function showTyping() {
    hideTyping();
    typingEl = document.createElement("div");
    typingEl.className = "msg assistant";
    typingEl.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
    chatEl.appendChild(typingEl);
    scrollDown();
  }
  function hideTyping() {
    if (typingEl) typingEl.remove();
    typingEl = null;
  }

  let bubble = null; // bolha de texto atual do assistente
  function newAssistantBubble() {
    hideTyping();
    const el = document.createElement("div");
    el.className = "msg assistant";
    chatEl.appendChild(el);
    bubble = { el, text: "", entry: logEntry({ t: "a", text: "" }), tab: logTab };
  }
  function appendAssistant(delta) {
    if (!bubble) newAssistantBubble();
    bubble.text += delta;
    bubble.el.innerHTML = renderMarkdown(bubble.text);
    if (bubble.entry) {
      bubble.entry.text = bubble.text;
      scheduleSave(bubble.tab);
    }
    scrollDown();
  }

  function addStep(label, code) {
    hideTyping();
    bubble = null;
    const entry = logEntry({ t: "s", label, code: code || "", ok: null, out: "" });
    const tab = logTab;
    const det = document.createElement("details");
    det.className = "step running";
    if (settings.showCode && code) det.open = true;
    det.innerHTML = '<summary><span class="badge">⏳</span><span class="label"></span></summary>';
    const labelEl = det.querySelector(".label");
    labelEl.textContent = label;
    if (code) {
      const pre = document.createElement("pre");
      pre.textContent = code;
      det.appendChild(pre);
    }
    chatEl.appendChild(det);
    scrollDown();
    return {
      update(text) {
        labelEl.textContent = label + " — " + text;
      },
      done(ok, output) {
        output = output && output.length > 4000 ? output.slice(0, 4000) + "…" : output || "";
        if (entry) {
          entry.ok = !!ok;
          entry.out = output;
          scheduleSave(tab);
        }
        labelEl.textContent = label;
        det.className = "step " + (ok ? "ok" : "fail");
        det.querySelector(".badge").textContent = ok ? "✓" : "✗";
        if (output) {
          const out = document.createElement("pre");
          out.className = "out";
          out.textContent = output;
          det.appendChild(out);
        }
        if (!ok && !replaying) det.open = true;
        scrollDown();
        if (busy && !replaying) showTyping();
      },
    };
  }

  function addNote(text) {
    hideTyping();
    logEntry({ t: "n", text });
    const el = document.createElement("div");
    el.className = "note";
    el.textContent = text;
    chatEl.appendChild(el);
    scrollDown();
  }

  function addError(text) {
    hideTyping();
    logEntry({ t: "e", text });
    const el = document.createElement("div");
    el.className = "msg error";
    el.textContent = text;
    chatEl.appendChild(el);
    scrollDown();
  }

  // ------------------------------------------------------------ aprovação do usuário

  const pendingApprovals = new Set();

  // Cartão com Aprovar/Recusar dentro do chat. Resolve true/false quando o usuário clica.
  function askApproval(title, detail, yesLabel) {
    hideTyping();
    bubble = null;
    const entry = logEntry({ t: "ap", title, detail, result: null });
    const tab = logTab;
    const el = document.createElement("div");
    el.className = "approval";
    el.innerHTML = '<div class="ap-title"></div><pre class="ap-detail"></pre><div class="ap-actions"><button class="primary ap-yes"></button><button class="secondary ap-no">Recusar</button></div>';
    el.querySelector(".ap-title").textContent = title;
    el.querySelector(".ap-detail").textContent = detail;
    el.querySelector(".ap-yes").textContent = yesLabel || "Aprovar e gravar";
    chatEl.appendChild(el);
    scrollDown();
    return new Promise((resolve) => {
      const finish = (ok) => {
        pendingApprovals.delete(finish);
        el.querySelector(".ap-actions").innerHTML = `<span class="ap-result ${ok ? "ok" : "no"}">${ok ? "✓ Aprovado" : "✗ Recusado"}</span>`;
        if (entry) {
          entry.result = ok;
          scheduleSave(tab);
        }
        if (busy) showTyping();
        resolve(ok);
      };
      pendingApprovals.add(finish);
      el.querySelector(".ap-yes").addEventListener("click", () => finish(true));
      el.querySelector(".ap-no").addEventListener("click", () => finish(false));
    });
  }

  // Histórico: cartão já respondido (ou que ficou sem resposta).
  function replayApproval(e) {
    const el = document.createElement("div");
    el.className = "approval";
    el.innerHTML = '<div class="ap-title"></div><pre class="ap-detail"></pre><div class="ap-actions"></div>';
    el.querySelector(".ap-title").textContent = e.title;
    el.querySelector(".ap-detail").textContent = e.detail;
    const r = e.result === true ? ["ok", "✓ Aprovado"] : e.result === false ? ["no", "✗ Recusado"] : ["no", "Sem resposta"];
    el.querySelector(".ap-actions").innerHTML = `<span class="ap-result ${r[0]}">${r[1]}</span>`;
    chatEl.appendChild(el);
  }

  // ------------------------------------------------------------ ferramentas para o Claude

  const fmt2 = (n) => Number(n).toFixed(2);

  // Formato compacto: uma linha por frase e as palavras com o tempo de início.
  function formatTranscript(t) {
    const lines = [`Duração do áudio: ${fmt2(t.duration)} s · modelo ${t.model} · arquivo completo: ${t.file}`];
    const words = t.words || [];
    let wi = 0;
    t.segments.forEach((s, i) => {
      lines.push(`#${i + 1} [${fmt2(s.start)}–${fmt2(s.end)}] ${s.text}`);
      if (words.length) {
        const ws = [];
        while (wi < words.length && words[wi].start < s.end - 0.001) {
          ws.push(`${fmt2(words[wi].start)} ${words[wi].text}`);
          wi++;
        }
        if (ws.length) lines.push("   palavras: " + ws.join(" | "));
      }
    });
    if (!t.segments.length) lines.push("(nenhuma fala detectada)");
    return lines.join("\n");
  }

  const TOOLS = [
    {
      name: "run_extendscript",
      description:
        "Run ExtendScript (ES3) inside Premiere Pro. Returns the value of the last expression, or the error message and line number.",
      inputSchema: {
        type: "object",
        properties: {
          description: {
            type: "string",
            description: "Short label shown to the user, in their language (e.g. 'Criando as pastas').",
          },
          code: { type: "string", description: "ExtendScript source to execute." },
        },
        required: ["description", "code"],
      },
      async handler(args) {
        if (typeof args.code !== "string" || !args.code.trim()) {
          return { text: "Parâmetro 'code' vazio ou inválido.", isError: true };
        }
        const raw = rawImportCalls(args.code);
        if (raw.length) {
          return {
            text: "Bloqueado pelo painel: para importar use PPC.importFiles(paths, bin) ou PPC.importMGT(path, seconds, videoTrackIndex, audioTrackIndex), que conferem se o arquivo pode entrar no projeto. Encontrei: " + raw.join(", "),
            isError: true,
          };
        }
        await syncImportPolicy(logTab);
        const step = addStep(args.description || "Executando script", args.code);
        const res = await runInPremiere(args.code);
        if (res.ok) {
          step.done(true, res.result);
          return { text: res.result || "OK" };
        }
        const msg = `Erro${res.line ? " na linha " + res.line : ""}: ${res.error}`;
        step.done(false, /PRECISA_APROVACAO/.test(msg) ? "Precisa da sua aprovação para importar arquivos de fora do projeto" : msg);
        return { text: msg, isError: true };
      },
    },
    {
      name: "get_project_state",
      description:
        "Get a fresh snapshot of the project: bin tree with items, sequences, and the active sequence's tracks, clips, playhead and selection.",
      inputSchema: { type: "object", properties: {} },
      async handler() {
        const step = addStep("Lendo o projeto");
        const res = await getProjectState();
        step.done(res.ok, res.ok ? "" : res.error);
        return res.ok ? { text: JSON.stringify(res.result) } : { text: res.error, isError: true };
      },
    },
    {
      name: "transcribe_sequence",
      description:
        "Export the active sequence's mixed audio and transcribe it locally with Whisper (no internet). Returns sentences with start/end times and word start times, in sequence seconds. Pass media_path to transcribe a specific audio/video file instead (times are then relative to that file). Can take a few minutes for long sequences.",
      inputSchema: {
        type: "object",
        properties: {
          media_path: { type: "string", description: "Optional: absolute path of a media file to transcribe instead of the sequence." },
          language: { type: "string", description: "Optional Whisper language name, e.g. 'portuguese', 'english', 'spanish', 'french', 'german', 'italian', or 'auto' to detect it from the audio. Defaults to the panel setting." },
        },
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        const step = addStep("Transcrevendo o áudio no computador");
        try {
          let media = args.media_path;
          if (!media) {
            const preset = Local.findWavPreset(hostAppPath());
            if (!preset) throw new Error("Preset de WAV do Premiere não encontrado.");
            const wav = Local.workFile("sequencia-" + Date.now() + ".wav");
            step.update("exportando o áudio da sequência");
            const ex = await host("PPC_exportAudio", enc(wav), enc(preset));
            if (!ex.ok) throw new Error(ex.error);
            if (!(await Local.waitForFile(wav, 120000))) throw new Error("O Premiere não exportou o áudio (" + ex.result.message + ").");
            media = wav;
          }
          const t = await Local.transcribe(media, {
            model: settings.asrModel,
            language: args.language || settings.asrLanguage,
            onProgress: (m) => step.update(m),
          });
          step.done(true, `${t.segments.length} frases · ${fmt2(t.duration)} s de áudio · ${fmt2(t.seconds)} s para transcrever`);
          return { text: formatTranscript(t) };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "create_caption_track",
      description:
        "Save an SRT (next to the project, in a 'Legendas' folder), import it into the 'Legendas' bin and add it as a new caption track on the active sequence. The SRT is validated first (times, order, no overlaps).",
      inputSchema: {
        type: "object",
        properties: {
          srt: { type: "string", description: "Full SRT content." },
          name: { type: "string", description: "File/item name, e.g. 'Legenda corrigida'." },
          start_seconds: { type: "number", description: "Sequence time where the SRT's 00:00:00 maps to. Usually 0." },
        },
        required: ["srt"],
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        const step = addStep("Criando a trilha de legenda");
        try {
          const { srt, count } = Local.normalizeSrt(args.srt);
          const st = await getProjectState();
          const projectPath = st.ok && st.result ? st.result.projectPath : null;
          const file = Local.writeSrt(srt, args.name, projectPath);
          const res = await host("PPC_createCaptions", enc(file), enc("Legendas"), Number(args.start_seconds) || 0);
          if (!res.ok) throw new Error(res.error + ` (o arquivo foi salvo em ${file})`);
          const msg = `${count} legendas · arquivo ${file} · ` +
            (res.result.captionTrackCreated ? "trilha de legenda criada" : "importado, mas a trilha não foi criada: arraste o item para a timeline");
          step.done(true, msg);
          return { text: msg };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "view_frame",
      description:
        "Look at a frame of the active sequence (what the Program Monitor shows) at a given time in seconds. Moves the playhead there. Use it to read on-screen text, names and logos, or to check a visual result.",
      inputSchema: {
        type: "object",
        properties: {
          time: { type: "number", description: "Sequence time in seconds. Omit to use the current playhead." },
        },
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        const step = addStep("Olhando o frame" + (args.time != null ? ` em ${fmt2(args.time)} s` : ""));
        try {
          const png = Local.workFile("frame-" + Date.now() + ".png");
          const res = await host("PPC_exportFrame", args.time != null ? Number(args.time) : "null", enc(png));
          if (!res.ok) throw new Error(res.error);
          const img = await Local.imageForModel(png, 1024);
          step.done(true, "");
          return {
            content: [
              { type: "text", text: `Frame em ${fmt2(res.result.time)} s` },
              { type: "image", data: img.data, mimeType: img.mimeType },
            ],
          };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "update_skill",
      description:
        "Record a lasting editing preference in one of the user's CLIENT skills, so future videos follow it (also in Claude Code). Only two files can be changed: 'historico' = references/historico-ajustes.md (what was asked and why) and 'estilo' = references/estilo-aprovado.md (exact approved values). Read the file first with read_document (path: <skill folder>/references/<file>) and match its format. The panel shows the change to the user, who must approve it; the result says whether it was approved. Never call it for one-off changes of a single video.",
      inputSchema: {
        type: "object",
        properties: {
          skill_id: { type: "string", description: "Skill folder id, e.g. 'impetus-upsell-emagrecimento'." },
          file: { type: "string", enum: ["historico", "estilo"] },
          summary: { type: "string", description: "One sentence in the user's language: what changes in the standard and why." },
          old_text: { type: "string", description: "Exact unique text to replace. Omit to append new_text at the end of the file. To add a row to a markdown table, replace its last row with that row plus the new one." },
          new_text: { type: "string", description: "New text." },
        },
        required: ["skill_id", "file", "summary", "new_text"],
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        let plan;
        try {
          plan = Local.planSkillEdit(String(args.skill_id), String(args.file), args.old_text ? String(args.old_text) : "", String(args.new_text || ""));
        } catch (e) {
          return { text: e.message || String(e), isError: true };
        }
        const fileLabel = args.file === "estilo" ? "estilo-aprovado.md" : "historico-ajustes.md";
        const detail =
          `${args.summary || ""}\n\nArquivo: ${args.skill_id} / ${fileLabel} (${plan.mode})\n\n` +
          (args.old_text ? `− ANTES:\n${args.old_text}\n\n+ DEPOIS:\n${args.new_text}` : `+ ACRESCENTAR:\n${args.new_text}`);
        const ok = await askApproval("🧩 Atualizar a skill " + args.skill_id + "?", detail);
        if (!ok) return { text: "O usuário RECUSOU esta alteração. Nada foi gravado. Não tente de novo sem ele pedir; pergunte o que ajustar se fizer sentido." };
        const step = addStep("Gravando na skill " + args.skill_id);
        try {
          const r = Local.applySkillEdit(String(args.skill_id), String(args.file), args.old_text ? String(args.old_text) : "", String(args.new_text));
          const msg = `Gravado em ${r.file}` + (r.backup ? ` · cópia anterior em ${r.backup}` : "");
          step.done(true, msg);
          return { text: msg };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "read_document",
      description:
        "Read a document or image from disk by absolute path: DOCX (text with formatting marks and comments), txt/md/srt/csv, or an image (png/jpg/webp) which you will see. Use for a copy/roteiro or reference that was not attached to the chat. PDFs must be attached to the chat instead.",
      inputSchema: {
        type: "object",
        properties: { path: { type: "string", description: "Absolute path." } },
        required: ["path"],
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        const p = String(args.path);
        const step = addStep("Lendo " + p.split(/[\\/]/).pop());
        try {
          if (/\.pdf$/i.test(p)) throw new Error("PDF: peça para o usuário anexar o arquivo no chat (📎).");
          if (Local.isImage(p)) {
            const b = await Local.imageBlock(p);
            if (!b) throw new Error("Não consegui abrir a imagem.");
            step.done(true, "");
            return { content: [{ type: "text", text: p }, { type: "image", data: b.source.data, mimeType: b.source.media_type }] };
          }
          const text = Local.readDocumentText(p);
          step.done(true, `${text.length} caracteres`);
          return { text };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "read_text_file",
      description: "Read a text file from disk (srt, vtt, txt, csv, json, xml, md), e.g. caption files the user exported or that are in the project.",
      inputSchema: {
        type: "object",
        properties: { path: { type: "string", description: "Absolute path." } },
        required: ["path"],
      },
      async handler(args) {
        if (!Local) return { text: "Ferramentas locais indisponíveis.", isError: true };
        const step = addStep("Lendo " + String(args.path).split(/[\\/]/).pop());
        try {
          const text = Local.readTextFile(String(args.path));
          step.done(true, "");
          return { text };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "remove_silences",
      description:
        "Decupagem por silêncio (the panel's ✂ Decupagem engine) on the ACTIVE sequence: exports its audio, measures the volume locally and cuts the silences on every unlocked track, keeping video and audio in sync. Prefer this over hand-written razor code for any 'tira os silêncios / decupa as pausas' request. Unset values use what the user configured in the Decupagem tab. Presets: natural (YouTube/podcast), dinamico (Reels/TikTok/VSL), agressivo (jump cut), suave (entrevista). Use dry_run first when the user wants to see how much would be cut.",
      inputSchema: {
        type: "object",
        properties: {
          preset: { type: "string", enum: ["auto", "natural", "dinamico", "agressivo", "suave"], description: "auto = reads this audio and picks threshold, pauses and margins by itself (use when the user asks it to adjust itself / 'se ajustar sozinho')." },
          threshold_db: { description: "Silence threshold in dB (e.g. -40), or 'auto' to derive it from the noise floor." },
          auto_offset_db: { type: "number", description: "With auto threshold: positive cuts more, negative cuts less." },
          min_silence: { type: "number", description: "Minimum pause length to cut, seconds." },
          pad_before: { type: "number", description: "Margin kept before speech, seconds." },
          pad_after: { type: "number", description: "Margin kept after speech, seconds." },
          min_speech: { type: "number", description: "Sounds shorter than this inside a silence are cut too, seconds." },
          mode: { type: "string", enum: ["ripple", "gap", "disable", "markers"], description: "ripple = cut and close gaps; gap = cut, leave gaps; disable = cut and disable; markers = only add markers." },
          new_sequence: { type: "boolean", description: "Work on a copy named '<seq> - DECUPADA' (default from the tab, normally true)." },
          dry_run: { type: "boolean", description: "Only analyse and report, change nothing." },
        },
      },
      async handler(args) {
        const step = addStep(args.dry_run ? "Analisando os silêncios" : "Decupando os silêncios");
        try {
          const text = await window.DecupUI.runFromChat(args || {}, (m) => step.update(m));
          step.done(true, "");
          return { text };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
  ];

  // ------------------------------------------------------------ ferramentas das skills (scripts e arquivos)

  const Runner = window.Runner;

  // Pastas onde o chat pode gravar: a do projeto (e até 2 acima), as configuradas e as "Clientes".
  function writeRoots() {
    const extra = String(settings.writeRoots || "")
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);
    for (const d of ["D:\\Clientes", "G:\\Clientes", "E:\\Clientes"]) {
      try {
        if (require("fs").statSync(d).isDirectory()) extra.push(d);
      } catch {}
    }
    return Runner.allowedRoots(activeTab && activeTab.path, extra);
  }

  const SKILL_TOOLS = [
    {
      name: "export_sequence_video",
      description:
        "Get the active sequence as ONE video file for a skill (skills start from a video in Brutas). If the sequence is just one whole, uncut file, returns that original file (no render). Otherwise renders the sequence (H.264, same size and frame rate) to out_dir — this blocks Premiere for a while (roughly real time or faster). Use after remove_silences when the skill expects an already decupado video.",
      inputSchema: {
        type: "object",
        properties: {
          out_dir: { type: "string", description: "Folder for the rendered file (e.g. <pasta mãe>\\Brutas). Default: ~/.premiere-chat/work." },
          name: { type: "string", description: "File name without extension (default: the sequence name)." },
          prefer_source: { type: "boolean", description: "Default true: reuse the original file when the sequence is a single uncut clip." },
        },
      },
      async handler(args) {
        const step = addStep("Preparando o vídeo da sequência");
        try {
          if (args.prefer_source !== false) {
            const src = await host("PPC_seqSource");
            if (!src.ok) throw new Error(src.error);
            if (src.result.single) {
              step.done(true, "Usando o arquivo original: " + src.result.path);
              return { text: `A sequência é um arquivo inteiro sem cortes. Use o original: ${src.result.path} (${src.result.duration} s). Copie para Brutas com copy_file se a skill pedir.` };
            }
            step.update("precisa exportar (" + src.result.reason + ")");
          }
          const pr = Local.findVideoPreset(hostAppPath());
          if (!pr) throw new Error("Não achei o preset H.264 do Premiere para exportar.");
          const info = await host("PPC_seqInfo");
          const base = String(args.name || (info.ok ? info.result.name : "sequencia")).replace(/[\\/:*?"<>|]+/g, "_").trim() || "sequencia";
          const dir = args.out_dir ? String(args.out_dir) : require("path").dirname(Local.workFile("x"));
          Runner.makeDirs([dir], { roots: writeRoots() });
          const out = require("path").join(dir, base + pr.ext);
          step.update("exportando (o Premiere fica ocupado até terminar)");
          const ex = await host("PPC_exportAudio", enc(out), enc(pr.preset));
          if (!ex.ok) throw new Error(ex.error);
          if (!(await Local.waitForFile(out, 600000))) throw new Error("O Premiere não gerou o vídeo (" + (ex.result && ex.result.message) + ").");
          step.done(true, out);
          return { text: "Vídeo da sequência exportado: " + out };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "show_plan",
      description:
        "Show (and keep updating) a checklist card of the editing pipeline in the chat, so the user follows the 'magic' step by step. Call it at the start of a multi-step edit with all steps, then again with the same steps whenever one starts or finishes (current = index of the running step, done = how many are finished). One card per request; later calls update it.",
      inputSchema: {
        type: "object",
        properties: {
          title: { type: "string", description: "e.g. 'Editando no padrão Leads dopaminérgica'" },
          steps: { type: "array", items: { type: "string" }, description: "Short Portuguese step names." },
          done: { type: "number", description: "How many steps are finished." },
          note: { type: "string", description: "Optional one-line status (e.g. 'renderizando 42%')." },
        },
        required: ["steps"],
      },
      async handler(args) {
        updatePlanCard(args.title || "Edição", args.steps || [], Number(args.done) || 0, args.note || "");
        return { text: "Plano atualizado." };
      },
    },
    {
      name: "run_command",
      description:
        "Run one program from the panel's allowlist, the way a skill's instructions say to (its Python/Node scripts, npx hyperframes render, ffmpeg...). No shell: pass the program name and the arguments as a list; pipes, redirects, '&&' and other programs are not available, so run steps one by one. Allowed programs: python (the editing runtime ~/.claude/edicao-runtime/python, already with the skills' libraries and models; use it whenever a skill says $PY or python), python-sistema (system Python 3.12, for skills that say so), py, node, npx (e.g. npx hyperframes render ...), npm, ffmpeg, ffprobe. Output is streamed to the user. Waits up to wait_minutes (default 50); a longer job keeps running in the background and you get a job id for job_status.",
      inputSchema: {
        type: "object",
        properties: {
          program: { type: "string", enum: ["python", "python-sistema", "py", "node", "npx", "npm", "ffmpeg", "ffprobe"] },
          args: { type: "array", items: { type: "string" }, description: "Arguments, one per item (paths with spaces are fine, no quoting needed)." },
          cwd: { type: "string", description: "Working folder (absolute). Usually the project's parent folder or the skill's work folder." },
          description: { type: "string", description: "What this step does, in Portuguese, shown to the user (e.g. 'Renderizando o vídeo final')." },
          wait_minutes: { type: "number", description: "How long to wait before returning (1-55, default 50)." },
        },
        required: ["program", "args"],
      },
      async handler(args) {
        const step = addStep(args.description || "Rodando " + args.program, [args.program].concat(args.args || []).join(" "));
        try {
          const job = Runner.start({ program: args.program, args: args.args || [], cwd: args.cwd }, Local, (line) => step.update(line));
          const mins = Math.max(1, Math.min(55, Number(args.wait_minutes) || 50));
          await Runner.wait(job, mins * 60000);
          const text = Runner.describe(job);
          if (job.status === "running") step.done(true, "Continua rodando em segundo plano (" + job.id + ").");
          else step.done(job.status === "done", job.out.trim().split(/\r?\n/).slice(-12).join("\n"));
          return { text, isError: job.status === "failed" };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "job_status",
      description: "Wait for (or check) a background job started by run_command. Returns its status and the end of its output.",
      inputSchema: {
        type: "object",
        properties: { job_id: { type: "string" }, wait_minutes: { type: "number", description: "0-55, default 30." } },
        required: ["job_id"],
      },
      async handler(args) {
        const job = Runner.get(args.job_id);
        if (!job) return { text: "Job não encontrado: " + args.job_id, isError: true };
        const step = addStep("Esperando " + job.label.slice(0, 60));
        const mins = Math.max(0, Math.min(55, args.wait_minutes == null ? 30 : Number(args.wait_minutes)));
        const timer = setInterval(() => step.update(job.lastLine), 1000);
        await Runner.wait(job, mins * 60000);
        clearInterval(timer);
        step.done(job.status !== "failed", job.status);
        return { text: Runner.describe(job), isError: job.status === "failed" };
      },
    },
    {
      name: "cancel_job",
      description: "Stop a running job (and the programs it started).",
      inputSchema: { type: "object", properties: { job_id: { type: "string" } }, required: ["job_id"] },
      async handler(args) {
        return { text: Runner.cancel(args.job_id) ? "Cancelado." : "Esse job não está rodando." };
      },
    },
    {
      name: "write_text_file",
      description:
        "Create or replace a text file (json, md, srt, html, css, js, py, xml...) — e.g. a skill's projeto.json / roteiro.json / plano, an HTML composition or a helper script. Only inside the allowed folders (the project's folder and up to two levels above it, the user's Clientes folders, ~/.premiere-chat, temp, plus folders the user allowed in settings); never inside ~/.claude (use update_skill for skill files). Creates missing folders.",
      inputSchema: {
        type: "object",
        properties: { path: { type: "string" }, content: { type: "string" }, overwrite: { type: "boolean", description: "Default true." } },
        required: ["path", "content"],
      },
      async handler(args) {
        const step = addStep("Gravando " + String(args.path).split(/[\\/]/).pop());
        try {
          const r = Runner.writeTextFile(String(args.path), args.content, { roots: writeRoots(), overwrite: args.overwrite !== false });
          step.done(true, "");
          return { text: `Gravado: ${r.path} (${r.bytes} bytes${r.replaced ? ", substituiu o anterior" : ""}).` };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "copy_file",
      description: "Copy a file (video, audio, image...) to a folder or path inside the allowed folders, e.g. putting the raw video in the project's 'Brutas' folder. Does not overwrite unless overwrite is true.",
      inputSchema: {
        type: "object",
        properties: { source: { type: "string" }, destination: { type: "string", description: "Target folder (ending in \\) or full file path." }, overwrite: { type: "boolean" } },
        required: ["source", "destination"],
      },
      async handler(args) {
        const step = addStep("Copiando " + String(args.source).split(/[\\/]/).pop());
        try {
          const need = outsidePaths(logTab, [String(args.source)]);
          if (need.length) {
            step.done(false, "Precisa da sua aprovação para trazer um arquivo de fora do projeto");
            return needApproval(need);
          }
          const r = Runner.copyFile(String(args.source), String(args.destination), { roots: writeRoots(), overwrite: !!args.overwrite });
          step.done(true, r.path);
          return { text: `Copiado para ${r.path} (${Math.round(r.bytes / 1024)} KB).` };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "make_folders",
      description: "Create folders (absolute paths) inside the allowed folders, e.g. the project structure a skill asks for (Brutas, SFX, Inserts, Musicas, _projeto).",
      inputSchema: { type: "object", properties: { paths: { type: "array", items: { type: "string" } } }, required: ["paths"] },
      async handler(args) {
        try {
          const made = Runner.makeDirs(args.paths || [], { roots: writeRoots() });
          addNote("Pastas prontas: " + made.map((d) => d.split(/[\\/]/).pop()).join(", "));
          return { text: "Pastas criadas ou já existentes:\n" + made.join("\n") };
        } catch (e) {
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "show_images",
      description:
        "Show still images (PNG/JPG test frames, prints, contact sheets) to the user inside the chat. With ask_approval true, the panel shows 'Aprovar' / 'Pedir ajuste' buttons and WAITS for the user's answer, returning it to you — use this for the 'mande print de teste e espere aprovação antes de renderizar' step of a skill, instead of ending your turn. You can look at the images yourself with Read.",
      inputSchema: {
        type: "object",
        properties: {
          paths: { type: "array", items: { type: "string" }, description: "Absolute image paths (up to 8)." },
          caption: { type: "string", description: "Short text in Portuguese above the images." },
          ask_approval: { type: "boolean" },
        },
        required: ["paths"],
      },
      async handler(args) {
        const paths = (args.paths || []).slice(0, 8).map(String);
        const r = await showImages(paths, args.caption || "", !!args.ask_approval);
        if (!args.ask_approval) return { text: `Mostrei ${paths.length} imagem(ns) ao usuário.` };
        if (r.approved) return { text: "O usuário APROVOU." + (r.feedback ? " Comentário: " + r.feedback : "") };
        if (r.cancelled) return { text: "O usuário parou o pedido sem responder.", isError: true };
        return { text: "O usuário pediu ajuste: " + (r.feedback || "(sem detalhes; pergunte o que mudar)") };
      },
    },
    {
      name: "place_on_timeline",
      description:
        "Bring a skill's result into Premiere as EDITABLE LAYERS: imports the files (into a bin) and places each one on a track at an exact time, without overwriting existing clips (a busy track pushes the item to the next free track above; missing tracks are created). Use it for the final video, B-roll, transparent overlays (lower thirds, motions, legendas renderizadas com alfa), music and SFX. By default it works on a COPY of the active sequence ('<nome> - MONTADA') so the original stays intact. You can pass the items inline or a plano-timeline.json written by the skill (same shape). Times are in sequence seconds.",
      inputSchema: {
        type: "object",
        properties: {
          plan_file: { type: "string", description: "Optional JSON file with { items, markers, target, copy_name, bin }." },
          items: {
            type: "array",
            items: {
              type: "object",
              properties: {
                file: { type: "string", description: "Absolute path of the media." },
                track: { type: "string", description: "'V2', 'V3', 'A2'... or 'auto-video' / 'auto-audio' (lowest free track from V2/A2 up)." },
                start: { type: "number", description: "Sequence time in seconds." },
                duration: { type: "number", description: "Seconds to use (omit = whole media; required for images)." },
                in: { type: "number", description: "Start inside the media, seconds (default 0)." },
                name: { type: "string" },
                fill: { type: "boolean", description: "Scale to fill the frame (images/B-roll of another size)." },
                scale: { type: "number", description: "Motion > Scale in %, overrides fill." },
                opacity: { type: "number", description: "0-100." },
                volume_db: { type: "number", description: "Audio level in dB (e.g. -18 for music under speech)." },
                label: { type: "number", description: "Color label 0-15 for the project item." },
              },
              required: ["file", "start"],
            },
          },
          markers: { type: "array", items: { type: "object", properties: { time: { type: "number" }, end: { type: "number" }, name: { type: "string" }, comment: { type: "string" }, color: { type: "number" } }, required: ["time"] } },
          target: { type: "string", enum: ["copy", "active"], description: "copy (default) = new sequence '<nome> - MONTADA'; active = the open sequence itself." },
          copy_name: { type: "string" },
          bin: { type: "string", description: "Bin for the imported files (default: the skill name or 'Skills')." },
          allow_overwrite: { type: "boolean", description: "Only if the user asked to replace what is on the tracks." },
        },
      },
      async handler(args) {
        const step = addStep("Montando na timeline");
        try {
          let plan = {};
          if (args.plan_file) plan = JSON.parse(require("fs").readFileSync(String(args.plan_file), "utf8").replace(/^\uFEFF/, ""));
          const items = (args.items || plan.items || []).map((it) => Object.assign({}, it));
          if (!items.length) throw new Error("Nenhum item para colocar.");
          const need = outsidePaths(logTab, items.map((it) => it.file));
          if (need.length) {
            step.done(false, "Precisa da sua aprovação para importar arquivos de fora do projeto");
            return needApproval(need);
          }
          await syncImportPolicy(logTab);
          step.update("lendo o tamanho das mídias");
          for (const it of items) {
            if (it.volume_db != null && it.volumeDb == null) it.volumeDb = it.volume_db;
            if (it.fill && !(it.srcW && it.srcH)) {
              const sz = Local.probeSize ? Local.probeSize(it.file) : null;
              if (sz) {
                it.srcW = sz.width;
                it.srcH = sz.height;
              }
            }
          }
          const opts = {
            target: args.target || plan.target || "copy",
            copyName: args.copy_name || plan.copy_name,
            bin: args.bin || plan.bin || "Skills",
            allowOverwrite: !!(args.allow_overwrite || plan.allow_overwrite),
            items,
            markers: args.markers || plan.markers || [],
          };
          await backupBeforeTurn(true);
          step.update(`colocando ${items.length} itens`);
          const r = await host("PPC_place", enc(JSON.stringify(opts)));
          if (!r.ok) throw new Error(r.error);
          const res = r.result;
          const lines = res.placed.map((p) => `${p.track} ${fmt2(p.start)}s${p.end != null ? "–" + fmt2(p.end) + "s" : ""} · ${p.file}`);
          const sk = res.skipped.map((s) => `✗ ${String(s.file).split(/[\\/]/).pop()}: ${s.reason}`);
          step.done(res.skipped.length === 0, lines.concat(sk).join("\n"));
          return {
            text: `Sequência: ${res.sequence}${res.sequence !== res.original ? " (cópia de " + res.original + ")" : ""} · bin ${res.bin} · ${res.placed.length} colocados, ${res.skipped.length} com problema, ${res.markers} marcadores.\n` + lines.concat(sk).join("\n"),
            isError: res.placed.length === 0,
          };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "import_premiere_xml",
      description: "Import a Premiere / Final Cut XML (e.g. the editable timeline a skill exported) into the project. It becomes a new sequence, which is opened. Use when a skill produced an .xml/.fcpxml timeline.",
      inputSchema: { type: "object", properties: { path: { type: "string" }, bin: { type: "string" } }, required: ["path"] },
      async handler(args) {
        const step = addStep("Importando o XML " + String(args.path).split(/[\\/]/).pop());
        try {
          const need = outsidePaths(logTab, [String(args.path), ...xmlMediaPaths(String(args.path))]);
          if (need.length) {
            step.done(false, "Precisa da sua aprovação para importar arquivos de fora do projeto");
            return needApproval(need);
          }
          await syncImportPolicy(logTab);
          await backupBeforeTurn(true);
          const r = await host("PPC_importXml", enc(args.path), enc(args.bin || "Skills"));
          if (!r.ok) throw new Error(r.error);
          step.done(true, (r.result.sequences || []).join(", "));
          return { text: `Importado no bin ${r.result.bin}. Sequências criadas: ${(r.result.sequences || []).join(", ") || "(nenhuma — confira se o XML tem uma sequência)"}.` };
        } catch (e) {
          step.done(false, e.message || String(e));
          return { text: e.message || String(e), isError: true };
        }
      },
    },
    {
      name: "request_import_approval",
      description:
        "Ask the user's approval BEFORE bringing into the project any file or folder that is outside the current project's folder (the inserts library, other projects, downloads, another client's folder...). Shows an approval card in the chat and WAITS for the answer. Batch all files you need in one call. An approval covers the listed files/folders for the rest of this conversation.",
      inputSchema: {
        type: "object",
        properties: {
          paths: { type: "array", items: { type: "string" }, description: "Absolute paths of the files (or folders) to import." },
          reason: { type: "string", description: "Why, in Portuguese, one line (e.g. 'B-roll de emagrecimento da biblioteca de inserts')." },
        },
        required: ["paths"],
      },
      async handler(args) {
        const tab = logTab;
        const paths = (args.paths || []).map(String).filter(Boolean);
        const need = outsidePaths(tab, paths);
        if (!need.length) return { text: "Esses arquivos já estão liberados (dentro do projeto ou já aprovados). Pode importar." };
        const shown = need.slice(0, 20).map((p) => "• " + p).join("\n") + (need.length > 20 ? "\n… e mais " + (need.length - 20) : "");
        const ok = await askApproval(
          "📥 Posso importar " + (need.length === 1 ? "este arquivo" : need.length + " arquivos") + " de fora do projeto?",
          (args.reason ? args.reason + "\n\n" : "") + shown,
          "Aprovar e importar"
        );
        if (ok) {
          approveImport(tab, need);
          scheduleSave(tab);
          return { text: "O usuário APROVOU. Pode importar:\n" + need.join("\n") };
        }
        return { text: "O usuário RECUSOU. Não importe esses arquivos; siga sem eles (marcador vermelho 'INSERT FALTANDO: <descrição>' se for insert)." };
      },
    },
  ];
  if (Runner && Local) TOOLS.push(...SKILL_TOOLS);
  const SKILL_TOOL_NAMES = new Set(SKILL_TOOLS.map((t) => t.name));
  const skillsEnabled = () => !!(Runner && Local) && settings.allowSkills !== false;
  const activeTools = () => TOOLS.filter((t) => skillsEnabled() || !SKILL_TOOL_NAMES.has(t.name));

  // Cartão de progresso da edição (um por pedido; as chamadas seguintes atualizam o mesmo).
  let planCard = null; // { el, entry, tab, turn }
  let turnSerial = 0;
  let lastTurnStarted = 0;

  function paintPlan(el, title, steps, done, note) {
    el.innerHTML = '<div class="pl-title"></div><ol class="pl-steps"></ol><div class="pl-note"></div>';
    el.querySelector(".pl-title").textContent = "✨ " + title;
    const ol = el.querySelector(".pl-steps");
    steps.forEach((s, i) => {
      const li = document.createElement("li");
      li.className = i < done ? "done" : i === done ? "now" : "";
      li.textContent = s;
      ol.appendChild(li);
    });
    const pct = steps.length ? Math.round((Math.min(done, steps.length) / steps.length) * 100) : 0;
    el.querySelector(".pl-note").textContent = (note ? note + " · " : "") + pct + "%";
  }

  function updatePlanCard(title, steps, done, note) {
    if (!planCard || planCard.turn !== turnSerial || !planCard.el.isConnected) {
      hideTyping();
      bubble = null;
      const el = document.createElement("div");
      el.className = "plan-card";
      chatEl.appendChild(el);
      planCard = { el, entry: logEntry({ t: "plan", title, steps, done, note }), tab: logTab, turn: turnSerial };
    }
    paintPlan(planCard.el, title, steps, done, note);
    if (planCard.entry) {
      Object.assign(planCard.entry, { title, steps, done, note });
      scheduleSave(planCard.tab);
    }
    scrollDown();
    if (busy) showTyping();
  }

  function replayPlan(e) {
    const el = document.createElement("div");
    el.className = "plan-card";
    paintPlan(el, e.title, e.steps || [], e.done || 0, e.note || "");
    chatEl.appendChild(el);
  }

  // Imagens no chat (com ou sem Aprovar/Pedir ajuste).
  function imageUrl(p) {
    try {
      const buf = require("fs").readFileSync(p);
      const type = /\.png$/i.test(p) ? "image/png" : /\.webp$/i.test(p) ? "image/webp" : "image/jpeg";
      return URL.createObjectURL(new Blob([buf], { type }));
    } catch {
      return null;
    }
  }

  function imagesCard(paths, caption) {
    const el = document.createElement("div");
    el.className = "approval img-card";
    el.innerHTML = '<div class="ap-title"></div><div class="img-grid"></div><div class="ap-actions"></div>';
    el.querySelector(".ap-title").textContent = caption || "Prévia";
    const grid = el.querySelector(".img-grid");
    for (const p of paths) {
      const url = imageUrl(p);
      const a = document.createElement("figure");
      a.title = p;
      if (url) {
        const img = document.createElement("img");
        img.src = url;
        img.addEventListener("click", () => img.classList.toggle("big"));
        a.appendChild(img);
      } else a.innerHTML = '<div class="img-missing">imagem não encontrada</div>';
      const cap = document.createElement("figcaption");
      cap.textContent = p.split(/[\\/]/).pop();
      a.appendChild(cap);
      grid.appendChild(a);
    }
    return el;
  }

  function showImages(paths, caption, ask) {
    hideTyping();
    bubble = null;
    const entry = logEntry({ t: "img", paths, caption, ask, result: null });
    const tab = logTab;
    const el = imagesCard(paths, caption);
    chatEl.appendChild(el);
    scrollDown();
    if (!ask) {
      if (busy) showTyping();
      return Promise.resolve({});
    }
    const actions = el.querySelector(".ap-actions");
    actions.innerHTML =
      '<button class="primary ap-yes">✅ Aprovar</button><button class="secondary ap-fix">✏️ Pedir ajuste</button>' +
      '<div class="img-fix hidden"><textarea rows="2" placeholder="O que mudar? (ex.: legenda maior, tirar o brilho)"></textarea><button class="primary ap-send">Enviar ajuste</button></div>';
    return new Promise((resolve) => {
      const finish = (res) => {
        pendingApprovals.delete(cancel);
        if (pendingMicAnswer) clearMicInvite();
        const txt = res.approved ? "✓ Aprovado" : res.cancelled ? "Sem resposta" : "✏️ Ajuste: " + (res.feedback || "");
        actions.innerHTML = `<span class="ap-result ${res.approved ? "ok" : "no"}"></span>`;
        actions.querySelector(".ap-result").textContent = txt;
        if (entry) {
          entry.result = res;
          scheduleSave(tab);
        }
        if (busy) showTyping();
        resolve(res);
      };
      const cancel = (ok) => finish(ok ? { approved: true } : { cancelled: true });
      pendingApprovals.add(cancel);
      // Na conversa por voz: pergunta em voz alta e escuta a resposta ("aprovado" ou o ajuste).
      if (voiceTurnActive) {
        // O microfone não liga sozinho: a resposta por voz vale quando a pessoa clicar em 🎤.
        inviteMic((said) => {
          if (!pendingApprovals.has(cancel)) return;
          if (/^(sim|aprovad[oa]|aprova|aprovo|pode( seguir| continuar| renderizar)?|ok|okay|beleza|perfeito|manda( ver)?|segue|t[aá] [oó]timo|gostei)\b/i.test(said.trim())) finish({ approved: true, feedback: said });
          else finish({ approved: false, feedback: said });
        });
        speakNow((caption ? caption + ". " : "") + "Pode aprovar ou me dizer o que mudar.");
      }
      actions.querySelector(".ap-yes").addEventListener("click", () => finish({ approved: true }));
      actions.querySelector(".ap-fix").addEventListener("click", () => {
        actions.querySelector(".img-fix").classList.remove("hidden");
        actions.querySelector("textarea").focus();
      });
      actions.querySelector(".ap-send").addEventListener("click", () => {
        const fb = actions.querySelector("textarea").value.trim();
        finish({ approved: false, feedback: fb });
      });
    });
  }

  function replayImages(e) {
    const el = imagesCard(e.paths || [], e.caption);
    if (e.ask) {
      const r = e.result || { cancelled: true };
      const txt = r.approved ? "✓ Aprovado" : r.cancelled ? "Sem resposta" : "✏️ Ajuste: " + (r.feedback || "");
      el.querySelector(".ap-actions").innerHTML = `<span class="ap-result ${r.approved ? "ok" : "no"}"></span>`;
      el.querySelector(".ap-result").textContent = txt;
    }
    chatEl.appendChild(el);
  }

  // ------------------------------------------------------------ conta / Claude Code

  let mcp = null;

  function setStatusEl(id, text, cls) {
    const el = $(id);
    el.textContent = text;
    el.className = "account-status" + (cls ? " " + cls : "");
  }
  // Bolinha do topo: verde se a conta que vai ser usada está pronta.
  function paintEngineState() {
    const e = engine();
    const ready = engineReady(e) && acct[e].loggedIn === true;
    const any = engineOn("claude") || engineOn("gpt");
    $("status-dot").className = "dot" + (ready ? "" : !any || acct[e].loggedIn === false ? " off" : " warn");
    $("status-dot").title = ready ? "Usando a conta " + nameOf(e) : "Nenhuma conta pronta: veja as configurações (⚙)";
    for (const k of ["claude", "gpt"]) {
      const b = $(k + "-badge");
      if (!b) continue;
      const lim = Date.now() < limitedUntil[k];
      const using = ready && e === k;
      b.textContent = lim ? "no limite" : using ? "em uso" : "";
      b.className = "acct-badge" + (lim ? " lim" : using ? " on" : " hidden");
    }
  }
  // Compatível com o código antigo: mostra no cartão da conta em uso.
  function setAccountStatus(text, cls) {
    setStatusEl(engine() === "gpt" ? "gpt-status" : "account-status", text, cls);
    paintEngineState();
  }

  function checkLocalTools() {
    const el = $("local-status");
    if (!Local) {
      el.textContent = "Indisponível fora do Premiere.";
      return;
    }
    const issues = [];
    if (!Local.findFfmpeg()) issues.push("ffmpeg não encontrado");
    if (!Local.findNode()) issues.push("Node.js não encontrado");
    if (!Local.transcriberScript()) issues.push("transcritor não instalado (rode install.ps1)");
    el.textContent = issues.length ? "⚠ " + issues.join(" · ") : "Transcrição local pronta (Whisper, sem internet).";
    el.className = "hint" + (issues.length ? " warn" : "");
  }

  // Verifica as duas contas. Devolve se a conta que vai ser usada agora está conectada.
  async function checkAccount() {
    if (!Bridge || !GptBridge) {
      setStatusEl("account-status", "Node.js indisponível (abra o painel dentro do Premiere).", "bad");
      setStatusEl("gpt-status", "Node.js indisponível (abra o painel dentro do Premiere).", "bad");
      $("btn-login").disabled = true;
      $("btn-gpt-login").disabled = true;
      paintEngineState();
      return false;
    }
    await Promise.all([checkClaudeAccount(), checkGptAccount()]);
    paintEngineState();
    return acct[engine()].loggedIn === true && engineOn(engine());
  }

  async function checkClaudeAccount() {
    const a = acct.claude;
    a.exe = Bridge.findClaude(settings.claudePath);
    if (!a.exe) {
      a.loggedIn = false;
      setStatusEl("account-status", "Claude Code não encontrado. Instale o app Claude Desktop ou o Claude Code.", "bad");
      $("btn-login").disabled = true;
      return false;
    }
    $("btn-login").disabled = false;
    $("claude-path").placeholder = a.exe;
    setStatusEl("account-status", "Verificando login…");
    const st = await Bridge.authStatus(a.exe);
    a.loggedIn = !!st.loggedIn;
    const method = String(st.authMethod || "");
    if (a.loggedIn && /api|console|key/i.test(method)) {
      setStatusEl("account-status", `Logado via ${method} — isso cobra pela API. Clique em Entrar e use a conta Claude.`, "warn");
      a.loggedIn = false;
    } else if (a.loggedIn) {
      const plan = st.subscriptionType ? ` · plano ${st.subscriptionType}` : "";
      setStatusEl("account-status", `Conectado com a conta Claude${plan}` + (engineOn("claude") ? "" : " · desligada"), engineOn("claude") ? "ok" : "");
      $("btn-login").textContent = "Trocar";
    } else {
      setStatusEl("account-status", "Não conectado. Clique em Entrar e faça login com sua conta Claude.", "bad");
      $("btn-login").textContent = "Entrar";
    }
    return a.loggedIn;
  }

  // Conta ChatGPT pelo Codex CLI (login da assinatura, nunca chave de API).
  async function checkGptAccount() {
    const a = acct.gpt;
    $("btn-gpt-install").classList.add("hidden");
    a.exe = GptBridge.findExe(settings.gptPath);
    if (!a.exe) {
      a.loggedIn = false;
      setStatusEl("gpt-status", "O motor do ChatGPT (Codex) não está instalado. Clique em Instalar.", "bad");
      $("btn-gpt-login").disabled = true;
      $("btn-gpt-install").classList.remove("hidden");
      return false;
    }
    $("btn-gpt-login").disabled = false;
    $("gpt-path").placeholder = a.exe;
    setStatusEl("gpt-status", "Verificando login…");
    const st = await GptBridge.authStatus(a.exe);
    a.loggedIn = !!st.loggedIn && st.authMethod !== "api key";
    if (st.loggedIn && st.authMethod === "api key") {
      setStatusEl("gpt-status", "O Codex está logado com chave de API (isso cobra à parte). Clique em Entrar e use a conta ChatGPT.", "warn");
    } else if (a.loggedIn) {
      setStatusEl("gpt-status", "Conectado com a conta ChatGPT" + (engineOn("gpt") ? "" : " · desligada"), engineOn("gpt") ? "ok" : "");
      $("btn-gpt-login").textContent = "Trocar";
    } else {
      setStatusEl("gpt-status", "Não conectado. Clique em Entrar e faça login com sua conta ChatGPT.", "bad");
      $("btn-gpt-login").textContent = "Entrar";
    }
    return a.loggedIn;
  }

  let installPoll = null;
  function startGptInstall() {
    if (!GptBridge) return;
    GptBridge.openInstall(Local && Local.findNode ? require("path").join(require("path").dirname(Local.findNode() || ""), "npm.cmd") : "");
    setStatusEl("gpt-status", "Instalando o Codex na janela que abriu (1 a 3 minutos)…", "warn");
    clearInterval(installPoll);
    let tries = 0;
    installPoll = setInterval(() => {
      tries++;
      if (GptBridge.findExe(settings.gptPath) || tries > 72) {
        clearInterval(installPoll);
        checkAccount();
      }
    }, 5000);
  }

  const loginPolls = {};
  function startLogin(eng) {
    eng = eng === "gpt" ? "gpt" : "claude";
    const a = acct[eng];
    if (!a.exe) return;
    const B = bridgeOf(eng);
    const statusId = eng === "gpt" ? "gpt-status" : "account-status";
    B.openLogin(a.exe);
    setStatusEl(statusId, "Conclua o login na janela que abriu (e no navegador)…", "warn");
    clearInterval(loginPolls[eng]);
    let tries = 0;
    loginPolls[eng] = setInterval(async () => {
      tries++;
      const st = await B.authStatus(a.exe);
      if (st.loggedIn || tries > 60) {
        clearInterval(loginPolls[eng]);
        checkAccount();
      }
    }, 5000);
  }

  async function ensureMcp() {
    // O servidor conhece todas as ferramentas; o que o Claude pode usar vem de activeTools().
    if (!mcp) mcp = await Bridge.startMcpServer(TOOLS);
    return mcp;
  }

  // Salva o projeto e guarda uma cópia antes de o Claude mexer em qualquer coisa.
  async function backupBeforeTurn(force) {
    if ((!settings.backup && !force) || !IN_PPRO || !Local) return;
    try {
      const res = await host("PPC_save");
      if (res.ok && res.result) Local.backupProject(res.result);
    } catch {
      /* backup é best-effort; não impede o pedido */
    }
  }

  // ------------------------------------------------------------ abas e histórico por projeto

  const tabsEl = $("tabs");
  const tabs = []; // { key, id, path, name, pane, log, sessionId, live }
  let activeTab = null;
  let turnTab = null; // aba do pedido em andamento
  let premiereActiveKey = null;

  const projectLabel = (name) => String(name || "Sem título").replace(/\.prproj$/i, "");

  function emptyHtml(tab) {
    const cliente = Local && tab.path ? Local.clientFromPath(tab.path) : null;
    return `<div class="empty">
      <h2>O que vamos fazer no projeto?</h2>
      <p>${escapeHtml(projectLabel(tab.name))}${cliente ? " · cliente " + escapeHtml(cliente) : ""}</p>
      ${tab.key === "preview" && IN_PPRO ? "" : editModeHtml(tab)}
      <button class="skills-open">🧩 SKILLS<span>skills de edição dos seus clientes</span></button>
      <div class="chips">
        <button class="chip magic">✨ Edite este vídeo do começo ao fim no padrão do cliente: decupagem, skill, motions, trilha e SFX, montado em camadas</button>
        <button class="chip">Arrume as pastas do projeto separando vídeos, áudios, imagens e sequências</button>
        <button class="chip">Crie a legenda da sequência corrigindo qualquer erro com base no vídeo</button>
        <button class="chip">Coloque marcadores nos momentos em que muda de assunto</button>
        <button class="chip">Renomeie os clipes da timeline pela ordem em que aparecem</button>
        <button class="chip">Edite a timeline seguindo a copy anexada: estrutura, inserts e legenda</button>
      </div>
    </div>`;
  }

  const saveTimers = new Map();
  function saveTab(tab) {
    if (!tab || !Local || tab.key === "preview") return;
    try {
      Local.saveHistory(tab.key, {
        path: tab.path,
        name: tab.name,
        sessionId: tab.sessionId,
        sessionEngine: tab.sessionEngine || "claude",
        editMode: tab.editMode || null,
        importOk: tab.importOk || [],
        updated: new Date().toISOString(),
        log: tab.log.slice(-500),
      });
    } catch {
      /* sem disco: segue só em memória */
    }
  }
  function scheduleSave(tab) {
    if (!tab) return;
    clearTimeout(saveTimers.get(tab.key));
    saveTimers.set(tab.key, setTimeout(() => saveTab(tab), 600));
  }

  // Redesenha o histórico salvo de uma aba, sem registrar nada de novo.
  function renderLog(tab) {
    const saved = { chatEl, bubble, typingEl };
    chatEl = tab.pane;
    typingEl = null;
    replaying = true;
    tab.pane.innerHTML = "";
    if (!tab.log.length) tab.pane.innerHTML = emptyHtml(tab);
    else {
      tab.pane.insertAdjacentHTML("beforeend", '<div class="note">Conversa anterior deste projeto</div>');
      for (const e of tab.log) {
        if (e.t === "u") addUserBubble(e.text, (e.atts || []).map((name) => ({ name })));
        else if (e.t === "a") {
          if (!e.text) continue;
          newAssistantBubble();
          appendAssistant(e.text);
        } else if (e.t === "s") addStep(e.label, e.code).done(e.ok !== false && e.ok !== null, e.ok === null ? "(interrompido)" : e.out);
        else if (e.t === "n") addNote(e.text);
        else if (e.t === "e") addError(e.text);
        else if (e.t === "ap") replayApproval(e);
        else if (e.t === "img") replayImages(e);
        else if (e.t === "plan") replayPlan(e);
      }
    }
    replaying = false;
    ({ chatEl, bubble, typingEl } = saved);
  }

  function makeTab(info) {
    const key = Local && IN_PPRO ? Local.projectKey(info.path, info.name) : "preview";
    const saved = Local && key !== "preview" ? Local.loadHistory(key) : null;
    const pane = document.createElement("div");
    pane.className = "pane hidden";
    chatRoot.appendChild(pane);
    const tab = {
      key,
      id: info.id || "",
      path: info.path || "",
      name: info.name || (saved && saved.name) || "Projeto",
      pane,
      log: (saved && saved.log) || [],
      sessionId: (saved && saved.sessionId) || null,
      sessionEngine: (saved && saved.sessionEngine) || "claude",
      editMode: (saved && saved.editMode) || null,
      importOk: (saved && saved.importOk) || [],
      live: true,
    };
    tabs.push(tab);
    renderLog(tab);
    return tab;
  }

  function renderTabs() {
    tabsEl.innerHTML = "";
    for (const tab of tabs) {
      const b = document.createElement("button");
      b.className = "tab" + (tab === activeTab ? " active" : "") + (tab === turnTab ? " busy" : "");
      b.title = (tab.path || tab.name) + (tab.key === premiereActiveKey ? " · ativo no Premiere" : "");
      b.innerHTML = '<span class="live"></span><span class="nm"></span>';
      b.querySelector(".live").textContent = tab === turnTab ? "⏳" : tab.key === premiereActiveKey ? "●" : "";
      b.querySelector(".nm").textContent = projectLabel(tab.name);
      b.addEventListener("click", () => selectTab(tab, true));
      tabsEl.appendChild(b);
    }
    tabsEl.classList.toggle("hidden", tabs.length === 0);
  }

  function selectTab(tab, fromClick) {
    activeTab = tab;
    for (const t of tabs) t.pane.classList.toggle("hidden", t !== tab);
    if (!busy) {
      chatEl = tab.pane;
      logTab = tab;
    }
    renderTabs();
    chatRoot.scrollTop = chatRoot.scrollHeight;
    // Clicou na aba de outro projeto aberto: traz esse projeto para frente no Premiere.
    if (fromClick && IN_PPRO && tab.path && tab.key !== premiereActiveKey && !busy) {
      host("PPC_activateProject", enc(tab.path)).then(syncProjects);
    }
  }

  // Acompanha os projetos abertos no Premiere: cria/fecha abas e segue o projeto ativo.
  let syncing = false;
  async function syncProjects() {
    if (!IN_PPRO || !Local || syncing) return;
    syncing = true;
    try {
      const res = await host("PPC_projects");
      if (!res.ok || !res.result) return;
      const { active, list } = res.result;
      const seen = new Set();
      let changed = false;
      for (const p of list) {
        const key = Local.projectKey(p.path, p.name);
        let tab = tabs.find((t) => t.key === key);
        // Mesmo projeto com outro caminho (Salvar como / renomeado): leva o histórico junto.
        if (!tab && p.id) {
          tab = tabs.find((t) => t.id === p.id && !list.some((q) => Local.projectKey(q.path, q.name) === t.key));
          if (tab) {
            tab.key = key;
            tab.path = p.path;
            tab.name = p.name;
            saveTab(tab);
            changed = true;
          }
        }
        if (!tab) {
          tab = makeTab(p);
          changed = true;
        } else if (tab.name !== p.name) {
          tab.name = p.name;
          changed = true;
        }
        tab.id = p.id || tab.id;
        seen.add(tab.key);
      }
      // Projetos fechados: a aba sai (o histórico continua salvo no disco).
      for (let i = tabs.length - 1; i >= 0; i--) {
        const t = tabs[i];
        if (!seen.has(t.key) && t !== turnTab) {
          saveTab(t);
          t.pane.remove();
          tabs.splice(i, 1);
          if (activeTab === t) activeTab = null;
          changed = true;
        }
      }
      const activeKey = active ? Local.projectKey(active.path, active.name) : null;
      if (activeKey !== premiereActiveKey) {
        premiereActiveKey = activeKey;
        const t = tabs.find((x) => x.key === activeKey);
        if (t) selectTab(t, false);
        if (t) maybeGreet(t);
        changed = true;
      }
      if (!activeTab && tabs.length) selectTab(tabs[0], false);
      if (changed) renderTabs();
    } catch {
      /* Premiere ocupado: tenta no próximo ciclo */
    } finally {
      syncing = false;
    }
  }

  // Boas-vindas faladas quando um projeto é aberto: "O que vamos editar hoje?" e já fica ouvindo.
  const GREETED_KEY = "premierechat.greeted";
  // Ao abrir um projeto: se já tem conversa, oferece retomar; se é novo, pergunta o que vamos editar.
  // Vale a cada abertura (fechar e abrir o projeto de novo pergunta de novo).
  function maybeGreet(tab) {
    const mode = settings.voiceGreet || "always";
    if (mode === "never" || !Local || !IN_PPRO || tab.key === "preview" || tab.greeted) return;
    let greeted = {};
    try {
      greeted = JSON.parse(localStorage.getItem(GREETED_KEY) || "{}");
    } catch {}
    if (mode === "first" && greeted[tab.key]) return;
    tab.greeted = true;
    greeted[tab.key] = Date.now();
    try {
      localStorage.setItem(GREETED_KEY, JSON.stringify(greeted));
    } catch {}
    // Espera o painel e o Premiere assentarem; não interrompe um pedido em andamento.
    setTimeout(() => {
      if (busy || rec || preparingMic || activeTab !== tab) return;
      if (tab.log.some((e) => e.t === "u")) askResume(tab);
      else greetNew(tab);
    }, 1500);
  }

  function greetNew(tab) {
    const nome = projectLabel(tab.name);
    addNote("🗣️ O que vamos editar hoje" + (nome ? " em " + nome : "") + "?");
    // O microfone NÃO liga sozinho: a pessoa clica em 🎤 quando quiser responder por voz.
    speakNow("O que vamos editar hoje?").then(() => inviteMic());
  }

  // Resumo curto do último pedido, para a pessoa lembrar onde parou.
  function lastRequest(tab) {
    const u = [...tab.log].reverse().find((e) => e.t === "u" && e.text);
    if (!u) return "";
    const t = String(u.text).replace(/\s+/g, " ").trim();
    return t.length > 110 ? t.slice(0, 107).replace(/\s+\S*$/, "") + "…" : t;
  }

  function askResume(tab) {
    const ultimo = lastRequest(tab);
    const el = document.createElement("div");
    el.className = "approval resume-card";
    el.innerHTML =
      '<div class="ap-title">💬 Encontrei a nossa conversa anterior neste projeto</div><p class="hint"></p>' +
      '<div class="ap-actions"><button class="primary rs-yes">▶ Retomar de onde parei</button><button class="secondary rs-new">✨ Conversa nova</button></div>';
    el.querySelector(".hint").textContent = ultimo ? "Último pedido: “" + ultimo + "”" : "";
    tab.pane.appendChild(el);
    scrollDown();
    let decided = false;
    const finish = (choice, said) => {
      if (decided) return;
      decided = true;
      if (pendingMicAnswer === answerByVoice) clearMicInvite();
      stopSpeaking();
      if (rec) rec.cancel();
      el.querySelector(".ap-actions").innerHTML = '<span class="ap-result ok"></span>';
      el.querySelector(".ap-result").textContent = choice === "new" ? "✨ Conversa nova" : "▶ Retomando";
      if (choice === "new") {
        newConversation(tab);
        greetNew(tab);
        return;
      }
      // Retomar: a sessão do Claude continua a mesma (ele lembra de tudo).
      if (said) {
        send(said, { byVoice: true });
        return;
      }
      addNote("▶ Retomando a conversa. Pode falar ou escrever o próximo passo.");
      speakNow("Beleza, vamos continuar. Qual é o próximo passo?").then(() => inviteMic());
    };
    el.querySelector(".rs-yes").addEventListener("click", () => finish("resume"));
    el.querySelector(".rs-new").addEventListener("click", () => finish("new"));
    const fala = "Encontrei a nossa conversa anterior." + (ultimo ? " Da última vez você pediu: " + ultimo.replace(/[“”"]/g, "") + "." : "") + " Quer retomar de onde parou ou começar do zero?";
    // Resposta por voz ao cartão: só quando a pessoa clicar em 🎤 (o microfone não liga sozinho).
    const answerByVoice = (said) => {
      {
        const t = said.trim();
        const n = t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        if (/\b(do zero|comecar|comeca|nova|novo|limpa|outra coisa)\b|^nao\b/.test(n)) finish("new");
        else if (/^(sim|retoma|retomar|retome|continua|continuar|continue|bora|pode|quero|vamos|ok|beleza|isso)\b/.test(n) && n.split(/\s+/).length <= 5) finish("resume");
        else finish("resume", t); // falou já o próximo pedido: retoma e manda
      }
    };
    inviteMic(answerByVoice);
    speakNow(fala);
  }

  // Garante que o projeto da aba é o ativo no Premiere antes de mexer nele.
  async function ensureProjectActive(tab) {
    if (!IN_PPRO || !tab.path) return true;
    await syncProjects();
    if (tab.key === premiereActiveKey) return true;
    await host("PPC_activateProject", enc(tab.path));
    await syncProjects();
    return tab.key === premiereActiveKey;
  }

  // Resumo do histórico, usado se a sessão antiga do Claude não puder ser retomada.
  function historySummary(tab) {
    const lines = [];
    // Deixa de fora a última entrada: é o pedido atual, que já vai na mensagem.
    for (const e of tab.log.slice(-41, -1)) {
      if (e.t === "u") lines.push("Usuário: " + e.text + (e.atts && e.atts.length ? ` [anexos: ${e.atts.join(", ")}]` : ""));
      else if (e.t === "a" && e.text) lines.push("Você: " + e.text.slice(0, 1500));
      else if (e.t === "s") lines.push(`(ferramenta: ${e.label} — ${e.ok ? "ok" : "falhou"})`);
    }
    return lines.length
      ? `<conversa_anterior>\nResumo do que já foi feito neste projeto em conversas anteriores (a sessão original não pôde ser retomada):\n${lines.join("\n")}\n</conversa_anterior>`
      : "";
  }

  // ------------------------------------------------------------ janela de skills

  const skillsModal = $("skills-modal");

  function openSkills() {
    const body = $("skills-body");
    body.innerHTML = "";
    if (!Local) {
      body.innerHTML = '<p class="hint">As skills só aparecem dentro do Premiere.</p>';
      skillsModal.classList.remove("hidden");
      return;
    }
    const r = Local.listClientSkills();
    if (r.error) body.innerHTML = `<p class="hint warn">${escapeHtml(r.error)}</p>`;
    const cliente = activeTab && activeTab.path ? Local.clientFromPath(activeTab.path) : null;
    const norm = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
    const groups = r.clients.slice().sort((a, b) => (norm(b.cliente) === norm(cliente)) - (norm(a.cliente) === norm(cliente)));
    for (const g of groups) {
      const sec = document.createElement("section");
      sec.className = "sk-client";
      const here = cliente && norm(g.cliente) === norm(cliente);
      sec.innerHTML = `<h3>${escapeHtml(g.cliente)}${here ? '<span class="tag">deste projeto</span>' : ""}</h3>`;
      if (!g.skills.length) sec.insertAdjacentHTML("beforeend", '<p class="hint">Nenhuma skill ainda.</p>');
      for (const s of g.skills) {
        const card = document.createElement("div");
        card.className = "sk-card" + (s.existe ? "" : " missing");
        card.innerHTML =
          `<div class="sk-head"><strong></strong>${s.padrao ? '<span class="tag">PADRÃO</span>' : ""}</div>` +
          `<p class="sk-desc"></p><button class="primary sk-use">Usar neste projeto</button>`;
        card.querySelector("strong").textContent = s.nome;
        card.querySelector(".sk-desc").textContent = s.existe ? s.desc : `Pasta da skill "${s.id}" não encontrada.`;
        card.querySelector(".sk-desc").title = s.desc;
        const btn = card.querySelector(".sk-use");
        btn.disabled = !s.existe;
        btn.addEventListener("click", () => useSkill(s));
        sec.appendChild(card);
      }
      body.appendChild(sec);
    }

    // Ferramentas: skills que não são de cliente (motion, legendas, transições, render).
    const tools = Local.listToolSkills ? Local.listToolSkills() : [];
    if (tools.length) {
      const sec = document.createElement("section");
      sec.className = "sk-client";
      sec.innerHTML = "<h3>Ferramentas de motion, legenda e render</h3>" + (skillsEnabled() ? "" : '<p class="hint warn">Rodar skills está desligado em ⚙: o Claude só vai poder aplicar o estilo à mão.</p>');
      for (const s of tools) {
        const card = document.createElement("div");
        card.className = "sk-card";
        card.innerHTML = '<div class="sk-head"><strong></strong></div><p class="sk-desc"></p><button class="secondary sk-use">Usar</button>';
        card.querySelector("strong").textContent = s.nome;
        card.querySelector(".sk-desc").textContent = s.desc;
        card.querySelector(".sk-desc").title = s.desc;
        card.querySelector(".sk-use").addEventListener("click", () => useSkill(s, true));
        sec.appendChild(card);
      }
      body.appendChild(sec);
    }
    skillsModal.classList.remove("hidden");
  }

  function useSkill(s, isTool) {
    try {
      const label = "Skill " + s.nome;
      attachments = attachments.filter((a) => !a.skill);
      attachments.push({
        id: "skill-" + s.id,
        skill: true,
        name: label,
        path: s.id,
        status: "ready",
        data: { blocks: Local.skillBlocks(s.id, s.nome), note: isTool ? "ferramenta" : "padrão do cliente" },
        promise: Promise.resolve(),
      });
      renderAttachments();
      if (!inputEl.value.trim()) inputEl.value = isTool ? `Use a skill ${s.nome} para ` : `Edite este projeto no padrão da skill ${s.nome}.`;
      autoGrow();
      skillsModal.classList.add("hidden");
      inputEl.focus();
    } catch (e) {
      addError(e.message || String(e));
    }
  }

  // ------------------------------------------------------------ conversa

  let busy = false;
  let currentTurn = null;

  function setBusy(b) {
    busy = b;
    sendBtn.classList.toggle("stop", b);
    sendBtn.innerHTML = b ? '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>' : '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
    sendBtn.title = b ? "Parar" : "Enviar";
  }

  let deviceListsFilled = false;
  function fillDeviceLists() {
    if (deviceListsFilled) return;
    deviceListsFilled = true;
    try {
      fillMics();
      fillVoices();
    } catch {}
  }

  function openSettings() {
    $("settings").classList.remove("hidden");
    setTimeout(fillDeviceLists, 50);
  }

  // ------------------------------------------------------------ anexos

  const attachBar = $("attach-bar");
  let attachments = []; // { id, name, path, status: 'loading'|'ready'|'error', data, error, promise }

  function attIcon(name) {
    if (/^Skill /.test(name)) return "🧩";
    if (/\.pdf$/i.test(name)) return "📕";
    if (/\.docx?$/i.test(name)) return "📄";
    if (/\.(png|jpe?g|webp|gif|bmp|tiff?)$/i.test(name)) return "🖼";
    if (/\.(mp4|mov|mxf|avi|mkv|m4v|webm)$/i.test(name)) return "🎬";
    if (/\.(mp3|wav|aac|m4a|flac|ogg|aiff?)$/i.test(name)) return "🎵";
    return "📝";
  }

  function renderAttachments() {
    attachBar.innerHTML = "";
    attachBar.classList.toggle("hidden", attachments.length === 0);
    for (const a of attachments) {
      const el = document.createElement("span");
      el.className = "att" + (a.status === "loading" ? " loading" : a.status === "error" ? " bad" : "");
      el.title = a.status === "error" ? a.error : a.path + (a.data && a.data.note ? " · " + a.data.note : "");
      el.innerHTML = '<span class="ic"></span><span class="nm"></span><button title="Remover">✕</button>';
      el.querySelector(".ic").textContent = a.status === "loading" ? "⏳" : a.status === "error" ? "⚠" : attIcon(a.name);
      el.querySelector(".nm").textContent = a.name;
      el.querySelector("button").addEventListener("click", () => {
        attachments = attachments.filter((x) => x !== a);
        renderAttachments();
      });
      attachBar.appendChild(el);
    }
  }

  function addAttachmentPath(p) {
    if (!Local) {
      addError("Anexos só funcionam dentro do Premiere.");
      return;
    }
    if (attachments.some((a) => a.path === p)) return;
    const a = { id: Math.random().toString(36).slice(2), name: String(p).split(/[\\/]/).pop(), path: p, status: "loading" };
    a.promise = Local.readAttachment(p).then(
      (data) => {
        a.status = "ready";
        a.data = data;
      },
      (e) => {
        a.status = "error";
        a.error = e.message || String(e);
        addError(a.error);
      }
    ).then(renderAttachments);
    attachments.push(a);
    renderAttachments();
  }

  // Arquivo sem caminho no disco (print colado, arquivo vindo do navegador): grava antes.
  async function addAttachmentFile(file) {
    if (file.path) return addAttachmentPath(file.path);
    if (!Local) return addError("Anexos só funcionam dentro do Premiere.");
    try {
      const buf = Buffer.from(await file.arrayBuffer());
      let name = file.name || "";
      if (!name || name === "image.png") {
        const ext = (file.type.split("/")[1] || "png").replace("jpeg", "jpg");
        name = "print-" + new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14) + "." + ext;
      }
      addAttachmentPath(Local.saveAttachment(name, buf));
    } catch (e) {
      addError("Não consegui anexar " + (file.name || "o arquivo") + ": " + (e.message || e));
    }
  }

  function pickFiles() {
    // Diálogo nativo do CEP devolve caminhos reais; o <input type=file> fica de reserva.
    try {
      if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
        const r = window.cep.fs.showOpenDialogEx(true, false, "Anexar arquivos", "", [
          "pdf", "docx", "txt", "md", "srt", "vtt", "csv", "png", "jpg", "jpeg", "webp", "gif", "bmp",
          "mp4", "mov", "mp3", "wav", "m4a", "psd",
        ]);
        if (r && r.err === 0) {
          (r.data || []).forEach(addAttachmentPath);
          return;
        }
      }
    } catch {
      /* cai no input */
    }
    $("file-input").click();
  }

  // Monta a mensagem: anexos (texto/imagem/PDF) + estado do Premiere + pedido.
  async function buildContent(text, list, state, tab) {
    await Promise.all(list.map((a) => a.promise));
    const blocks = [];
    const ok = list.filter((a) => a.status === "ready");
    for (const a of ok) blocks.push(...a.data.blocks);
    blocks.push({
      type: "text",
      text:
        `<premiere_state>${JSON.stringify(state.ok ? state.result : { error: state.error })}</premiere_state>\n\n` +
        editModeBlock(tab) +
        (ok.length ? `Anexos desta mensagem: ${ok.map((a) => a.name).join(", ")}\n\n` : "") +
        text,
    });
    return blocks;
  }

  // Modelo e esforço do pedido para cada conta: o escolhido em ⚙, ou no Automático pelo tipo de pedido.
  function routeFor(eng, text, sentAtts, sendOpts, tab) {
    const gpt = eng === "gpt";
    let model = gpt ? (settings.gptModel === "auto" ? "" : settings.gptModel || "") : settings.model;
    let effort = settings.effort;
    let note = "";
    const ctx = {
      text,
      hasSkill: sentAtts.some((a) => a.skill),
      hasDocs: sentAtts.some((a) => /\.(pdf|docx?|txt|md|rtf)$/i.test(a.name || "")),
      byVoice: !!(sendOpts && sendOpts.byVoice),
      effort: settings.effort,
    };
    const effortPt = (e) => ({ low: "baixo", medium: "médio", high: "alto", xhigh: "muito alto" }[e] || e);
    const words = text.split(/\s+/).filter(Boolean).length;
    const last = tab.lastRoute;
    if (gpt && settings.gptModel === "auto" && window.ModelRouter) {
      // ChatGPT: o modelo é o da conta; o Automático ajusta só o raciocínio pelo tipo de pedido.
      const route = window.ModelRouter.pick(ctx);
      const byTier = { opus: "high", sonnet: "medium", haiku: "low" };
      let tier = route.model;
      if (tier !== "opus" && last && last.model === "opus" && Date.now() - last.at < 30 * 60000 && words <= 25) tier = "opus";
      effort = settings.effort || byTier[tier] || "medium";
      tab.lastRoute = { model: tier, effort, at: Date.now() };
      note = "🧠 ChatGPT · raciocínio " + effortPt(effort);
    } else if (!gpt && settings.model === "auto" && window.ModelRouter) {
      const route = window.ModelRouter.pick(ctx);
      // Continuação curta de uma edição grande (ex.: "aprovado, segue", "aumenta a legenda") fica no Opus.
      if (route.model !== "opus" && last && last.model === "opus" && Date.now() - last.at < 30 * 60000 && words <= 25) {
        route.model = "opus";
        route.effort = last.effort;
        route.label = "Opus · continuação da edição";
      }
      model = route.model;
      effort = route.effort;
      tab.lastRoute = { model, effort, at: Date.now() };
      note = "🧠 " + route.label + (effort ? " · esforço " + effortPt(effort) : "");
    } else if (gpt) note = "🧠 ChatGPT";
    return { model: model || "", effort: effort || "", note };
  }

  async function send(text, sendOpts) {
    text = text.trim();
    if (busy) return;
    stopSpeaking();
    if (!text && attachments.length) text = "Analise os anexos e me diga o que você entendeu e o que dá para fazer no projeto com eles.";
    if (!text) return;
    const tab = activeTab;
    if (!tab) return;
    // Mandou o pedido (digitado ou falado): o convite do 🎤 não vale mais.
    if (!(sendOpts && sendOpts.byVoice)) clearMicInvite();

    if (!engineOn("claude") && !engineOn("gpt")) {
      openSettings();
      addError("As duas contas estão desligadas. Ligue a chave da conta Claude ou da ChatGPT nas configurações (⚙).");
      return;
    }
    if (acct[engine()].loggedIn !== true) await checkAccount();
    let eng = engine();
    if (!bridgeOf(eng) || !acct[eng].exe) {
      openSettings();
      addError(eng === "gpt" ? "O motor do ChatGPT (Codex) não está disponível. Veja as configurações (⚙)." : "O Claude Code não está disponível. Veja as configurações (⚙).");
      return;
    }
    if (acct[eng].loggedIn !== true) {
      openSettings();
      addError("Entre com sua conta " + nameOf(eng) + " nas configurações (⚙) para começar.");
      return;
    }
    if (!(await ensureProjectActive(tab))) {
      addError(`O projeto "${projectLabel(tab.name)}" não está ativo no Premiere. Clique na janela dele no Premiere e envie de novo.`);
      return;
    }

    // Daqui até o fim do pedido, tudo vai para a aba que fez o pedido, mesmo se você trocar de aba.
    turnTab = tab;
    logTab = tab;
    chatEl = tab.pane;
    renderTabs();

    const sentAtts = attachments.filter((a) => a.status !== "error");
    attachments = [];
    renderAttachments();
    addUserBubble(text, sentAtts);
    // Arquivo que a própria pessoa anexou já está aprovado para entrar no projeto.
    for (const a of sentAtts) if (a.path) approveImport(tab, [a.path]);
    inputEl.value = "";
    autoGrow();
    setBusy(true);
    showTyping();
    bubble = null;

    // Resposta falada: quando o pedido veio pela voz (ou sempre, se configurado), e só com a voz ligada.
    const voiceTurn = voiceOn() && !!(Voice && Local) && settings.voiceReply !== "never" && (settings.voiceReply === "always" || !!(sendOpts && sendOpts.byVoice));
    voiceTurnActive = voiceTurn;
    let finalText = "";
    let turnResult = null;

    try {
      const server = await ensureMcp();
      await backupBeforeTurn();
      turnSerial++;
      lastTurnStarted = Date.now();
      const state = await getProjectState();
      const basePrompt = await buildContent(text, sentAtts, state, tab);

      let r;
      for (let pass = 0; pass < 2; pass++) {
        const gpt = eng === "gpt";
        const route = routeFor(eng, text, sentAtts, sendOpts, tab);
        if (route.note) addNote(route.note);
        let prompt = basePrompt;
        if (pass > 0) {
          prompt = [{ type: "text", text: "Aviso do painel: a outra conta parou no meio deste pedido porque atingiu o limite de uso. Parte do pedido pode já ter sido feita: confira o estado do projeto (get_project_state) antes de continuar e não refaça o que já está pronto." }, ...prompt];
        }
        // A conversa salva é da outra conta: começa uma nova com o resumo do que já foi feito.
        if (tab.sessionId && (tab.sessionEngine || "claude") !== eng) {
          tab.sessionId = null;
          const summary = historySummary(tab);
          if (summary) prompt = [{ type: "text", text: summary }, ...prompt];
        }
        for (let attempt = 0; attempt < 2; attempt++) {
          let streamed = false;
          currentTurn = bridgeOf(eng).runTurn(prompt, {
            exe: acct[eng].exe,
            mcp: server,
            systemPrompt: SYSTEM_PROMPT + panelContext() + (gpt ? gptEngineNote() : "") + (voiceTurn ? VOICE_HINT : ""),
            onActivity: (a) => addStep(a.label).done(a.ok !== false, a.detail || ""),
            toolNames: activeTools().map((t) => t.name),
            // Skills nativas do Claude Code + leitura de arquivos (só leitura). Rodar e gravar passa pelas ferramentas do painel.
            builtinTools: skillsEnabled() ? ["Skill", "Read", "Glob", "Grep"] : [],
            model: route.model,
            effort: route.effort,
            sessionId: tab.sessionId,
            onTextStart: () => {
              finalText = "";
              newAssistantBubble();
            },
            onText: (d) => {
              streamed = true;
              finalText += d;
              appendAssistant(d);
            },
          });
          try {
            r = await currentTurn.promise;
          } catch (e) {
            r = { is_error: true, result: e.message || String(e) };
          }
          // Sessão antiga sumiu (outro computador, limpeza do Claude Code): recomeça com um resumo.
          const msg = [r.result, ...(r.errors || [])].filter(Boolean).join(" · ");
          if (attempt === 0 && tab.sessionId && r.is_error && /no conversation found|session.*not found|no rollout found|thread\/resume failed|não encontrad/i.test(msg)) {
            tab.sessionId = null;
            const summary = historySummary(tab);
            if (summary) prompt = [{ type: "text", text: summary }, ...prompt];
            continue;
          }
          r.streamed = streamed;
          break;
        }
        r.engine = eng;
        if (r.session_id) {
          tab.sessionId = r.session_id;
          tab.sessionEngine = eng;
        }
        // Limite da assinatura: a conta descansa e, com a outra ligada, o mesmo pedido continua nela.
        const errMsg = [r.result, ...(r.errors || [])].filter(Boolean).join(" · ");
        if (pass === 0 && !r.cancelled && r.is_error && isLimitError(errMsg)) {
          limitedUntil[eng] = Date.now() + LIMIT_PAUSE;
          paintEngineState();
          const other = otherEngine(eng);
          if (settings.autoSwitch !== false && engineReady(other) && acct[other].exe && acct[other].loggedIn === true) {
            addNote(`⚠ A conta ${nameOf(eng)} atingiu o limite de uso. Continuando o pedido com a conta ${nameOf(other)}…`);
            eng = other;
            bubble = null;
            showTyping();
            continue;
          }
        }
        break;
      }
      turnResult = r;

      if (r.cancelled) {
        addError("Interrompido.");
      } else if (r.is_error) {
        const msg = [r.result, ...(r.errors || [])].filter(Boolean).join(" · ") || r.subtype || "erro desconhecido";
        if (isLimitError(msg)) {
          const other = otherEngine(r.engine);
          let hint = "";
          if (!engineOn(other)) hint = ` Para continuar agora, ligue a conta ${nameOf(other)} em ⚙ e mande de novo.`;
          else if (acct[other].loggedIn !== true) hint = ` Entre na conta ${nameOf(other)} em ⚙ para continuar com ela.`;
          else if (settings.autoSwitch === false) hint = ` Mande de novo: o próximo pedido já vai pela conta ${nameOf(other)}.`;
          addError(`Limite de uso da conta ${nameOf(r.engine)} atingido: ${msg}.${hint}`);
        } else if (/log ?in|login|auth|401|unauthorized/i.test(msg)) {
          acct[r.engine].loggedIn = false;
          openSettings();
          checkAccount();
          addError("Sua sessão do " + nameOf(r.engine) + " não está conectada. Clique em Entrar nas configurações.");
        } else {
          addError((r.engine === "gpt" ? "ChatGPT (Codex): " : "Claude Code: ") + msg);
        }
      } else if (!r.streamed && r.result) {
        appendAssistant(String(r.result));
      }
    } catch (err) {
      addError(err && err.message ? err.message : String(err));
    } finally {
      currentTurn = null;
      voiceTurnActive = false;
      // Aviso sonoro de pedido concluído (independente da voz).
      if (turnResult && !turnResult.cancelled) playDone();
      // Fala a resposta e, no modo conversa, volta a ouvir.
      if (voiceTurn && voiceOn() && turnResult && !turnResult.cancelled) {
        const said = turnResult.is_error ? "Deu um problema. Veja a mensagem no chat." : Voice.speakable(finalText || turnResult.result || "");
        if (said) {
          speakNow(said).then((res) => {
            if (res && !res.stopped && settings.voiceConvo === true && voiceOn() && !busy && !rec) startVoice();
          });
        }
      }
      importPanelSkills(); // skill que o chat acabou de criar em skills-novas
      lastTurnStarted = 0;
      paintEngineState();
      hideTyping();
      bubble = null;
      saveTab(tab);
      turnTab = null;
      setBusy(false);
      if (activeTab) {
        chatEl = activeTab.pane;
        logTab = activeTab;
      }
      renderTabs();
      inputEl.focus();
    }
  }

  function stop() {
    for (const finish of [...pendingApprovals]) finish(false);
    if (currentTurn) currentTurn.cancel();
    if (Local && Local._cancelTranscription) Local._cancelTranscription();
    if (Runner) Runner.cancelAll(); // renders e scripts das skills param junto
    stopSpeaking();
  }

  // ------------------------------------------------------------ voz liga/desliga, som, inserts, modo de edição e importação

  // Voz desligada: o painel não fala e não escuta (vale para todos os projetos, inclusive os novos).
  const voiceOn = () => settings.voiceEnabled !== false;

  // "Plim" suave de notificação quando o chat conclui um pedido. Independente da voz.
  let soundCtx = null;
  function playDone(force) {
    if (!force && settings.soundEnabled === false) return;
    const vol = Math.max(0, Math.min(100, Number(settings.soundVolume != null ? settings.soundVolume : 40))) / 100;
    if (!vol) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!soundCtx || soundCtx.state === "closed") soundCtx = new AC();
      const ac = soundCtx;
      if (ac.state === "suspended") ac.resume();
      const t0 = ac.currentTime + 0.02;
      const out = ac.createGain();
      out.gain.value = 0.32 * vol;
      const lp = ac.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 5200;
      out.connect(lp).connect(ac.destination);
      // Duas notas curtas de sino (pl-im), com um parcial agudo bem baixo para soar de "notificação".
      const notes = [
        [1174.7, 0, 0.55],
        [1568.0, 0.075, 0.9],
      ];
      for (const [f, at, len] of notes) {
        for (const [mult, amp] of [[1, 1], [2.76, 0.12]]) {
          const o = ac.createOscillator();
          const g = ac.createGain();
          o.type = "sine";
          o.frequency.value = f * mult;
          const s = t0 + at;
          g.gain.setValueAtTime(0.0001, s);
          g.gain.exponentialRampToValueAtTime(amp, s + 0.006);
          g.gain.exponentialRampToValueAtTime(0.0001, s + len * (mult > 1 ? 0.35 : 1));
          o.connect(g).connect(out);
          o.start(s);
          o.stop(s + len + 0.05);
        }
      }
    } catch {}
  }
  // Nome antigo (pedidos longos): agora é o mesmo plim.
  function chime() {
    playDone();
  }

  // ---- pasta dos inserts gerais

  function pickFolder(title, initial) {
    try {
      if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
        const r = window.cep.fs.showOpenDialogEx(false, true, title, initial || "", []);
        return r && r.err === 0 && r.data && r.data[0] ? String(r.data[0]) : "";
      }
    } catch {}
    return window.prompt(title, initial || "") || "";
  }
  function pickFile(title, types) {
    try {
      if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
        const r = window.cep.fs.showOpenDialogEx(false, false, title, "", types || []);
        return r && r.err === 0 && r.data && r.data[0] ? String(r.data[0]) : "";
      }
    } catch {}
    return window.prompt(title, "") || "";
  }
  function dirExists(p) {
    try {
      return !!p && require("fs").statSync(p).isDirectory();
    } catch {
      return false;
    }
  }
  // Sugestão: a primeira pasta "Inserts gerais" dentro de <disco>:\Clientes\<cliente>.
  function guessInsertsDir() {
    try {
      const fs = require("fs");
      const path = require("path");
      for (const d of ["G", "D", "E", "F", "C"]) {
        const base = d + ":\\Clientes";
        let clientes = [];
        try {
          clientes = fs.readdirSync(base);
        } catch {
          continue;
        }
        for (const c of clientes) {
          const p = path.join(base, c, "Inserts gerais");
          if (dirExists(p)) return p;
        }
      }
    } catch {}
    return "";
  }
  function insertsDir() {
    return dirExists(settings.insertsDir) ? settings.insertsDir : "";
  }
  function showInsertsModal(fromSettings) {
    const m = $("inserts-modal");
    $("im-dir").value = settings.insertsDir || guessInsertsDir();
    $("im-msg").textContent = "";
    $("im-later").textContent = fromSettings ? "Cancelar" : "Agora não";
    m.classList.remove("hidden");
  }
  function maybeAskInserts() {
    if (!Local || settings.insertsAsked || insertsDir()) return;
    showInsertsModal(false);
  }
  $("im-pick").addEventListener("click", () => {
    const p = pickFolder("Pasta dos inserts gerais", $("im-dir").value.trim());
    if (p) $("im-dir").value = p;
  });
  $("im-ok").addEventListener("click", () => {
    const p = $("im-dir").value.trim().replace(/[\\/]+$/, "");
    if (!dirExists(p)) {
      $("im-msg").textContent = "Essa pasta não existe neste PC. Escolha a pasta com os inserts.";
      $("im-msg").className = "hint warn";
      return;
    }
    settings.insertsDir = p;
    settings.insertsAsked = true;
    saveSettings(settings);
    $("inserts-dir").value = p;
    $("inserts-modal").classList.add("hidden");
    addNote("📁 Pasta dos inserts gerais: " + p);
  });
  $("im-later").addEventListener("click", () => {
    settings.insertsAsked = true;
    saveSettings(settings);
    $("inserts-modal").classList.add("hidden");
  });
  $("inserts-pick").addEventListener("click", () => {
    const p = pickFolder("Pasta dos inserts gerais", $("inserts-dir").value.trim() || guessInsertsDir());
    if (p) $("inserts-dir").value = p;
  });

  // ---- arquivos de fora do projeto: só entram com aprovação

  const normP = (p) =>
    String(p || "")
      .replace(/^file:\/\/\/?/i, "")
      .replace(/\//g, "\\")
      .replace(/\\+$/, "")
      .toLowerCase();
  // Pasta do projeto; e a pasta mãe, quando o .prproj está numa subpasta (Brutas/Inserts/SFX ao lado).
  function projectArea(tab) {
    const out = [];
    if (!tab || !tab.path) return out;
    try {
      const path = require("path");
      const fs = require("fs");
      const dir = path.dirname(tab.path);
      out.push(dir);
      const parent = path.dirname(dir);
      const marks = ["brutas", "inserts", "sfx", "musicas", "músicas", "trilhas"];
      let sib = false;
      try {
        sib = fs.readdirSync(parent).some((n) => marks.includes(n.toLowerCase()));
      } catch {}
      if (parent && parent !== dir && (sib || /proj|premiere|prproj/i.test(path.basename(dir)))) out.push(parent);
    } catch {}
    return out;
  }
  function importRoots(tab) {
    const roots = projectArea(tab);
    try {
      const os = require("os");
      const path = require("path");
      roots.push(path.join(os.homedir(), ".premiere-chat"), os.tmpdir(), path.join(os.homedir(), ".claude", "skills"));
    } catch {}
    return roots;
  }
  function approveImport(tab, paths) {
    if (!tab) return;
    tab.importOk = tab.importOk || [];
    for (const p of paths) {
      const n = normP(p);
      if (n && !tab.importOk.includes(n)) tab.importOk.push(n);
    }
  }
  function importAllowed(tab, p) {
    const n = normP(p);
    if (!n) return true;
    const under = (r) => {
      r = normP(r);
      return !!r && (n === r || n.startsWith(r + "\\"));
    };
    return importRoots(tab).some(under) || ((tab && tab.importOk) || []).some(under);
  }
  function outsidePaths(tab, paths) {
    return [...new Set((paths || []).map(String).filter((p) => p && !importAllowed(tab, p)))];
  }
  function needApproval(list) {
    return {
      text:
        "PRECISA_APROVACAO: estes arquivos estão fora da pasta do projeto e o usuário ainda não aprovou trazê-los:\n" +
        list.join("\n") +
        "\nChame request_import_approval com esses caminhos (e o motivo) e tente de novo só se ele aprovar.",
      isError: true,
    };
  }
  async function syncImportPolicy(tab) {
    if (!IN_PPRO) return;
    try {
      await host("PPC_setImportPolicy", enc(JSON.stringify({ roots: importRoots(tab), ok: (tab && tab.importOk) || [] })));
    } catch {}
  }
  // Chamadas de importação direto no ExtendScript (fora do PPC.importFiles / PPC.importMGT, que conferem).
  function rawImportCalls(code) {
    const found = [];
    const re = /([A-Za-z_$][\w$]*)\s*\)?\s*\.\s*(importFiles|importSequences|importAEComps|importAllAEComps|importMGT|importMGTFromLibrary)\s*\(/g;
    let m;
    while ((m = re.exec(String(code || "")))) if (m[1] !== "PPC") found.push(m[1] + "." + m[2]);
    return found;
  }
  // Mídia citada dentro de um XML do Premiere/FCP (pathurl / src).
  function xmlMediaPaths(xmlPath) {
    try {
      const s = require("fs").readFileSync(xmlPath, "utf8");
      const out = [];
      const re = /<pathurl>([^<]+)<\/pathurl>|\bsrc="(file:[^"]+)"/g;
      let m;
      while ((m = re.exec(s))) {
        let u = (m[1] || m[2] || "").replace(/&amp;/g, "&");
        try {
          u = decodeURIComponent(u);
        } catch {}
        u = u.replace(/^file:\/\/localhost\//i, "").replace(/^file:\/\/\/?/i, "");
        if (/^[A-Za-z]%3A|^[A-Za-z]:/.test(u)) out.push(u.replace(/\//g, "\\"));
      }
      return out;
    } catch {
      return [];
    }
  }

  // ---- como vamos editar: com base num projeto pronto ou do zero (skills)

  function editModeHtml(tab) {
    const m = tab.editMode;
    if (m && m.mode) {
      const label = m.mode === "base" ? "📂 Com base no projeto pronto: " + escapeHtml(String(m.path || "").split(/[\\/]/).pop()) : "✨ Do zero, seguindo as skills carregadas";
      return `<div class="mode-card chosen"><span class="mc-label">${label}</span><button class="secondary mc-change">Trocar</button></div>`;
    }
    return `<div class="mode-card">
        <div class="mc-title">Como vamos editar este projeto?</div>
        <div class="mc-actions">
          <button class="mc-opt em-base"><b>📂 Com base em um projeto pronto</b><span>escolho um projeto já editado como modelo</span></button>
          <button class="mc-opt em-zero"><b>✨ Do zero</b><span>seguindo as skills já carregadas</span></button>
        </div>
      </div>`;
  }
  function setEditMode(tab, mode) {
    tab.editMode = mode;
    saveTab(tab);
    if (!tab.log.length) renderLog(tab);
    if (mode && mode.mode === "base") approveImport(tab, [require("path").dirname(mode.path)]);
  }
  function editModeBlock(tab) {
    const m = tab && tab.editMode;
    if (!m || !m.mode) return "";
    if (m.mode === "zero")
      return "<modo_edicao>DO ZERO: o usuário escolheu editar este projeto do zero, seguindo só as skills carregadas (a skill do cliente). Não use projetos antigos como modelo.</modo_edicao>\n\n";
    return (
      `<modo_edicao>COM BASE EM UM PROJETO PRONTO: o usuário quer que este projeto siga o projeto já editado "${m.path}". ` +
      "Use-o como modelo: leia a estrutura dele (faixas, cortes, inserts, legendas, textos, efeitos, trilha e SFX) com o leitor de .prproj das skills " +
      "(run_command python ~/.claude/skills/impetus-upsell-emagrecimento/scripts/analisar_prproj.py <prproj> --lista, depois --seq <n> saida.json) e repita o mesmo padrão no material deste projeto, junto com a skill do cliente. " +
      "Não abra, altere nem salve o projeto pronto no Premiere. A pasta dele já está aprovada; mídia de outras pastas só entra com request_import_approval.</modo_edicao>\n\n"
    );
  }

  // Instruções do painel que dependem deste PC (pasta de inserts e a regra de importação).
  function panelContext() {
    const ins = insertsDir();
    return (
      "\n\nINSERTS LIBRARY: " +
      (ins
        ? `the user's general inserts base folder ("Inserts gerais") on this PC is ${ins}. When a skill points to a file under another ".../Inserts gerais/..." path (e.g. G:\\Clientes\\IMPETUS\\Inserts gerais\\...), use the same relative path under this folder; search it with Glob when a file is not at the exact path.`
        : "no general inserts folder was chosen on this PC. If a skill needs the inserts library and its path does not exist, tell the user to choose it in ⚙ (Pasta dos inserts gerais).") +
      "\n\nIMPORTING FILES FROM OUTSIDE THE PROJECT (the user's rule, enforced by the panel): never bring into the Premiere project (import, place_on_timeline, import_premiere_xml, MOGRTs, or copy_file into the project folders) any file that is outside the current project's folder without the user's approval. " +
      "Call request_import_approval first with the exact files (or one folder) and a short reason in Portuguese: it shows an approval card in the chat and waits. Batch everything you need in one request. " +
      "No approval needed for: files the user attached, files inside the project folder, files generated by you or the skills in ~/.premiere-chat or the temp folder, and skill templates inside ~/.claude/skills. " +
      "In run_extendscript, import only through PPC.importFiles(paths, bin) and PPC.importMGT(path, seconds, videoTrackIndex, audioTrackIndex) — raw app.project.importFiles / importMGT / importSequences are blocked. " +
      'If a tool answers PRECISA_APROVACAO, call request_import_approval for those files and retry only if approved; if the user refuses, continue without them (a red marker "INSERT FALTANDO: <descrição>" when it was an insert).'
    );
  }

  // ------------------------------------------------------------ eventos

  function autoGrow() {
    inputEl.style.height = "auto";
    inputEl.style.height = Math.min(inputEl.scrollHeight, 140) + "px";
  }

  inputEl.addEventListener("input", autoGrow);
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send(inputEl.value);
    }
  });
  sendBtn.addEventListener("click", () => (busy ? stop() : send(inputEl.value)));
  // Sugestões e botão SKILLS ficam dentro de cada aba (são redesenhados), então o clique é delegado.
  chatRoot.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (chip) return send(chip.textContent);
    if (e.target.closest(".skills-open")) openSkills();
    if (e.target.closest(".em-zero") && activeTab) setEditMode(activeTab, { mode: "zero", at: Date.now() });
    if (e.target.closest(".mc-change") && activeTab) setEditMode(activeTab, null);
    if (e.target.closest(".em-base") && activeTab) {
      const p = pickFile("Escolha o projeto pronto que vai servir de modelo", ["prproj"]);
      if (p && /\.prproj$/i.test(p)) setEditMode(activeTab, { mode: "base", path: p, at: Date.now() });
      else if (p) addNote("Escolha um arquivo de projeto do Premiere (.prproj).");
    }
  });
  $("btn-skills").addEventListener("click", openSkills);
  $("skills-close").addEventListener("click", () => skillsModal.classList.add("hidden"));
  skillsModal.addEventListener("click", (e) => {
    if (e.target === skillsModal) skillsModal.classList.add("hidden");
  });

  // Anexos: botão 📎, arrastar e soltar no painel, colar (Ctrl+V) print ou arquivo.
  $("btn-attach").addEventListener("click", pickFiles);

  // ------------------------------------------------------------ atualização do plugin (GitHub)
  // Publicar = subir premiere-chat.zip no repositório. Aqui só avisa; instala quando a pessoa clica.

  const Updater = window.Updater;
  const updateModal = $("update-modal");
  let updInfo = null; // último resultado de Updater.check()
  let updError = "";
  let updChecking = false;
  let updInstalling = false;
  let updNotified = false;
  const UPD_CHECK_EVERY = 3 * 60 * 60 * 1000;

  if (Updater) {
    try {
      Updater.init(extensionDir());
    } catch {}
  }

  // Skills: as que o painel criou (skills-novas) e as que vieram dentro do plugin vão para ~/.claude/skills.
  const SkillsSync = window.SkillsSync;
  function importPanelSkills() {
    if (!SkillsSync) return;
    try {
      const msg = SkillsSync.describe(SkillsSync.importNew(), null);
      if (msg) addNote(msg);
    } catch (e) {
      console.warn("skills-novas", e);
    }
  }
  if (SkillsSync && IN_PPRO) {
    setTimeout(() => {
      try {
        const msg = SkillsSync.describe(SkillsSync.importNew(), SkillsSync.syncBundle(extensionDir()));
        if (msg) addNote(msg);
      } catch (e) {
        console.warn("skills do plugin", e);
      }
    }, 2500);
  }

  function updDate(iso) {
    if (!iso) return "";
    try {
      return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
    } catch {
      return iso;
    }
  }

  function setUpdateBadge() {
    const on = !!(updInfo && updInfo.available);
    $("upd-dot").classList.toggle("hidden", !on);
    $("btn-update").title = on ? "Atualização disponível: clique para ver" : "Atualização do plugin";
  }

  async function checkUpdates(manual) {
    if (!Updater || updChecking) return;
    updChecking = true;
    if (manual) renderUpdate();
    try {
      updInfo = await Updater.check();
      updError = "";
    } catch (e) {
      updError = e.message || String(e);
    } finally {
      updChecking = false;
    }
    setUpdateBadge();
    if (!updateModal.classList.contains("hidden")) renderUpdate();
    if (!manual && updInfo && updInfo.available && !updNotified) {
      updNotified = true;
      addNote("⬆ Tem atualização nova do plugin. Clique em ⬆ no topo para ver e instalar.");
    }
  }

  function renderUpdate() {
    const body = $("update-body");
    body.innerHTML = "";
    const card = (html) => {
      const d = document.createElement("div");
      d.className = "upd-card";
      d.innerHTML = html;
      body.appendChild(d);
      return d;
    };
    if (!Updater) {
      card('<p class="hint">A atualização só funciona dentro do Premiere.</p>');
      return;
    }
    const inst = Updater.installed();
    const cfg = Updater.config();
    const c1 = card('<div class="upd-row"><span>Versão instalada</span><strong class="u-ver"></strong></div><p class="hint u-inst"></p>');
    c1.querySelector(".u-ver").textContent = "v" + inst.version;
    c1.querySelector(".u-inst").textContent = inst.installedAt ? "Instalada pela atualização em " + updDate(inst.installedAt) + (inst.message ? " · " + inst.message.split("\n")[0] : "") : "Instalada manualmente (ainda não veio pela atualização).";

    if (!cfg.repo) {
      card('<p class="hint">Nenhum repositório configurado. Coloque o nome do repositório do GitHub (ex.: <code>usuario/premiere-chat</code>) no arquivo <code>update-config.json</code> do plugin.</p>');
      return;
    }

    const c2 = card('<div class="upd-row"><span>Repositório</span><code class="u-repo"></code></div><div class="u-status"></div><div class="upd-actions"></div>');
    c2.querySelector(".u-repo").textContent = cfg.repo;
    const st = c2.querySelector(".u-status");
    const acts = c2.querySelector(".upd-actions");

    if (updInstalling) {
      st.innerHTML = '<p class="hint u-prog"></p>';
      st.querySelector(".u-prog").textContent = updInstalling === true ? "Instalando…" : updInstalling;
      return;
    }
    if (updChecking) st.innerHTML = '<p class="hint">Procurando atualização…</p>';
    else if (updError) {
      st.innerHTML = '<p class="upd-err"></p>';
      st.querySelector(".upd-err").textContent = "Não consegui verificar: " + updError;
    } else if (!updInfo) st.innerHTML = '<p class="hint">Ainda não verificado.</p>';
    else if (!updInfo.latest) st.innerHTML = '<p class="hint">O repositório ainda não tem nenhum premiere-chat.zip publicado.</p>';
    else if (!updInfo.available) {
      st.innerHTML = '<p class="upd-ok">✓ Você está com a versão mais recente.</p><p class="hint u-last"></p>';
      st.querySelector(".u-last").textContent = "Última publicação: " + updDate(updInfo.latest.date);
    } else {
      st.innerHTML = '<p class="upd-new">⬆ Atualização disponível</p><p class="hint u-when"></p><pre class="upd-notes"></pre>';
      st.querySelector(".u-when").textContent = "Publicada em " + updDate(updInfo.latest.date) + (updInfo.latest.author ? " por " + updInfo.latest.author : "");
      st.querySelector(".upd-notes").textContent = updInfo.latest.message || "(sem descrição)";
      const b = document.createElement("button");
      b.className = "primary";
      b.textContent = "Instalar atualização";
      b.addEventListener("click", installUpdate);
      acts.appendChild(b);
    }
    const chk = document.createElement("button");
    chk.className = "secondary";
    chk.textContent = updChecking ? "Verificando…" : "Verificar agora";
    chk.disabled = updChecking;
    chk.addEventListener("click", () => checkUpdates(true));
    acts.appendChild(chk);
  }

  async function installUpdate() {
    if (!updInfo || !updInfo.latest || updInstalling) return;
    if (busy) {
      addNote("⬆ Espere o pedido atual terminar para instalar a atualização.");
      return;
    }
    updInstalling = "Começando…";
    renderUpdate();
    try {
      for (const t of tabs) saveTab(t);
    } catch {}
    try {
      const r = await Updater.install(updInfo.latest, (m) => {
        updInstalling = m;
        renderUpdate();
      });
      updInstalling = false;
      const body = $("update-body");
      body.innerHTML = "";
      const d = document.createElement("div");
      d.className = "upd-card";
      d.innerHTML = '<p class="upd-ok"></p><p class="hint">O painel precisa reabrir para usar a versão nova. Se a atualização mexeu na integração com o Premiere, feche e abra o Premiere.</p><div class="upd-actions"><button class="primary">Reabrir o painel agora</button></div>';
      d.querySelector(".upd-ok").textContent = "✓ Atualizado para a versão " + r.version + ".";
      d.querySelector("button").addEventListener("click", () => location.reload());
      body.appendChild(d);
      updInfo.available = false;
      setUpdateBadge();
    } catch (e) {
      updInstalling = false;
      updError = "a instalação falhou: " + (e.message || e) + " (a versão anterior foi mantida)";
      renderUpdate();
    }
  }

  $("btn-update").addEventListener("click", () => {
    updateModal.classList.remove("hidden");
    renderUpdate();
    if (!updChecking && !updInstalling) checkUpdates(true);
  });
  $("update-close").addEventListener("click", () => updateModal.classList.add("hidden"));
  updateModal.addEventListener("click", (e) => {
    if (e.target === updateModal && !updInstalling) updateModal.classList.add("hidden");
  });
  if (Updater && IN_PPRO) {
    setTimeout(() => checkUpdates(false), 15000);
    setInterval(() => checkUpdates(false), UPD_CHECK_EVERY);
  }

  // ------------------------------------------------------------ comando de voz

  const Voice = window.Voice;
  let rec = null; // gravação em andamento
  let voiceBusy = false;
  let preparingMic = false;
  let micInfo = { list: [], def: "", muted: false, level: null, device: "", at: 0 }; // última leitura dos microfones

  function micScript() {
    try {
      return require("path").join(extensionDir(), "js", "default-mic.ps1");
    } catch {
      return null;
    }
  }

  // Lê os microfones e o padrão do Windows (sem travar o painel).
  async function refreshMics() {
    if (!Voice || !Local) return micInfo;
    const [list, def] = await Promise.all([Voice.listMicsAsync(Local.findFfmpeg()), Voice.defaultMicName(micScript())]);
    micInfo = { list, def: def.name, muted: !!def.muted, level: def.level, device: Voice.matchDevice(list, def.name), at: Date.now() };
    return micInfo;
  }

  // Microfone a usar agora: o escolhido em ⚙ (se ainda existir) ou o padrão do Windows.
  async function chooseMic(fresh) {
    if (fresh || Date.now() - micInfo.at > 15000) await refreshMics();
    else refreshMics(); // atualiza em segundo plano para a próxima vez
    if (settings.voiceMic && micInfo.list.includes(settings.voiceMic)) return { device: settings.voiceMic, why: "escolhido em ⚙" };
    if (micInfo.device) return { device: micInfo.device, why: "padrão do Windows", muted: micInfo.muted, level: micInfo.level };
    return { device: micInfo.list[0] || "", why: micInfo.def ? `padrão "${micInfo.def}" não encontrado; usando o primeiro` : "primeiro da lista" };
  }

  function fillMics() {
    const sel = $("voice-mic");
    const paint = () => {
      const cur = settings.voiceMic;
      sel.innerHTML = "";
      const o0 = document.createElement("option");
      o0.value = "";
      o0.textContent = "Padrão do Windows" + (micInfo.def ? " (agora: " + micInfo.def + (micInfo.muted ? " — MUDO" : "") + ")" : "");
      sel.appendChild(o0);
      for (const m of micInfo.list) {
        const o = document.createElement("option");
        o.value = m;
        o.textContent = m;
        sel.appendChild(o);
      }
      sel.value = cur && micInfo.list.includes(cur) ? cur : "";
      const st = $("voice-status");
      if (!Voice || !Local) st.textContent = "O comando de voz só funciona dentro do Premiere.";
      else if (!micInfo.list.length) st.textContent = "Nenhum microfone encontrado.";
      else st.textContent = "Transcrição no seu PC: " + (Voice.findWhisperCpp() ? "whisper.cpp na placa de vídeo (rápido)." : "Whisper no processador (mais lento; instale o B-roll Automático para usar a placa de vídeo).") + " No padrão do Windows, trocar de microfone ou headset no Windows já vale aqui.";
    };
    paint();
    refreshMics().then(paint);
  }

  const micBtn = $("btn-mic");
  const vbar = $("voice-bar");

  function voiceUi(state, text) {
    micBtn.classList.toggle("rec", state === "rec");
    micBtn.classList.toggle("wait", state === "wait");
    vbar.classList.toggle("hidden", state === "idle");
    vbar.classList.toggle("wait", state === "wait" || state === "speak");
    vbar.classList.toggle("speak", state === "speak");
    if (text) $("vb-text").textContent = text;
    if (state !== "rec") $("vb-level").style.width = "0%";
  }

  async function startVoice(onTranscript) {
    if (settings.voiceEnabled === false) return; // comando de voz desligado em ⚙
    stopSpeaking();
    if (useNatural() && window.NaturalVoice && settings.voiceReply !== "never") window.NaturalVoice.warmUp(serverScript());
    if (!Voice || !Local) {
      addNote("O comando de voz só funciona dentro do Premiere.");
      return;
    }
    if (rec || voiceBusy || preparingMic) return;
    preparingMic = true;
    voiceUi("wait", "Preparando o microfone…");
    let g = null, allZero = true, device = "";
    // Se o microfone sumiu (headset desligado, troca no Windows), relê o padrão e tenta de novo uma vez.
    for (let attempt = 0; attempt < 2; attempt++) {
      const pick = await chooseMic(attempt > 0);
      device = pick.device;
      if (!preparingMic) return voiceUi("idle"); // cancelado enquanto preparava
      // O Windows está com o microfone padrão no mudo (ou volume zero): avisa em vez de gravar silêncio.
      if (pick.muted || pick.level === 0) {
        preparingMic = false;
        voiceUi("idle");
        micWarning(device, pick.muted ? "está no MUDO no Windows" : "está com o volume de entrada em 0% no Windows");
        return;
      }
      if (!device) {
        preparingMic = false;
        voiceUi("idle");
        addError("Microfone: nenhum microfone encontrado. Conecte um e confira em Configurações do Windows > Som > Entrada.");
        return;
      }
      allZero = true;
      rec = Voice.record({
        ffmpeg: Local.findFfmpeg(),
        device,
        outFile: Local.workFile("voz-" + Date.now() + ".wav"),
        autoStop: settings.voiceAutoStop !== false,
        silenceSec: 1.3,
        maxSec: 60,
        onLevel: (db, speaking) => {
          if (db > -95) allZero = false;
          $("vb-level").style.width = Math.max(0, Math.min(100, ((db + 60) / 50) * 100)) + "%";
          $("vb-level").className = speaking ? "on" : "";
        },
      });
      preparingMic = false;
      voiceUi("rec", "Ouvindo (" + device + ")… " + (settings.voiceAutoStop !== false ? "para sozinho quando você parar" : "clique em 🎤 de novo para parar"));
      try {
        g = await rec.promise;
        rec = null;
        break;
      } catch (e) {
        rec = null;
        const msg = e.message || String(e);
        if (attempt === 0 && /I\/O error|could not find|não mandou áudio|not found/i.test(msg)) {
          preparingMic = true;
          voiceUi("wait", "O microfone mudou, procurando o padrão do Windows…");
          continue;
        }
        voiceUi("idle");
        addError("Microfone (" + device + "): " + msg);
        return;
      }
    }
    if (!g) return voiceUi("idle");
    if (g.cancelled) return voiceUi("idle");
    if (!g.spoke) {
      voiceUi("idle");
      addNote(
        allZero
          ? `🎤 O microfone "${g.device}" mandou silêncio total. Confira se ele não está mudo e se é o microfone padrão em Configurações do Windows > Som > Entrada (ou escolha outro em ⚙ > Comando de voz). Se nenhum funcionar, libere o microfone para apps da área de trabalho em Configurações > Privacidade > Microfone.`
          : "🎤 Não ouvi nenhum comando. Clique em 🎤 e fale de novo."
      );
      return;
    }
    voiceBusy = true;
    voiceUi("wait", "Entendendo o que você disse…");
    try {
      const t = await Voice.transcribe(g.wav, { language: settings.asrLanguage, Local, model: settings.asrModel });
      try {
        require("fs").unlinkSync(g.wav);
      } catch {}
      voiceUi("idle");
      if (!t.text) {
        addNote("🎤 Não consegui entender. Tente falar mais perto do microfone.");
        return;
      }
      if (onTranscript) {
        onTranscript(t.text);
        return;
      }
      // Com um pedido rodando, "para" / "cancela" falado interrompe.
      if (busy && /^(para|pare|parar|cancela|cancelar|stop)[.!]?$/i.test(t.text.trim())) {
        addNote("🎤 Parando o pedido.");
        stop();
        return;
      }
      const prev = inputEl.value.trim();
      inputEl.value = prev ? prev + " " + t.text : t.text;
      autoGrow();
      if (settings.voiceAutoSend !== false && !busy) send(inputEl.value, { byVoice: true });
      else inputEl.focus();
    } catch (e) {
      voiceUi("idle");
      addError("Transcrição da voz: " + (e.message || e));
    } finally {
      voiceBusy = false;
    }
  }

  // Aviso no chat com botão para abrir as configurações de som do Windows (o painel não muda nada sozinho).
  function micWarning(device, problem) {
    hideTyping();
    const el = document.createElement("div");
    el.className = "approval mic-warn";
    el.innerHTML = '<div class="ap-title"></div><p class="hint"></p><div class="ap-actions"><button class="primary">Abrir configurações de som</button><button class="secondary">Tentar de novo</button></div>';
    el.querySelector(".ap-title").textContent = "🎤 O microfone \"" + device + "\" " + problem + ".";
    el.querySelector(".hint").textContent =
      "Tire o mudo em Configurações > Sistema > Som > Entrada (ou na tecla de microfone do teclado, se houver) e clique em Tentar de novo. Se quiser usar outro microfone ou headset, é só colocá-lo como padrão do Windows: o painel acompanha.";
    const [open, retry] = el.querySelectorAll("button");
    open.addEventListener("click", () => {
      try {
        require("child_process").spawn("explorer.exe", ["ms-settings:sound"], { detached: true, stdio: "ignore" }).unref();
      } catch {}
    });
    retry.addEventListener("click", () => {
      el.remove();
      micInfo.at = 0;
      startVoice();
    });
    chatEl.appendChild(el);
    scrollDown();
  }

  function stopVoice() {
    if (rec) rec.stop();
    else if (preparingMic) preparingMic = false;
  }

  // O painel nunca abre o microfone sozinho. Quando ele espera uma resposta, o 🎤 pisca de leve
  // e o próximo clique nele usa essa resposta (ex.: retomar ou começar do zero).
  let pendingMicAnswer = null;
  function inviteMic(handler) {
    if (!Voice || !Local || settings.voiceEnabled === false) return;
    pendingMicAnswer = handler || null;
    micBtn.classList.add("invite");
    micBtn.title = "Clique para responder por voz (o microfone só liga quando você clica)";
  }
  function clearMicInvite() {
    pendingMicAnswer = null;
    micBtn.classList.remove("invite");
    micBtn.title = "Falar um comando (clique, fale e pare: ele entende sozinho). Segurar o botão também funciona.";
  }
  function startVoiceByClick() {
    const h = pendingMicAnswer;
    clearMicInvite();
    startVoice(h || undefined);
  }

  // Clique: começa (e para sozinho no silêncio) ou para na hora. Segurar: fala enquanto segura.
  let holdTimer = null, holding = false;
  micBtn.addEventListener("pointerdown", () => {
    stopSpeaking();
    if (rec) return;
    holding = false;
    holdTimer = setTimeout(() => {
      holding = true;
      startVoiceByClick();
    }, 350);
  });
  micBtn.addEventListener("pointerup", () => {
    clearTimeout(holdTimer);
    if (holding) {
      holding = false;
      stopVoice();
    } else if (rec || preparingMic) stopVoice();
    else startVoiceByClick();
  });
  micBtn.addEventListener("pointerleave", () => clearTimeout(holdTimer));
  $("vb-cancel").addEventListener("click", () => {
    preparingMic = false;
    if (rec) rec.cancel();
    stopSpeaking();
    voiceUi("idle");
  });

  // ------------------------------------------------------------ resposta falada

  function gptEngineNote() {
    let list = "";
    try {
      if (Local) {
        const items = [];
        items.push({ id: "novo-projeto-edicao", desc: "Regra principal para começar qualquer projeto de edição de vídeo de cliente." });
        for (const c of Local.listClientSkills().clients || []) for (const s of c.skills) if (s.existe) items.push({ id: s.id, desc: "[" + c.cliente + "] " + s.desc });
        for (const s of Local.listToolSkills()) items.push(s);
        list = items.map((s) => "- " + s.id + ": " + String(s.desc || "").slice(0, 260)).join("\n");
      }
    } catch {}
    const dir = require("path").join(require("os").homedir(), ".claude", "skills").replace(/\\/g, "/");
    return (
      "\n\nENGINE NOTE — you are running as the ChatGPT brain of this panel (through Codex), not Claude Code. Everything above still applies, with these differences:\n" +
      "- There is NO Skill, Read, Glob or Grep tool. Skills are folders in " + dir + "/<id>/. To load a skill, read " + dir + "/<id>/SKILL.md with read_text_file, then read the reference files it points to (read_text_file for text, read_document for images/DOCX), and FOLLOW it exactly as described above. Use paths with forward slashes.\n" +
      "- Your shell is read-only and is only for listing/reading files (e.g. dir, type, rg). Never edit files, run scripts or render through the shell: use the panel tools (run_command, write_text_file, make_folders, copy_file, place_on_timeline...).\n" +
      "- This is not a coding task and there is no repository: do not offer code reviews, patches or git. You are a video editor working inside Adobe Premiere Pro.\n" +
      "- Never use paid APIs (including OpenAI API calls, image/voice generation services) — same rule as above.\n" +
      (list ? "Available skills (id: when to use):\n" + list + "\n" : "")
    );
  }

  const VOICE_HINT = "\n\nVOICE MODE: the user is talking to you by voice and will HEAR the start of your final reply (read aloud by the panel). Begin the final reply with one or two short, natural spoken sentences in Portuguese that say the result or ask the one question you need (no file paths, lists, code or numbers with many digits in them). Details can follow in text below. When you need an approval or a choice, say it plainly so the user can answer by voice.";
  let voiceTurnActive = false;
  let speaking = null; // { stop, stopped }

  function ttsScript() {
    try {
      return require("path").join(extensionDir(), "js", "tts.ps1");
    } catch {
      return null;
    }
  }

  function fillVoices() {
    const sel = $("voice-name");
    sel.innerHTML = "";
    const script = ttsScript();
    const list = Voice && script ? Voice.listVoices(script) : [];
    const pt = list.filter((v) => /^pt/i.test(v.lang));
    const others = list.filter((v) => !/^pt/i.test(v.lang));
    const NV = window.NaturalVoice;
    {
      const o = document.createElement("option");
      o.value = "natural";
      o.textContent = "✨ Natural (Chatterbox, placa de vídeo)" + (NV && NV.isInstalled() ? "" : " — não instalada");
      sel.appendChild(o);
    }
    for (const v of pt.concat(others)) {
      const o = document.createElement("option");
      o.value = v.id;
      o.textContent = v.name + (v.lang ? " · " + v.lang : "");
      sel.appendChild(o);
    }
    if (!list.length) sel.insertAdjacentHTML("beforeend", '<option value="">Voz padrão do Windows</option>');
    sel.value =
      settings.voiceName === "natural" || (!settings.voiceName && NV && NV.isInstalled())
        ? "natural"
        : settings.voiceName && list.some((v) => v.id === settings.voiceName)
        ? settings.voiceName
        : (pt[0] && pt[0].id) || "";
    updateNaturalBox();
  }

  // Fala o texto com a voz escolhida. -> Promise<{ stopped }>
  function useNatural() {
    const NV = window.NaturalVoice;
    if (!NV || !NV.isInstalled()) return false;
    return settings.voiceName === "natural" || !settings.voiceName;
  }

  function serverScript() {
    const d = extensionDir();
    return d ? require("path").join(d, "js", "servidor_voz.py") : null;
  }

  function speakNatural(text) {
    stopSpeaking();
    const h = window.NaturalVoice.speak(text, {
      script: serverScript(),
      ffmpeg: Local.findFfmpeg(),
      fx: settings.voiceFx || "nenhum",
      ref: settings.voiceRef || null,
      exaggeration: settings.voiceEmo != null ? settings.voiceEmo : 0.4,
      onStatus: (m) => voiceUi("speak", "🔊 " + m),
    });
    const me = { stop: h.stop, stopped: false };
    speaking = me;
    voiceUi("speak", "🔊 " + (text.length > 70 ? text.slice(0, 70) + "…" : text));
    return h.promise.then((res) => {
      if (speaking === me) {
        speaking = null;
        if (!rec) voiceUi("idle");
      }
      if (res && !res.ok && !me.stopped) {
        // Reserva: se a voz natural falhar, fala com a do Windows.
        addNote("A voz natural falhou (" + res.error + "). Usando a voz do Windows.");
        return speakWindows(text);
      }
      return { stopped: me.stopped, error: null };
    });
  }

  function speakNow(text) {
    if (!text || !voiceOn()) return Promise.resolve({ stopped: true });
    if (useNatural() && Local) return speakNatural(text);
    return speakWindows(text);
  }

  function speakWindows(text) {
    const script = ttsScript();
    if (!Voice || !script || !text) return Promise.resolve({ stopped: true });
    stopSpeaking();
    let voice = settings.voiceName && settings.voiceName !== "natural" ? settings.voiceName : "";
    if (!voice) {
      const pt = Voice.listVoices(script).filter((v) => /^pt/i.test(v.lang));
      voice = pt[0] ? pt[0].id : "";
    }
    const h = Voice.speak(text, { script, voice, rate: settings.voiceRate || 0 });
    const me = { stop: h.stop, stopped: false };
    speaking = me;
    voiceUi("speak", "🔊 " + (text.length > 70 ? text.slice(0, 70) + "…" : text));
    return h.promise.then((res) => {
      if (speaking === me) {
        speaking = null;
        if (!rec) voiceUi("idle");
      }
      if (res && !res.ok && !me.stopped) addNote("Não consegui falar: " + (res.error || "erro na voz do Windows"));
      return { stopped: me.stopped, error: res && !res.ok ? res.error || "erro na voz do Windows" : null };
    });
  }

  function stopSpeaking() {
    if (!speaking) return;
    speaking.stopped = true;
    speaking.stop();
    speaking = null;
    if (!rec) voiceUi("idle");
  }

  function updateNaturalBox() {
    const NV = window.NaturalVoice;
    const isNat = $("voice-name").value === "natural";
    $("natural-box").classList.toggle("hidden", !isNat);
    const st = $("natural-status");
    const inst = $("natural-install");
    if (!NV) {
      st.textContent = "A voz natural só funciona dentro do Premiere.";
      inst.classList.add("hidden");
    } else if (!NV.isInstalled()) {
      st.textContent = "A voz natural ainda não está instalada neste PC. Ela roda na placa de vídeo, sem internet depois de instalada.";
      inst.classList.remove("hidden");
    } else {
      st.textContent = "Voz natural instalada. Na primeira fala ela leva alguns segundos para carregar (depois fica pronta por 15 min sem uso).";
      inst.classList.add("hidden");
    }
  }
  $("voice-name").addEventListener("change", updateNaturalBox);
  $("voice-ref-pick").addEventListener("click", () => $("voice-ref-file").click());
  $("voice-ref-file").addEventListener("change", (e) => {
    const f = e.target.files && e.target.files[0];
    if (f && f.path) $("voice-ref").value = f.path;
  });
  $("natural-install").addEventListener("click", () => {
    const d = extensionDir();
    if (!d) return;
    const ps1 = require("path").join(d, "js", "instalar-voz.ps1");
    // Janela visível: mostra o download e a instalação (alguns GB, uma vez só).
    require("child_process").spawn("cmd.exe", ["/c", "start", "Instalando a voz natural", "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-NoExit", "-File", ps1], { detached: true, stdio: "ignore" }).unref();
    $("natural-status").textContent = "Instalando numa janela separada. Quando terminar, feche-a e abra as configurações de novo.";
  });

  $("voice-test").addEventListener("click", () => {
    settings.voiceName = $("voice-name").value;
    settings.voiceRate = Number($("voice-rate").value) || 0;
    settings.voiceFx = $("voice-fx").value;
    settings.voiceEmo = Number($("voice-emo").value) || 0.4;
    settings.voiceRef = $("voice-ref").value.trim();
    const st = $("voice-status");
    const btn = $("voice-test");
    if (!Voice || !Local || !ttsScript()) {
      st.textContent = "A voz só funciona dentro do Premiere.";
      return;
    }
    btn.disabled = true;
    st.textContent = "🔊 Tocando com a voz " + ($("voice-name").selectedOptions[0] ? $("voice-name").selectedOptions[0].textContent : "padrão") + "…";
    speakNow("Oi! É assim que eu vou te responder aqui no Premiere.").then((r) => {
      btn.disabled = false;
      st.textContent = r.error ? "Não consegui falar: " + r.error : "Pronto. Se não ouviu nada, confira o volume e a saída de som do Windows.";
    });
  });
  if (!Voice || !Local) micBtn.title = "Comando de voz (só dentro do Premiere)";
  function applyVoiceEnabled() {
    const off = settings.voiceEnabled === false;
    micBtn.classList.toggle("voice-off", off);
    const vb = $("btn-voice");
    vb.classList.toggle("off", off);
    vb.setAttribute("aria-pressed", off ? "false" : "true");
    vb.title = off ? "Comando de voz desligado: o painel não fala e não escuta (clique para ligar)" : "Comando de voz ligado (clique para desligar)";
    if ($("voice-enabled")) $("voice-enabled").checked = !off;
    if (off) {
      clearMicInvite();
      stopSpeaking();
      if (rec || preparingMic) $("vb-cancel").click();
    }
  }
  applyVoiceEnabled();
  $("btn-voice").addEventListener("click", () => {
    settings.voiceEnabled = settings.voiceEnabled === false;
    saveSettings(settings);
    applyVoiceEnabled();
  });
  $("file-input").addEventListener("change", (e) => {
    Array.from(e.target.files || []).forEach(addAttachmentFile);
    e.target.value = "";
  });
  const overlay = $("drop-overlay");
  let dragDepth = 0;
  const hasFiles = (e) => e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files");
  document.addEventListener("dragenter", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth++;
    overlay.classList.remove("hidden");
  });
  document.addEventListener("dragover", (e) => {
    if (hasFiles(e)) e.preventDefault();
  });
  document.addEventListener("dragleave", () => {
    if (--dragDepth <= 0) {
      dragDepth = 0;
      overlay.classList.add("hidden");
    }
  });
  document.addEventListener("drop", (e) => {
    e.preventDefault();
    dragDepth = 0;
    overlay.classList.add("hidden");
    Array.from((e.dataTransfer && e.dataTransfer.files) || []).forEach(addAttachmentFile);
  });
  inputEl.addEventListener("paste", (e) => {
    const files = Array.from((e.clipboardData && e.clipboardData.files) || []);
    if (!files.length) return;
    e.preventDefault();
    files.forEach(addAttachmentFile);
  });

  // Nova conversa: a anterior vai para ~/.premiere-chat/historico/arquivo e a aba recomeça.
  $("btn-new").addEventListener("click", () => newConversation(activeTab));

  // Arquiva a conversa da aba e começa uma nova (o histórico antigo fica guardado em disco).
  function newConversation(tab) {
    if (!tab) return;
    if (busy && turnTab === tab) stop();
    if (Local && tab.key !== "preview") {
      try {
        Local.archiveHistory(tab.key);
      } catch {}
    }
    tab.log = [];
    tab.sessionId = null;
    tab.lastRoute = null;
    tab.editMode = null;
    tab.importOk = [];
    saveTab(tab);
    renderLog(tab);
  }

  $("btn-settings").addEventListener("click", () => {
    $("settings").classList.toggle("hidden");
    if (!$("settings").classList.contains("hidden")) setTimeout(fillDeviceLists, 50);
  });
  $("btn-login").addEventListener("click", () => startLogin("claude"));
  $("btn-recheck").addEventListener("click", () => {
    checkAccount();
    checkLocalTools();
  });
  $("btn-backups").addEventListener("click", () => {
    if (!Local) return;
    try {
      require("child_process").spawn("explorer.exe", [Local.backupsDir()], { detached: true, stdio: "ignore" }).unref();
    } catch {
      addNote("Backups em: " + Local.backupsDir());
    }
  });

  function fillSettingsForm() {
    $("engine").value = settings.engine === "gpt" ? "gpt" : "claude";
    $("use-claude").checked = settings.useClaude !== false;
    $("use-gpt").checked = settings.useGpt === true;
    $("auto-switch").checked = settings.autoSwitch !== false;
    $("sound-enabled").checked = settings.soundEnabled !== false;
    $("sound-volume").value = settings.soundVolume != null ? settings.soundVolume : 40;
    $("inserts-dir").value = settings.insertsDir || "";
    const gm = settings.gptModel == null ? "auto" : settings.gptModel;
    $("gpt-model-mode").value = gm === "auto" || gm === "" ? gm : "custom";
    $("gpt-model").value = gm === "auto" ? "" : gm;
    $("gpt-path").value = settings.gptPath || "";
    showEngineFields();
    $("model").value = settings.model;
    $("effort").value = settings.effort;
    $("claude-path").value = settings.claudePath;
    $("show-code").checked = settings.showCode;
    $("backup").checked = settings.backup;
    $("asr-model").value = settings.asrModel;
    $("asr-language").value = settings.asrLanguage;
    $("allow-skills").checked = settings.allowSkills !== false;
    deviceListsFilled = false;
    $("voice-autosend").checked = settings.voiceAutoSend !== false;
    $("voice-autostop").checked = settings.voiceAutoStop !== false;
    $("voice-reply").value = settings.voiceReply || "voice";
    $("voice-rate").value = settings.voiceRate || 0;
    $("voice-convo").checked = settings.voiceConvo !== false;
    $("voice-enabled").checked = settings.voiceEnabled !== false;
    $("voice-greet").value = settings.voiceGreet || "always";
    $("voice-fx").value = settings.voiceFx || "nenhum";
    $("voice-emo").value = settings.voiceEmo != null ? settings.voiceEmo : 0.4;
    $("voice-ref").value = settings.voiceRef || "";
    $("write-roots").value = settings.writeRoots || "";
  }

  // Mostra os campos do cérebro escolhido (modelos do Claude ou do ChatGPT).
  function showEngineFields() {
    const c = $("use-claude").checked;
    const g = $("use-gpt").checked;
    $("model-claude").classList.toggle("hidden", !c);
    $("model-gpt").classList.toggle("hidden", !g);
    $("gpt-model").classList.toggle("hidden", $("gpt-model-mode").value !== "custom");
    $("engine").parentElement.parentElement.classList.toggle("hidden", !(c && g));
    $("auto-switch").parentElement.classList.toggle("hidden", !(c && g));
    $("acct-claude").classList.toggle("off", !c);
    $("acct-gpt").classList.toggle("off", !g);
  }
  // Chave de cada conta vale na hora (sem precisar de Salvar).
  for (const [id, key] of [["use-claude", "useClaude"], ["use-gpt", "useGpt"]]) {
    $(id).addEventListener("change", () => {
      if (!$("use-claude").checked && !$("use-gpt").checked) {
        $(id).checked = true;
        addNote("Pelo menos uma conta precisa ficar ligada.");
        return;
      }
      settings[key] = $(id).checked;
      saveSettings(settings);
      showEngineFields();
      checkAccount();
    });
  }
  $("engine").addEventListener("change", () => {
    settings.engine = $("engine").value === "gpt" ? "gpt" : "claude";
    settings.engineChosen = true;
    saveSettings(settings);
    paintEngineState();
  });
  $("btn-gpt-login").addEventListener("click", () => startLogin("gpt"));
  $("sound-test").addEventListener("click", () => {
    const keep = settings.soundVolume;
    settings.soundVolume = Number($("sound-volume").value);
    playDone(true);
    settings.soundVolume = keep;
  });
  $("gpt-model-mode").addEventListener("change", showEngineFields);
  $("btn-gpt-install").addEventListener("click", startGptInstall);

  $("btn-save").addEventListener("click", () => {
    const gmMode = $("gpt-model-mode").value;
    const newEngine = $("engine").value === "gpt" ? "gpt" : "claude";
    const pathChanged = settings.claudePath !== $("claude-path").value.trim() || (settings.gptPath || "") !== $("gpt-path").value.trim();
    const before = engine();
    const insDir = $("inserts-dir").value.trim().replace(/[\\/]+$/, "");
    if (insDir && !dirExists(insDir)) addNote("⚠ A pasta dos inserts gerais não existe neste PC: " + insDir);
    settings = {
      ...settings,
      engineChosen: true,
      engine: newEngine,
      useClaude: $("use-claude").checked,
      useGpt: $("use-gpt").checked,
      autoSwitch: $("auto-switch").checked,
      soundEnabled: $("sound-enabled").checked,
      soundVolume: Number($("sound-volume").value),
      insertsDir: insDir,
      insertsAsked: settings.insertsAsked || !!insDir,
      gptModel: gmMode === "custom" ? $("gpt-model").value.trim() || "auto" : gmMode,
      gptPath: $("gpt-path").value.trim(),
      modelRouterMigrated: true,
      voiceNaturalMigrated: true,
      voiceGreetMigrated: true,
      model: $("model").value,
      effort: $("effort").value,
      claudePath: $("claude-path").value.trim(),
      showCode: $("show-code").checked,
      backup: $("backup").checked,
      asrModel: $("asr-model").value,
      asrLanguage: $("asr-language").value,
      allowSkills: $("allow-skills").checked,
      voiceMic: $("voice-mic").value,
      voiceAutoSend: $("voice-autosend").checked,
      voiceAutoStop: $("voice-autostop").checked,
      voiceReply: $("voice-reply").value,
      voiceName: $("voice-name").value,
      voiceRate: Number($("voice-rate").value) || 0,
      voiceConvo: $("voice-convo").checked,
      voiceEnabled: $("voice-enabled").checked,
      voiceGreet: $("voice-greet").value,
      voiceFx: $("voice-fx").value,
      voiceEmo: Number($("voice-emo").value) || 0.4,
      voiceRef: $("voice-ref").value.trim(),
      writeRoots: $("write-roots").value,
    };
    saveSettings(settings);
    applyVoiceEnabled();
    $("settings").classList.add("hidden");
    if (pathChanged) checkAccount();
    else paintEngineState();
    if (engine() !== before) addNote("🧠 Próximos pedidos pela conta " + nameOf(engine()) + ". A conversa continua; ela recebe um resumo do que já foi feito.");
  });

  window.addEventListener("beforeunload", () => {
    if (currentTurn) currentTurn.cancel();
    if (mcp) mcp.close();
  });

  window.addEventListener("beforeunload", () => tabs.forEach(saveTab));

  // Abas: dentro do Premiere seguem os projetos abertos; fora dele, uma aba de prévia.
  if (IN_PPRO && Local) {
    syncProjects();
    setInterval(syncProjects, 2000);
  } else {
    selectTab(makeTab({ name: "Prévia" }), false);
  }

  // Aba Decupagem
  if (window.DecupUI) {
    window.DecupUI.init({
      host,
      enc,
      inPremiere: IN_PPRO,
      Local,
      hostAppPath,
      runInPremiere,
      // Decupagem mexe em muita coisa: faz backup sempre, mesmo com a opção desligada.
      backup: async () => {
        if (!IN_PPRO || !Local) return;
        try {
          const res = await host("PPC_save");
          if (res.ok && res.result) Local.backupProject(res.result);
        } catch {}
      },
    });
  }
  function showView(v) {
    const decup = v === "decup";
    document.body.classList.toggle("mode-decup", decup);
    $("decup").classList.toggle("hidden", !decup);
    $("view-chat").classList.toggle("active", !decup);
    $("view-decup").classList.toggle("active", decup);
    if (decup && window.DecupUI) window.DecupUI.shown();
  }
  $("view-chat").addEventListener("click", () => showView("chat"));
  $("view-decup").addEventListener("click", () => showView("decup"));

  fillSettingsForm();
  checkLocalTools();
  checkAccount().then((ok) => {
    if (!ok) openSettings();
  });
  // Primeira vez neste PC: escolher a pasta dos inserts gerais.
  setTimeout(maybeAskInserts, 900);
})();
