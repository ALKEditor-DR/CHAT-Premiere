/*
 * Aba Efeitos: sub-abas SFX, Transições, Textos e Light leaks.
 * As mesmas ações servem ao chat (window.EfeitosUI.api), para as skills usarem nas edições.
 */
(function () {
  "use strict";
  const E = window.Efeitos;
  if (!E) return;
  const $ = (id) => document.getElementById(id);
  const node = typeof require === "function";
  const fs = node ? require("fs") : null;
  const path = node ? require("path") : null;
  const os = node ? require("os") : null;

  let deps = null;
  let root = null;
  let sub = "sfx";
  const AUDIO = /\.(wav|mp3|aif|aiff|m4a|aac|ogg|flac)$/i;

  // ---------------------------------------------------------------- dados salvos (valem para todos os projetos)

  const STORE = node ? path.join(os.homedir(), ".premiere-chat", "efeitos.json") : null;
  const EMPTY = { sfxFolders: [], fav: { sfx: [], tr: [], tx: [], lk: [] }, trDur: 1, trForce: 100, lkForce: 70, text: {} };
  let data = load();
  function load() {
    let d = {};
    try {
      d = JSON.parse(node ? fs.readFileSync(STORE, "utf8") : localStorage.getItem("premierechat.efeitos") || "{}");
    } catch {}
    return Object.assign({}, EMPTY, d, { fav: Object.assign({ sfx: [], tr: [], tx: [], lk: [] }, d.fav), sfxFolders: d.sfxFolders || [] });
  }
  function save() {
    try {
      const s = JSON.stringify(data, null, 1);
      if (node) {
        fs.mkdirSync(path.dirname(STORE), { recursive: true });
        fs.writeFileSync(STORE, s, "utf8");
      } else localStorage.setItem("premierechat.efeitos", s);
    } catch {}
  }
  const isFav = (k, id) => data.fav[k].includes(id);
  function toggleFav(k, id) {
    const l = data.fav[k];
    const i = l.indexOf(id);
    if (i >= 0) l.splice(i, 1);
    else l.push(id);
    save();
    return i < 0;
  }

  // ---------------------------------------------------------------- ações no Premiere

  async function info() {
    if (!deps.inPremiere) throw new Error("Abra o painel dentro do Premiere.");
    const r = await deps.host("PPC_fxInfo");
    if (!r.ok) throw new Error(r.error);
    return r.result;
  }

  async function applyTransition(id, o) {
    const tr = E.transition(id);
    if (!tr) throw new Error("Transição não encontrada: " + id);
    const i = await info();
    const half = Math.max(0.1, ((o.duration || tr.dur) * (o.speed || 1)) / 2);
    const opts = {
      half,
      where: o.where || "playhead",
      track: o.track || "",
      outOps: E.compile(tr, "out", half, i.fps, o.force),
      inOps: E.compile(tr, "in", half, i.fps, o.force),
    };
    const r = await deps.host("PPC_fxTransition", deps.enc(JSON.stringify(opts)));
    if (!r.ok) throw new Error(r.error);
    return r.result;
  }

  async function removeTransition(o) {
    await info();
    const r = await deps.host("PPC_fxTransition", deps.enc(JSON.stringify({ half: 0.5, where: o.where || "playhead", track: o.track || "", outOps: [], inOps: [], remove: true })));
    if (!r.ok) throw new Error(r.error);
    return r.result;
  }

  // Coloca um arquivo na timeline. O arquivo foi escolhido pela pessoa (ou gerado aqui): só ele é liberado.
  async function place(file, item) {
    await deps.host("PPC_setImportPolicy", deps.enc(JSON.stringify({ roots: [], ok: [file] })));
    const r = await deps.host("PPC_place", deps.enc(JSON.stringify({ target: "active", bin: item.bin, items: [Object.assign({ file }, item)], markers: [] })));
    if (!r.ok) throw new Error(r.error);
    if (!r.result.placed.length) throw new Error((r.result.skipped[0] && r.result.skipped[0].reason) || "não consegui colocar na timeline");
    return r.result.placed[0];
  }
  async function topTrack(a, b) {
    const r = await deps.host("PPC_fxTop", String(a), String(b));
    return r.ok ? "V" + r.result : "auto-video";
  }

  // Duração do áudio: sem ela o Premiere poderia colocar o SFX por cima do áudio seguinte da trilha.
  function audioDur(file) {
    return new Promise((res) => {
      const a = new Audio();
      const t = setTimeout(() => res(null), 4000);
      const end = (v) => {
        clearTimeout(t);
        res(v);
      };
      a.onloadedmetadata = () => end(isFinite(a.duration) && a.duration > 0.04 ? a.duration : null);
      a.onerror = () => end(null);
      a.preload = "metadata";
      a.src = fileUrl(file);
    });
  }
  async function insertSfx(file) {
    const i = await info();
    const dur = await audioDur(file);
    return place(file, Object.assign({ track: "auto-audio", start: i.playhead, bin: "Efeitos/SFX" }, dur ? { duration: dur } : {}));
  }

  function mediaDir(projectPath) {
    const base = projectPath ? path.join(path.dirname(projectPath), "_efeitos") : path.join(os.homedir(), ".premiere-chat", "efeitos", "midia");
    fs.mkdirSync(base, { recursive: true });
    return base;
  }
  const slug = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 40) || "efeito";

  // Desenha quadro a quadro e grava um .mov com transparência (ProRes 4444).
  async function renderMov(o) {
    const ff = deps.Local && deps.Local.findFfmpeg();
    if (!ff) throw new Error("ffmpeg não encontrado neste PC (ele vem com o instalador do plugin).");
    const cv = document.createElement("canvas");
    cv.width = o.w;
    cv.height = o.h;
    const ctx = cv.getContext("2d", { willReadFrequently: true });
    const total = Math.max(2, Math.round(o.dur * o.fps));
    const tmp = o.file + ".parte.mov";
    const vf = (o.outW && (o.outW !== o.w || o.outH !== o.h) ? `scale=${o.outW}:${o.outH}:flags=bicubic:` : "scale=") + "out_color_matrix=bt709:out_range=tv";
    const args = ["-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", o.w + "x" + o.h, "-r", String(o.fps), "-i", "-", "-vf", vf, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-alpha_bits", "8", "-qscale:v", "9", "-vendor", "apl0", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", tmp];
    const p = require("child_process").spawn(ff, args, { windowsHide: true, stdio: ["pipe", "ignore", "pipe"] });
    let err = "";
    p.stderr.on("data", (d) => (err = (err + d).slice(-2000)));
    const closed = new Promise((res) => {
      p.on("error", (e) => res(String(e.message || e)));
      p.on("close", (c) => res(c === 0 ? "" : err || "ffmpeg saiu com código " + c));
    });
    let img = null;
    let dead = false;
    closed.then(() => (dead = true));
    p.stdin.on("error", () => (dead = true));
    for (let f = 0; f < total && !dead; f++) {
      const t = f / o.fps;
      // Trecho parado (o texto ja entrou e ainda nao saiu): repete o quadro anterior.
      const still = img && o.still && t > o.still[0] + 1 / o.fps && t < o.still[1];
      if (!still) {
        o.draw(ctx, o.w, o.h, t);
        img = ctx.getImageData(0, 0, o.w, o.h);
        if (o.post) o.post(img.data);
      }
      // Cópia: o buffer do canvas não pode mudar enquanto o ffmpeg lê.
      if (!p.stdin.write(Buffer.from(img.data.buffer.slice(0)))) await Promise.race([new Promise((r) => p.stdin.once("drain", r)), closed]);
      if (o.onProgress && f % 5 === 0) o.onProgress(Math.round((f / total) * 100));
      if (f % 3 === 0) await new Promise((r) => setTimeout(r, 0));
    }
    if (!dead) p.stdin.end();
    const e = await closed;
    if (e) {
      try {
        fs.unlinkSync(tmp);
      } catch {}
      throw new Error("Falha ao gerar o vídeo: " + e);
    }
    fs.renameSync(tmp, o.file);
    return o.file;
  }

  async function insertText(cfgIn, o) {
    const cfg = Object.assign({}, E.textDefaults, cfgIn);
    if (!E.text(cfg.preset)) throw new Error("Texto animado não encontrado: " + cfg.preset);
    // Sempre guarda em partes: assim o texto reabre nos campos, inclusive o que veio do chat.
    cfg.segs = (cfg.segs || E.toSegs(cfg.text)).filter((s) => String(s.t).trim());
    cfg.text = E.plain(cfg);
    const vir = E.text(cfg.preset).viral;
    cfg.segs = cfg.segs.map((s, n) => {
      const md = vir ? vir[Math.min(n, vir.length - 1)] : { f: cfg.font };
      const fo = E.fontOf(s, s.hl != null ? !!s.hl : !!md.hl, md.f, md.w);
      return Object.assign({}, s, { font: fo.f, weight: fo.w, own: true });
    });
    if (!cfg.text) throw new Error("Escreva o texto.");
    cfg.dur = Math.max(0.6, Math.min(20, Number(cfg.dur) || 3));
    const i = await info();
    try {
      for (const s of cfg.segs.concat((E.text(cfg.preset).viral || []).map((l) => ({ font: l.f, weight: l.w })))) await document.fonts.load(E.cssFont(40, s.font || cfg.font, s.weight));
    } catch {}
    const file = path.join(mediaDir(i.project), `texto-${slug(cfg.text)}-${Date.now().toString(36)}.mov`);
    await renderMov({ w: even(i.w), h: even(i.h), fps: i.fps, dur: cfg.dur, file, draw: (c, w, h, t) => E.drawText(c, w, h, t, cfg), still: E.textStill(cfg), onProgress: o && o.onProgress });
    fs.writeFileSync(file + ".json", JSON.stringify(cfg, null, 1), "utf8");
    if (o && o.replace) {
      const r = await deps.host("PPC_fxReplace", deps.enc(o.replace), deps.enc(file));
      if (!r.ok) throw new Error(r.error);
      return { file, replaced: true };
    }
    const start = o && o.start != null ? Number(o.start) : i.playhead;
    const track = (o && o.track) || (await topTrack(start, start + cfg.dur));
    return Object.assign({ file }, await place(file, { track, start, duration: cfg.dur, bin: "Efeitos/Textos", name: cfg.text.slice(0, 40) }));
  }
  const even = (n) => Math.round(n / 2) * 2;

  async function insertLeak(id, o) {
    const lk = E.leak(id);
    if (!lk) throw new Error("Light leak não encontrado: " + id);
    const i = await info();
    const dur = Math.max(0.3, Math.min(20, Number(o && o.duration) || lk.dur));
    const force = Math.max(0.1, Math.min(1.5, (o && o.force) || 0.7));
    const k = Math.min(1, 640 / Math.max(i.w, i.h)); // luz difusa: desenha pequeno e amplia
    const w = even(i.w * k);
    const h = even(i.h * k);
    // O mesmo leak (mesmo tamanho, duração e força) é reaproveitado.
    const file = path.join(mediaDir(i.project), `leak-${lk.id}-${even(i.w)}x${even(i.h)}-${Math.round(i.fps * 100)}-${Math.round(dur * 100)}-${Math.round(force * 100)}.mov`);
    if (!fs.existsSync(file))
      await renderMov({ w, h, outW: even(i.w), outH: even(i.h), fps: i.fps, dur, file, draw: (c, W, H, t) => E.drawLeak(c, W, H, t, dur, lk, force), post: E.toAlpha, onProgress: o && o.onProgress });
    const center = o && o.at != null ? Number(o.at) : i.playhead;
    const start = Math.max(0, lk.move === "drift" ? center : center - dur / 2);
    const track = (o && o.track) || (await topTrack(start, start + dur));
    return Object.assign({ file }, await place(file, { track, start, duration: dur, bin: "Efeitos/Light leaks" }));
  }

  // ---------------------------------------------------------------- biblioteca de textos da pessoa (MOGRT)

  let lib = null; // { file, seq, seqId, w, h, items }
  let libErr = "";
  // Fica em ~/.premiere-chat (uma por biblioteca), não na pasta da pessoa.
  const libPreview = () => {
    if (!data.lib || !node) return "";
    let h = 0;
    for (const ch of data.lib.toLowerCase()) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return path.join(os.homedir(), ".premiere-chat", "efeitos", "previas", "meus-textos-" + h.toString(36) + ".webm");
  };
  function loadLib() {
    lib = null;
    libErr = "";
    E.texts = E.texts.filter((t) => !t.lib);
    if (!data.lib || !window.TextLib) return;
    try {
      lib = window.TextLib.load(data.lib);
      E.texts.push(...lib.items.map((it) => ({ id: it.id, cat: "Texto Viral", sub: it.group, mine: true, lib: it, nome: "Meu " + it.group + " · " + it.n, sample: "", from: {}, unit: "line", len: 0.4, stag: 0.1 })));
    } catch (e) {
      libErr = e.message || String(e);
    }
  }
  const libCfg = (it) => {
    data.libCfg = data.libCfg || {};
    const c = (data.libCfg[it.id] = Object.assign({ texts: [], ctl: {}, k: 100, dur: Math.round((it.end - it.start) * 10) / 10 }, data.libCfg[it.id]));
    it.controls.filter((x) => x.type === "text").forEach((x) => {
      c.texts[x.i] = c.texts[x.i] || { t: "", size: 100 };
    });
    return c;
  };
  const ctlKey = (c) => c.name + "#" + c.n;
  const libModel = (x) => {
    const f = window.TextLib.psFonts().byPs.get(x.ps);
    return { f: f ? f.family : x.ps, w: f ? f.w : 400 };
  };
  // Qual parte é o destaque: a marcada no MOGRT; senão a de fonte diferente das outras; senão a maior.
  function libHl(it, c, x) {
    const own = c.texts[x.i] && c.texts[x.i].hl;
    if (own != null) return own;
    const tx = it.controls.filter((k) => k.type === "text");
    if (tx.length === 1) return true;
    if (tx.some((k) => /destaque/i.test(k.name))) return /destaque/i.test(x.name);
    const n = {};
    tx.forEach((k) => (n[k.ps] = (n[k.ps] || 0) + 1));
    if (Object.keys(n).length > 1) return n[x.ps] === Math.min(...Object.values(n));
    return x.size === Math.max(...tx.map((k) => k.size));
  }
  const REAL_OF = { "VT Poppins": "Poppins", "VT Anton": "Anton", "VT Montserrat": "Montserrat", "VT Bebas": "Bebas Neue", "VT Abril": "Abril Fatface" };
  const libPs = (f, w) => window.TextLib.ps(REAL_OF[f] || f, w);
  // Nome interno da fonte que a parte deve ter ("" = fica a do modelo).
  function libFontPs(it, c, x) {
    if (!x.fontEdit) return "";
    const m = libModel(x);
    const fo = E.fontOf(c.texts[x.i], libHl(it, c, x), m.f, m.w);
    const ps = libPs(fo.f, fo.w);
    return ps && ps !== x.ps ? ps : "";
  }
  // o: { texts: [string], start, track, duration }
  async function insertLib(id, o) {
    o = o || {};
    if (!lib) loadLib();
    const it = lib && lib.items.find((x) => x.id === id);
    if (!it) throw new Error(libErr || "Texto não encontrado na biblioteca: " + id);
    const c = libCfg(it);
    const i = await info();
    const texts = it.controls
      .filter((x) => x.type === "text")
      .map((x) => {
        const t = c.texts[x.i];
        const own = o.texts ? o.texts[x.i] : t.t;
        const r = { i: x.i };
        if (own != null && String(own).trim()) r.text = String(own);
        const ps = libFontPs(it, c, x);
        if (ps) r.ps = ps;
        if (x.sizeEdit && t.size && t.size !== 100) r.size = Math.round(x.size * t.size) / 100;
        return r;
      })
      .filter((r) => r.text != null || r.ps || r.size);
    const colors = [];
    const nums = [];
    for (const k of it.controls) {
      const v = c.ctl[ctlKey(k)];
      if (v == null || v === k.value) continue;
      if (k.type === "color") colors.push({ name: k.name, n: k.n, rgb: [1, 3, 5].map((p) => parseInt(v.slice(p, p + 2), 16)) });
      else if (k.type === "num") nums.push({ name: k.name, n: k.n, v: Number(v) });
    }
    // O projeto da biblioteca foi escolhido pela pessoa: só ele é liberado para importar.
    await deps.host("PPC_setImportPolicy", deps.enc(JSON.stringify({ roots: [], ok: [data.lib] })));
    const opts = { lib: data.lib, seqId: lib.seqId, seqName: lib.seq, clipStart: it.start, start: o.start != null ? Number(o.start) : i.playhead, duration: Number(o.duration || c.dur) || it.end - it.start, track: o.track || "", scale: it.scale, seqW: lib.w, k: (c.k || 100) / 100, texts, colors, nums };
    const r = await deps.host("PPC_fxLibInsert", deps.enc(JSON.stringify(opts)));
    if (!r.ok) throw new Error(r.error);
    return r.result;
  }
  // Prévias: exporta a sequência da biblioteca uma vez e reduz (fica ao lado do projeto da pessoa).
  // Chave do que muda a aparência: projeto salvo + fontes padrão + fontes escolhidas por linha.
  function prevKey() {
    let m = 0;
    try {
      m = fs.statSync(data.lib).mtimeMs;
    } catch {}
    const own = lib ? lib.items.map((it) => it.controls.filter((x) => x.type === "text").map((x) => libFontPs(it, libCfg(it), x))) : [];
    return JSON.stringify([m, own]);
  }
  let prevCache = null;
  function prevInfo() {
    const f = libPreview().replace(/webm$/, "json");
    if (prevCache && prevCache.f === f) return prevCache;
    let d = {};
    try {
      d = JSON.parse(fs.readFileSync(f, "utf8"));
    } catch {}
    return (prevCache = { f, key: d.key || "", boxes: d.boxes || {} });
  }
  const run = (args) =>
    new Promise((res, rej) => {
      const p = require("child_process").spawn(deps.Local.findFfmpeg(), args, { windowsHide: true, stdio: ["ignore", "ignore", "pipe"] });
      let err = "";
      p.stderr.on("data", (d) => (err = (err + d).slice(-200000)));
      p.on("error", rej);
      p.on("close", (c) => (c === 0 ? res(err) : rej(new Error("ffmpeg: " + err.slice(-200)))));
    });
  function findAme() {
    let best = "";
    try {
      for (const d of fs.readdirSync("C:\\Program Files\\Adobe")) {
        const e = path.join("C:\\Program Files\\Adobe", d, "Adobe Media Encoder.exe");
        if (/^Adobe Media Encoder/i.test(d) && d > path.basename(path.dirname(best || "a")) && fs.existsSync(e)) best = e;
      }
    } catch {}
    return best;
  }
  const exec = (cmd, args, ms) =>
    new Promise((res) => require("child_process").execFile(cmd, args, { windowsHide: true, timeout: ms || 15000, encoding: "utf8" }, (e, o) => res({ ok: !e, out: String(o || "") })));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ameOpen = async () => /Adobe Media Encoder/i.test((await exec("tasklist", ["/FI", "IMAGENAME eq Adobe Media Encoder.exe", "/NH"])).out);
  /*
   * Miniaturas pelo Media Encoder, a partir de uma CÓPIA do projeto com as fontes padrão: não mexe no
   * Premiere nem no projeto da pessoa. Com o Media Encoder já aberto não faz nada (poderia soltar a fila dela).
   */
  let making = null;
  function makePreviews(say) {
    return (making = making || doPreviews(say || (() => {})).finally(() => (making = null)));
  }
  // Menor area que contem o texto em todos os quadros do trecho (pixel a pixel, fundo preto).
  function textBox(file, start, dur, w, h) {
    return new Promise((res, rej) => {
      const p = require("child_process").spawn(deps.Local.findFfmpeg(), ["-v", "error", "-ss", String(start), "-t", String(dur), "-i", file, "-vf", `fps=5,scale=${w}:${h},format=gray`, "-f", "rawvideo", "-"], { windowsHide: true, stdio: ["ignore", "pipe", "ignore"] });
      const parts = [];
      p.stdout.on("data", (b) => parts.push(b));
      p.on("error", rej);
      p.on("close", () => {
        const d = Buffer.concat(parts);
        const n = Math.floor(d.length / (w * h));
        let x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (let f = 0; f < n; f++)
          for (let y = 0; y < h; y++)
            for (let x = 0, o = (f * h + y) * w; x < w; x++)
              if (d[o + x] > 45) {
                if (x < x0) x0 = x;
                if (x > x1) x1 = x;
                if (y < y0) y0 = y;
                if (y > y1) y1 = y;
              }
        if (x1 - x0 < 6 || y1 - y0 < 6) return res(null);
        const m = 6; // respiro para o brilho
        x0 = Math.max(0, x0 - m);
        y0 = Math.max(0, y0 - m);
        res([x0, y0, Math.min(w, x1 + 1 + m) - x0, Math.min(h, y1 + 1 + m) - y0]);
      });
    });
  }
  async function doPreviews(say) {
    const ame = findAme();
    if (!ame) throw new Error("O Adobe Media Encoder não está instalado: as miniaturas ficam paradas.");
    if (await ameOpen()) throw new Error("Feche o Adobe Media Encoder e tente de novo (para não mexer na sua fila).");
    const key = prevKey();
    const dir = path.join(os.homedir(), ".premiere-chat", "efeitos", "previas");
    const work = path.join(dir, "trabalho");
    fs.mkdirSync(work, { recursive: true });
    const prj = path.join(work, "biblioteca.prproj");
    const out = path.join(work, "previas.mp4");
    const jsx = path.join(work, "exportar.jsx");
    for (const f of [prj, out, jsx])
      try {
        fs.unlinkSync(f);
      } catch {}
    const map = {};
    for (const it of lib.items)
      for (const x of it.controls.filter((c) => c.type === "text")) {
        const ps = libFontPs(it, libCfg(it), x);
        if (ps) map[x.pid] = ps;
      }
    window.TextLib.withFonts(data.lib, prj, map);
    const q = JSON.stringify;
    // Sem acento e sem caractere especial no script: so os caminhos, escapados.
    const esc = (t) => q(t).replace(/[\u0080-\uffff]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"));
    fs.writeFileSync(jsx, `var fe = app.getFrontend(); fe.addDLToBatch(${esc(prj)}, "H.264", "", ${esc(lib.seqId)}, ${esc(out)}); app.getEncoderHost().runBatch();`, "utf8");
    say("Gerando as miniaturas dos seus textos (1 a 2 minutos)…");
    require("child_process").spawn(ame, ["--console", "es.processFile", jsx], { detached: true, stdio: "ignore", windowsHide: true }).unref();
    let ready = false;
    let last = -1;
    const end = Date.now() + 6 * 60000;
    try {
      while (Date.now() < end) {
        await sleep(4000);
        let n = 0;
        try {
          n = fs.statSync(out).size;
        } catch {}
        // Só está pronto quando para de crescer e o ffmpeg consegue abrir.
        if (n > 0 && n === last) {
          try {
            await run(["-v", "error", "-i", out, "-frames:v", "1", "-f", "null", "-"]);
            ready = true;
            break;
          } catch {}
        }
        last = n;
      }
    } finally {
      // Fomos nós que abrimos: fecha pelo caminho normal (sem forçar).
      await exec("taskkill", ["/IM", "Adobe Media Encoder.exe"]);
    }
    if (!ready) throw new Error("O Media Encoder não terminou as miniaturas.");
    say("Recortando as miniaturas…");
    const tmp = path.join(work, "previas.webm");
    await run(["-y", "-v", "error", "-i", out, "-an", "-vf", "scale=720:720:force_original_aspect_ratio=decrease:force_divisible_by=2,fps=30", "-c:v", "libvpx", "-b:v", "2500k", "-g", "10", "-deadline", "realtime", "-cpu-used", "5", tmp]);
    // Área do texto de cada um (fundo preto), no trecho em que ele já entrou.
    const boxes = {};
    const k0 = 720 / Math.max(lib.w, lib.h);
    const W = Math.floor((lib.w * k0) / 2) * 2;
    const H = Math.floor((lib.h * k0) / 2) * 2;
    for (const it of lib.items) {
      const d = it.end - it.start;
      try {
        const b = await textBox(tmp, it.start + d * 0.1, d * 0.8, W, H);
        if (b) boxes[it.id] = b;
      } catch {}
    }
    if (!Object.keys(boxes).length) throw new Error("As miniaturas saíram vazias.");
    fs.copyFileSync(tmp, libPreview());
    fs.writeFileSync(libPreview().replace(/webm$/, "json"), JSON.stringify({ key, boxes }), "utf8");
    prevCache = null;
    libVideo = null;
    for (const f of [prj, out, jsx, tmp])
      try {
        fs.unlinkSync(f);
      } catch {}
  }
  // Ao abrir os Textos: gera sozinho quando falta ou quando a biblioteca/fonte mudou (no máximo uma vez por abertura).
  let autoDone = "";
  function autoPreviews() {
    if (!deps.inPremiere || !lib || making || !findAme()) return;
    const k = prevKey();
    if (autoDone === k || (fs.existsSync(libPreview()) && prevInfo().key === k)) return;
    autoDone = k;
    makePreviews(status).then(
      () => {
        status("✓ Miniaturas prontas.", "ok");
        // Só redesenha os cartões: não fecha o texto que a pessoa está editando.
        document.querySelectorAll("#efeitos .fx-card.mine").forEach((c) => c._still && c._still());
        mountLib();
      },
      (e) => status(e.message || String(e), "bad")
    );
  }

  // ---------------------------------------------------------------- SFX: pastas

  let sfx = [];
  let scanning = null;
  async function scan() {
    if (!node) return [];
    const list = [];
    const walk = async (dir, base, depth) => {
      if (depth > 8 || list.length > 8000) return;
      let ents = [];
      try {
        ents = await fs.promises.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of ents) {
        if (e.name.startsWith(".")) continue;
        const p = path.join(dir, e.name);
        if (e.isDirectory()) await walk(p, base, depth + 1);
        else if (AUDIO.test(e.name)) {
          const rel = path.relative(base, dir);
          list.push({ file: p, name: e.name.replace(/\.[^.]+$/, ""), cat: rel ? rel.split(path.sep)[0] : path.basename(base) });
        }
      }
    };
    for (const f of data.sfxFolders) await walk(f, f, 0);
    const seen = new Set();
    sfx = list.filter((s) => !seen.has(s.file.toLowerCase()) && seen.add(s.file.toLowerCase())).sort((a, b) => a.name.localeCompare(b.name, "pt", { numeric: true }));
    return sfx;
  }
  const rescan = () => (scanning = scan().finally(() => (scanning = null)));

  // ---------------------------------------------------------------- interface

  const ICON = {
    star: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 16.8 6.6 19.7l1.1-6.1L3.2 9.4l6.1-.8z"/></svg>',
    play: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4l12 8-12 8z"/></svg>',
    stop: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
    plus: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  };
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };
  function status(text, cls) {
    const lm = $("lib-msg"); // a biblioteca fica em ⚙
    if (lm) {
      lm.textContent = text || "";
      lm.className = "hint" + (cls === "bad" ? " warn" : "");
    }
    const s = $("fx-status");
    if (!s) return;
    s.textContent = text || "";
    s.className = "fx-status" + (cls ? " " + cls : "");
  }
  // Uma ação por vez; erro sempre aparece na barra.
  let working = false;
  async function act(label, fn) {
    if (working) return;
    if (deps.isBusy && deps.isBusy()) return status("Espere o chat terminar o pedido atual.", "bad");
    working = true;
    root.classList.add("working");
    status(label + "…");
    try {
      status(await fn(), "ok");
    } catch (e) {
      status(e.message || String(e), "bad");
    } finally {
      working = false;
      root.classList.remove("working");
    }
  }

  function starBtn(kind, id, onChange) {
    const b = el("button", "fx-star" + (isFav(kind, id) ? " on" : ""), ICON.star);
    const paint = () => {
      b.classList.toggle("on", isFav(kind, id));
      b.title = isFav(kind, id) ? "Tirar dos favoritos" : "Favoritar";
      b.setAttribute("aria-pressed", String(isFav(kind, id)));
    };
    paint();
    b.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleFav(kind, id);
      paint();
      if (onChange) onChange();
    });
    return b;
  }

  const ui = { sfx: { q: "", cat: "", fav: false, max: 150 }, tr: { q: "", cat: "", fav: false }, tx: { q: "", cat: "", fav: false }, lk: { q: "", cat: "", fav: false } };
  const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

  // Busca + favoritos + categorias (iguais nas quatro sub-abas).
  function filters(kind, cats, repaint) {
    const u = ui[kind];
    const box = el("div", "fx-filters");
    const row = el("div", "fx-row");
    const q = el("input", "fx-search");
    q.type = "search";
    q.placeholder = "Buscar…";
    q.value = u.q;
    q.setAttribute("aria-label", "Buscar");
    q.addEventListener("input", () => {
      u.q = q.value;
      repaint();
    });
    const fv = el("button", "fx-favs" + (u.fav ? " on" : ""), ICON.star + "Favoritos");
    fv.addEventListener("click", () => {
      u.fav = !u.fav;
      fv.classList.toggle("on", u.fav);
      repaint();
    });
    row.append(q, fv);
    const chips = el("div", "fx-cats");
    for (const c of ["", ...cats]) {
      const b = el("button", "fx-cat" + (u.cat === c ? " on" : ""));
      b.textContent = c || "Tudo";
      b.addEventListener("click", () => {
        u.cat = c;
        chips.querySelectorAll(".fx-cat").forEach((x) => x.classList.toggle("on", x === b));
        repaint();
      });
      chips.appendChild(b);
    }
    box.append(row);
    if (cats.length > 1) box.append(chips);
    return box;
  }
  const match = (kind, it, id, name) => {
    const u = ui[kind];
    return (!u.fav || isFav(kind, id)) && (!u.cat || it.cat === u.cat) && (!u.q || norm(name + " " + (it.cat || "")).includes(norm(u.q)));
  };

  // ---- SFX
  let player = null;
  let playing = null;
  let ac = null;
  const fileUrl = (p) => "file:///" + encodeURI(p.replace(/\\/g, "/")).replace(/#/g, "%23").replace(/\?/g, "%3F");
  function stopSfx() {
    if (player) player.pause();
    if (playing) {
      playing.classList.remove("on");
      playing.querySelector(".fx-play").innerHTML = ICON.play;
    }
    playing = null;
  }
  async function wave(row, file) {
    const cv = row.querySelector("canvas");
    if (cv.dataset.ok || !node) return;
    try {
      if (fs.statSync(file).size > 20e6) return;
      const buf = await fs.promises.readFile(file);
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      const a = await ac.decodeAudioData(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
      const d = a.getChannelData(0);
      const x = cv.getContext("2d");
      x.clearRect(0, 0, cv.width, cv.height);
      x.fillStyle = getComputedStyle(root).getPropertyValue("--accent") || "#8b7cf6";
      const step = Math.max(1, Math.floor(d.length / cv.width));
      for (let i = 0; i < cv.width; i++) {
        let m = 0;
        for (let j = i * step; j < (i + 1) * step; j += 4) m = Math.max(m, Math.abs(d[j] || 0));
        const h = Math.max(1, m * cv.height);
        x.fillRect(i, (cv.height - h) / 2, 1, h);
      }
      cv.dataset.ok = "1";
      row.querySelector(".fx-dur").textContent = a.duration.toFixed(1).replace(".", ",") + " s";
    } catch {}
  }
  function playSfx(row, file) {
    if (playing === row) return stopSfx();
    stopSfx();
    player = player || new Audio();
    player.src = fileUrl(file);
    player.onended = stopSfx;
    playing = row;
    row.classList.add("on");
    row.querySelector(".fx-play").innerHTML = ICON.stop;
    player.play().catch(() => {
      stopSfx();
      status("O painel não toca este formato, mas dá para inserir na timeline.", "bad");
    });
    wave(row, file);
  }
  function sfxRow(s, repaint) {
    const r = el("div", "fx-sfx");
    r.title = s.file + "\nArraste para a timeline, ou clique em + para colocar na agulha";
    r.draggable = true;
    const pb = el("button", "fx-play", ICON.play);
    pb.title = "Ouvir";
    pb.addEventListener("click", () => playSfx(r, s.file));
    const mid = el("div", "fx-mid", '<div class="fx-name"></div><canvas width="160" height="18"></canvas>');
    mid.querySelector(".fx-name").textContent = s.name;
    mid.addEventListener("dblclick", () => playSfx(r, s.file));
    const ins = el("button", "fx-add", ICON.plus);
    ins.title = "Colocar na agulha";
    ins.addEventListener("click", () =>
      act("Colocando o SFX", async () => {
        const p = await insertSfx(s.file);
        return "✓ " + s.name + " em " + p.track + " · " + p.start.toFixed(2).replace(".", ",") + " s";
      })
    );
    r.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("com.adobe.cep.dnd.file.0", s.file);
      e.dataTransfer.effectAllowed = "copy";
    });
    r.append(pb, mid, el("span", "fx-dur"), starBtn("sfx", s.file, () => ui.sfx.fav && repaint()), ins);
    return r;
  }
  function paintSfx(body) {
    const top = el("div", "fx-bar");
    const addB = el("button", "primary", "＋ Importar pasta de SFX");
    addB.addEventListener("click", () => {
      const p = deps.pickFolder("Escolha a pasta com os seus SFX", data.sfxFolders[0] || "");
      if (!p) return;
      if (data.sfxFolders.some((f) => f.toLowerCase() === p.toLowerCase())) return status("Essa pasta já está na lista.");
      data.sfxFolders.push(p);
      save();
      status("Lendo a pasta…");
      rescan().then(() => {
        paint();
        status(sfx.filter((s) => s.file.toLowerCase().startsWith(p.toLowerCase())).length + " SFX importados de " + path.basename(p) + ".", "ok");
      });
    });
    const re = el("button", "secondary", "Atualizar");
    re.title = "Ler as pastas de novo";
    re.addEventListener("click", () => {
      status("Lendo as pastas…");
      rescan().then(() => {
        paint();
        status(sfx.length + " SFX.", "ok");
      });
    });
    top.append(addB, re);
    body.append(top);
    if (data.sfxFolders.length) {
      const fl = el("div", "fx-folders");
      for (const f of data.sfxFolders) {
        const c = el("span", "fx-folder");
        c.title = f;
        c.textContent = f.split(/[\\/]/).filter(Boolean).pop() || f;
        const x = el("button", "", "✕");
        x.title = "Tirar da aba (não apaga nada do disco)";
        x.addEventListener("click", () => {
          data.sfxFolders = data.sfxFolders.filter((k) => k !== f);
          save();
          rescan().then(paint);
        });
        c.append(x);
        fl.append(c);
      }
      body.append(fl);
    }
    const list = el("div", "fx-list");
    const repaint = () => {
      list.innerHTML = "";
      stopSfx();
      const f = sfx.filter((s) => match("sfx", s, s.file, s.name));
      f.slice(0, ui.sfx.max).forEach((s) => list.append(sfxRow(s, repaint)));
      if (f.length > ui.sfx.max) {
        const m = el("button", "secondary", "Mostrar mais (" + (f.length - ui.sfx.max) + ")");
        m.addEventListener("click", () => {
          ui.sfx.max += 150;
          repaint();
        });
        list.append(m);
      }
      if (!f.length) list.append(el("p", "fx-empty", scanning ? "Lendo as pastas…" : !data.sfxFolders.length ? "Importe uma pasta para ver os seus SFX aqui. Os arquivos continuam onde estão." : ui.sfx.fav ? "Nenhum favorito aqui. Clique na estrela de um SFX." : "Nada encontrado."));
    };
    const cats = [...new Set(sfx.map((s) => s.cat))].sort((a, b) => a.localeCompare(b, "pt"));
    if (ui.sfx.cat && !cats.includes(ui.sfx.cat)) ui.sfx.cat = "";
    body.append(filters("sfx", cats, repaint), list);
    repaint();
  }

  // ---- prévias em canvas
  let hover = null;
  function animate(cv, draw, dur) {
    const start = performance.now();
    const me = (hover = {});
    const tick = (n) => {
      if (hover !== me || !cv.isConnected) return;
      draw(((n - start) / 1000) % dur);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
  function card(kind, it, o) {
    const c = el("div", "fx-card" + (o.tall ? " tall" : ""));
    c.tabIndex = 0;
    const cv = el("canvas");
    cv.width = o.w || 176;
    cv.height = o.h || 100;
    const x = cv.getContext("2d");
    const draw = (t) => o.draw(x, cv.width, cv.height, t);
    draw(o.still);
    const on = () => animate(cv, draw, o.loop);
    const off = () => {
      hover = null;
      draw(o.still);
    };
    c.addEventListener("mouseenter", on);
    c.addEventListener("mouseleave", off);
    c.addEventListener("focus", on);
    c.addEventListener("blur", off);
    const foot = el("div", "fx-foot");
    const nm = el("span", "fx-name");
    nm.textContent = it.nome;
    foot.append(nm, starBtn(kind, it.id, o.onFav));
    c.append(cv, foot);
    c.addEventListener("click", () => o.click(c));
    c.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.key === " ") && e.target === c) {
        e.preventDefault();
        o.click(c);
      }
    });
    return c;
  }

  // Duas cenas simples (A e B), desenhadas aqui, para mostrar o movimento.
  const scenes = {};
  function scene(w, h, which) {
    const key = which + w + "x" + h;
    if (scenes[key]) return scenes[key];
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const x = c.getContext("2d");
    const g = x.createLinearGradient(0, 0, w, h);
    (which === "A" ? ["#2b2a5e", "#8b7cf6", "#e7a6ff"] : ["#0f3d4c", "#2fb3a3", "#f3e08a"]).forEach((col, i) => g.addColorStop(i / 2, col));
    x.fillStyle = g;
    x.fillRect(0, 0, w, h);
    x.globalAlpha = 0.5;
    x.fillStyle = which === "A" ? "#1a1838" : "#0a2630";
    x.beginPath();
    for (let i = 0; i <= 6; i++) x.lineTo((w / 6) * i, h * (0.62 + (i % 2 ? -0.16 : 0.1) * (which === "A" ? 1 : -1)));
    x.lineTo(w, h);
    x.lineTo(0, h);
    x.fill();
    x.globalAlpha = 0.9;
    x.fillStyle = "#fff";
    x.beginPath();
    x.arc(w * (which === "A" ? 0.72 : 0.28), h * 0.3, h * 0.11, 0, 7);
    x.fill();
    x.font = `700 ${Math.round(h * 0.34)}px Arial`;
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillText(which, w / 2, h * 0.56);
    return (scenes[key] = c);
  }
  function drawTransition(x, w, h, t, tr, force) {
    const hold = 0.45;
    const half = tr.dur / 2;
    const T = hold + half;
    const side = t < T ? "out" : "in";
    const u = side === "out" ? Math.max(0, (t - hold) / half) : Math.max(0, 1 - (t - T) / half);
    const s = E.state(tr, side, u, force);
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.filter = "none";
    x.globalAlpha = 1;
    x.fillStyle = "#000";
    x.fillRect(0, 0, w, h);
    const blur = s.b * 0.06;
    if (blur > 0.2) x.filter = `blur(${blur}px)`;
    const one = (ox, oy, alpha) => {
      x.save();
      x.globalAlpha = alpha;
      x.translate(w / 2 + s.dx * w, h / 2 + s.dy * h);
      x.rotate((s.r * Math.PI) / 180);
      x.transform(1, 0, Math.tan((s.k * Math.PI) / 180) * 0.6, 1, 0, 0);
      x.scale(s.s * s.sx, s.s);
      const img = scene(w, h, side === "out" ? "A" : "B");
      const fx = ((((s.wx + ox) % 1) + 1) % 1) * w;
      const fy = ((((s.wy + oy) % 1) + 1) % 1) * h;
      for (const a of [0, -w]) for (const b of [0, -h]) if (fx + a < w && fy + b < h) x.drawImage(img, -w / 2 + fx + a, -h / 2 + fy + b);
      x.restore();
    };
    if (s.db > 1) {
      const n = 9;
      const L = s.db / 500;
      for (let i = 0; i < n; i++) {
        const o = (i / (n - 1) - 0.5) * L;
        one(s.dir === 90 ? o : 0, s.dir === 90 ? 0 : o, 1 / (i + 1));
      }
    } else one(0, 0, 1);
    x.filter = "none";
    if (s.e) {
      x.globalAlpha = Math.min(0.96, Math.abs(s.e) / 5);
      x.fillStyle = s.e > 0 ? "#fff" : "#000";
      x.fillRect(0, 0, w, h);
      x.globalAlpha = 1;
    }
  }

  // ---- Transições
  const range = (label, min, max, val, fmt, set) => {
    const l = el("label", "fx-range");
    const t = el("span");
    const i = el("input");
    i.type = "range";
    i.min = min;
    i.max = max;
    i.value = val;
    const p = () => (t.textContent = label + " " + fmt(Number(i.value)));
    p();
    i.addEventListener("input", () => {
      set(Number(i.value));
      p();
    });
    i.addEventListener("change", save);
    l.append(t, i);
    return l;
  };
  let trSel = null;
  function paintTr(body) {
    const grid = el("div", "fx-grid");
    const bar = el("div", "fx-sticky");
    const ctl = el("div", "fx-row");
    ctl.append(
      range("Duração", 50, 200, Math.round((data.trDur || 1) * 100), (v) => v + " %", (v) => (data.trDur = v / 100)),
      range("Força", 25, 150, data.trForce || 100, (v) => v + " %", (v) => (data.trForce = v))
    );
    const go = (where) => {
      const t = trSel && E.transition(trSel);
      if (!t) return status("Escolha uma transição primeiro.", "bad");
      act("Aplicando " + t.nome, async () => {
        const r = await applyTransition(t.id, { where, speed: data.trDur, force: (data.trForce || 100) / 100 });
        return "✓ " + t.nome + " em " + (r.done.length === 1 ? r.done[0] : r.done.length + " cortes") + (r.skipped.length ? " · " + r.skipped.length + " pulado(s): " + r.skipped[0].reason : "") + " (Ctrl+Z desfaz)";
      });
    };
    const btns = el("div", "fx-row");
    const b1 = el("button", "primary", "Aplicar no corte da agulha");
    b1.addEventListener("click", () => go("playhead"));
    const b2 = el("button", "secondary", "Nos clipes selecionados");
    b2.title = "Aplica em todos os cortes entre os clipes selecionados";
    b2.addEventListener("click", () => go("selected"));
    const b3 = el("button", "secondary", "Tirar do corte");
    b3.title = "Tira a transição do painel no corte da agulha (aplicar outra já troca sozinho)";
    b3.addEventListener("click", () => act("Tirando", async () => "✓ Transição tirada de " + (await removeTransition({})).done[0]));
    btns.append(b1, b2, b3);
    bar.append(ctl, btns);
    const repaint = () => {
      grid.innerHTML = "";
      const f = E.transitions.filter((t) => match("tr", t, t.id, t.nome));
      for (const t of f) {
        const c = card("tr", t, {
          still: 0.45 + t.dur * 0.36,
          loop: 0.9 + t.dur + 0.3,
          draw: (x, w, h, s) => drawTransition(x, w, h, s, t, (data.trForce || 100) / 100),
          onFav: () => ui.tr.fav && repaint(),
          click: (n) => {
            trSel = t.id;
            grid.querySelectorAll(".fx-card").forEach((k) => k.classList.toggle("sel", k === n));
            status(t.nome + " escolhida.");
          },
        });
        c.classList.toggle("sel", trSel === t.id);
        c.addEventListener("dblclick", () => go("playhead"));
        grid.append(c);
      }
      if (!f.length) grid.append(el("p", "fx-empty", "Nada encontrado."));
    };
    body.append(filters("tr", [...new Set(E.transitions.map((t) => t.cat))], repaint), grid, bar);
    repaint();
  }

  // ---- Fontes instaladas
  const WEIGHTS = { 100: "Finíssima", 200: "Extra leve", 250: "Finíssima", 275: "Extra leve", 300: "Leve", 350: "Semi leve", 400: "Normal", 500: "Média", 600: "Semi negrito", 700: "Negrito", 800: "Extra negrito", 900: "Preta" };
  let fonts = [["Arial", [400, 700, 900]], ["Arial Black", [400]], ["Georgia", [400, 700]], ["Impact", [400]], ["Segoe UI", [300, 400, 600, 700, 900]], ["Times New Roman", [400, 700]], ["Verdana", [400, 700]]].map(([name, w]) => ({ name, w }));
  // Vêm dentro do plugin (pasta fontes): funcionam em qualquer PC, sem instalar.
  const VT = [["VT Abril", [400]], ["VT Anton", [400]], ["VT Bebas", [400]], ["VT Montserrat", [700, 900]], ["VT Poppins", [500, 600]]].map(([name, w]) => ({ name, w }));
  fonts.push(...VT);
  let fontsLoaded = null;
  function loadFonts() {
    if (!fontsLoaded)
      fontsLoaded = new Promise((res) => {
        try {
          const ps = path.join(deps.extDir, "js", "fontes.ps1");
          require("child_process").execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps], { windowsHide: true, timeout: 20000, maxBuffer: 4e6, encoding: "utf8" }, (err, out) => {
            const l = String(out || "").replace(/^\uFEFF/, "").split(/\r?\n/).map((x) => x.split("\t")).filter((x) => x[0] && x[1]);
            if (err || l.length < 5) return res(false);
            fonts = l.map(([name, w]) => ({ name: name.trim(), w: w.split(",").map(Number) }));
            fonts.push(...VT);
            if (!fonts.some((f) => f.name === "Arial Black")) fonts.push({ name: "Arial Black", w: [400] });
            applyFonts();
            fonts.sort((a, b) => a.name.localeCompare(b.name, "pt"));
            res(true);
          });
        } catch {
          res(false);
        }
      });
    return fontsLoaded;
  }
  let closeFonts = null;
  // Lista de fontes, cada uma na própria letra, com busca. onPick({ name, w }).
  function pickFont(anchor, current, sampleText, onPick, allow) {
    const again = closeFonts && closeFonts.anchor === anchor;
    if (closeFonts) closeFonts();
    if (again) return;
    const box = el("div", "fx-fontbox");
    const q = el("input", "fx-search");
    q.type = "search";
    q.placeholder = "Buscar fonte…";
    q.setAttribute("aria-label", "Buscar fonte");
    const list = el("div", "fx-fontlist");
    box.append(q, list);
    const close = () => {
      box.remove();
      document.removeEventListener("pointerdown", out, true);
      closeFonts = null;
    };
    close.anchor = anchor;
    const out = (e) => {
      if (!box.contains(e.target) && !anchor.contains(e.target)) close();
    };
    let shown = [];
    let n = 0;
    const more = () => {
      for (const f of shown.slice(n, n + 40)) {
        const b = el("button", "fx-fontitem" + (f.name === current ? " on" : ""));
        const s = el("span", "fx-fontsample");
        s.textContent = sampleText || f.name;
        s.style.fontFamily = `"${f.name}"`;
        s.style.fontWeight = f.w.filter((v) => v <= 800).pop() || 400;
        const nm = el("small");
        nm.textContent = f.name + (f.w.length > 1 ? " · " + f.w.length + " pesos" : "");
        b.append(s, nm);
        b.addEventListener("click", () => {
          onPick(f);
          close();
        });
        list.append(b);
      }
      n += 40;
    };
    const filter = () => {
      shown = fonts.filter((f) => norm(f.name).includes(norm(q.value)) && (!allow || allow(f)));
      n = 0;
      list.innerHTML = "";
      more();
      if (!shown.length) list.append(el("p", "fx-empty", "Nenhuma fonte com esse nome neste PC."));
    };
    q.addEventListener("input", filter);
    q.addEventListener("keydown", (e) => {
      if (e.key === "Escape") close();
      if (e.key === "Enter" && shown[0]) {
        onPick(shown[0]);
        close();
      }
    });
    list.addEventListener("scroll", () => {
      if (list.scrollTop + list.clientHeight > list.scrollHeight - 120) more();
    });
    filter();
    anchor.after(box);
    document.addEventListener("pointerdown", out, true);
    closeFonts = close;
    q.focus();
    const on = list.querySelector(".on");
    if (on) list.scrollTop = on.offsetTop - list.offsetTop;
  }

  // Fonte e peso de uma parte. o: { hl(), model: { f, w }, ta, sample, check(f, w) }
  function fontRow(seg, o) {
    const fr = el("div", "fx-fontrow");
    const fb = el("button", "fx-fontbtn");
    const wt = el("select", "fx-weight");
    wt.title = "Peso da letra";
    wt.setAttribute("aria-label", "Peso da letra");
    const bk = el("button", "fx-part-swap", "usar padrão");
    const now = () => E.fontOf(seg, o.hl(), o.model.f, o.model.w);
    const paintFont = () => {
      const c = now();
      const ws = (fonts.find((f) => f.name === c.f) || { w: [] }).w;
      const w = ws.length && !ws.includes(c.w) ? ws.reduce((a, b) => (Math.abs(b - c.w) < Math.abs(a - c.w) ? b : a)) : c.w;
      fb.textContent = c.f || "Fonte do modelo";
      fb.title = seg.own ? "Fonte só desta parte: " + c.f : E.fonts ? "Fonte padrão (" + (o.hl() ? "destaque" : "texto") + "): clique para mudar só nesta parte" : "Fonte do modelo: " + c.f;
      fb.style.fontFamily = `"${c.f}", "Arial Black", Arial, sans-serif`;
      fb.style.fontWeight = w;
      if (o.ta) {
        o.ta.style.fontFamily = fb.style.fontFamily;
        o.ta.style.fontWeight = w;
      }
      wt.innerHTML = "";
      for (const v of ws) {
        const op = el("option");
        op.value = v;
        op.textContent = WEIGHTS[v] || "Peso " + v;
        op.selected = v === w;
        wt.append(op);
      }
      wt.classList.toggle("hidden", ws.length < 2);
      bk.classList.toggle("hidden", !seg.own);
      bk.title = E.fonts ? "Voltar para a fonte padrão" : "Voltar para a fonte do modelo";
    };
    const set = (f, w) => {
      if (o.check && !o.check(f, w)) return;
      seg.font = f;
      seg.weight = w;
      seg.own = true;
      save();
      paintFont();
    };
    wt.addEventListener("change", () => set(now().f, Number(wt.value)));
    fb.addEventListener("click", () => pickFont(fr, now().f, o.sample(), (f) => set(f.name, bestWeight(f)), o.allow));
    bk.addEventListener("click", () => {
      seg.own = false;
      delete seg.font;
      delete seg.weight;
      save();
      paintFont();
    });
    fr.append(fb, wt, bk);
    paintFont();
    fr.repaint = paintFont;
    return fr;
  }
  // Fonte nova: começa no peso mais forte até 800, que é o comum em vídeo.
  const bestWeight = (f) => f.w.filter((v) => v <= 800).pop() || f.w[0] || 400;

  // ---- Fontes padrão (uma vez só, para todos os textos)
  const VT_OF = { Poppins: "VT Poppins", Anton: "VT Anton", Montserrat: "VT Montserrat", "Bebas Neue": "VT Bebas", "Abril Fatface": "VT Abril" };
  // Sempre o MESMO objeto: a barra e o desenho mexem no que fica salvo.
  const defFonts = () => {
    data.fonts = data.fonts || {};
    for (const [k, v] of Object.entries({ on: true, normal: { f: "Poppins", w: 600 }, dest: { f: "Anton", w: 400 } })) if (data.fonts[k] == null) data.fonts[k] = v;
    return data.fonts;
  };
  // PC sem a fonte instalada: usa a que vem no plugin.
  const usable = (x) => (fonts.some((f) => f.name === x.f) || !VT_OF[x.f] ? x : { f: VT_OF[x.f], w: x.w });
  function applyFonts() {
    const d = defFonts();
    E.fonts = d.on ? { normal: usable(d.normal), dest: usable(d.dest) } : null;
  }
  function fontsBar(changed) {
    const d = defFonts();
    const box = el("div", "fx-fontsbar");
    const head = el("label", "fx-check");
    const cb = el("input");
    cb.type = "checkbox";
    cb.checked = d.on;
    head.append(cb, document.createTextNode(" Fontes padrão em todos os textos"));
    cb.addEventListener("change", () => {
      d.on = cb.checked;
      save();
      applyFonts();
      grid.classList.toggle("off", !d.on);
      changed();
    });
    const grid = el("div", "fx-fontsgrid");
    grid.classList.toggle("off", !d.on);
    for (const [k, label] of [["normal", "Texto padrão"], ["dest", "Texto destaque"]]) {
      const col = el("div", "fx-fontcol");
      const lb = el("span", "fx-part-name");
      lb.textContent = label;
      const row = el("div", "fx-fontrow");
      const fb = el("button", "fx-fontbtn");
      const wt = el("select", "fx-weight");
      wt.setAttribute("aria-label", "Peso do " + label);
      const draw = () => {
        const c = usable(d[k]);
        const ws = (fonts.find((f) => f.name === c.f) || { w: [] }).w;
        fb.textContent = d[k].f;
        fb.style.fontFamily = `"${c.f}", Arial`;
        fb.style.fontWeight = c.w;
        wt.innerHTML = "";
        for (const v of ws) {
          const op = el("option");
          op.value = v;
          op.textContent = WEIGHTS[v] || "Peso " + v;
          op.selected = v === c.w;
          wt.append(op);
        }
        wt.classList.toggle("hidden", ws.length < 2);
      };
      const put = (f, w) => {
        d[k] = { f, w };
        save();
        applyFonts();
        draw();
        changed();
      };
      wt.addEventListener("change", () => put(d[k].f, Number(wt.value)));
      fb.addEventListener("click", () => pickFont(row, d[k].f, k === "dest" ? "DESTAQUE" : "Texto padrão", (f) => put(f.name, bestWeight(f)), (f) => !/^VT /.test(f.name)));
      row.append(fb, wt);
      draw();
      loadFonts().then(() => row.isConnected && draw());
      col.append(lb, row);
      grid.append(col);
    }
    box.append(head, grid);
    return box;
  }

  // ---- Meus textos (biblioteca)
  let libVideo = null;
  function libVid() {
    const f = libPreview();
    if (!f || !fs.existsSync(f)) return null;
    const key = f + fs.statSync(f).mtimeMs;
    if (!libVideo || libVideo.key !== key) {
      const v = document.createElement("video");
      v.muted = true;
      v.preload = "auto";
      v.src = fileUrl(f);
      libVideo = { v, key, q: Promise.resolve() };
    }
    return libVideo;
  }
  // Recorta no texto (medido ao gerar as prévias) e centraliza no cartão.
  function fitDraw(x, w, h, v, it) {
    x.fillStyle = "#000";
    x.fillRect(0, 0, w, h);
    const b = prevInfo().boxes[it.id] || [0, 0, v.videoWidth, v.videoHeight];
    const k = Math.min((w * 0.92) / b[2], (h * 0.86) / b[3]);
    x.drawImage(v, b[0], b[1], b[2], b[3], (w - b[2] * k) / 2, (h - b[3] * k) / 2, b[2] * k, b[3] * k);
  }
  function libStill(cv, it) {
    const L = libVid();
    const x = cv.getContext("2d");
    const label = () => {
      const c = libCfg(it);
      const ts = it.controls.filter((k) => k.type === "text");
      const big = Math.max(...ts.map((k) => k.size || 1));
      const cols = it.controls.filter((k) => k.type === "color");
      const t = document.createElement("canvas");
      t.width = cv.width;
      t.height = cv.height;
      const segs = ts.map((k) => {
        const m = libModel(k);
        const hl = libHl(it, c, k);
        const fo = E.fontOf(c.texts[k.i], hl, m.f, m.w);
        return { t: k.text, hl, font: fo.f, weight: fo.w, own: true, size: 100 * ((k.size || big) / big) };
      });
      const pick = (hl) => (cols.find((k) => (k.value !== "#ffffff") === hl) || { value: hl ? "#ffcc00" : "#ffffff" }).value;
      E.drawText(t.getContext("2d"), t.width, t.height, 1.6, { preset: "revela-linha", segs, lines: true, dur: 3, size: 170, color: pick(false), accent: pick(true) });
      x.fillStyle = "#000";
      x.fillRect(0, 0, cv.width, cv.height);
      x.drawImage(t, 0, 0);
    };
    label();
    if (!L) return;
    L.q = L.q.then(
      () =>
        new Promise((res) => {
          const v = L.v;
          const done = () => {
            clearTimeout(to);
            v.removeEventListener("seeked", on);
            res();
          };
          const on = () => {
            try {
              if (cv.isConnected) fitDraw(x, cv.width, cv.height, v, it);
            } catch {}
            done();
          };
          const to = setTimeout(done, 4000);
          const go = () => {
            v.addEventListener("seeked", on);
            v.currentTime = it.start + Math.min(1.6, (it.end - it.start) * 0.4);
          };
          if (v.readyState >= 1) go();
          else v.addEventListener("loadedmetadata", go, { once: true });
        })
    );
  }
  // Prévia em movimento: um vídeo só para o cartão em foco.
  function libPlay(cv, it) {
    const f = libPreview();
    if (!f || !fs.existsSync(f)) return () => {};
    const v = document.createElement("video");
    v.muted = true;
    v.src = fileUrl(f);
    const x = cv.getContext("2d");
    let on = true;
    v.addEventListener("loadedmetadata", () => {
      v.currentTime = it.start;
      v.play().catch(() => {});
    });
    const tick = () => {
      if (!on || !cv.isConnected) return v.pause();
      if (v.currentTime >= it.end - 0.05 || v.ended) {
        v.currentTime = it.start;
        v.play().catch(() => {});
      }
      if (v.readyState >= 2 && !v.seeking) fitDraw(x, cv.width, cv.height, v, it);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    return () => {
      on = false;
      v.pause();
      v.removeAttribute("src");
    };
  }
  function libCard(t, o) {
    const it = t.lib;
    const c = el("div", "fx-card mine");
    c.tabIndex = 0;
    const cv = el("canvas");
    cv.width = 352;
    cv.height = 200;
    libStill(cv, it);
    c._still = () => libStill(cv, it);
    let stop = null;
    const on = () => (stop = stop || libPlay(cv, it));
    const off = () => {
      if (stop) stop();
      stop = null;
      libStill(cv, it);
    };
    c.addEventListener("mouseenter", on);
    c.addEventListener("mouseleave", off);
    const foot = el("div", "fx-foot");
    const nm = el("span", "fx-name");
    nm.textContent = t.nome;
    foot.append(nm, starBtn("tx", t.id, o.onFav));
    c.append(cv, foot);
    c.addEventListener("click", () => o.click(c));
    c.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.key === " ") && e.target === c) {
        e.preventDefault();
        o.click(c);
      }
    });
    return c;
  }
  let libStop = null;
  function libEditor(t, ed) {
    const it = t.lib;
    const c = libCfg(it);
    ed.innerHTML = "";
    if (libStop) libStop();
    const pv = el("canvas", "fx-preview");
    pv.width = 400;
    pv.height = 400;
    libStill(pv, it);
    setTimeout(() => (libStop = libPlay(pv, it)), 50);
    const form = el("div", "fx-form");
    const parts = el("div", "fx-parts");
    const txt = it.controls.filter((x) => x.type === "text");
    // Cada cor vai para o texto que vem antes dela na lista do MOGRT (ou o próximo, se não houver).
    const colorOf = {};
    const rest = [];
    let last = -1;
    const used = new Set();
    it.controls.forEach((k, pos) => {
      if (k.type === "text") last = k.i;
      else if (k.type === "color") {
        const m = /TEXTO (\d)/.exec(k.name);
        let i = m ? Number(m[1]) - 1 : last;
        if (!m) {
          // "Cor" antes do texto do grupo: pertence ao próximo.
          const grp = it.controls.slice(0, pos).filter((z) => z.type === "num" && /TEXTO (\d)/.test(z.name)).pop();
          if (grp) i = Number(/TEXTO (\d)/.exec(grp.name)[1]) - 1;
        }
        if (i < 0) i = 0;
        (colorOf[i] = colorOf[i] || []).push(k);
      } else rest.push(k);
      used.add(pos);
    });
    txt.forEach((x) => {
      const seg = c.texts[x.i];
      const cols = colorOf[x.i] || [];
      const row = el("div", "fx-part");
      const val = () => (cols[0] ? c.ctl[ctlKey(cols[0])] || cols[0].value : "#ffffff");
      const tint = () => {
        const n = parseInt(val().slice(1), 16) || 0;
        row.style.setProperty("--pc", val());
        row.classList.toggle("dark", 0.3 * (n >> 16) + 0.59 * ((n >> 8) & 255) + 0.11 * (n & 255) < 90);
      };
      tint();
      const head = el("div", "fx-part-head");
      if (cols.length) {
        const pick = el("input");
        pick.type = "color";
        pick.value = val();
        pick.title = "Cor deste texto";
        pick.setAttribute("aria-label", "Cor deste texto");
        pick.addEventListener("input", () => {
          // Degradê de duas pontas: as duas recebem a cor.
          cols.forEach((k) => (c.ctl[ctlKey(k)] = pick.value));
          save();
          tint();
        });
        head.append(pick);
      }
      const name = el("span", "fx-part-name");
      name.textContent = txt.length > 1 ? "Linha " + (x.i + 1) + (/\[(.+)\]/.test(x.name) ? " · " + /\[(.+)\]/.exec(x.name)[1] : "") : "Texto";
      const sw = el("button", "fx-part-swap");
      sw.textContent = libHl(it, c, x) ? "destaque" : "padrão";
      sw.title = "Qual fonte padrão esta linha usa: clique para trocar";
      head.append(name, sw);
      const ta = el("textarea");
      ta.rows = 1;
      ta.value = seg.t;
      ta.placeholder = "ex.: " + x.text.replace(/\n/g, " / ");
      ta.title = "Vazio: fica o texto que está na biblioteca";
      ta.addEventListener("input", () => {
        seg.t = ta.value;
        save();
      });
      row.append(head, ta);
      if (x.fontEdit) {
        const fr = fontRow(seg, {
          hl: () => libHl(it, c, x),
          model: libModel(x),
          ta,
          sample: () => (ta.value.trim() || x.text).split("\n")[0].slice(0, 24),
          allow: (f) => !/^VT /.test(f.name),
          check: (f, w) => {
            if (libPs(f, w)) return true;
            status("Essa fonte não pode ser usada no MOGRT (não achei o nome interno dela).", "bad");
            return false;
          },
        });
        sw.addEventListener("click", () => {
          seg.hl = !libHl(it, c, x);
          save();
          libEditor(t, ed);
        });
        row.append(fr);
      }
      if (x.sizeEdit) {
        const sr = el("div", "fx-scalerow");
        const sz = range("Escala", 30, 300, seg.size || 100, (v) => v + " %", (v) => (seg.size = v));
        sz.classList.add("fx-scale");
        sr.append(sz);
        row.append(sr);
      }
      parts.append(row);
    });
    const r1 = el("div", "fx-row");
    const dur = el("input");
    dur.type = "number";
    dur.min = 0.5;
    dur.max = 30;
    dur.step = 0.1;
    dur.value = c.dur;
    dur.addEventListener("input", () => {
      c.dur = Number(dur.value) || it.end - it.start;
      save();
    });
    const fl = el("label", "fx-field");
    const fs2 = el("span");
    fs2.textContent = "Duração (s)";
    fl.append(fs2, dur);
    r1.append(fl, range("Tamanho geral", 30, 250, c.k || 100, (v) => v + " %", (v) => (c.k = v)));
    const more = el("details", "fx-more");
    more.append(el("summary", "", "Ajustes do modelo"));
    const mr = el("div", "fx-row");
    for (const k of rest) {
      const key = ctlKey(k);
      mr.append(range(k.name.replace(/ – /, " "), k.min, k.max, c.ctl[key] != null ? c.ctl[key] : k.value, (v) => String(v), (v) => (c.ctl[key] = v)));
    }
    more.append(mr);
    const btns = el("div", "fx-row");
    const b1 = el("button", "primary", "Inserir na agulha");
    b1.addEventListener("click", () =>
      act("Inserindo o texto", async () => {
        const r = await insertLib(t.id);
        return "✓ " + t.nome + " em " + r.track + " · " + r.start.toFixed(2).replace(".", ",") + " s" + (r.missing.length ? " · não mudou: " + r.missing.join(", ") : "");
      })
    );
    const b2 = el("button", "secondary", "Voltar ao modelo");
    b2.title = "Desfaz fonte, cor, escala e ajustes (o texto escrito fica)";
    b2.addEventListener("click", () => {
      data.libCfg[it.id] = { texts: c.texts.map((s) => ({ t: s.t, size: 100 })), ctl: {}, k: 100 };
      save();
      libEditor(t, ed);
    });
    btns.append(b1, b2);
    form.append(parts, r1, more, btns);
    ed.append(pv, form);
    loadFonts().then(() => {});
  }
  function paintPrevBtn(g) {
    const has = node && fs.existsSync(libPreview());
    const old = has && prevInfo().key !== prevKey();
    g.textContent = making ? "Gerando miniaturas…" : !has ? "Gerar miniaturas reais" : old ? "Miniaturas desatualizadas · refazer" : "Refazer miniaturas";
    g.classList.toggle("primary", !has || old);
    g.classList.toggle("secondary", has && !old);
  }
  // Escolher, atualizar e gerar miniaturas ficam nas configurações (⚙), fora da aba.
  function mountLib() {
    const b = $("lib-settings");
    if (!b) return;
    b.innerHTML = "";
    b.append(libBar());
  }
  function libBar() {
    const box = el("div", "fx-libbar");
    if (!data.lib || libErr) {
      box.append(el("p", "hint", libErr ? "Biblioteca: " : "Tem textos seus (MOGRT) num projeto? Escolha o projeto e eles aparecem aqui, com a animação original."));
      if (libErr) box.firstChild.append(document.createTextNode(libErr));
    } else {
      const p = el("p", "hint");
      p.textContent = "Meus textos: " + data.lib.split(/[\\/]/).pop() + " (" + lib.items.length + ")";
      p.title = data.lib;
      box.append(p);
    }
    const row = el("div", "fx-row");
    const b = el("button", "secondary", data.lib ? "Trocar projeto" : "Escolher projeto dos meus textos");
    b.addEventListener("click", () => {
      const f = deps.pickFile("Projeto do Premiere com os seus textos", ["prproj"]);
      if (!f) return;
      if (!/\.prproj$/i.test(f)) return status("Escolha um projeto do Premiere (.prproj).", "bad");
      data.lib = f;
      save();
      loadLib();
      paint();
      status(lib ? lib.items.length + " textos encontrados." : libErr, lib ? "ok" : "bad");
    });
    row.append(b);
    if (data.lib) {
      const u = el("button", "secondary", "Atualizar");
      u.title = "Ler o projeto de novo (salve antes no Premiere)";
      u.addEventListener("click", () => {
        loadLib();
        paint();
        status(lib ? lib.items.length + " textos." : libErr, lib ? "ok" : "bad");
      });
      row.append(u);
    }
    if (lib) {
      const g = el("button", "secondary fx-prevbtn");
      paintPrevBtn(g);
      g.title = "O Media Encoder gera os textos uma vez, com as suas fontes padrão (normalmente é automático)";
      g.addEventListener("click", () =>
        act("Gerando as miniaturas", async () => {
          await makePreviews(status);
          setTimeout(paint, 50);
          return "✓ Miniaturas prontas.";
        })
      );
      row.append(g);
    }
    box.append(row);
    return box;
  }

  // ---- Textos
  let libSel = null;
  let txEdit = null; // caminho do .mov que está sendo editado
  function paintTx(body) {
    const cfg = (data.text = Object.assign({ preset: "sobe-palavra", text: "" }, E.textDefaults, data.text));
    if (/^lib-/.test(cfg.preset)) cfg.preset = "sobe-palavra";
    const ed = el("div", "fx-editor");
    const libEd = el("div", "fx-editor hidden");
    const showLib = (on) => {
      ed.classList.toggle("hidden", on);
      libEd.classList.toggle("hidden", !on);
      if (!on && libStop) {
        libStop();
        libStop = null;
      }
    };
    const pv = el("canvas", "fx-preview");
    pv.width = 270;
    pv.height = 270;
    const px = pv.getContext("2d");
    if (!Array.isArray(cfg.segs) || !cfg.segs.length) cfg.segs = E.toSegs(cfg.text);
    const sj = JSON.stringify(cfg.segs);
    if (sj.includes('"font"') && !sj.includes('"own"') && txEdit) cfg.segs.forEach((s) => (s.own = !!s.font)); // texto antigo reaberto: mantém a fonte dele
    if (cfg.segs.length < 2 && !E.text(cfg.preset).viral) cfg.segs = cfg.segs.some((s) => s.hl) ? [{ t: "", hl: false }, ...cfg.segs] : [cfg.segs[0] || { t: "", hl: false }, { t: "", hl: true }];
    // Sem nada escrito, a prévia mostra o exemplo do modelo.
    const sample = () => (cfg.segs.some((s) => s.t.trim()) ? Object.assign({}, cfg) : Object.assign({}, cfg, E.text(cfg.preset).viral ? { segs: E.viralSample(E.text(cfg.preset)) } : { segs: E.toSegs(E.text(cfg.preset).sample), lines: false }));
    const live = () => animatePreview(pv, (t) => E.drawText(px, pv.width, pv.height, t, sample()), () => Math.max(0.6, cfg.dur) + 0.3);
    const form = el("div", "fx-form");
    // Um campo por parte, na ordem em que aparece no vídeo, com a cor dela ao lado.
    const parts = el("div", "fx-parts");
    // Cor escura: o campo fica claro para o texto continuar legivel.
    const tint = (r, c) => {
      const n = parseInt(String(c).slice(1), 16) || 0;
      r.style.setProperty("--pc", c);
      r.classList.toggle("dark", 0.3 * (n >> 16) + 0.59 * ((n >> 8) & 255) + 0.11 * (n & 255) < 90);
    };
    const paintParts = (focus) => {
      parts.innerHTML = "";
      cfg.segs.forEach((seg, i) => {
        const row = el("div", "fx-part");
        const key = seg.hl ? "accent" : "color";
        tint(row, cfg[key]);
        const head = el("div", "fx-part-head");
        const pick = el("input");
        pick.type = "color";
        pick.value = cfg[key];
        pick.title = seg.hl ? "Cor do destaque (vale para todos os destaques)" : "Cor do texto (vale para todos os textos)";
        pick.setAttribute("aria-label", pick.title);
        pick.addEventListener("input", () => {
          cfg[key] = pick.value;
          save();
          parts.querySelectorAll(`.fx-part[data-k="${key}"]`).forEach((r) => {
            tint(r, pick.value);
            r.querySelector("input[type=color]").value = pick.value;
          });
        });
        row.dataset.k = key;
        const name = el("span", "fx-part-name");
        name.textContent = (E.text(cfg.preset).viral ? "Linha " + (i + 1) + " · " : "") + (seg.hl ? "Destaque" : "Texto");
        const sw = el("button", "fx-part-swap", "trocar cor");
        sw.title = seg.hl ? "Passar para a cor do texto" : "Passar para a cor do destaque";
        sw.addEventListener("click", () => {
          seg.hl = !seg.hl;
          save();
          paintParts(i);
        });
        const x = el("button", "fx-part-x", "✕");
        x.title = "Tirar esta parte";
        x.disabled = cfg.segs.length < 2;
        x.classList.toggle("hidden", cfg.segs.length < 2);
        x.addEventListener("click", () => {
          cfg.segs.splice(i, 1);
          save();
          paintParts();
        });
        head.append(pick, name, sw, x);
        const ta = el("textarea");
        ta.rows = 1;
        ta.value = seg.t;
        ta.placeholder = seg.ph && E.text(cfg.preset).viral ? "ex.: " + seg.ph : seg.hl ? "Escreva o destaque…" : "Escreva o texto…";
        ta.setAttribute("aria-label", name.textContent);
        ta.addEventListener("input", () => {
          seg.t = ta.value;
          save();
        });
        // Fonte e peso: os padrões, ou só desta parte.
        const vm = E.text(cfg.preset).viral;
        const md = vm ? vm[Math.min(i, vm.length - 1)] : null;
        const fr = fontRow(seg, { hl: () => seg.hl, model: md ? { f: md.f, w: md.w || 400 } : { f: cfg.font, w: 400 }, ta, sample: () => ta.value.trim().split("\n")[0].slice(0, 24) });
        const sz = range("Escala", 30, 300, seg.size || 100, (v) => v + " %", (v) => {
          seg.size = v;
          rs.classList.toggle("off", v === 100);
        });
        sz.classList.add("fx-scale");
        const rs = el("button", "fx-part-swap", "100 %");
        rs.title = "Voltar a escala desta parte para 100 %";
        rs.classList.toggle("off", (seg.size || 100) === 100);
        rs.addEventListener("click", () => {
          seg.size = 100;
          save();
          paintParts();
        });
        const sr = el("div", "fx-scalerow");
        sr.append(sz, rs);
        row.append(head, ta, fr, sr);
        parts.append(row);
        if (focus === i) ta.focus();
      });
      const add = el("button", "secondary fx-part-add", "＋ Adicionar parte");
      add.title = "Continua o texto depois da última parte";
      add.addEventListener("click", () => {
        const hl = !cfg.segs[cfg.segs.length - 1].hl;
        // A parte nova repete a fonte da última parte do mesmo tipo.
        const same = cfg.segs.filter((s) => s.hl === hl).pop() || {};
        cfg.segs.push({ t: "", hl, font: same.font, weight: same.weight, own: same.own, size: same.size });
        save();
        paintParts(cfg.segs.length - 1);
      });
      const ln = el("label", "fx-check");
      const cb = el("input");
      cb.type = "checkbox";
      cb.checked = !!cfg.lines;
      cb.addEventListener("change", () => {
        cfg.lines = cb.checked;
        save();
      });
      ln.append(cb, document.createTextNode(" Cada parte em uma linha"));
      const foot = el("div", "fx-row");
      if (!E.text(cfg.preset).viral) foot.append(ln);
      foot.append(add);
      parts.append(foot);
    };
    paintParts();
    loadFonts().then((ok) => ok && parts.isConnected && paintParts());
    const field = (label, input) => {
      const l = el("label", "fx-field");
      const s = el("span");
      s.textContent = label;
      l.append(s, input);
      return l;
    };
    const inp = (type, key, conv) => {
      const i = el("input");
      i.type = type;
      i.value = cfg[key];
      i.addEventListener("input", () => {
        cfg[key] = conv ? conv(i.value) : i.value;
        save();
      });
      return i;
    };
    const r1 = el("div", "fx-row");
    r1.append(field("Duração (s)", Object.assign(inp("number", "dur", Number), { min: 0.6, max: 20, step: 0.1 })));
    const r2 = el("div", "fx-row");
    r2.append(field("Cor da caixa (só nos modelos Caixa)", inp("color", "boxColor")));
    const r3 = el("div", "fx-row");
    r3.append(
      range("Tamanho geral", 30, 250, cfg.size, (v) => v + " %", (v) => (cfg.size = v)),
      range("Altura", 5, 95, Math.round((cfg.pos != null ? cfg.pos : 0.5) * 100), (v) => v + " %", (v) => (cfg.pos = v / 100))
    );
    const btns = el("div", "fx-row");
    const b1 = el("button", "primary", txEdit ? "Atualizar o clipe" : "Inserir na agulha");
    const prog = (p) => status("Gerando o texto… " + p + " %");
    b1.addEventListener("click", () =>
      act("Gerando o texto", async () => {
        const r = await insertText(cfg, { onProgress: prog, replace: txEdit });
        if (r.replaced) {
          txEdit = r.file;
          return "✓ Texto atualizado na timeline.";
        }
        return "✓ Texto em " + r.track + " · " + r.start.toFixed(2).replace(".", ",") + " s";
      })
    );
    const b2 = el("button", "secondary", txEdit ? "Parar de editar" : "Editar o selecionado");
    b2.title = "Abre aqui um texto já colocado, para mudar";
    b2.addEventListener("click", () => {
      if (txEdit) {
        txEdit = null;
        return paint();
      }
      act("Abrindo o texto", async () => {
        const i = await info();
        const s = i.selection.find((k) => k.path && fs.existsSync(k.path + ".json"));
        if (!s) throw new Error("Selecione na timeline um texto criado aqui.");
        data.text = Object.assign({}, E.textDefaults, JSON.parse(fs.readFileSync(s.path + ".json", "utf8")));
        txEdit = s.path;
        save();
        paint();
        return "Editando “" + s.name + "”. Mude e clique em Atualizar.";
      });
    });
    btns.append(b1, b2);
    form.append(parts, r1, r2, r3, btns);
    const showBox = () => r2.classList.toggle("hidden", !E.text(cfg.preset).box);
    showBox();
    ed.append(pv, form);
    const grid = el("div", "fx-grid");
    const repaint = () => {
      grid.innerHTML = "";
      const viral = ui.tx.cat === "Texto Viral";
      subs.classList.toggle("hidden", !viral);
      subs.querySelectorAll(".fx-cat").forEach((b) => b.classList.toggle("on", (b.dataset.s || "") === (ui.tx.sub || "")));
      let lastSub = null;
      const f = E.texts.filter((t) => match("tx", t, t.id, t.nome + " " + (t.sub || "")) && (!viral || !ui.tx.sub || t.sub === ui.tx.sub));
      // Meus textos primeiro, dentro de cada grupo de linhas.
      if (viral) f.sort((a, b) => a.sub.localeCompare(b.sub) || !!b.mine - !!a.mine);
      for (const t of f) {
        const grp = t.sub + (t.mine ? " · meus textos" : lib ? " · do painel" : "");
        if (viral && grp !== lastSub) {
          lastSub = grp;
          const hd = el("h4", "fx-group");
          hd.textContent = grp;
          grid.append(hd);
        }
        if (t.lib) {
          const lc = libCard(t, {
            onFav: () => ui.tx.fav && repaint(),
            click: (n) => {
              libSel = t.id;
              grid.querySelectorAll(".fx-card").forEach((k) => k.classList.toggle("sel", k === n));
              libEditor(t, libEd);
              showLib(true);
              body.scrollTop = 0;
            },
          });
          lc.classList.toggle("sel", libSel === t.id);
          grid.append(lc);
          continue;
        }
        const conf = Object.assign({}, E.textDefaults, { preset: t.id, text: t.sample, dur: 2.6, size: 130, font: "Arial Black" }, t.viral ? { segs: E.viralSample(t) } : {});
        const c = card("tx", t, {
          still: t.viral ? 1.75 : 1.2,
          loop: 2.8,
          draw: (x, w, h, s) => E.drawText(x, w, h, s, conf),
          onFav: () => ui.tx.fav && repaint(),
          click: (n) => {
            cfg.preset = t.id;
            libSel = null;
            showLib(false);
            if (t.viral) {
              // Lembra a divisao original: 3 linhas -> 1 -> 3 volta como era (se o texto nao mudou).
              const txt = (l) => l.map((k) => String(k.t).trim()).filter(Boolean);
              if (!cfg.split || cfg.split.join(" ") !== txt(cfg.segs).join(" ")) cfg.split = txt(cfg.segs);
              cfg.segs = E.viralSegs(t, cfg.split.map((k) => ({ t: k })));
              cfg.lines = false;
              paintParts();
            } else if (cfg.segs.length < 2) {
              cfg.segs.push({ t: "", hl: !cfg.segs[0].hl });
              paintParts();
            } else if (cfg.segs.some((s) => s.ph != null)) {
              // Saiu do Texto Viral: cada linha continua na sua linha.
              cfg.segs.forEach((s) => delete s.ph);
              cfg.lines = true;
              paintParts();
            }
            if (t.big && !cfg.lines) {
              cfg.lines = true;
              paintParts();
            }
            showBox();
            save();
            grid.querySelectorAll(".fx-card").forEach((k) => k.classList.toggle("sel", k === n));
            live();
          },
        });
        c.classList.toggle("sel", !libSel && cfg.preset === t.id);
        grid.append(c);
      }
      if (!f.length) grid.append(el("p", "fx-empty", "Nada encontrado."));
    };
    const subs = el("div", "fx-cats fx-subcats");
    for (const s of ["", "1 linha", "2 linhas", "3 linhas"]) {
      const b = el("button", "fx-cat");
      b.dataset.s = s;
      b.textContent = s || "Todas as linhas";
      b.addEventListener("click", () => {
        ui.tx.sub = s;
        repaint();
      });
      subs.append(b);
    }
    const fbar = fontsBar(() => {
      paintParts();
      const lt = libSel && E.texts.find((t) => t.id === libSel);
      if (lt) libEditor(lt, libEd);
      repaint();
      mountLib();
    });
    setTimeout(autoPreviews, 1500);
    body.append(fbar, ed, libEd, filters("tx", [...new Set(E.texts.map((t) => t.cat))], repaint), subs, grid);
    // As fontes dos modelos carregam uma vez; depois as prévias são redesenhadas.
    Promise.all(VT.flatMap((f) => f.w.map((w) => document.fonts.load(E.cssFont(40, f.name, w))))).then(() => grid.isConnected && repaint());
    repaint();
    live();
  }
  let previewRun = null;
  function animatePreview(cv, draw, dur) {
    const me = (previewRun = {});
    let start = performance.now();
    const tick = (n) => {
      if (previewRun !== me || !cv.isConnected || root.classList.contains("hidden")) return;
      let t = (n - start) / 1000;
      if (t > dur()) {
        start = n;
        t = 0;
      }
      draw(t);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  // ---- Light leaks
  let lkSel = null;
  function paintLk(body) {
    const grid = el("div", "fx-grid");
    const bar = el("div", "fx-sticky");
    const row = el("div", "fx-row");
    const b = el("button", "primary", "Inserir na agulha");
    b.title = "Fica centralizado na agulha (os ambientes começam nela), na trilha livre mais alta";
    const go = () => {
      const l = lkSel && E.leak(lkSel);
      if (!l) return status("Escolha um light leak primeiro.", "bad");
      act("Gerando " + l.nome, async () => {
        const r = await insertLeak(l.id, { force: (data.lkForce || 70) / 100, onProgress: (p) => status("Gerando " + l.nome + "… " + p + " %") });
        return "✓ " + l.nome + " em " + r.track + " · " + r.start.toFixed(2).replace(".", ",") + " s";
      });
    };
    b.addEventListener("click", go);
    row.append(range("Força", 25, 150, data.lkForce || 70, (v) => v + " %", (v) => (data.lkForce = v)), b);
    bar.append(row);
    const repaint = () => {
      grid.innerHTML = "";
      const f = E.leaks.filter((t) => match("lk", t, t.id, t.nome));
      for (const l of f) {
        const c = card("lk", l, {
          still: l.dur / 2,
          loop: l.dur + 0.3,
          draw: (x, w, h, s) => {
            E.drawLeak(x, w, h, Math.min(s, l.dur), l.dur, l, (data.lkForce || 70) / 100);
            x.globalCompositeOperation = "lighter";
            x.globalAlpha = 0.3;
            x.drawImage(scene(w, h, "A"), 0, 0);
            x.globalAlpha = 1;
            x.globalCompositeOperation = "source-over";
          },
          onFav: () => ui.lk.fav && repaint(),
          click: (n) => {
            lkSel = l.id;
            grid.querySelectorAll(".fx-card").forEach((k) => k.classList.toggle("sel", k === n));
            status(l.nome + " escolhido.");
          },
        });
        c.classList.toggle("sel", lkSel === l.id);
        c.addEventListener("dblclick", go);
        grid.append(c);
      }
      if (!f.length) grid.append(el("p", "fx-empty", "Nada encontrado."));
    };
    body.append(filters("lk", [], repaint), grid, bar);
    repaint();
  }

  const SUBS = [["sfx", "SFX", paintSfx], ["tr", "Transições", paintTr], ["tx", "Textos", paintTx], ["lk", "Light leaks", paintLk]];
  function paint() {
    if (!root) return;
    mountLib();
    stopSfx();
    if (closeFonts) closeFonts();
    hover = previewRun = null;
    if (libStop) libStop();
    libStop = libSel = null;
    root.innerHTML = "";
    const nav = el("div", "fx-subs");
    nav.setAttribute("role", "tablist");
    for (const [id, nome] of SUBS) {
      const b = el("button", "fx-sub" + (sub === id ? " on" : ""));
      b.textContent = nome;
      b.setAttribute("role", "tab");
      b.setAttribute("aria-selected", String(sub === id));
      b.addEventListener("click", () => {
        sub = id;
        paint();
      });
      nav.append(b);
    }
    const body = el("div", "fx-body");
    const st = el("div", "fx-status");
    st.id = "fx-status";
    st.setAttribute("role", "status");
    root.append(nav, body, st);
    SUBS.find((s) => s[0] === sub)[2](body);
  }

  window.EfeitosUI = {
    init(d) {
      deps = d;
      root = $("efeitos");
      loadLib();
      applyFonts();
      paint();
    },
    shown() {
      if (data.sfxFolders.length && !sfx.length && !scanning) rescan().then(() => sub === "sfx" && paint());
      paint();
    },
    hidden() {
      stopSfx();
      hover = previewRun = null;
    },
    // Para o chat / skills.
    api: {
      applyTransition,
      removeTransition,
      insertText,
      insertLib,
      library: () => (lib ? lib.items.map((x) => ({ id: x.id, group: x.group, n: x.n, parts: x.controls.filter((c) => c.type === "text").map((c) => c.name) })) : []),
      libraryFile: () => data.lib || "",
      insertLeak,
      async sfxList() {
        if (!sfx.length && data.sfxFolders.length) await (scanning || rescan());
        return sfx.map((s) => Object.assign({ fav: isFav("sfx", s.file) }, s));
      },
      favorites: () => data.fav,
      isBusy: () => working,
    },
    _renderMov: renderMov,
    _makePreviews: (say) => makePreviews(say),
  };
})();
