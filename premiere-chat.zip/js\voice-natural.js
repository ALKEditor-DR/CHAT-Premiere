/*
 * Voz natural (Chatterbox Multilingual, MIT) rodando na placa de vídeo.
 *
 * Um servidor Python local (js/servidor_voz.py) fica com o modelo carregado; o painel
 * pede a fala frase a frase e toca cada uma assim que fica pronta, gerando a próxima
 * enquanto a anterior toca. Efeito "Jarvis" opcional pelo ffmpeg.
 */
(function () {
  "use strict";

  const req = typeof require === "function" ? require : null;
  if (!req) {
    if (typeof window !== "undefined") window.NaturalVoice = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const http = req("http");
  const crypto = req("crypto");
  const { spawn, spawnSync } = req("child_process");

  const BASE = path.join(os.homedir(), ".premiere-chat", "voz-natural");
  const PY = path.join(BASE, "env", "Scripts", "python.exe");
  const api = {};

  api.isInstalled = () => fs.existsSync(PY);
  api.paths = { base: BASE, python: PY };

  // ------------------------------------------------------------ servidor

  let server = null; // { proc, port, token, ready: Promise }

  function startServer(scriptPath, onStatus) {
    const token = crypto.randomBytes(16).toString("hex");
    const proc = spawn(PY, ["-u", scriptPath, "--port", "0", "--token", token, "--idle-min", "15"], {
      windowsHide: true,
      env: Object.assign({}, process.env, { HF_HOME: path.join(BASE, "modelos"), PYTHONIOENCODING: "utf-8" }),
    });
    const s = { proc, port: 0, token, log: "" };
    s.ready = new Promise((resolve, reject) => {
      let buf = "";
      const timer = setTimeout(() => reject(new Error("A voz natural demorou demais para carregar.")), 15 * 60000);
      const onData = (d) => {
        const t = d.toString();
        s.log = (s.log + t).slice(-4000);
        buf += t;
        const m = buf.match(/PRONTO (\d+)/);
        if (m) {
          clearTimeout(timer);
          s.port = Number(m[1]);
          resolve(s);
        } else if (onStatus && /Downloading|Fetching/.test(t)) onStatus("baixando o modelo de voz (só na primeira vez)…");
      };
      proc.stdout.on("data", onData);
      proc.stderr.on("data", onData);
      proc.on("error", (e) => {
        clearTimeout(timer);
        reject(e);
      });
      proc.on("close", (code) => {
        clearTimeout(timer);
        if (server === s) server = null;
        reject(new Error("O servidor de voz fechou (código " + code + "). " + s.log.trim().split(/\r?\n/).slice(-3).join(" ")));
      });
    });
    return s;
  }

  // Liga o servidor (se ainda não estiver ligado) e espera o modelo carregar.
  api.ensure = function (scriptPath, onStatus) {
    if (!api.isInstalled()) return Promise.reject(new Error("A voz natural não está instalada."));
    if (!server || server.proc.exitCode !== null) server = startServer(scriptPath, onStatus);
    return server.ready;
  };

  // Começa a carregar em segundo plano (ex.: quando a pessoa clica no 🎤).
  api.warmUp = function (scriptPath) {
    if (!api.isInstalled()) return;
    api.ensure(scriptPath).catch(() => {});
  };

  api.shutdown = function () {
    if (server && server.proc.exitCode === null) {
      try {
        spawnSync("taskkill", ["/pid", String(server.proc.pid), "/T", "/F"], { windowsHide: true });
      } catch {}
    }
    server = null;
  };

  function post(s, route, body) {
    return new Promise((resolve, reject) => {
      const data = Buffer.from(JSON.stringify(body), "utf8");
      const r = http.request(
        { host: "127.0.0.1", port: s.port, path: route, method: "POST", headers: { "Content-Type": "application/json", "Content-Length": data.length, Authorization: "Bearer " + s.token } },
        (res) => {
          let out = "";
          res.on("data", (d) => (out += d));
          res.on("end", () => {
            try {
              const j = JSON.parse(out);
              if (!j.ok) reject(new Error(j.error || "falha na voz"));
              else resolve(j);
            } catch (e) {
              reject(e);
            }
          });
        }
      );
      r.on("error", reject);
      r.setTimeout(120000, () => r.destroy(new Error("a voz demorou demais")));
      r.end(data);
    });
  }

  // ------------------------------------------------------------ texto -> frases

  // Frases de até ~220 caracteres (o modelo fica mais natural com trechos curtos).
  api.sentences = function (text) {
    const parts = String(text || "")
      .replace(/\s+/g, " ")
      .trim()
      .split(/(?<=[.!?…])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ0-9"“])/);
    const out = [];
    for (let p of parts) {
      while (p.length > 220) {
        let cut = p.lastIndexOf(", ", 220);
        if (cut < 80) cut = p.lastIndexOf(" ", 220);
        if (cut < 40) cut = 220;
        out.push(p.slice(0, cut + 1).trim());
        p = p.slice(cut + 1).trim();
      }
      if (p) out.push(p);
    }
    // Frases muito curtas ("Pronto!") soam melhor juntas com a seguinte.
    const merged = [];
    for (const f of out) {
      const last = merged[merged.length - 1];
      if (last && last.length < 30 && (last + " " + f).length <= 240) merged[merged.length - 1] = last + " " + f;
      else merged.push(f);
    }
    return merged;
  };

  // ------------------------------------------------------------ efeito

  const FX = {
    nenhum: null,
    leve: "highpass=f=80,equalizer=f=3000:t=q:w=1.2:g=2,aecho=0.8:0.4:24:0.08,acompressor=threshold=-20dB:ratio=2.5:attack=5:release=80",
    jarvis:
      "highpass=f=110,lowpass=f=9000,equalizer=f=2800:t=q:w=1.2:g=3,chorus=0.7:0.9:22:0.25:0.3:1.5,aecho=0.8:0.55:28|46:0.16|0.08,acompressor=threshold=-20dB:ratio=3:attack=5:release=80,volume=1.2",
  };

  function applyFx(ffmpeg, wav, fx) {
    const f = FX[fx];
    if (!f || !ffmpeg) return wav;
    const out = wav.replace(/\.wav$/i, "-fx.wav");
    const r = spawnSync(ffmpeg, ["-v", "error", "-y", "-i", wav, "-af", f, out], { windowsHide: true, timeout: 20000 });
    return r.status === 0 && fs.existsSync(out) ? out : wav;
  }

  // ------------------------------------------------------------ falar

  function playFile(file, state) {
    return new Promise((resolve) => {
      if (state.stopped) return resolve();
      let url;
      try {
        url = URL.createObjectURL(new Blob([fs.readFileSync(file)], { type: "audio/wav" }));
      } catch {
        return resolve();
      }
      const a = new Audio(url);
      state.audio = a;
      const done = () => {
        URL.revokeObjectURL(url);
        state.audio = null;
        resolve();
      };
      a.onended = done;
      a.onerror = done;
      a.play().catch(done);
    });
  }

  /*
   * Fala o texto. opts: { script, ffmpeg, fx: 'nenhum'|'leve'|'jarvis', ref, exaggeration, cfg, onStatus }
   * -> { promise (resolve {ok, error} ao terminar ou parar), stop() }
   */
  api.speak = function (text, opts) {
    const state = { stopped: false, audio: null };
    const dir = path.join(os.tmpdir(), "premiere-chat-voz");
    const promise = (async () => {
      const s = await api.ensure(opts.script, opts.onStatus);
      fs.mkdirSync(dir, { recursive: true });
      const frases = api.sentences(text);
      const gen = (i) =>
        post(s, "/falar", {
          text: frases[i],
          out: path.join(dir, `f-${Date.now()}-${i}.wav`),
          ref: opts.ref || null,
          exaggeration: opts.exaggeration != null ? opts.exaggeration : 0.4,
          cfg_weight: opts.cfg != null ? opts.cfg : 0.5,
        }).then((r) => applyFx(opts.ffmpeg, r.path, opts.fx || "nenhum"));
      let next = frases.length ? gen(0) : null;
      for (let i = 0; i < frases.length && !state.stopped; i++) {
        const file = await next;
        next = i + 1 < frases.length ? gen(i + 1) : null; // gera a próxima enquanto esta toca
        await playFile(file, state);
        for (const f of [file, file.replace(/-fx\.wav$/i, ".wav")]) {
          try {
            fs.unlinkSync(f);
          } catch {}
        }
      }
      if (next) next.catch(() => {});
      return { ok: true };
    })().catch((e) => ({ ok: false, error: e.message || String(e) }));
    return {
      promise,
      stop() {
        state.stopped = true;
        if (state.audio) {
          try {
            state.audio.pause();
          } catch {}
        }
      },
    };
  };

  if (typeof window !== "undefined") window.NaturalVoice = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
