# Estilo aprovado – UPsell UP 3 multiproduto (Impetus)

Aprovado no UP 3 HerzPur / GlucoVital / NachtPrime (GER, 4:5, 1292x1604, 24 qps) em 2026-11-20. Valores completos em `padrao-up3.md`.

## Entrega
- Tudo na timeline do Premiere, em camadas separadas, numa cópia "<sequência> - MONTADA". Marcadores por bloco.

## Produtos
- Cada produto aparece quando é citado. Produto novo só depois de apresentado na fala.
- BG do produto novo nas telas-chave (apresentação, ingredientes, três pilares, oferta, garantia, CTA).

## Tela de produto (mockup PNG sobre fundo)
- Mockup parado no centro (Y 0,60), escala 48–56 %.
- Animação: predefinição **"ZOOM IN 20X"** ou **"ZOOM OUT 20X"** (Transform, Escala 100→120 % ou 120→100 %, ~10 s, suavizado). Alternar in/out entre telas seguidas.
- **Não usar "EFEITO 3D"** (Basic 3D girando + sombra) nessas telas.
- Fundo de HerzPur/GlucoVital: o mockup animado do próprio produto com "Gaussian Blur + LUMETRI". Fundo do produto novo: o BG dele, sem blur.

## Cartões
- Sequência aninhada 4:5 a 79 %, "borda arredondada", zoom 100→110 %, sobre a mesma aninhada desfocada ("Gaussian Blur + LUMETRI") + vinheta vertical.

## Destaques
- Anton branco MAIÚSCULAS, trecho a trecho da legenda, Wonder Glow, pop 0→100 % em 0,16 s e 100→118 % até o fim, sobre camada de ajuste com "Gaussian Blur + LUMETRI".

## Neon
- MOGRT "Text Animation_Neon_04" amarelo (255,232,0), Y 0,23, só preços e nome do produto novo.

## Transições, acabamento, áudio
- Lens Blur + Flash em camadas de ajuste nos cortes (2 curtos : 1 longo), zoom suave nas viradas, light leak + shutter só na oferta/fechamento, vinheta geral.
- Mesmas trilhas e SFX do UP 1; trilhas a −22,6 dB com fades.
