/*
 * Comando de voz: grava o microfone pelo ffmpeg (DirectShow), para sozinho quando a pessoa
 * para de falar e transcreve no próprio PC.
 *
 * Transcrição: whisper.cpp na placa de vídeo, se o plugin B-roll Automático já o instalou
 * (~/.premiere-broll/whisper + modelo large-v3-turbo), que leva ~1 s; senão, o transcritor
 * do próprio painel (Whisper no processador, mais lento).
 */
(function () {
  "use strict";

  const req = typeof require === "function" ? require : null;
  if (!req) {
    if (typeof window !== "undefined") window.Voice = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const { spawn, spawnSync } = req("child_process");

  const RATE = 16000;
  const api = {};

  // Microfones do Windows (DirectShow), na ordem do sistema.
  api.listMics = function (ffmpeg) {
    if (!ffmpeg) return [];
    try {
      const r = spawnSync(ffmpeg, ["-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"], { encoding: "utf8", windowsHide: true, timeout: 10000 });
      const text = String(r.stderr || "") + String(r.stdout || "");
      const out = [];
      for (const line of text.split(/\r?\n/)) {
        const m = line.match(/"([^"]+)"\s*\(audio\)/);
        if (m) out.push(m[1]);
      }
      return out;
    } catch {
      return [];
    }
  };

  // Igual a listMics, sem travar o painel.
  api.listMicsAsync = function (ffmpeg) {
    return new Promise((resolve) => {
      if (!ffmpeg) return resolve([]);
      const p = spawn(ffmpeg, ["-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"], { windowsHide: true });
      let text = "";
      p.stdout.on("data", (d) => (text += d));
      p.stderr.on("data", (d) => (text += d));
      p.on("error", () => resolve([]));
      p.on("close", () => {
        const out = [];
        for (const line of text.split(/\r?\n/)) {
          const m = line.match(/"([^"]+)"\s*\(audio\)/);
          if (m) out.push(m[1]);
        }
        resolve(out);
      });
    });
  };

  // Microfone padrão do Windows (Configurações > Som > Entrada): { name, muted, level } (name "" se não houver).
  api.defaultMicName = function (script) {
    return new Promise((resolve) => {
      if (!script) return resolve({ name: "" });
      const p = spawn("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script], { windowsHide: true });
      let out = "";
      p.stdout.on("data", (d) => (out += d));
      p.on("error", () => resolve({ name: "" }));
      p.on("close", () => {
        const line = out.replace(/^\uFEFF/, "").trim().split(/\r?\n/).pop() || "";
        const [name, state, level] = line.split("|");
        resolve({ name: name || "", muted: state === "mudo", level: level != null && level !== "" ? Number(level) : null });
      });
      setTimeout(() => {
        try {
          p.kill();
        } catch {}
      }, 8000);
    });
  };

  // Acha, na lista do ffmpeg, o aparelho com o nome do padrão do Windows (nomes podem vir cortados).
  api.matchDevice = function (list, name) {
    if (!list.length) return "";
    if (!name) return "";
    const n = name.toLowerCase();
    return (
      list.find((d) => d.toLowerCase() === n) ||
      list.find((d) => n.startsWith(d.toLowerCase()) || d.toLowerCase().startsWith(n)) ||
      list.find((d) => n.includes(d.toLowerCase()) || d.toLowerCase().includes(n)) ||
      ""
    );
  };

  function wavHeader(dataBytes) {
    const h = Buffer.alloc(44);
    h.write("RIFF", 0);
    h.writeUInt32LE(36 + dataBytes, 4);
    h.write("WAVE", 8);
    h.write("fmt ", 12);
    h.writeUInt32LE(16, 16);
    h.writeUInt16LE(1, 20);
    h.writeUInt16LE(1, 22);
    h.writeUInt32LE(RATE, 24);
    h.writeUInt32LE(RATE * 2, 28);
    h.writeUInt16LE(2, 32);
    h.writeUInt16LE(16, 34);
    h.write("data", 36);
    h.writeUInt32LE(dataBytes, 40);
    return h;
  }

  /*
   * Grava até parar (stop()), até o silêncio depois da fala (autoStop) ou até maxSec.
   * opts: { ffmpeg, device, outFile, autoStop: true, silenceSec: 1.3, maxSec: 60, onLevel(db, speaking) }
   * -> { promise: Promise<{ wav, seconds, spoke }>, stop(), cancel() }
   */
  api.record = function (opts) {
    const device = opts.device || api.listMics(opts.ffmpeg)[0];
    let proc = null, finished = false, cancelled = false;
    const chunks = [];
    let bytes = 0;
    const promise = new Promise((resolve, reject) => {
      if (!opts.ffmpeg) return reject(new Error("ffmpeg não encontrado."));
      if (!device && !opts.inputArgs) return reject(new Error("Nenhum microfone encontrado. Confira se ele está ligado e liberado em Configurações do Windows > Privacidade > Microfone (\"permitir que apps da área de trabalho acessem o microfone\")."));
      // inputArgs: só para testes (ex.: um arquivo tocado em tempo real no lugar do microfone).
      const input = opts.inputArgs || ["-f", "dshow", "-audio_buffer_size", "50", "-i", "audio=" + device];
      proc = spawn(opts.ffmpeg, ["-hide_banner", "-nostdin", "-v", "error"].concat(input, [ "-ac", "1", "-ar", String(RATE), "-f", "s16le", "-"]), { windowsHide: true });
      let err = "";
      const win = Math.round(RATE * 0.05) * 2; // 50 ms em bytes
      let pending = Buffer.alloc(0);
      let noise = null, calib = [], speechMs = 0, silenceMs = 0, spoke = false, elapsed = 0;
      const silenceSec = opts.silenceSec || 1.3;
      const maxMs = (opts.maxSec || 60) * 1000;

      proc.stdout.on("data", (d) => {
        chunks.push(d);
        bytes += d.length;
        pending = pending.length ? Buffer.concat([pending, d]) : d;
        while (pending.length >= win) {
          const w = pending.subarray(0, win);
          pending = pending.subarray(win);
          let sum = 0;
          for (let i = 0; i < w.length; i += 2) {
            const s = w.readInt16LE(i) / 32768;
            sum += s * s;
          }
          const db = 20 * Math.log10(Math.sqrt(sum / (w.length / 2)) + 1e-9);
          elapsed += 50;
          // Os primeiros 300 ms medem o ruído do ambiente.
          if (elapsed <= 300) {
            calib.push(db);
            if (elapsed === 300) noise = calib.sort((a, b) => a - b)[Math.floor(calib.length / 2)];
          }
          const floor = noise == null ? -60 : noise;
          const speaking = db > Math.max(floor + 12, -48);
          if (speaking) {
            speechMs += 50;
            silenceMs = 0;
            if (speechMs >= 250) spoke = true;
          } else silenceMs += 50;
          if (opts.onLevel) opts.onLevel(db, speaking);
          if (opts.autoStop !== false && spoke && silenceMs >= silenceSec * 1000) stop();
          if (elapsed >= maxMs) stop();
          // Ninguém falou em 8 s: desiste.
          if (opts.autoStop !== false && !spoke && elapsed >= 8000) stop();
        }
      });
      proc.stderr.on("data", (d) => (err += d));
      proc.on("error", (e) => reject(e));
      proc.on("close", () => {
        if (cancelled) return resolve({ cancelled: true });
        if (bytes < RATE) return reject(new Error("O microfone não mandou áudio. " + (err.trim().split(/\r?\n/).pop() || "Confira se ele está liberado para apps da área de trabalho.")));
        const data = Buffer.concat(chunks, bytes - (bytes % 2));
        fs.mkdirSync(path.dirname(opts.outFile), { recursive: true });
        fs.writeFileSync(opts.outFile, Buffer.concat([wavHeader(data.length), data]));
        resolve({ wav: opts.outFile, seconds: data.length / 2 / RATE, spoke, device });
      });
      proc._spoke = () => spoke;
    });
    function stop() {
      if (finished || !proc) return;
      finished = true;
      // "q" encerra o ffmpeg com calma; o kill garante.
      try {
        proc.stdin.write("q");
      } catch {}
      setTimeout(() => {
        try {
          proc.kill();
        } catch {}
      }, 300);
      try {
        proc.kill();
      } catch {}
    }
    return {
      promise,
      device,
      stop,
      cancel() {
        cancelled = true;
        stop();
      },
    };
  };

  // ------------------------------------------------------------ transcrição

  const HOME = os.homedir();
  api.findWhisperCpp = function () {
    const base = path.join(HOME, ".premiere-broll");
    for (const sub of ["whisper", path.join("whisper", "Release"), path.join("whisper", "bin")]) {
      const exe = path.join(base, sub, "whisper-cli.exe");
      if (fs.existsSync(exe)) {
        const models = path.join(base, "models");
        let model = path.join(models, "ggml-large-v3-turbo-q5_0.bin");
        if (!fs.existsSync(model)) {
          try {
            const any = fs.readdirSync(models).find((f) => /^ggml-.*\.bin$/i.test(f));
            model = any ? path.join(models, any) : null;
          } catch {
            model = null;
          }
        }
        if (model) return { exe, model };
      }
    }
    return null;
  };

  const LANG_CODE = { portuguese: "pt", english: "en", spanish: "es", french: "fr", german: "de", italian: "it", auto: "auto" };

  // Vocabulário que ajuda o Whisper a acertar termos de edição e nomes dos clientes.
  const PROMPT = "Comando para o Premiere: decupagem, timeline, sequência, b-roll, insert, lower third, legenda, trilha, SFX, HyperFrames, skill, Impetus, upsell, lead dopaminérgica, marcador, bin, clipe.";

  // Frases que o Whisper inventa quando só há silêncio ou ruído.
  const HALLUCINATIONS = /^(legendas? pela comunidade|obrigad[oa]\.?$|tchau\.?$|\[.*\]$|\(.*\)$|música\.?$|♪)/i;

  function cleanText(t) {
    t = String(t || "").replace(/\s+/g, " ").trim();
    if (t.startsWith(PROMPT.slice(0, 20))) t = "";
    if (HALLUCINATIONS.test(t)) return "";
    return t;
  }

  api.transcribe = function (wav, opts) {
    opts = opts || {};
    const lang = LANG_CODE[opts.language] || "pt";
    const wc = api.findWhisperCpp();
    if (wc) {
      return new Promise((resolve, reject) => {
        const args = ["-m", wc.model, "-f", wav, "-l", lang, "-nt", "-np", "--prompt", PROMPT];
        const p = spawn(wc.exe, args, { windowsHide: true, cwd: path.dirname(wc.exe) });
        let out = "", err = "";
        p.stdout.on("data", (d) => (out += d));
        p.stderr.on("data", (d) => (err += d));
        p.on("error", reject);
        p.on("close", (code) => {
          if (code !== 0) return reject(new Error("whisper.cpp falhou: " + err.slice(-300)));
          resolve({ text: cleanText(out), engine: "whisper.cpp (placa de vídeo)" });
        });
      });
    }
    if (!opts.Local) return Promise.reject(new Error("Transcritor não encontrado."));
    return opts.Local.transcribe(wav, { model: opts.model, language: opts.language === "auto" ? "portuguese" : opts.language }).then((t) => ({
      text: cleanText((t.segments || []).map((s) => s.text).join(" ") || t.text),
      engine: "Whisper (processador)",
    }));
  };

  // ------------------------------------------------------------ fala (vozes do Windows)

  let voicesCache = null;
  // -> [{ id, name, lang }] (id "onecore:Microsoft Daniel" ou nome SAPI)
  api.listVoices = function (script) {
    if (voicesCache) return voicesCache;
    try {
      const r = spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-List"], { encoding: "utf8", windowsHide: true, timeout: 20000 });
      voicesCache = String(r.stdout || "")
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => {
          const [id, lang] = l.split("|");
          return { id, name: id.replace(/^onecore:/, "") + (id.startsWith("onecore:") ? "" : " (clássica)"), lang: lang || "" };
        });
    } catch {
      voicesCache = [];
    }
    return voicesCache;
  };

  // Texto de resposta em markdown -> frases para ler em voz alta (sem código, caminhos e tabelas).
  api.speakable = function (md, maxChars) {
    maxChars = maxChars || 450;
    // Linhas com caminho de arquivo, link ou tabela são detalhe: ficam só no texto.
    let t = String(md || "")
      .replace(/```[\s\S]*?```/g, " ")
      .split(/\r?\n/)
      .filter((l) => !/[A-Za-z]:\\|https?:\/\/|^\s*\|/.test(l))
      .join("\n")
      .replace(/`([^`]*)`/g, (m, inner) => (/[\\/]|\.\w{2,4}$/.test(inner) ? "" : inner))
      .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/^\s*\|.*\|\s*$/gm, "")
      .replace(/^\s*[-*]\s+/gm, "")
      .replace(/^\s*\d+\.\s+/gm, "")
      .replace(/^#+\s*/gm, "")
      .replace(/[A-Za-z]:\\[^\s,;)]+/g, "")
      .replace(/https?:\/\/\S+/g, "")
      .replace(/[*_~>#|]/g, "")
      .replace(/[ \t]+/g, " ");
    const paras = t.split(/\n\s*\n/).map((p) => p.replace(/\s*\n\s*/g, ". ").replace(/\.\s*\./g, ".").trim()).filter(Boolean);
    let out = "";
    for (const p of paras) {
      if (!out) out = p;
      else if ((out + " " + p).length <= maxChars) out += " " + p;
      else break;
      if (out.length >= maxChars) break;
    }
    if (out.length > maxChars) {
      const cut = out.slice(0, maxChars);
      const end = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "));
      out = end > 80 ? cut.slice(0, end + 1) : cut.replace(/\s+\S*$/, "") + "…";
    }
    return out.trim();
  };

  /*
   * Fala o texto. opts: { script (caminho do tts.ps1), voice, rate (-5..5) }
   * -> { promise (resolve quando termina ou é parado), stop() }
   */
  api.speak = function (text, opts) {
    const file = path.join(os.tmpdir(), "premiere-chat-fala-" + Date.now() + ".txt");
    fs.writeFileSync(file, String(text), "utf8");
    const args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", opts.script, "-TextFile", file, "-Rate", String(Math.round(opts.rate || 0))];
    if (opts.voice) args.push("-Voice", opts.voice);
    const p = spawn("powershell.exe", args, { windowsHide: true });
    let err = "";
    p.stderr.on("data", (d) => (err += d));
    const promise = new Promise((resolve) => {
      p.on("close", (code) => {
        try {
          fs.unlinkSync(file);
        } catch {}
        resolve({ ok: code === 0, error: code === 0 ? null : err.trim().slice(-300) });
      });
      p.on("error", (e) => resolve({ ok: false, error: e.message }));
    });
    return {
      promise,
      stop() {
        try {
          spawnSync("taskkill", ["/pid", String(p.pid), "/T", "/F"], { windowsHide: true });
        } catch {}
      },
    };
  };

  if (typeof window !== "undefined") window.Voice = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
