# Estilo do UPsell Emagrecimento (Impetus)

Referência visual indicada pelo usuário: `D:\Clientes\IMPETUS\TESTES DE IA\REFERENCiA\UP_1A_V2_Jellyglow_GER_Digistore_40m40s.mp4`
(8 min e 30 s, 1080x1350, 24 qps, −17,1 LUFS). Valores abaixo foram medidos nela e são os padrões de `render.py` (dicionário `E`).
Primeiro vídeo feito com a skill: Cidrepeak FRA (pasta `D:\Clientes\IMPETUS\TESTES DE IA`).

## Formato e ritmo
- 4:5, 1080x1350, 24 qps.
- Decupagem: silêncio maior que 0,22 s é cortado (sobram 0,10 s depois da fala e 0,12 s antes da próxima). Na referência a maior pausa é 0,42 s.
- Média de uma cena nova a cada ~2,7 s. Apresentador alterna plano aberto (100%) e fechado (132%, no rosto de quem fala) a cada corte; depoimento alterna 100% / 115%.
- Ordem dos brutos: número no início do nome (`1 LISA`, `2 LUCILE`...). Quem fala vem do nome do arquivo.
- Bruto vertical 9:16: janela 4:5 a partir de y=150 (cabeças no terço de cima). Depoimento (outro formato): janela centralizada.

## Legenda normal (preset "Legendas Andre")
- Poppins SemiBold 60 px, branca, sombra suave.
- Caixa arredondada (raio 14) cor #121212 a 52% de opacidade, altura 97 px, margem lateral 22 px.
- Centro da caixa em y=1194. Centralizada.
- 1 a 3 palavras, até ~18 caracteres, quebrando na pontuação. Entra seca, sem animação.
- Some enquanto houver destaque na tela.

## Destaque (texto grande)
- Bebas Neue Bold 150 px, MAIÚSCULAS, branco, sombra escura, centro em y=650. Palavra-chave em amarelo #EEFF2D (`y:`).
- Uma a três palavras por cartão, trocando no ritmo da fala (cartões seguidos formam a frase).
- Sobre o apresentador: fundo desfocado (blur 22) e escurecido (62%), com rampa de 0,18 s. Sobre B-roll: o B-roll fica nítido e escurece 25%.
- Cartão misto (linha pequena + palavra grande, como "Lesen Sie das / NOCH EINMAL / in Ruhe"): linha pequena Poppins SemiBold 92 px, palavra grande Bebas até 270 px (ocupa quase toda a largura). Aprovado maior depois do 1º print.
- Onde usar: gancho ("não feche esta página / não clique em voltar"), "fique até o fim", promessas e números fortes, nome do protocolo, "o problema", "livraison gratuite", "relisez calmement", a frase do pack mais caro e o fechamento da oferta. No Cidrepeak: 16 trechos em 5 min e 53 s.

## Nome na tela
- Poppins Bold 64 px branca + faixa laranja #F29A0E atrás da metade de baixo; segunda linha Poppins SemiBold 34 px. Em y=960.
- Do lado de quem fala (esquerda por padrão; `"lado": "direita"` para quem está à direita).

## B-roll
- Cobre a tela (sem cartão), com aproximação lenta de 100% para 106%.
- Casar com a frase: corpo/3D para hormônios e metabolismo, relógio/calendário para prazos, caixa/entrega para "seu pedido", laboratório para qualidade/ciência, produto animado para dose e ingredientes, mulheres para resultado.
- Biblioteca do cliente: `D:\Clientes\IMPETUS\Inserts gerais` (EMAGRECIMENTO, Entregas, Mounjaro, TEMPO. CALENDARIO, Pilulas, Ciencia) e `D:\Clientes\IMPETUS\ARQUIVOS NECESSARIOS` (LABORATORIOS OU CIENTISTAS, 3D VÍDEOS LOST WEIGHT, Background). Evitar vídeos com texto queimado.
- **Escolha de cada insert (orgânico UGC x banco x IA x mockup), cobertura, light leak + shutter, telas, LTs, música e SFX: siga `padroes-upsell-impetus.md`** (aprendido nos 4 upsells entregues). Ele substitui a regra antiga de evitar vídeos estilo TikTok: nos vídeos aprovados o UGC orgânico é usado para resultado/prova real, em cartão sobre o fundo do produto.
- Produto: `Inserts/Produto` (mockups PNG por quantidade de potes e `Animados/1, 2, 3, 6 POTES`).

## Tela de preço
- Fundo `ARQUIVOS NECESSARIOS\Background\BG YELLOW.mp4` (marrom), em loop.
- Mockup da quantidade falada (12, 9, 6 potes) no alto, flutuando devagar, com sombra.
- Preço em neon no centro (y≈0,56): verde #39FF14 para preço por pote, amarelo #F0FF3C para total. Entra no instante em que o número é falado.
- Soma final (6 já comprados + 12 de hoje): dois mockups (em cima e embaixo) e o "18" em neon no meio.
- Legenda normal continua por cima.

## Acabamento
- Vinheta em todo o vídeo (cantos a ~55%).
- Clarão branco (0,18 s subindo, 0,32 s descendo) nas viradas de assunto: início do gancho, início de cada bloco do roteiro, depoimento, "o problema", início da oferta, "relisez", soma final. No Cidrepeak: 8.

## Áudio
- Voz do decupado, normalizada, compressão leve.
- Trilha da pasta `D:\EDIÇÃO\Musicas\Musicas Storytelling`, 18 LU abaixo da voz. Duas trilhas trocando no depoimento (Cidrepeak: "Flowing Energy" até o depoimento, "Corporate On Minimal" até o fim).
- SFX de `D:\EDIÇÃO\Musicas\SFX`, só onde a referência usa: whoosh suave (`mid whoosh`, −12 dB) com o pico no clarão; `swhoosh` (−17 dB) na entrada das telas de preço sem clarão. Nada de efeito cartoon ou agressivo.
- Final em −17 LUFS, limitador em −1 dB.
