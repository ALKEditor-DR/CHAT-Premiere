/*
 * Ferramentas locais do painel (Node): transcrição com Whisper no próprio computador,
 * localização do ffmpeg/node e do preset de WAV do Premiere, gravação de SRT, frames e backups.
 * Nada aqui usa internet além do download único do modelo de transcrição.
 */
(function (root) {
  "use strict";

  const req = typeof require === "function" ? require : root.require;
  if (typeof req !== "function") {
    root.LocalTools = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const { spawn } = req("child_process");

  const IS_WIN = process.platform === "win32";
  const HOME_DIR = path.join(os.homedir(), ".premiere-chat");
  const api = {};

  function dir(...parts) {
    const d = path.join(HOME_DIR, ...parts);
    fs.mkdirSync(d, { recursive: true });
    return d;
  }

  function isFile(p) {
    try {
      return fs.statSync(p).isFile();
    } catch {
      return false;
    }
  }

  // config.json é escrito pelo install.ps1 com os caminhos de node e ffmpeg encontrados.
  function config() {
    try {
      return JSON.parse(fs.readFileSync(path.join(HOME_DIR, "config.json"), "utf8").replace(/^﻿/, ""));
    } catch {
      return {};
    }
  }

  function which(names, extra) {
    const list = [];
    for (const d of (process.env.PATH || "").split(path.delimiter)) {
      if (d) for (const n of names) list.push(path.join(d, n));
    }
    list.push(...(extra || []));
    return list.find(isFile) || null;
  }

  // Executáveis instalados pelo winget ficam em pastas versionadas.
  function wingetFind(prefix, rel) {
    if (!IS_WIN || !process.env.LOCALAPPDATA) return [];
    const base = path.join(process.env.LOCALAPPDATA, "Microsoft", "WinGet", "Packages");
    const out = [];
    let pkgs = [];
    try {
      pkgs = fs.readdirSync(base).filter((p) => p.startsWith(prefix));
    } catch {
      return out;
    }
    for (const p of pkgs) {
      let subs = [];
      try {
        subs = fs.readdirSync(path.join(base, p));
      } catch {}
      for (const s of subs) out.push(path.join(base, p, s, rel));
    }
    return out;
  }

  api.findNode = function () {
    const c = config();
    if (c.node && isFile(c.node)) return c.node;
    return which(IS_WIN ? ["node.exe"] : ["node"], [
      ...wingetFind("OpenJS.NodeJS", "node.exe"),
      "C:\\Program Files\\nodejs\\node.exe",
      "/opt/homebrew/bin/node",
      "/usr/local/bin/node",
    ]);
  };

  api.findFfmpeg = function () {
    const c = config();
    if (c.ffmpeg && isFile(c.ffmpeg)) return c.ffmpeg;
    return which(IS_WIN ? ["ffmpeg.exe"] : ["ffmpeg"], [
      ...wingetFind("Gyan.FFmpeg", path.join("bin", "ffmpeg.exe")),
      "/opt/homebrew/bin/ffmpeg",
      "/usr/local/bin/ffmpeg",
    ]);
  };

  api.transcriberScript = function () {
    const p = path.join(HOME_DIR, "transcriber", "transcribe.js");
    return isFile(p) && fs.existsSync(path.join(HOME_DIR, "transcriber", "node_modules", "@huggingface")) ? p : null;
  };

  // Preset "Waveform Audio 48kHz 16-bit" que vem com o Premiere.
  api.findWavPreset = function (hostExePath) {
    const roots = [];
    if (hostExePath) roots.push(path.dirname(hostExePath));
    if (IS_WIN) {
      try {
        for (const d of fs.readdirSync("C:\\Program Files\\Adobe")) {
          if (/^Adobe Premiere Pro/i.test(d)) roots.push(path.join("C:\\Program Files\\Adobe", d));
        }
      } catch {}
    }
    for (const r of roots) {
      const base = path.join(r, "MediaIO", "systempresets");
      let subs = [];
      try {
        subs = fs.readdirSync(base);
      } catch {
        continue;
      }
      for (const s of subs) {
        let files = [];
        try {
          files = fs.readdirSync(path.join(base, s));
        } catch {}
        const f = files.find((n) => /^Waveform Audio.*\.epr$/i.test(n));
        if (f) return path.join(base, s, f);
      }
    }
    return null;
  };

  // Largura e altura de uma imagem ou vídeo (ffprobe), ou null.
  api.probeSize = function (file) {
    const ffmpeg = api.findFfmpeg();
    if (!ffmpeg) return null;
    const probe = path.join(path.dirname(ffmpeg), IS_WIN ? "ffprobe.exe" : "ffprobe");
    if (!isFile(probe)) return null;
    try {
      const r = req("child_process").spawnSync(probe, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", file], { encoding: "utf8", windowsHide: true, timeout: 15000 });
      const m = String(r.stdout || "").trim().match(/^(\d+),(\d+)/);
      return m ? { width: Number(m[1]), height: Number(m[2]) } : null;
    } catch {
      return null;
    }
  };

  // Preset de vídeo para exportar a sequência (H.264, igual à origem). -> { preset, ext } ou null
  api.findVideoPreset = function (hostExePath) {
    const roots = [];
    if (hostExePath) roots.push(path.dirname(hostExePath));
    if (IS_WIN) {
      try {
        for (const d of fs.readdirSync("C:\\Program Files\\Adobe")) {
          if (/^Adobe Premiere/i.test(d)) roots.push(path.join("C:\\Program Files\\Adobe", d));
        }
      } catch {}
    }
    // Em ordem de preferência: MP4 H.264 igual à origem; senão H.264 em MOV.
    const wanted = [
      [/^Match Source - Adaptive High Bitrate\.epr$/i, ".mp4"],
      [/^Match Source - High Bitrate\.epr$/i, ".mp4"],
      [/^H\.?264 Match Source - High bitrate\.epr$/i, ".mov"],
    ];
    for (const [re, ext] of wanted) {
      for (const r of roots) {
        const base = path.join(r, "MediaIO", "systempresets");
        let subs = [];
        try {
          subs = fs.readdirSync(base);
        } catch {
          continue;
        }
        for (const s of subs) {
          let files = [];
          try {
            files = fs.readdirSync(path.join(base, s));
          } catch {}
          const f = files.find((n) => re.test(n));
          // 4D6F6F56 = QuickTime (.mov); 4E49434B_48323634 = H.264 (.mp4)
          if (f) return { preset: path.join(base, s, f), ext: /4D6F6F56/i.test(s) ? ".mov" : ext };
        }
      }
    }
    return null;
  };

  api.workFile = function (name) {
    return path.join(dir("work"), name);
  };

  /*
   * Transcreve um arquivo de áudio/vídeo localmente.
   * opts: { model, language, onProgress(msg) } -> Promise<{ duration, text, segments }>
   */
  api.transcribe = function (mediaPath, opts) {
    opts = opts || {};
    return new Promise((resolve, reject) => {
      const node = api.findNode();
      const ffmpeg = api.findFfmpeg();
      const script = api.transcriberScript();
      if (!node) return reject(new Error("Node.js não encontrado. Rode o install.ps1 de novo."));
      if (!ffmpeg) return reject(new Error("ffmpeg não encontrado. Instale com: winget install Gyan.FFmpeg"));
      if (!script) return reject(new Error("Transcritor não instalado. Rode o install.ps1 de novo."));

      const out = api.workFile("transcricao-" + Date.now() + ".json");
      const args = [script, mediaPath, "--out", out, "--ffmpeg", ffmpeg];
      if (opts.model) args.push("--model", opts.model);
      if (opts.language) args.push("--language", opts.language);

      const child = spawn(node, args, { cwd: path.dirname(script), windowsHide: true, stdio: ["ignore", "ignore", "pipe"] });
      let errBuf = "";
      let lastError = "";
      child.stderr.setEncoding("utf8");
      child.stderr.on("data", (d) => {
        errBuf += d;
        let nl;
        while ((nl = errBuf.indexOf("\n")) >= 0) {
          const line = errBuf.slice(0, nl).trim();
          errBuf = errBuf.slice(nl + 1);
          try {
            const ev = JSON.parse(line);
            if (ev.progress && opts.onProgress) opts.onProgress(ev.progress);
            if (ev.error) lastError = ev.error;
          } catch {
            if (line) lastError = line;
          }
        }
      });
      child.on("error", (e) => reject(e));
      child.on("close", (code) => {
        if (code !== 0) return reject(new Error("Falha na transcrição: " + (lastError || "código " + code)));
        try {
          const data = JSON.parse(fs.readFileSync(out, "utf8"));
          data.file = out;
          resolve(data);
        } catch (e) {
          reject(new Error("Resultado da transcrição ilegível: " + e.message));
        }
      });
      api._cancelTranscription = () => child.kill();
    });
  };

  // ---------------------------------------------------------------- SRT

  const TC = /^(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})$/;

  function tcToSec(tc) {
    const m = TC.exec(tc.trim());
    if (!m) return null;
    return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4].padEnd(3, "0") / 1000;
  }

  // Valida e normaliza um SRT. Retorna { srt, count } ou lança erro descritivo.
  api.normalizeSrt = function (text) {
    const blocks = String(text).replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").trim().split(/\n\s*\n/);
    const out = [];
    let prevEnd = -1;
    blocks.forEach((b, i) => {
      const lines = b.split("\n");
      if (/^\d+$/.test(lines[0].trim())) lines.shift();
      const times = (lines.shift() || "").split("-->");
      const start = times.length === 2 ? tcToSec(times[0]) : null;
      const end = times.length === 2 ? tcToSec(times[1]) : null;
      if (start === null || end === null) throw new Error(`Bloco ${i + 1}: tempo inválido (use 00:00:01,000 --> 00:00:03,500).`);
      if (end <= start) throw new Error(`Bloco ${i + 1}: o fim precisa ser depois do início.`);
      if (start < prevEnd - 0.001) throw new Error(`Bloco ${i + 1}: começa antes do fim da legenda anterior.`);
      const body = lines.map((l) => l.trim()).filter(Boolean);
      if (!body.length) throw new Error(`Bloco ${i + 1}: sem texto.`);
      prevEnd = end;
      out.push({ start, end, body });
    });
    if (!out.length) throw new Error("SRT vazio.");
    const fmt = (s) => {
      const ms = Math.round(s * 1000);
      const p = (n, w) => String(n).padStart(w, "0");
      return `${p(Math.floor(ms / 3600000), 2)}:${p(Math.floor(ms / 60000) % 60, 2)}:${p(Math.floor(ms / 1000) % 60, 2)},${p(ms % 1000, 3)}`;
    };
    const srt = out.map((c, i) => `${i + 1}\n${fmt(c.start)} --> ${fmt(c.end)}\n${c.body.join("\n")}`).join("\n\n") + "\n";
    return { srt, count: out.length };
  };

  // Grava o SRT ao lado do projeto (pasta "Legendas") ou na pasta de trabalho do painel.
  api.writeSrt = function (srt, name, projectPath) {
    let base;
    if (projectPath) {
      base = path.join(path.dirname(projectPath), "Legendas");
      try {
        fs.mkdirSync(base, { recursive: true });
      } catch {
        base = dir("legendas");
      }
    } else {
      base = dir("legendas");
    }
    const safe = String(name || "Legenda corrigida").replace(/[\\/:*?"<>|]+/g, "-").slice(0, 80);
    const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    const file = path.join(base, `${safe} ${stamp}.srt`);
    fs.writeFileSync(file, "\uFEFF" + srt, "utf8");
    return file;
  };

  // ---------------------------------------------------------------- arquivos e imagens

  const TEXT_EXT = /\.(srt|vtt|txt|csv|tsv|json|xml|md|sbv|ass|ssa)$/i;

  api.readTextFile = function (p) {
    if (!TEXT_EXT.test(p)) throw new Error("Só leio arquivos de texto (srt, vtt, txt, csv, json, xml, md).");
    const st = fs.statSync(p);
    if (st.size > 3 * 1024 * 1024) throw new Error("Arquivo grande demais (máx. 3 MB).");
    return fs.readFileSync(p, "utf8").replace(/^\uFEFF/, "");
  };

  function waitForFile(p, ms) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      let lastSize = -1;
      const tick = () => {
        let size = -1;
        try {
          size = fs.statSync(p).size;
        } catch {}
        if (size > 0 && size === lastSize) return resolve(true);
        lastSize = size;
        if (Date.now() - t0 > ms) return resolve(size > 0);
        setTimeout(tick, 250);
      };
      tick();
    });
  }
  api.waitForFile = waitForFile;

  // Reduz a imagem (ffmpeg) para economizar o limite de uso e devolve base64 JPEG.
  api.imageForModel = async function (pngPath, maxWidth) {
    const ffmpeg = api.findFfmpeg();
    // Algumas versões do Premiere acrescentam ".png" ao nome pedido.
    const t0 = Date.now();
    while (!isFile(pngPath) && !isFile(pngPath + ".png") && Date.now() - t0 < 15000) {
      await new Promise((r) => setTimeout(r, 250));
    }
    if (!isFile(pngPath) && isFile(pngPath + ".png")) pngPath = pngPath + ".png";
    const ok = await waitForFile(pngPath, 5000);
    if (!ok) throw new Error("O Premiere não gerou o frame.");
    if (!ffmpeg) return { data: fs.readFileSync(pngPath).toString("base64"), mimeType: "image/png" };
    const jpg = pngPath.replace(/\.png$/i, "") + ".jpg";
    await new Promise((resolve) => {
      const ff = spawn(ffmpeg, ["-nostdin", "-y", "-i", pngPath, "-vf", `scale='min(${maxWidth || 1024},iw)':-2`, "-q:v", "4", jpg], {
        windowsHide: true,
        stdio: "ignore",
      });
      ff.on("close", resolve);
      ff.on("error", resolve);
    });
    if (isFile(jpg)) return { data: fs.readFileSync(jpg).toString("base64"), mimeType: "image/jpeg" };
    return { data: fs.readFileSync(pngPath).toString("base64"), mimeType: "image/png" };
  };

  // ---------------------------------------------------------------- anexos do chat

  const zlib = req("zlib");
  const IMAGE_EXT = /\.(png|jpe?g|webp|gif|bmp|tiff?)$/i;
  const MEDIA_EXT = /\.(mp4|mov|mxf|avi|mkv|m4v|webm|mp3|wav|aac|m4a|flac|ogg|aif|aiff|psd|ai|mogrt|prproj)$/i;

  api.attachmentsDir = function () {
    return dir("anexos", new Date().toISOString().slice(0, 10));
  };

  // Grava um anexo que veio sem caminho (print colado, arquivo arrastado) e devolve o caminho.
  api.saveAttachment = function (name, buffer) {
    const safe = String(name || "anexo").replace(/[\\/:*?"<>|]+/g, "-").slice(-100);
    let file = path.join(api.attachmentsDir(), safe);
    if (fs.existsSync(file)) {
      const ext = path.extname(safe);
      file = path.join(api.attachmentsDir(), path.basename(safe, ext) + "-" + Date.now() + ext);
    }
    fs.writeFileSync(file, buffer);
    return file;
  };

  // Leitor mínimo de ZIP (DOCX é um ZIP): devolve { nomeDoArquivo: Buffer }.
  function readZip(buf, wanted) {
    let eocd = -1;
    for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
      if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error("Arquivo DOCX inválido ou corrompido.");
    const count = buf.readUInt16LE(eocd + 10);
    let p = buf.readUInt32LE(eocd + 16);
    const out = {};
    for (let n = 0; n < count; n++) {
      if (buf.readUInt32LE(p) !== 0x02014b50) break;
      const method = buf.readUInt16LE(p + 10);
      const csize = buf.readUInt32LE(p + 20);
      const nlen = buf.readUInt16LE(p + 28);
      const xlen = buf.readUInt16LE(p + 30);
      const clen = buf.readUInt16LE(p + 32);
      const local = buf.readUInt32LE(p + 42);
      const name = buf.toString("utf8", p + 46, p + 46 + nlen);
      p += 46 + nlen + xlen + clen;
      if (!wanted(name)) continue;
      const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
      const data = buf.subarray(start, start + csize);
      try {
        out[name] = method === 8 ? zlib.inflateRawSync(data) : Buffer.from(data);
      } catch {}
    }
    return out;
  }

  const xmlText = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");

  // Converte o document.xml do Word em texto, mantendo negrito (**), marca-texto (==),
  // tachado (~~) e cor, listas e tabelas — muitas copies marcam inserts com cor ou negrito.
  function docxXmlToText(xml) {
    const body = (xml.match(/<w:body>([\s\S]*)<\/w:body>/) || [null, xml])[1];
    const paraText = (p) => {
      let t = "";
      const runs = p.match(/<w:hyperlink\b[\s\S]*?<\/w:hyperlink>|<w:r\b[\s\S]*?<\/w:r>/g) || [];
      for (const r of runs) {
        if (r.startsWith("<w:hyperlink")) { t += paraText(r.replace(/^<w:hyperlink\b[^>]*>/, "")); continue; }
        const rpr = (r.match(/<w:rPr>([\s\S]*?)<\/w:rPr>/) || [null, ""])[1];
        let txt = "";
        for (const x of r.match(/<w:t(?:\s[^>]*)?>[\s\S]*?<\/w:t>|<w:tab\/>|<w:br\s*\/>|<w:br [^>]*\/>/g) || []) {
          if (x.startsWith("<w:tab")) txt += "\t";
          else if (x.startsWith("<w:br")) txt += "\n";
          else txt += xmlText(x.replace(/<[^>]+>/g, ""));
        }
        if (!txt.trim()) { t += txt; continue; }
        const hl = /<w:highlight w:val="(?!none)/.test(rpr) || /<w:shd [^>]*w:fill="(?!auto|FFFFFF)[0-9A-F]{6}"/i.test(rpr);
        const color = (rpr.match(/<w:color w:val="([0-9A-F]{6})"/i) || [])[1];
        const bold = /<w:b\/>|<w:b w:val="(1|true|on)"/.test(rpr);
        const strike = /<w:strike\/>|<w:strike w:val="(1|true|on)"/.test(rpr);
        if (bold) txt = "**" + txt + "**";
        if (hl) txt = "==" + txt + "==";
        if (strike) txt = "~~" + txt + "~~";
        if (color && !/^0{6}$/.test(color)) txt = `{cor #${color.toUpperCase()}: ${txt}}`;
        t += txt;
      }
      return t;
    };
    const out = [];
    for (const b of body.match(/<w:tbl>[\s\S]*?<\/w:tbl>|<w:p\b[\s\S]*?<\/w:p>/g) || []) {
      if (b.startsWith("<w:tbl")) {
        out.push("[tabela]");
        for (const row of b.match(/<w:tr\b[\s\S]*?<\/w:tr>/g) || []) {
          const cells = (row.match(/<w:tc\b[\s\S]*?<\/w:tc>/g) || []).map((c) =>
            (c.match(/<w:p\b[\s\S]*?<\/w:p>/g) || []).map(paraText).join(" / ").trim()
          );
          out.push("| " + cells.join(" | ") + " |");
        }
        out.push("[fim da tabela]");
      } else {
        const style = (b.match(/<w:pStyle w:val="([^"]+)"/) || [])[1] || "";
        const head = /^(Heading|T.?tulo)\s*(\d)/i.exec(style);
        const prefix = head ? "#".repeat(Math.min(+head[2] || 1, 4)) + " " : /<w:numPr>/.test(b) ? "- " : "";
        out.push(prefix + paraText(b));
      }
    }
    return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function docxComments(files) {
    const xml = files["word/comments.xml"];
    if (!xml) return "";
    const list = (xml.toString("utf8").match(/<w:comment\b[\s\S]*?<\/w:comment>/g) || []).map((c) => {
      const who = (c.match(/w:author="([^"]*)"/) || [])[1] || "";
      const txt = (c.match(/<w:t(?:\s[^>]*)?>[\s\S]*?<\/w:t>/g) || []).map((x) => xmlText(x.replace(/<[^>]+>/g, ""))).join("");
      return `- ${who ? who + ": " : ""}${txt}`;
    });
    return list.length ? "\n\n[comentários do documento]\n" + list.join("\n") : "";
  }

  // Reduz qualquer imagem para JPEG (lado maior <= max) dentro da pasta de trabalho.
  function shrinkImage(src, max) {
    const ffmpeg = api.findFfmpeg();
    if (!ffmpeg) return Promise.resolve(null);
    const out = api.workFile("img-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7) + ".jpg");
    const vf = `scale='if(gt(iw,ih),min(${max},iw),-2)':'if(gt(iw,ih),-2,min(${max},ih))'`;
    return new Promise((resolve) => {
      const ff = spawn(ffmpeg, ["-nostdin", "-y", "-i", src, "-frames:v", "1", "-vf", vf, "-q:v", "3", out], {
        windowsHide: true,
        stdio: "ignore",
      });
      ff.on("close", () => resolve(isFile(out) ? out : null));
      ff.on("error", () => resolve(null));
    });
  }

  async function imageBlock(file) {
    const small = await shrinkImage(file, 1568);
    if (small) return { type: "image", source: { type: "base64", media_type: "image/jpeg", data: fs.readFileSync(small).toString("base64") } };
    const mt = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp" }[path.extname(file).toLowerCase()];
    if (!mt) return null;
    return { type: "image", source: { type: "base64", media_type: mt, data: fs.readFileSync(file).toString("base64") } };
  }

  /*
   * Lê um anexo e devolve { kind, name, path, blocks, note }.
   * blocks são blocos de conteúdo da mensagem (texto, imagem, documento PDF) para o Claude.
   */
  api.readAttachment = async function (file) {
    const name = path.basename(file);
    const st = fs.statSync(file);
    const res = { kind: "arquivo", name, path: file, blocks: [], note: "" };
    const header = (label) => `<anexo nome="${name}" tipo="${label}" caminho="${file}">`;

    if (/\.pdf$/i.test(file)) {
      if (st.size > 30 * 1024 * 1024) throw new Error(`${name}: PDF grande demais (máx. 30 MB).`);
      res.kind = "pdf";
      res.blocks.push({ type: "text", text: header("pdf") + " (conteúdo no documento a seguir)</anexo>" });
      res.blocks.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: fs.readFileSync(file).toString("base64") }, title: name });
    } else if (/\.docx$/i.test(file)) {
      res.kind = "docx";
      const files = readZip(fs.readFileSync(file), (n) => n === "word/document.xml" || n === "word/comments.xml" || /^word\/media\/.+\.(png|jpe?g|gif|bmp|webp)$/i.test(n));
      if (!files["word/document.xml"]) throw new Error(`${name}: não achei o texto dentro do DOCX.`);
      const text = docxXmlToText(files["word/document.xml"].toString("utf8")) + docxComments(files);
      res.blocks.push({ type: "text", text: `${header("docx")}\nMarcações: **negrito**, ==marca-texto==, ~~tachado~~, {cor #RRGGBB: texto colorido}.\n\n${text}\n</anexo>` });
      const imgs = Object.keys(files).filter((n) => n.startsWith("word/media/")).slice(0, 8);
      for (const n of imgs) {
        const tmp = api.workFile("docx-" + Date.now() + "-" + path.basename(n));
        fs.writeFileSync(tmp, files[n]);
        const b = await imageBlock(tmp);
        if (b) res.blocks.push({ type: "text", text: `Imagem dentro de ${name}: ${path.basename(n)} (salva em ${tmp})` }, b);
      }
      res.note = `${text.length} caracteres` + (imgs.length ? ` · ${imgs.length} imagem(ns)` : "");
    } else if (/\.(doc|pages|odt|rtf)$/i.test(file)) {
      throw new Error(`${name}: esse formato não dá para ler. Salve como .docx ou PDF e anexe de novo.`);
    } else if (IMAGE_EXT.test(file)) {
      res.kind = "imagem";
      const b = await imageBlock(file);
      if (!b) throw new Error(`${name}: não consegui abrir a imagem.`);
      res.blocks.push({ type: "text", text: header("imagem") + "</anexo>" }, b);
    } else if (TEXT_EXT.test(file)) {
      res.kind = "texto";
      if (st.size > 3 * 1024 * 1024) throw new Error(`${name}: arquivo de texto grande demais (máx. 3 MB).`);
      const text = fs.readFileSync(file, "utf8").replace(/^﻿/, "");
      res.blocks.push({ type: "text", text: `${header("texto")}\n${text}\n</anexo>` });
    } else if (MEDIA_EXT.test(file)) {
      res.kind = "mídia";
      res.blocks.push({ type: "text", text: header("mídia") + " Arquivo de mídia: pode ser importado no projeto (app.project.importFiles) ou transcrito (transcribe_sequence com media_path).</anexo>" });
    } else {
      res.blocks.push({ type: "text", text: header("outro") + " Formato não lido automaticamente; só o caminho.</anexo>" });
    }
    return res;
  };

  // Para a ferramenta read_document: DOCX ou texto como texto puro; imagem como bloco.
  api.readDocumentText = function (file) {
    if (/\.docx$/i.test(file)) {
      const files = readZip(fs.readFileSync(file), (n) => n === "word/document.xml" || n === "word/comments.xml");
      if (!files["word/document.xml"]) throw new Error("Não achei o texto dentro do DOCX.");
      return docxXmlToText(files["word/document.xml"].toString("utf8")) + docxComments(files);
    }
    return api.readTextFile(file);
  };

  api.isImage = (f) => IMAGE_EXT.test(f);
  api.imageBlock = imageBlock;

  // ---------------------------------------------------------------- histórico por projeto

  const crypto = req("crypto");

  // Chave estável por projeto: o caminho do .prproj (sem diferença de maiúsculas/barras).
  api.projectKey = function (projectPath, projectName) {
    const base = projectPath ? path.normalize(projectPath).toLowerCase() : "sem-titulo:" + (projectName || "");
    return crypto.createHash("sha1").update(base).digest("hex").slice(0, 16);
  };

  function historyFile(key) {
    return path.join(dir("historico"), key + ".json");
  }

  api.loadHistory = function (key) {
    try {
      return JSON.parse(fs.readFileSync(historyFile(key), "utf8"));
    } catch {
      return null;
    }
  };

  // Grava num arquivo temporário e renomeia: o histórico não corrompe se o Premiere fechar no meio.
  api.saveHistory = function (key, data) {
    const file = historyFile(key);
    const tmp = file + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(data), "utf8");
    fs.renameSync(tmp, file);
  };

  // "Nova conversa": guarda a conversa anterior em historico/arquivo antes de limpar.
  api.archiveHistory = function (key) {
    const file = historyFile(key);
    if (!isFile(file)) return;
    const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    fs.renameSync(file, path.join(dir("historico", "arquivo"), `${key}-${stamp}.json`));
  };

  // ---------------------------------------------------------------- skills de cliente

  const SKILLS_DIR = path.join(os.homedir(), ".claude", "skills");

  function skillMeta(id) {
    const file = path.join(SKILLS_DIR, id, "SKILL.md");
    let md = "";
    try {
      md = fs.readFileSync(file, "utf8").replace(/^﻿/, "");
    } catch {
      return null;
    }
    const fm = (md.match(/^---\r?\n([\s\S]*?)\r?\n---/) || [null, ""])[1];
    let desc = "";
    const m = fm.match(/^description:\s*(?:>-?|\|-?)?\s*\r?\n?([\s\S]*?)(?=^\w[\w-]*:|$(?![\s\S]))/m);
    if (m) desc = m[1].replace(/\s+/g, " ").trim().replace(/^["']|["']$/g, "");
    return { file, md, desc };
  }

  // Lista as skills de cliente registradas em novo-projeto-edicao/clientes.json.
  api.listClientSkills = function () {
    let clients = {};
    try {
      clients = JSON.parse(fs.readFileSync(path.join(SKILLS_DIR, "novo-projeto-edicao", "clientes.json"), "utf8").replace(/^﻿/, ""));
    } catch {
      return { error: "Não encontrei a lista de clientes (~/.claude/skills/novo-projeto-edicao/clientes.json).", clients: [] };
    }
    const out = [];
    for (const [cliente, info] of Object.entries(clients)) {
      const skills = ((info && info.skills) || []).map((s) => {
        const meta = skillMeta(s.id);
        return { nome: s.nome || s.id, id: s.id, padrao: !!s.padrao, desc: meta ? meta.desc : "", existe: !!meta };
      });
      out.push({ cliente, skills });
    }
    return { clients: out };
  };

  // Skills que não são de cliente (motion, legendas, render...). As remotion-* viram um item só.
  api.listToolSkills = function () {
    const clientIds = new Set();
    for (const c of api.listClientSkills().clients || []) for (const s of c.skills) clientIds.add(s.id);
    let dirs = [];
    try {
      dirs = fs.readdirSync(SKILLS_DIR, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name);
    } catch {
      return [];
    }
    const out = [];
    const remotion = dirs.filter((d) => /^remotion-/.test(d) && skillMeta(d));
    for (const id of dirs.sort()) {
      if (clientIds.has(id) || id === "novo-projeto-edicao" || id === "synced" || /^remotion-/.test(id)) continue;
      const meta = skillMeta(id);
      if (meta) out.push({ id, nome: id, desc: meta.desc });
    }
    if (remotion.length) {
      const main = remotion.includes("remotion-best-practices") ? "remotion-best-practices" : remotion[0];
      out.push({ id: main, nome: `Remotion (${remotion.length} skills)`, desc: "Vídeos e motion em React, renderizados no seu PC: " + remotion.map((r) => r.replace("remotion-", "")).join(", ") + ". Grátis só para pessoa física ou empresa de até 3 pessoas." });
    }
    return out;
  };

  // Cliente do projeto pelo caminho: a pasta logo depois de "Clientes".
  api.clientFromPath = function (p) {
    const parts = String(p || "").split(/[\\/]+/);
    const i = parts.findIndex((x) => /^clientes$/i.test(x));
    return i >= 0 && parts[i + 1] ? parts[i + 1] : null;
  };

  function listFiles(base, max) {
    const out = [];
    const walk = (d) => {
      for (const n of fs.readdirSync(d, { withFileTypes: true })) {
        if (out.length >= max) return;
        const p = path.join(d, n.name);
        if (n.isDirectory()) walk(p);
        else out.push(p);
      }
    };
    try {
      walk(base);
    } catch {}
    return out;
  }

  // Bloco de mensagem com a skill inteira (SKILL.md + lista de arquivos de apoio).
  api.skillBlocks = function (id, nome) {
    const meta = skillMeta(id);
    if (!meta) throw new Error(`Skill "${id}" não encontrada em ${SKILLS_DIR}.`);
    const base = path.join(SKILLS_DIR, id);
    const files = listFiles(base, 200).filter((f) => !/[\\/]SKILL\.md$/i.test(f));
    const text =
      `<skill nome="${nome || id}" id="${id}" pasta="${base}">\n` +
      `Esta é uma skill de edição do usuário, escrita para o Claude Code com terminal. Siga a skill. Aqui no painel: rode os scripts dela com run_command (programa + lista de argumentos, sem terminal), leia arquivos e imagens com Read/Glob/Grep, grave arquivos de texto com write_text_file, crie pastas com make_folders e copie mídia com copy_file. Mostre os prints de teste com show_images (ask_approval) e espere a aprovação antes do render completo. No fim, entregue DENTRO do Premiere em camadas editáveis: import_premiere_xml se a skill gerou XML; senão place_on_timeline (b-roll e imagens na V2+, motions/LTs com fundo transparente acima, trilha e SFX em trilhas de áudio próprias), numa cópia da sequência. Se rodar scripts estiver desligado nas configurações do painel, aplique o padrão dela à mão com as ferramentas do Premiere.\n\n` +
      meta.md +
      (files.length ? `\n\nArquivos da skill:\n${files.map((f) => "- " + f).join("\n")}` : "") +
      `\n</skill>`;
    return [{ type: "text", text }];
  };

  // ---------------------------------------------------------------- alimentar a skill

  // Só estes dois arquivos de uma skill de cliente podem ser alterados pelo chat.
  const SKILL_FILES = {
    historico: path.join("references", "historico-ajustes.md"),
    estilo: path.join("references", "estilo-aprovado.md"),
  };

  function clientSkillIds() {
    const r = api.listClientSkills();
    const ids = new Set();
    for (const c of r.clients || []) for (const s of c.skills) ids.add(s.id);
    return ids;
  }

  api.skillFilePath = function (id, which) {
    if (!clientSkillIds().has(id)) throw new Error(`"${id}" não é uma skill de cliente da lista (clientes.json).`);
    const rel = SKILL_FILES[which];
    if (!rel) throw new Error('Arquivo inválido: use "historico" ou "estilo".');
    return path.join(SKILLS_DIR, id, rel);
  };

  // Calcula a mudança sem gravar: { file, before, after, mode }.
  api.planSkillEdit = function (id, which, oldText, newText) {
    const file = api.skillFilePath(id, which);
    const before = isFile(file) ? fs.readFileSync(file, "utf8").replace(/^﻿/, "") : "";
    if (!newText || !String(newText).trim()) throw new Error("Texto novo vazio.");
    let after;
    let mode;
    if (oldText) {
      const n = before.split(oldText).length - 1;
      if (n === 0) throw new Error("O trecho a substituir não foi encontrado no arquivo. Leia o arquivo de novo (read_document) e copie o trecho exato.");
      if (n > 1) throw new Error("O trecho a substituir aparece mais de uma vez. Use um trecho maior e único.");
      after = before.replace(oldText, () => newText);
      mode = "substituir";
    } else {
      after = before.replace(/\s*$/, "") + (before.trim() ? "\n\n" : "") + String(newText).replace(/\s*$/, "") + "\n";
      mode = "acrescentar";
    }
    return { file, before, after, mode };
  };

  // Grava, guardando antes uma cópia em ~/.premiere-chat/skill-backups/<skill>/.
  api.applySkillEdit = function (id, which, oldText, newText) {
    const plan = api.planSkillEdit(id, which, oldText, newText);
    let backup = null;
    if (isFile(plan.file)) {
      const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
      backup = path.join(dir("skill-backups", id), `${path.basename(plan.file, ".md")}-${stamp}.md`);
      fs.copyFileSync(plan.file, backup);
    } else {
      fs.mkdirSync(path.dirname(plan.file), { recursive: true });
    }
    const tmp = plan.file + ".tmp";
    fs.writeFileSync(tmp, plan.after, "utf8");
    fs.renameSync(tmp, plan.file);
    return { file: plan.file, backup, mode: plan.mode };
  };

  // ---------------------------------------------------------------- backups

  // Copia o .prproj (recém-salvo) para ~/.premiere-chat/backups, mantendo os 30 mais recentes.
  api.backupProject = function (prprojPath) {
    if (!prprojPath || !isFile(prprojPath)) return null;
    const bdir = dir("backups");
    const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    const dest = path.join(bdir, `${path.basename(prprojPath, ".prproj")} ${stamp}.prproj`);
    fs.copyFileSync(prprojPath, dest);
    const all = fs
      .readdirSync(bdir)
      .filter((f) => f.endsWith(".prproj"))
      .map((f) => ({ f, t: fs.statSync(path.join(bdir, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
    for (const old of all.slice(30)) {
      try {
        fs.unlinkSync(path.join(bdir, old.f));
      } catch {}
    }
    return dest;
  };

  api.backupsDir = () => dir("backups");

  root.LocalTools = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
