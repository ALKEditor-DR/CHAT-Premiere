#!/usr/bin/env python
"""Lê uma sequência de um .prproj e despeja TUDO o que está na timeline em JSON:
por faixa, cada item com início/fim, nome, caminho do arquivo, entrada no arquivo, velocidade, efeitos (com valores
e keyframes), textos de gráficos/legendas, sequências aninhadas, transições e itens desativados.

python analisar_prproj.py projeto.prproj --lista                 (lista as sequências)
python analisar_prproj.py projeto.prproj --seq <n|nome> saida.json
"""
import base64
import gzip
import json
import re
import sys
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
TK = 254016000000
root = ET.fromstring(gzip.open(sys.argv[1]).read())
byid = {e.attrib["ObjectID"]: e for e in root.iter() if "ObjectID" in e.attrib}
uid = {e.attrib["ObjectUID"]: e for e in root.iter() if "ObjectUID" in e.attrib}
POR_HASH = {}
for e in root.iter():
    h = e.attrib.get("BinaryHash")
    if h and e.text and e.text.strip():
        POR_HASH[h] = e.text.strip()


def ref(e):
    if e is None:
        return None
    if "ObjectRef" in e.attrib:
        return byid.get(e.attrib["ObjectRef"])
    if "ObjectURef" in e.attrib:
        return uid.get(e.attrib["ObjectURef"])
    return e


PADRAO = re.compile(rb"(?:[\x20-\x7e]|[\xc2-\xf4][\x80-\xbf]+){3,}")
LIXO = re.compile(r"^(AnimationType|Poppins|LucidaConsole|Arial|Montserrat|Inter|Roboto|Bebas|Anton|Archivo|Oswald|Impact|Helvetica|"
                  r"Open ?Sans|Lato|Raleway|Gotham|Futura|Proxima|Segoe|Myriad|Source|Noto|D3|Kanit|Bangers|TheBold|Komika)", re.I)


def textos_b64(s):
    try:
        raw = base64.b64decode(s)
    except Exception:
        return []
    toks = [t.decode("utf-8", "replace").strip() for t in PADRAO.findall(raw)]
    fontes = [t for t in toks if LIXO.match(t)]
    out = [t for t in toks if not LIXO.match(t) and "�" not in t and re.search(r"[A-Za-zÀ-ÿ0-9€$%]{2}", t)]
    return out, fontes


def seq_nome(clip):
    src = ref(clip.find("Clip/Source"))
    if src is None:
        return None
    for e in src.iter():
        r = ref(e) if ("ObjectRef" in e.attrib or "ObjectURef" in e.attrib) else None
        if r is not None and r.tag == "Sequence":
            return r.findtext("Name")
    return None


def caminho(clip):
    src = ref(clip.find("Clip/Source"))
    if src is None:
        return None
    vis = set()
    pilha = [src]
    while pilha:
        x = pilha.pop()
        if id(x) in vis:
            continue
        vis.add(id(x))
        for tag in ("ActualMediaFilePath", "FilePath"):
            t = x.findtext(".//" + tag)
            if t:
                return t
        for e in x.iter():
            r = ref(e) if ("ObjectRef" in e.attrib or "ObjectURef" in e.attrib) else None
            if r is not None and r.tag in ("Media", "MediaSource", "VideoMediaSource", "AudioMediaSource"):
                pilha.append(r)
    return None


def efeitos(ti):
    co = ti.find("ClipTrackItem/ComponentOwner")
    ch = ref(co.find("Components")) if co is not None else None
    cl = ch.find("ComponentChain/Components") if ch is not None else None
    res, textos, fontes = [], [], []
    for c0 in (cl if cl is not None else []):
        c = ref(c0)
        if c is None:
            continue
        nome = c.findtext("Component/DisplayName") or c.findtext("DisplayName") or c.findtext(".//MatchName") or c.tag
        vals = {}
        bypass = c.findtext("Component/Bypass") == "true"
        for p in (c.find("Component/Params") if c.find("Component/Params") is not None else []):
            pp = ref(p)
            if pp is None:
                continue
            nm = pp.findtext("Name") or ""
            for tag in ("StartKeyframeValue", "CurrentValue", "StartKeyframe"):
                v = pp.findtext(tag)
                if v and len(v) > 60 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", v):
                    t, f = textos_b64(v.strip())
                    textos += t
                    fontes += f
            h = pp.find("StartKeyframeValue")
            if h is not None and h.attrib.get("BinaryHash") in POR_HASH:
                t, f = textos_b64(POR_HASH[h.attrib["BinaryHash"]])
                textos += t
                fontes += f
            if not nm:
                continue
            sk = pp.findtext("StartKeyframe")
            v = sk.split(",")[1] if sk and "," in sk else pp.findtext("CurrentValue")
            if pp.findtext("IsTimeVarying") == "true" and pp.findtext("Keyframes"):
                ks = [k for k in pp.findtext("Keyframes").split(";") if k]
                try:
                    v = "KF:" + ";".join(f"{int(k.split(',')[0]) / TK:.2f}={k.split(',')[1][:8]}" for k in ks[:8])
                except (ValueError, IndexError):
                    v = "KF"
            if v is not None and len(str(v)) < 120:
                vals[nm] = str(v)[:60]
        res.append({"efeito": nome, "desligado": bypass, "valores": vals})
    return res, textos, sorted(set(fontes))


seqs = [x for x in root.iter("Sequence") if x.findtext("Name")]
if "--lista" in sys.argv:
    for i, s in enumerate(seqs):
        print(i, s.findtext("Name"))
    sys.exit()
alvo = sys.argv[sys.argv.index("--seq") + 1]
seq = seqs[int(alvo)] if alvo.isdigit() else next(s for s in seqs if s.findtext("Name") == alvo)
out = {"sequencia": seq.findtext("Name"), "faixas": {}}
for t in seq.find("TrackGroups"):
    g = ref(t.find("Second"))
    if g is None or g.tag not in ("VideoTrackGroup", "AudioTrackGroup", "DataTrackGroup"):
        continue
    k = {"VideoTrackGroup": "V", "AudioTrackGroup": "A", "DataTrackGroup": "LEG"}[g.tag]
    trs = g.find(".//Tracks")
    for i, tt in enumerate(trs if trs is not None else []):
        tr = ref(tt)
        if tr is None:
            continue
        r = tr.find(".//ClipItems/TrackItems")
        itens = []
        for it in (r if r is not None else []):
            ti = ref(it)
            if ti is None:
                continue
            c = ti.find(".//ClipTrackItem")
            if c is None:
                continue
            ts = c.find("TrackItem")
            s = int(ts.findtext("Start") or 0) / TK
            e = int(ts.findtext("End") or 0) / TK
            sc = ref(c.find("SubClip"))
            cl = ref(sc.find("Clip")) if sc is not None else None
            item = {"ini": round(s, 3), "fim": round(e, 3), "nome": sc.findtext("Name") if sc is not None else ti.tag}
            if c.findtext("IsMuted") == "true" or ti.findtext(".//IsMuted") == "true":
                item["desativado"] = True
            if cl is not None:
                ip = cl.findtext("Clip/InPoint")
                item["entrada"] = round(int(ip) / TK, 3) if ip else 0
                sp = cl.findtext("Clip/PlaybackSpeed")
                if sp and sp not in ("1.", "1"):
                    item["velocidade"] = sp
                cam = caminho(cl)
                if cam:
                    item["arquivo"] = cam
                sn = seq_nome(cl)
                if sn:
                    item["aninhada"] = sn
            fx, txt, fontes = efeitos(ti)
            if k == "LEG":
                b = ti.find(".//BlockVectorItem")
                blk = ref(b) if b is not None else None
                if blk is not None:
                    for fd in blk.iter("FormattedTextData"):
                        bb = fd.text.strip() if fd.text and fd.text.strip() else POR_HASH.get(fd.attrib.get("BinaryHash"))
                        if bb:
                            t2, f2 = textos_b64(bb)
                            txt += t2
                            fontes += f2
            fx = [f for f in fx if f["efeito"] not in ("Opacity", "Motion", "Volume", "Channel Volume", "Panner", "Time Remapping")
                  or f["valores"] and any(str(v).startswith("KF") or v not in ("100.", "0.", "1.", "50.", "0.5,0.5") for v in f["valores"].values())]
            if fx:
                item["efeitos"] = fx
            if txt:
                item["texto"] = " | ".join(dict.fromkeys(txt))
            if fontes:
                item["fontes"] = fontes
            itens.append(item)
        trans = []
        tt2 = tr.find(".//TransitionItems/TrackItems")
        for it in (tt2 if tt2 is not None else []):
            x = ref(it)
            q = x.find(".//TransitionTrackItem/TrackItem") if x is not None else None
            if q is not None:
                trans.append({"ini": round(int(q.findtext("Start") or 0) / TK, 3), "fim": round(int(q.findtext("End") or 0) / TK, 3),
                              "nome": x.findtext(".//TransitionTrackItem/DisplayName") or x.findtext(".//DisplayName")})
        if itens or trans:
            out["faixas"][f"{k}{i + 1}"] = {"itens": itens, "transicoes": trans}
json.dump(out, open(sys.argv[-1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k, v in out["faixas"].items():
    print(k, len(v["itens"]), "itens", len(v["transicoes"]), "transições", "| ex:", (v["itens"][0]["nome"] if v["itens"] else ""))
