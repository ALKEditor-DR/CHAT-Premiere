#!/usr/bin/env python
"""Compara dois vídeos quadro a quadro e lista os trechos diferentes. Use para descobrir o que o usuário mudou.

python comparar.py base.mp4 aprovado.mp4 [limiar=2.0]
"""
import subprocess
import sys

import numpy as np

A, B = sys.argv[1], sys.argv[2]
thr = float(sys.argv[3]) if len(sys.argv) > 3 else 2.0
sw, sh = 108, 192


def rd(p):
    return subprocess.Popen(["ffmpeg", "-v", "error", "-i", p, "-vf", f"scale={sw}:{sh}", "-f", "rawvideo", "-pix_fmt", "gray", "-"],
                            stdout=subprocess.PIPE, bufsize=10**8)


pa, pb = rd(A), rd(B)
d = []
while True:
    a = pa.stdout.read(sw * sh)
    b = pb.stdout.read(sw * sh)
    if len(a) < sw * sh or len(b) < sw * sh:
        break
    d.append(float(np.abs(np.frombuffer(a, np.uint8).astype(np.float32) - np.frombuffer(b, np.uint8)).mean()))
d = np.array(d)
on = d > thr
print("frames", len(d), "| diferença mediana", round(float(np.median(d)), 2), "(perto de 1 costuma ser cor ou vinheta no vídeo todo)")
i = 0
while i < len(d):
    if on[i]:
        j = i
        while j + 1 < len(d) and (on[j + 1] or on[j + 1:j + 6].any()):
            j += 1
        print(f"  {i / 30:7.2f} a {(j + 1) / 30:7.2f}  diferença média {d[i:j + 1].mean():.1f}")
        i = j + 1
    else:
        i += 1
