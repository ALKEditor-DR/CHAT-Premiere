/*
 * Decupagem por silêncio: analisa o volume do áudio e calcula os trechos a cortar.
 *
 * Os parâmetros seguem o que os cortadores de silêncio profissionais usam (Auto-Editor,
 * Recut, TimeBolt, AutoCut): limiar em dB, silêncio mínimo para cortar, margem antes e
 * depois da fala, fala mínima (ignora estalos e respiros curtos) e histerese, para o corte
 * não "piscar" quando o volume oscila em volta do limiar.
 *
 * Duas etapas: analyze() lê o áudio uma vez e guarda o volume a cada 10 ms; computeCuts()
 * recalcula os cortes na hora, a cada ajuste, sem ler o áudio de novo.
 */
(function () {
  "use strict";

  const req = typeof require === "function" ? require : null;

  const HOP = 0.01; // 10 ms por janela de análise
  const RATE = 16000;
  const SILENT_DB = -100;

  // Presets. Valores em segundos e dB.
  const PRESETS = {
    natural: {
      label: "Natural (YouTube, aula, podcast)",
      threshold: -40, auto: true, autoOffset: 0, minSilence: 0.7, padBefore: 0.15, padAfter: 0.25,
      minSpeech: 0.15, hysteresis: 3, minCut: 0.2, trimEdges: true,
    },
    dinamico: {
      label: "Dinâmico (Reels, TikTok, VSL)",
      threshold: -38, auto: true, autoOffset: 0, minSilence: 0.35, padBefore: 0.08, padAfter: 0.12,
      minSpeech: 0.12, hysteresis: 3, minCut: 0.15, trimEdges: true,
    },
    agressivo: {
      label: "Agressivo (jump cut)",
      threshold: -35, auto: true, autoOffset: 2, minSilence: 0.2, padBefore: 0.04, padAfter: 0.06,
      minSpeech: 0.1, hysteresis: 2, minCut: 0.1, trimEdges: true,
    },
    suave: {
      label: "Suave (entrevista, depoimento)",
      threshold: -45, auto: true, autoOffset: -2, minSilence: 1.2, padBefore: 0.3, padAfter: 0.4,
      minSpeech: 0.2, hysteresis: 4, minCut: 0.25, trimEdges: true,
    },
  };

  const DEFAULTS = Object.assign({ preset: "dinamico", mode: "ripple", newSequence: true }, PRESETS.dinamico);

  function percentile(sorted, p) {
    if (!sorted.length) return SILENT_DB;
    const i = Math.min(sorted.length - 1, Math.max(0, Math.round((sorted.length - 1) * p)));
    return sorted[i];
  }

  // Estima o ruído de fundo e o nível da fala e sugere um limiar entre os dois.
  function estimate(db) {
    const vals = [];
    for (let i = 0; i < db.length; i++) if (db[i] > -95) vals.push(db[i]);
    vals.sort((a, b) => a - b);
    const noise = percentile(vals, 0.1);
    const speech = percentile(vals, 0.9);
    let suggested = noise + Math.max(6, (speech - noise) * 0.3);
    suggested = Math.max(-60, Math.min(-15, suggested));
    return { noise: round1(noise), speech: round1(speech), suggested: Math.round(suggested) };
  }

  function round1(n) {
    return Math.round(n * 10) / 10;
  }

  /*
   * Lê o áudio pelo ffmpeg (mono, 16 kHz) e calcula o volume RMS em dB a cada 10 ms.
   * -> Promise<{ db: Float32Array, hop, duration, noise, speech, suggested }>
   */
  function analyze(mediaPath, ffmpeg, onProgress) {
    return new Promise((resolve, reject) => {
      if (!req) return reject(new Error("Análise indisponível fora do Premiere."));
      const { spawn } = req("child_process");
      const win = Math.round(RATE * HOP);
      const out = [];
      let carry = Buffer.alloc(0);
      let sum = 0, n = 0, lastReport = 0;
      const proc = spawn(ffmpeg, ["-nostdin", "-v", "error", "-i", mediaPath, "-vn", "-ac", "1", "-ar", String(RATE), "-f", "f32le", "-"], { windowsHide: true });
      let err = "";
      proc.stderr.on("data", (d) => (err += d.toString()));
      proc.stdout.on("data", (chunk) => {
        const buf = carry.length ? Buffer.concat([carry, chunk]) : chunk;
        const usable = buf.length - (buf.length % 4);
        for (let o = 0; o < usable; o += 4) {
          const s = buf.readFloatLE(o);
          sum += s * s;
          if (++n === win) {
            const rms = Math.sqrt(sum / n);
            out.push(rms > 1e-5 ? 20 * Math.log10(rms) : SILENT_DB);
            sum = 0;
            n = 0;
          }
        }
        carry = buf.subarray(usable);
        const secs = out.length * HOP;
        if (onProgress && secs - lastReport >= 30) {
          lastReport = secs;
          onProgress(`lendo o áudio: ${Math.round(secs)} s`);
        }
      });
      proc.on("error", reject);
      proc.on("close", (code) => {
        if (code !== 0) return reject(new Error("ffmpeg falhou ao ler o áudio: " + err.trim().slice(-300)));
        if (n > 0) out.push(Math.sqrt(sum / n) > 1e-5 ? 20 * Math.log10(Math.sqrt(sum / n)) : SILENT_DB);
        const db = Float32Array.from(out);
        resolve(Object.assign({ db, hop: HOP, duration: db.length * HOP }, estimate(db)));
      });
    });
  }

  /*
   * Calcula os trechos de silêncio a cortar.
   * analysis: resultado de analyze(); p: parâmetros (ver DEFAULTS).
   * -> { threshold, cuts: [{start, end}], keep: [{start, end}], removed, finalDuration }
   */
  function computeCuts(analysis, p) {
    const { db, hop, duration } = analysis;
    const thr = p.auto ? analysis.suggested + (Number(p.autoOffset) || 0) : Number(p.threshold);
    const hyst = Math.max(0, Number(p.hysteresis) || 0);

    // 1. Fala x silêncio, com histerese: entra em fala acima do limiar e só sai abaixo de limiar - histerese.
    const speech = [];
    let inSpeech = false, start = 0;
    for (let i = 0; i < db.length; i++) {
      const v = db[i];
      if (!inSpeech && v >= thr) {
        inSpeech = true;
        start = i;
      } else if (inSpeech && v < thr - hyst) {
        inSpeech = false;
        speech.push([start * hop, i * hop]);
      }
    }
    if (inSpeech) speech.push([start * hop, duration]);

    // 2. Descarta "falas" curtas demais (estalos, cliques, respiros fortes) ANTES de medir as
    //    pausas: senão um respiro no meio de uma pausa longa a divide em duas pausas curtas
    //    e ela deixa de ser cortada.
    const minSp = Math.max(0, Number(p.minSpeech) || 0);
    //    Só some o som curto e isolado (com pausa dos dois lados); uma sílaba curta colada
    //    nas palavras vizinhas fica.
    const halfSil = Math.max(0, Number(p.minSilence) || 0) / 2;
    const voiced = speech.filter((s, i) => {
      if (s[1] - s[0] >= minSp) return true;
      const gapPrev = i > 0 ? s[0] - speech[i - 1][1] : Infinity;
      const gapNext = i < speech.length - 1 ? speech[i + 1][0] - s[1] : Infinity;
      return !(gapPrev >= halfSil && gapNext >= halfSil);
    });

    // 3. Junta falas separadas por um silêncio menor que o mínimo (esse silêncio fica).
    const minSil = Math.max(0, Number(p.minSilence) || 0);
    const real = [];
    for (const s of voiced) {
      const last = real[real.length - 1];
      if (last && s[0] - last[1] < minSil) last[1] = s[1];
      else real.push(s.slice());
    }

    // Pausas longas o bastante para cortar (antes das margens), para mostrar na prévia.
    const pauses = [];
    let pc = 0;
    for (const s of real) {
      if (s[0] - pc >= minSil && s[0] > pc) pauses.push({ start: r3(pc), end: r3(s[0]) });
      pc = s[1];
    }
    if (duration - pc >= minSil) pauses.push({ start: r3(pc), end: r3(duration) });

    // 4. Margens antes e depois da fala, juntando o que se sobrepõe.
    const pb = Math.max(0, Number(p.padBefore) || 0);
    const pa = Math.max(0, Number(p.padAfter) || 0);
    const keep = [];
    for (const s of real) {
      const a = Math.max(0, s[0] - pb);
      const b = Math.min(duration, s[1] + pa);
      const last = keep[keep.length - 1];
      if (last && a <= last.end) last.end = Math.max(last.end, b);
      else keep.push({ start: a, end: b });
    }

    // 5. Cortes = o que sobra entre os trechos mantidos.
    const cuts = [];
    let cursor = 0;
    for (const k of keep) {
      if (k.start > cursor) cuts.push({ start: cursor, end: k.start });
      cursor = k.end;
    }
    if (cursor < duration) cuts.push({ start: cursor, end: duration });
    // Corte mínimo: depois das margens, cortes de poucos quadros só dão um pulo na imagem
    // sem ganhar tempo. Esses ficam de fora (a pausa fica inteira).
    const minCut = Math.max(0.04, Number(p.minCut) || 0);
    let finalCuts = cuts.filter((c) => c.end - c.start >= minCut);
    if (!p.trimEdges) finalCuts = finalCuts.filter((c) => c.start > 0.001 && c.end < duration - 0.001);
    if (!keep.length) finalCuts = []; // nada acima do limiar: não corta o vídeo inteiro

    const removed = finalCuts.reduce((t, c) => t + (c.end - c.start), 0);
    return { threshold: Math.round(thr * 10) / 10, cuts: finalCuts.map((c) => ({ start: r3(c.start), end: r3(c.end) })), pauses, keep, removed, finalDuration: duration - removed };
  }

  function r3(n) {
    return Math.round(n * 1000) / 1000;
  }

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const step = (v, s) => Math.round(v / s) * s;

  // Trechos de fala brutos (com histerese), em índices de janela.
  function detectSpeech(db, thr, hyst) {
    const segs = [];
    let on = false, s = 0;
    for (let i = 0; i < db.length; i++) {
      if (!on && db[i] >= thr) {
        on = true;
        s = i;
      } else if (on && db[i] < thr - hyst) {
        on = false;
        segs.push([s, i]);
      }
    }
    if (on) segs.push([s, db.length]);
    return segs;
  }

  /*
   * Ajuste automático: lê o próprio áudio e escolhe todos os parâmetros.
   * - limiar: entre o ruído de fundo e o nível da fala;
   * - histerese: pela oscilação do ruído de fundo;
   * - silêncio mínimo: pela pausa típica entre frases desse apresentador;
   * - margens: pelo tempo que a voz leva para subir (ataque) e sumir (cauda);
   * - fala mínima: maior quando o áudio é mais ruidoso (mais estalos falsos).
   * -> { values, notes }
   */
  function autoTune(analysis) {
    const { db, hop } = analysis;
    const thr = analysis.suggested;
    const noise = analysis.noise;
    const snr = analysis.speech - noise;

    // Oscilação do ruído de fundo (desvio padrão das janelas abaixo do limiar).
    let n = 0, sum = 0, sq = 0;
    for (let i = 0; i < db.length; i++) {
      const v = db[i];
      if (v > -95 && v < thr - 3) {
        n++;
        sum += v;
        sq += v * v;
      }
    }
    const std = n > 10 ? Math.sqrt(Math.max(0, sq / n - (sum / n) ** 2)) : 3;
    const hysteresis = clamp(step(std * 1.5, 0.5), 2, 6);

    const segs = detectSpeech(db, thr, hysteresis).filter((s) => (s[1] - s[0]) * hop >= 0.06);
    const gaps = [];
    for (let i = 1; i < segs.length; i++) {
      const g = (segs[i][0] - segs[i - 1][1]) * hop;
      if (g >= 0.05) gaps.push(g);
    }
    gaps.sort((a, b) => a - b);

    // Ataque (antes da fala) e cauda (depois): janelas acima do ruído + 4 dB coladas no trecho.
    const floor = (noise + thr) / 2;
    const tails = [], attacks = [];
    for (const [s, e] of segs) {
      let k = 0;
      while (e + k < db.length && k < 60 && db[e + k] > floor) k++;
      tails.push(k * hop);
      k = 0;
      while (s - k - 1 >= 0 && k < 40 && db[s - k - 1] > floor) k++;
      attacks.push(k * hop);
    }
    tails.sort((a, b) => a - b);
    attacks.sort((a, b) => a - b);

    const enough = gaps.length >= 5;
    const typicalPause = enough ? percentile(gaps, 0.6) : 0.4;
    const tail = tails.length ? percentile(tails, 0.75) : 0.1;
    const attack = attacks.length ? percentile(attacks, 0.75) : 0.05;

    const values = {
      auto: true,
      autoOffset: 0,
      threshold: thr,
      hysteresis,
      minSilence: Math.round(clamp(step(typicalPause, 0.05), 0.3, 1.0) * 100) / 100,
      padAfter: Math.round(clamp(tail + 0.05, 0.1, 0.35) * 100) / 100,
      padBefore: Math.round(clamp(attack + 0.03, 0.06, 0.25) * 100) / 100,
      minSpeech: snr < 25 ? 0.18 : 0.12,
      minCut: 0.15,
      trimEdges: true,
    };
    const f = (v) => v.toFixed(2).replace(".", ",");
    const qual = snr >= 35 ? "áudio limpo" : snr >= 25 ? "áudio bom" : "áudio com ruído";
    const notes = `${qual} (fala ${Math.round(snr)} dB acima do ruído) · pausa típica ${f(typicalPause)} s` +
      ` · a voz some em ${f(tail)} s · ${segs.length} trechos de fala` + (enough ? "" : " · poucas pausas: usei valores padrão no tempo");
    return { values, notes };
  }

  // Áudio de demonstração (para a prévia no navegador): fala com pausas de tamanhos variados.
  function demoAnalysis(seconds) {
    const len = Math.round((seconds || 90) / HOP);
    const db = new Float32Array(len);
    let i = 0, seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    while (i < len) {
      const talk = Math.round((1.5 + rnd() * 5) / HOP);
      for (let k = 0; k < talk && i < len; k++, i++) db[i] = -22 + Math.sin(k / 6) * 6 + rnd() * 6 - (rnd() < 0.08 ? 18 : 0);
      const pause = Math.round((0.1 + rnd() * rnd() * 2.5) / HOP);
      for (let k = 0; k < pause && i < len; k++, i++) db[i] = -58 + rnd() * 5 + (rnd() < 0.01 ? 30 : 0);
    }
    return Object.assign({ db, hop: HOP, duration: len * HOP, demo: true }, estimate(db));
  }

  const api = { PRESETS, DEFAULTS, analyze, computeCuts, estimate, autoTune, demoAnalysis, HOP };
  if (typeof window !== "undefined") window.Decupagem = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
