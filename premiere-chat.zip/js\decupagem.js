/*
 * Decupagem por silêncio: analisa o volume do áudio e calcula os trechos a cortar.
 *
 * Os parâmetros seguem o que os cortadores de silêncio profissionais usam (Auto-Editor,
 * Recut, TimeBolt, AutoCut): limiar em dB, silêncio mínimo para cortar, margem antes e
 * depois da fala, fala mínima (ignora estalos e respiros curtos) e histerese, para o corte
 * não "piscar" quando o volume oscila em volta do limiar.
 *
 * Duas etapas: analyze() lê o áudio uma vez e guarda o volume a cada 10 ms; computeCuts()
 * recalcula os cortes na hora, a cada ajuste, sem ler o áudio de novo.
 */
(function () {
  "use strict";

  const req = typeof require === "function" ? require : null;

  const HOP = 0.01; // 10 ms por janela de análise
  const RATE = 16000;
  const SILENT_DB = -100;

  // Presets. Valores em segundos e dB.
  const PRESETS = {
    natural: {
      label: "Natural (YouTube, aula, podcast)",
      threshold: -40, auto: true, autoOffset: 0, minSilence: 0.7, padBefore: 0.15, padAfter: 0.25,
      minSpeech: 0.15, hysteresis: 3, minCut: 0.2, trimEdges: true,
    },
    dinamico: {
      label: "Dinâmico (Reels, TikTok, VSL)",
      threshold: -38, auto: true, autoOffset: 0, minSilence: 0.35, padBefore: 0.1, padAfter: 0.15,
      minSpeech: 0.12, hysteresis: 3, minCut: 0.15, trimEdges: true,
    },
    agressivo: {
      label: "Agressivo (jump cut)",
      threshold: -35, auto: true, autoOffset: 2, minSilence: 0.25, padBefore: 0.06, padAfter: 0.09,
      minSpeech: 0.1, hysteresis: 2, minCut: 0.1, trimEdges: true,
    },
    suave: {
      label: "Suave (entrevista, depoimento)",
      threshold: -45, auto: true, autoOffset: -2, minSilence: 1.2, padBefore: 0.3, padAfter: 0.4,
      minSpeech: 0.2, hysteresis: 4, minCut: 0.25, trimEdges: true,
    },
  };

  const DEFAULTS = Object.assign({ preset: "dinamico", mode: "ripple", newSequence: true, protectWords: true }, PRESETS.dinamico);

  function percentile(sorted, p) {
    if (!sorted.length) return SILENT_DB;
    const i = Math.min(sorted.length - 1, Math.max(0, Math.round((sorted.length - 1) * p)));
    return sorted[i];
  }

  /*
   * Lê o áudio pelo ffmpeg (mono, 16 kHz) e calcula, a cada 10 ms:
   *  - db: volume RMS em dB (vogais, voz em geral);
   *  - hf: volume do sinal com pré-ênfase (realça 2-8 kHz), que pega as consoantes fracas
   *    ("s", "f", "ch", "t") do começo e do fim das palavras, que quase não mexem no RMS.
   * -> Promise<{ db, hf, hop, duration, noise, speech, suggested, hfNoise, hfThr }>
   */
  function analyze(mediaPath, ffmpeg, onProgress) {
    return new Promise((resolve, reject) => {
      if (!req) return reject(new Error("Análise indisponível fora do Premiere."));
      const { spawn } = req("child_process");
      const win = Math.round(RATE * HOP);
      const out = [], outHf = [];
      let carry = Buffer.alloc(0);
      let sum = 0, sumHf = 0, n = 0, prev = 0, lastReport = 0;
      const toDb = (ms) => (ms > 1e-10 ? 10 * Math.log10(ms) : SILENT_DB);
      const proc = spawn(ffmpeg, ["-nostdin", "-v", "error", "-i", mediaPath, "-vn", "-ac", "1", "-ar", String(RATE), "-f", "f32le", "-"], { windowsHide: true });
      let err = "";
      proc.stderr.on("data", (d) => (err += d.toString()));
      proc.stdout.on("data", (chunk) => {
        const buf = carry.length ? Buffer.concat([carry, chunk]) : chunk;
        const usable = buf.length - (buf.length % 4);
        for (let o = 0; o < usable; o += 4) {
          const s = buf.readFloatLE(o);
          const e = s - 0.95 * prev; // pré-ênfase
          prev = s;
          sum += s * s;
          sumHf += e * e;
          if (++n === win) {
            out.push(toDb(sum / n));
            outHf.push(toDb(sumHf / n));
            sum = sumHf = 0;
            n = 0;
          }
        }
        carry = buf.subarray(usable);
        const secs = out.length * HOP;
        if (onProgress && secs - lastReport >= 30) {
          lastReport = secs;
          onProgress(`lendo o áudio: ${Math.round(secs)} s`);
        }
      });
      proc.on("error", reject);
      proc.on("close", (code) => {
        if (code !== 0) return reject(new Error("ffmpeg falhou ao ler o áudio: " + err.trim().slice(-300)));
        if (n > 0) {
          out.push(toDb(sum / n));
          outHf.push(toDb(sumHf / n));
        }
        resolve(fromLevels(Float32Array.from(out), Float32Array.from(outHf)));
      });
    });
  }

  function fromLevels(db, hf) {
    const a = Object.assign({ db, hop: HOP, duration: db.length * HOP }, estimate(db));
    if (hf) {
      a.hf = hf;
      const e = estimate(hf);
      a.hfNoise = e.noise;
      a.hfSpeech = e.speech;
      a.hfThr = e.suggested;
    }
    return a;
  }

  /*
   * Ruído de fundo e nível da fala. O ruído sai das partes mais baixas (5 %) e a fala das mais
   * altas (95 %). O limiar fica entre os dois, mas NUNCA a menos de 26 dB do nível da fala:
   * palavra dita mais baixo (fim de frase, sílaba átona) costuma ficar 15 a 25 dB abaixo do pico
   * e não pode virar "silêncio". Era isso que fazia o corte comer palavras e cortar no meio da frase
   * quando o vídeo tinha poucas pausas.
   */
  function estimate(db) {
    const vals = [];
    for (let i = 0; i < db.length; i++) if (db[i] > -95) vals.push(db[i]);
    vals.sort((a, b) => a - b);
    const noise = percentile(vals, 0.05);
    const speech = percentile(vals, 0.95);
    const snr = speech - noise;
    let suggested = noise + Math.max(6, snr * 0.3);
    suggested = Math.min(suggested, speech - 26);
    suggested = Math.max(suggested, noise + 4);
    suggested = Math.max(-65, Math.min(-20, suggested));
    return { noise: round1(noise), speech: round1(speech), suggested: Math.round(suggested) };
  }

  function round1(n) {
    return Math.round(n * 10) / 10;
  }

  /*
   * Fala x silêncio, com histerese, pelo volume. Depois cada trecho de fala é esticado pelas
   * consoantes (hf) coladas nele, até 150 ms para cada lado: pega o "s" do fim e o "f" do começo
   * da palavra, mas um respiro solto no meio da pausa (que também tem agudo) não vira fala.
   * -> [[iniJanela, fimJanela], ...]
   */
  function detectSpeech(a, thr, hyst) {
    const { db, hf } = a;
    const segs = [];
    let on = false, s = 0;
    for (let i = 0; i < db.length; i++) {
      if (!on && db[i] >= thr) {
        on = true;
        s = i;
      } else if (on && db[i] < thr - hyst) {
        on = false;
        segs.push([s, i]);
      }
    }
    if (on) segs.push([s, db.length]);
    if (!hf || a.hfThr == null) return segs;
    const hfThr = a.hfThr + (thr - a.suggested);
    const MAX = Math.round(0.15 / HOP);
    for (const g of segs) {
      let k = 0;
      while (k < MAX && g[0] - 1 >= 0 && hf[g[0] - 1] >= hfThr) g[0]--, k++;
      k = 0;
      while (k < MAX && g[1] < db.length && hf[g[1]] >= hfThr) g[1]++, k++;
    }
    return segs;
  }

  function peak(arr, i0, i1) {
    let m = SILENT_DB;
    for (let i = Math.max(0, i0); i < Math.min(arr.length, i1); i++) if (arr[i] > m) m = arr[i];
    return m;
  }

  /*
   * Calcula os trechos de silêncio a cortar.
   * analysis: resultado de analyze() (com analysis.words se a transcrição rodou); p: parâmetros.
   * -> { threshold, cuts: [{start, end}], keep, pauses, removed, finalDuration, protectedWords }
   */
  function computeCuts(analysis, p) {
    const { db, hop, duration } = analysis;
    const thr = p.auto ? analysis.suggested + (Number(p.autoOffset) || 0) : Number(p.threshold);
    const hyst = Math.max(0, Number(p.hysteresis) || 0);
    const minSil = Math.max(0, Number(p.minSilence) || 0);
    const minSp = Math.max(0, Number(p.minSpeech) || 0);
    const words = p.protectWords !== false && Array.isArray(analysis.words) ? analysis.words : null;
    const idx = (t) => Math.round(t / hop);

    // 1. Fala pelo volume e pelas consoantes.
    let speech = detectSpeech(analysis, thr, hyst).map(([s, e]) => [s * hop, e * hop]);

    // 2. Palavras da transcrição: uma palavra com algum som de verdade nunca é cortada, mesmo dita
    //    baixinho. Palavra "inventada" pela transcrição em cima de silêncio (sem som nenhum) não conta.
    let protectedWords = 0;
    const wordSegs = [];
    if (words) {
      const floorDb = analysis.noise + 6;
      const floorHf = analysis.hf ? analysis.hfNoise + 6 : Infinity;
      for (const w of words) {
        const ws = Number(w.start), we = Number(w.end);
        if (!(we > ws)) continue;
        const pk = peak(db, idx(ws), idx(we) + 1);
        const pkHf = analysis.hf ? peak(analysis.hf, idx(ws), idx(we) + 1) : SILENT_DB;
        if (pk < floorDb && pkHf < floorHf) continue;
        // Só o trecho da palavra que tem som: a transcrição às vezes estica a palavra pela pausa.
        let a = idx(ws), b = idx(we);
        while (a < b && db[a] < floorDb && (!analysis.hf || analysis.hf[a] < floorHf)) a++;
        while (b > a && db[b - 1] < floorDb && (!analysis.hf || analysis.hf[b - 1] < floorHf)) b--;
        if (b > a) wordSegs.push([a * hop, b * hop]);
      }
      protectedWords = wordSegs.length;
    }
    const touchesWord = (s) => wordSegs.some((w) => w[0] < s[1] + 0.02 && w[1] > s[0] - 0.02);

    // 3. Descarta só o som curto, ISOLADO e FRACO (estalo, clique, respiro). Uma palavra curta
    //    ("é", "e", "a", "já") entre duas pausas tem volume de fala e fica.
    const halfSil = minSil / 2;
    const voiced = speech.filter((s, i) => {
      if (s[1] - s[0] >= minSp) return true;
      if (touchesWord(s)) return true;
      if (peak(db, idx(s[0]), idx(s[1]) + 1) >= thr + 10) return true;
      const gapPrev = i > 0 ? s[0] - speech[i - 1][1] : Infinity;
      const gapNext = i < speech.length - 1 ? speech[i + 1][0] - s[1] : Infinity;
      return !(gapPrev >= halfSil && gapNext >= halfSil);
    });
    speech = voiced.concat(wordSegs).sort((x, y) => x[0] - y[0]);

    // 4. Junta falas separadas por um silêncio menor que o mínimo (esse silêncio fica).
    const real = [];
    for (const s of speech) {
      const last = real[real.length - 1];
      if (last && s[0] - last[1] < minSil) last[1] = Math.max(last[1], s[1]);
      else real.push(s.slice());
    }

    // Pausas longas o bastante para cortar (antes das margens), para mostrar na prévia.
    const pauses = [];
    let pc = 0;
    for (const s of real) {
      if (s[0] - pc >= minSil && s[0] > pc) pauses.push({ start: r3(pc), end: r3(s[0]) });
      pc = Math.max(pc, s[1]);
    }
    if (duration - pc >= minSil) pauses.push({ start: r3(pc), end: r3(duration) });

    // 5. Margens antes e depois da fala, juntando o que se sobrepõe.
    const pb = Math.max(0, Number(p.padBefore) || 0);
    const pa = Math.max(0, Number(p.padAfter) || 0);
    const keep = [];
    for (const s of real) {
      const a = Math.max(0, s[0] - pb);
      const b = Math.min(duration, s[1] + pa);
      const last = keep[keep.length - 1];
      if (last && a <= last.end) last.end = Math.max(last.end, b);
      else keep.push({ start: a, end: b });
    }

    // 6. Cortes = o que sobra entre os trechos mantidos. Cada ponta do corte vai para o ponto mais
    //    silencioso logo ali dentro da pausa (até 40 ms): o corte só encolhe, nunca entra na fala,
    //    e cai no vale do som, sem estalo.
    const SNAP = Math.round(0.04 / hop);
    const quietest = (i0, i1) => {
      let best = i0, bv = Infinity;
      for (let i = Math.max(0, i0); i <= Math.min(db.length - 1, i1); i++) if (db[i] < bv - 0.5) (bv = db[i]), (best = i);
      return best;
    };
    const cuts = [];
    let cursor = 0;
    for (const k of keep) {
      if (k.start > cursor) cuts.push({ start: cursor, end: k.start });
      cursor = k.end;
    }
    if (cursor < duration) cuts.push({ start: cursor, end: duration });
    for (const c of cuts) {
      const a = idx(c.start), b = idx(c.end);
      if (c.start > 0.001) c.start = quietest(a, Math.min(b, a + SNAP)) * hop;
      if (c.end < duration - 0.001) c.end = quietest(Math.max(a, b - SNAP), b) * hop;
    }

    // Corte mínimo: cortes de poucos quadros só dão um pulo na imagem sem ganhar tempo.
    const minCut = Math.max(0.04, Number(p.minCut) || 0);
    let finalCuts = cuts.filter((c) => c.end - c.start >= minCut);
    if (!p.trimEdges) finalCuts = finalCuts.filter((c) => c.start > 0.001 && c.end < duration - 0.001);
    if (!keep.length) finalCuts = []; // nada acima do limiar: não corta o vídeo inteiro

    const removed = finalCuts.reduce((t, c) => t + (c.end - c.start), 0);
    return {
      threshold: Math.round(thr * 10) / 10,
      cuts: finalCuts.map((c) => ({ start: r3(c.start), end: r3(c.end) })),
      pauses, keep, removed, finalDuration: duration - removed, protectedWords: words ? protectedWords : null,
    };
  }

  function r3(n) {
    return Math.round(n * 1000) / 1000;
  }

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const step = (v, s) => Math.round(v / s) * s;

  /*
   * Ajuste automático: lê o próprio áudio e escolhe todos os parâmetros.
   * - limiar: entre o ruído de fundo e o nível da fala;
   * - histerese: pela oscilação do ruído de fundo;
   * - silêncio mínimo: pela pausa típica entre frases desse apresentador;
   * - margens: pelo tempo que a voz leva para subir (ataque) e sumir (cauda);
   * - fala mínima: maior quando o áudio é mais ruidoso (mais estalos falsos).
   * -> { values, notes }
   */
  function autoTune(analysis) {
    const { db, hop } = analysis;
    const thr = analysis.suggested;
    const noise = analysis.noise;
    const snr = analysis.speech - noise;

    // Oscilação do ruído de fundo (desvio padrão das janelas abaixo do limiar).
    let n = 0, sum = 0, sq = 0;
    for (let i = 0; i < db.length; i++) {
      const v = db[i];
      if (v > -95 && v < thr - 3) {
        n++;
        sum += v;
        sq += v * v;
      }
    }
    const std = n > 10 ? Math.sqrt(Math.max(0, sq / n - (sum / n) ** 2)) : 3;
    const hysteresis = clamp(step(std * 1.5, 0.5), 2, 6);

    const segs = detectSpeech(analysis, thr, hysteresis).filter((s) => (s[1] - s[0]) * hop >= 0.06);
    const gaps = [];
    for (let i = 1; i < segs.length; i++) {
      const g = (segs[i][0] - segs[i - 1][1]) * hop;
      if (g >= 0.05) gaps.push(g);
    }
    gaps.sort((a, b) => a - b);

    // Ataque (antes da fala) e cauda (depois): janelas acima do ruído + 4 dB coladas no trecho.
    const floor = (noise + thr) / 2;
    const tails = [], attacks = [];
    for (const [s, e] of segs) {
      let k = 0;
      while (e + k < db.length && k < 60 && db[e + k] > floor) k++;
      tails.push(k * hop);
      k = 0;
      while (s - k - 1 >= 0 && k < 40 && db[s - k - 1] > floor) k++;
      attacks.push(k * hop);
    }
    tails.sort((a, b) => a - b);
    attacks.sort((a, b) => a - b);

    const enough = gaps.length >= 5;
    const typicalPause = enough ? percentile(gaps, 0.6) : 0.4;
    const tail = tails.length ? percentile(tails, 0.75) : 0.1;
    const attack = attacks.length ? percentile(attacks, 0.75) : 0.05;

    const values = {
      auto: true,
      autoOffset: 0,
      threshold: thr,
      hysteresis,
      minSilence: Math.round(clamp(step(typicalPause, 0.05), 0.3, 1.0) * 100) / 100,
      padAfter: Math.round(clamp(tail + 0.06, 0.13, 0.35) * 100) / 100,
      padBefore: Math.round(clamp(attack + 0.04, 0.09, 0.25) * 100) / 100,
      minSpeech: snr < 25 ? 0.18 : 0.12,
      minCut: 0.15,
      trimEdges: true,
    };
    const f = (v) => v.toFixed(2).replace(".", ",");
    const qual = snr >= 35 ? "áudio limpo" : snr >= 25 ? "áudio bom" : "áudio com ruído";
    const notes = `${qual} (fala ${Math.round(snr)} dB acima do ruído) · pausa típica ${f(typicalPause)} s` +
      ` · a voz some em ${f(tail)} s · ${segs.length} trechos de fala` + (enough ? "" : " · poucas pausas: usei valores padrão no tempo");
    return { values, notes };
  }

  // Áudio de demonstração (para a prévia no navegador): fala com pausas de tamanhos variados.
  function demoAnalysis(seconds) {
    const len = Math.round((seconds || 90) / HOP);
    const db = new Float32Array(len);
    let i = 0, seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    while (i < len) {
      const talk = Math.round((1.5 + rnd() * 5) / HOP);
      for (let k = 0; k < talk && i < len; k++, i++) db[i] = -22 + Math.sin(k / 6) * 6 + rnd() * 6 - (rnd() < 0.08 ? 18 : 0);
      const pause = Math.round((0.1 + rnd() * rnd() * 2.5) / HOP);
      for (let k = 0; k < pause && i < len; k++, i++) db[i] = -58 + rnd() * 5 + (rnd() < 0.01 ? 30 : 0);
    }
    return Object.assign(fromLevels(db, null), { demo: true });
  }

  const api = { PRESETS, DEFAULTS, analyze, computeCuts, estimate, autoTune, demoAnalysis, fromLevels, HOP };
  if (typeof window !== "undefined") window.Decupagem = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
