/*
 * Catálogo de efeitos do Premiere Chat (criação própria): transições, textos e light leaks.
 *
 * Transição = função state(side, u): u vai de 0 (longe do corte) a 1 (no corte); side = "out" (clipe que
 * sai) ou "in" (clipe que entra). A MESMA função desenha a prévia e gera os keyframes dos efeitos nativos
 * do Premiere (Transform, Offset, Directional Blur, Gaussian Blur, Lumetri). Nada depende de plugin pago.
 * Estado: { s: escala, sx: escala só na largura, r: graus, dx/dy: deslocamento (1 = o quadro), k: inclinação,
 *           wx/wy: deslocamento "sem fim" (a imagem se repete na borda), b: desfoque, db: desfoque direcional,
 *           dir: ângulo do db, e: exposição em stops }
 */
(function (root) {
  "use strict";
  const api = {};
  const PI = Math.PI;
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  const inCubic = (u) => u * u * u;
  const inQuart = (u) => u * u * u * u;
  const outCubic = (u) => 1 - Math.pow(1 - u, 3);
  const outBack = (u) => 1 + 2.2 * Math.pow(u - 1, 3) + 1.2 * Math.pow(u - 1, 2);
  const outExpo = (u) => (u >= 1 ? 1 : 1 - Math.pow(2, -10 * u));
  const mix = (a, b, t) => a + (b - a) * t;

  // ---------------------------------------------------------------- transições

  const T = [];
  const add = (id, cat, nome, dur, state) => T.push({ id, cat, nome, dur, state });

  add("zoom-punch", "Zoom", "Zoom punch", 0.5, (sd, u, f) => (sd === "out" ? { s: 1 + 0.9 * f * inCubic(u) } : { s: 1 + 0.45 * f * inCubic(u) }));
  add("zoom-atravessa", "Zoom", "Zoom atravessa", 0.7, (sd, u, f) => (sd === "out" ? { s: 1 + 2.2 * f * inQuart(u), b: 26 * f * inQuart(u) } : { s: 1 + 0.35 * f * inCubic(u), b: 26 * f * inQuart(u) }));
  add("zoom-recuo", "Zoom", "Zoom recuo", 0.6, (sd, u, f) => (sd === "out" ? { s: 1 + 0.25 * f * inCubic(u), b: 10 * f * inCubic(u) } : { s: 1 + 1.3 * f * inCubic(u) }));
  add("zoom-giro", "Zoom", "Zoom com giro", 0.7, (sd, u, f) => (sd === "out" ? { s: 1 + 1.4 * f * inCubic(u), r: 14 * f * inCubic(u) } : { s: 1 + 0.9 * f * inCubic(u), r: -14 * f * inCubic(u) }));
  add("zoom-esticado", "Zoom", "Zoom esticado", 0.5, (sd, u, f) => ({ s: 1 + 0.15 * f * inCubic(u), sx: 1 + 2 * f * inQuart(u) }));
  add("zoom-suave", "Zoom", "Zoom suave", 1.0, (sd, u, f) => (sd === "out" ? { s: 1 + 0.18 * f * inCubic(u) } : { s: 1 + 0.18 * f * inCubic(u), e: 0.25 * f * inQuart(u) }));

  const dirs = [["esquerda", -1, 0, 90], ["direita", 1, 0, 90], ["cima", 0, -1, 0], ["baixo", 0, 1, 0]];
  for (const [n, x, y, ang] of dirs) {
    add("deslizar-" + n, "Deslizar", "Deslizar " + n, 0.6, (sd, u) => {
      const m = 0.5 * inCubic(u) * (sd === "out" ? 1 : -1);
      return { wx: x * m, wy: y * m };
    });
  }
  for (const [n, x, y, ang] of dirs) {
    add("chicote-" + n, "Chicote", "Chicote " + n, 0.5, (sd, u, f) => {
      const m = inQuart(u) * (sd === "out" ? 1 : -1);
      return { wx: x * m, wy: y * m, db: 90 * f * inCubic(u), dir: ang };
    });
  }
  add("queda", "Deslizar", "Queda com rebote", 0.8, (sd, u) => (sd === "out" ? { wy: 0.5 * inCubic(u) } : { wy: -0.5 * (1 - outBack(1 - u)) }));

  add("giro-direita", "Giro", "Giro direita", 0.6, (sd, u, f) => ({ r: (sd === "out" ? 1 : -1) * 90 * f * inCubic(u), s: 1 + 0.85 * Math.sin((PI / 2) * inCubic(u)) }));
  add("giro-esquerda", "Giro", "Giro esquerda", 0.6, (sd, u, f) => ({ r: (sd === "out" ? -1 : 1) * 90 * f * inCubic(u), s: 1 + 0.85 * Math.sin((PI / 2) * inCubic(u)) }));
  add("balanco", "Giro", "Balanço", 0.6, (sd, u, f) => ({ r: (sd === "out" ? 1 : -1) * 18 * f * inCubic(u), s: 1 + 0.45 * inCubic(u), b: 8 * f * inCubic(u) }));
  add("inclinar", "Giro", "Inclinar", 0.5, (sd, u, f) => ({ k: (sd === "out" ? 1 : -1) * 30 * f * inCubic(u), s: 1 + 0.6 * inCubic(u) }));

  add("desfoque", "Desfoque", "Desfoque", 0.6, (sd, u, f) => ({ b: 70 * f * inCubic(u) }));
  add("desfoque-zoom", "Desfoque", "Desfoque com zoom", 0.7, (sd, u, f) => ({ b: 50 * f * inCubic(u), s: 1 + 0.22 * f * inCubic(u) }));
  add("desfoque-horizontal", "Desfoque", "Rastro horizontal", 0.5, (sd, u, f) => ({ db: 120 * f * inCubic(u), dir: 90 }));
  add("desfoque-vertical", "Desfoque", "Rastro vertical", 0.5, (sd, u, f) => ({ db: 120 * f * inCubic(u), dir: 0 }));

  add("flash", "Luz", "Flash", 0.4, (sd, u, f) => ({ e: 4.5 * f * inCubic(u) }));
  add("flash-zoom", "Luz", "Flash com zoom", 0.5, (sd, u, f) => ({ e: 4 * f * inQuart(u), s: 1 + 0.35 * f * inCubic(u), b: 12 * f * inCubic(u) }));
  add("flash-duplo", "Luz", "Flash duplo", 0.6, (sd, u, f) => ({ e: 4 * f * Math.pow(Math.abs(Math.sin(u * PI * 1.5)), 3) }));
  add("apagar", "Luz", "Apagar e acender", 0.6, (sd, u, f) => ({ e: -5 * inCubic(u), s: 1 + 0.06 * f * inCubic(u) }));

  // Valores fixos (não aleatórios): a prévia e o resultado saem iguais.
  const JIT = [0, 0.7, -0.9, 0.5, -0.3, 1, -0.7, 0.4, -1];
  const jit = (u, k) => JIT[Math.floor(u * 8 + k * 3) % JIT.length];
  add("tremor", "Impacto", "Tremor", 0.5, (sd, u, f) => ({ dx: 0.03 * f * jit(u, 0) * u, dy: 0.03 * f * jit(u, 1) * u, s: 1 + 0.1 * u, r: 1.5 * f * jit(u, 2) * u }));
  add("impacto", "Impacto", "Impacto", 0.5, (sd, u, f) => (sd === "out" ? { s: 1 + 0.5 * f * inQuart(u) } : { s: 1 + 0.3 * f * inCubic(u), dx: 0.025 * f * jit(u, 0) * u, dy: 0.025 * f * jit(u, 1) * u, e: 1.6 * f * inQuart(u) }));
  add("glitch", "Impacto", "Glitch", 0.4, (sd, u, f) => ({ wx: 0.12 * f * jit(u, 0) * u, wy: 0.04 * f * jit(u, 1) * u, e: 0.9 * f * Math.max(0, jit(u, 2)) * u, db: u > 0.5 ? 25 * f * Math.abs(jit(u, 1)) : 0, dir: 90 }));
  add("elastico", "Impacto", "Elástico", 0.8, (sd, u, f) => (sd === "out" ? { s: 1 + 0.35 * f * inCubic(u) } : { s: 1 + 0.35 * f * Math.abs(Math.cos((1 - u) * PI * 1.5)) * u }));

  api.transitions = T;
  api.transition = (id) => T.find((t) => t.id === id || t.nome.toLowerCase() === String(id || "").toLowerCase()) || null;

  const NEUTRO = { s: 1, sx: 1, r: 0, dx: 0, dy: 0, k: 0, wx: 0, wy: 0, b: 0, db: 0, dir: 0, e: 0 };
  // Em u = 0 é sempre neutro: o resto do clipe não muda.
  api.state = (tr, side, u, force) => {
    const s = Object.assign({}, NEUTRO, u <= 0 ? {} : tr.state(side, clamp(u), force == null ? 1 : force));
    // Giro e inclinacao: aumenta a escala o bastante para nunca aparecer borda preta (16:9 e 9:16).
    const r = (Math.abs(s.r) * PI) / 180;
    const k = Math.tan((Math.abs(s.k) * PI) / 180);
    const cover = (Math.abs(Math.cos(r)) + 1.78 * Math.abs(Math.sin(r))) * (1 + 1.78 * k) + 2 * Math.max(Math.abs(s.dx), Math.abs(s.dy)) * (r ? 1.78 : 1);
    if (r || k) s.s = Math.max(s.s, cover);
    return s;
  };

  const r4 = (n) => Math.round(n * 10000) / 10000;
  /*
   * Keyframes de um lado. Tempo em segundos a partir do início da janela (0..half).
   * -> [{ fx, set: {..}, keys: { prop: [[t, v], ...] } }]
   */
  api.compile = function (tr, side, half, fps, force) {
    const n = clamp(Math.round(half * (fps || 30)), 4, 24);
    const S = [];
    for (let i = 0; i <= n; i++) {
      const p = i / n;
      S.push([p * half, api.state(tr, side, side === "out" ? p : 1 - p, force)]);
    }
    const moves = (k) => S.some(([, s]) => Math.abs(s[k] - NEUTRO[k]) > 1e-6);
    const col = (fn) => S.map(([t, s]) => [r4(t), fn(s)]);
    const ops = [];
    const tk = {};
    if (moves("s") || moves("sx")) {
      tk.scale = col((s) => r4(s.s * 100));
      if (moves("sx")) tk.scaleW = col((s) => r4(s.s * s.sx * 100));
    }
    if (moves("r")) tk.rotation = col((s) => r4(s.r));
    if (moves("k")) tk.skew = col((s) => r4(s.k));
    if (moves("dx") || moves("dy")) tk.position = col((s) => [r4(s.dx), r4(s.dy)]);
    if (Object.keys(tk).length) ops.push({ fx: "transform", set: { uniform: !moves("sx"), useShutter: false, shutter: 180 }, keys: tk });
    if (moves("wx") || moves("wy")) ops.push({ fx: "offset", set: {}, keys: { shift: col((s) => [r4(s.wx), r4(s.wy)]) } });
    if (moves("db")) ops.push({ fx: "dirblur", set: { direction: S.map(([, s]) => s.dir).find((d) => d) || 0 }, keys: { length: col((s) => r4(s.db)) } });
    if (moves("b")) ops.push({ fx: "gblur", set: { repeat: true }, keys: { amount: col((s) => r4(s.b)) } });
    if (moves("e")) ops.push({ fx: "lumetri", set: {}, keys: { exposure: col((s) => r4(clamp(s.e, -5, 5))) } });
    return ops;
  };

  // ---------------------------------------------------------------- textos

  /*
   * unit: quem anima (char | word | line); from: de onde vem; len/stag: duração e atraso por unidade.
   * box / hl / bar / mask: enfeites. cfg.segs = partes com ou sem destaque (ou cfg.text com *destaque*).
   */
  const X = [];
  const tx = (id, cat, nome, o) => X.push(Object.assign({ id, cat, nome, unit: "word", len: 0.45, stag: 0.08, ease: "outCubic", from: {}, sample: "SEU *TEXTO* AQUI" }, o));
  tx("sobe-palavra", "Palavra", "Sobe por palavra", { from: { dy: 0.9, a: 0 } });
  tx("pop-palavra", "Palavra", "Pop por palavra", { from: { s: 0, a: 0 }, ease: "outBack", len: 0.35 });
  tx("desfoque-palavra", "Palavra", "Desfoque por palavra", { from: { b: 0.35, a: 0, s: 1.25 }, len: 0.55 });
  tx("lados-palavra", "Palavra", "Palavras dos lados", { from: { dx: 1.6, a: 0, alt: true }, len: 0.5, ease: "outExpo" });
  tx("giro-palavra", "Palavra", "Giro por palavra", { from: { r: -14, dy: 0.7, a: 0 }, ease: "outBack" });
  tx("maquina", "Letra", "Máquina de escrever", { unit: "char", from: { a: 0 }, len: 0.01, stag: 0.05 });
  tx("cai-letra", "Letra", "Letras caindo", { unit: "char", from: { dy: -1.2, r: 18, a: 0 }, ease: "outBack", stag: 0.03 });
  tx("onda-letra", "Letra", "Onda de letras", { unit: "char", from: { dy: 0.6, s: 0.4, a: 0 }, ease: "outBack", stag: 0.025 });
  tx("foco-letra", "Letra", "Letras em foco", { unit: "char", from: { b: 0.3, a: 0, dx: 0.4 }, stag: 0.025, len: 0.5 });
  tx("revela-linha", "Linha", "Revelar por linha", { unit: "line", mask: true, from: { dy: 1.25 }, stag: 0.14, len: 0.6, ease: "outExpo", sample: "PRIMEIRA LINHA\n*SEGUNDA LINHA*" });
  tx("cortina-linha", "Linha", "Linha lateral", { unit: "line", mask: true, from: { dx: -8 }, stag: 0.12, len: 0.6, ease: "outExpo", sample: "PRIMEIRA LINHA\n*SEGUNDA LINHA*" });
  tx("apoio-destaque", "Linha", "Apoio e destaque", { unit: "word", from: { dy: 0.8, b: 0.2, a: 0 }, big: true, sample: "isso muda\n*TUDO*\npara você" });
  tx("caixa", "Caixa", "Caixa", { unit: "line", box: true, mask: true, from: { dy: 1.2 }, stag: 0.12, len: 0.5, ease: "outExpo" });
  tx("marca-texto", "Caixa", "Marca-texto", { unit: "word", hl: true, from: { a: 0, dy: 0.25 }, len: 0.35 });
  tx("lower-third", "Caixa", "Lower third", { unit: "line", bar: true, mask: true, align: "left", pos: 0.8, big: true, size: 0.75, from: { dx: -6 }, stag: 0.14, len: 0.6, ease: "outExpo", sample: "*NOME COMPLETO*\ncargo ou assunto" });
  tx("glitch-texto", "Impacto", "Glitch", { unit: "line", glitch: true, from: { a: 0 }, len: 0.05 });
  tx("batida", "Impacto", "Batida", { unit: "line", from: { s: 2.4, a: 0, b: 0.12 }, len: 0.28, ease: "outExpo", shake: true });
  api.texts = X;
  api.text = (id) => X.find((t) => t.id === id || t.nome.toLowerCase() === String(id || "").toLowerCase()) || null;
  api.textDefaults = { font: "Arial Black", size: 100, color: "#ffffff", accent: "#ffd400", boxColor: "#111111", shadow: true, dur: 3, pos: null };

  const EASE = { outCubic, outBack, outExpo };

  // Texto em partes: [{ t, hl }]. O chat escreve *destaque*; no painel cada parte tem o seu campo.
  api.toSegs = (text) =>
    String(text || "")
      .split("*")
      .map((t, i) => ({ t: t.replace(/^ +| +$/g, ""), hl: i % 2 === 1 }))
      .filter((s) => s.t);
  api.plain = (cfg) => (cfg.segs ? cfg.segs.map((s) => s.t).join(" ") : String(cfg.text || "").replace(/\*/g, "")).replace(/\s+/g, " ").trim();
  // Fonte de uma parte (a dela ou a geral). O nome vai entre aspas: sem aspas nem barras dentro.
  const cssFont = (px, f, w) => `${Number(w) || 400} ${px}px "${String(f || "Arial Black").replace(/["\\]/g, "")}", "Arial Black", Arial, sans-serif`;
  api.cssFont = cssFont;
  /*
   * Fontes padrão da pessoa: api.fonts = { normal: { f, w }, dest: { f, w } } ou null (cada modelo usa a sua).
   * Vale em tudo, menos na parte em que a pessoa escolheu a fonte na mão (seg.own).
   */
  api.fonts = null;
  api.fontOf = (seg, hl, modelF, modelW) => {
    if (seg && seg.own && seg.font) return { f: seg.font, w: seg.weight || 400 };
    if (api.fonts) return hl ? api.fonts.dest : api.fonts.normal;
    return { f: (seg && seg.font) || modelF, w: (seg && seg.font ? seg.weight : (seg && seg.weight) || modelW) || 400 };
  };
  // Partes -> linhas de palavras. cfg.lines: cada parte começa numa linha nova. Pontuação cola na palavra anterior.
  function wordLines(cfg) {
    const out = [[]];
    (cfg.segs || api.toSegs(cfg.text)).forEach((s, i) => {
      if (i && cfg.lines && out[out.length - 1].length) out.push([]);
      const fo = api.fontOf(s, !!s.hl, cfg.font, cfg.weight);
      String(s.t)
        .split(/\r?\n/)
        .forEach((ln, j) => {
          if (j) out.push([]);
          ln.split(/\s+/)
            .filter(Boolean)
            .forEach((w, k) => {
              const cur = out[out.length - 1];
              cur.push({ t: w, hl: !!s.hl, font: fo.f, weight: fo.w, k: clamp((Number(s.size) || 100) / 100, 0.2, 4), glue: cur.length > 0 && k === 0 && /^[.,!?;:…%)]/.test(w) });
            });
        });
    });
    return out.filter((l) => l.length);
  }

  // Quebra o texto em linhas; linha longa demais é quebrada pela largura.
  function layout(ctx, pr, cfg, W, H) {
    const base = Math.min(W, H) * 0.13 * (cfg.size / 100) * (pr.size || 1);
    const lines = [];
    for (const words of wordLines(cfg)) {
      const allHl = words.every((w) => w.hl);
      const px = base * (pr.big ? (allHl ? 1.35 : 0.62) : 1);
      const max = W * 0.88;
      let space = 0; // espaço depois da última palavra (na fonte dela)
      let cur = [];
      let w = 0;
      const flush = () => {
        // A altura da linha é a da maior letra dela.
        if (cur.length) lines.push({ px: Math.max(...cur.map((c) => c.px)), words: cur, w: w - space });
        cur = [];
        w = 0;
      };
      for (const word of words) {
        const wpx = px * word.k;
        ctx.font = cssFont(wpx, word.font, word.weight);
        const ww = ctx.measureText(word.t).width;
        if (word.glue && cur.length) w -= space;
        else if (cur.length && w + ww > max) flush();
        cur.push({ t: word.t, hl: word.hl, font: word.font, weight: word.weight, px: wpx, asc: ctx.measureText("H").actualBoundingBoxAscent || wpx * 0.7, desc: ctx.measureText("gjpq").actualBoundingBoxDescent || wpx * 0.2, x: w, w: ww });
        space = ctx.measureText(" ").width;
        w += ww + space;
      }
      flush();
    }
    // Palavra sozinha maior que o quadro: diminui só a linha dela.
    for (const l of lines) {
      const k = Math.min(1, (W * 0.92) / Math.max(1, l.w + (pr.box ? l.px * 0.44 : 0)));
      if (k < 1) {
        l.px *= k;
        l.w *= k;
        for (const x of l.words) (x.x *= k), (x.w *= k), (x.px *= k), (x.asc *= k), (x.desc *= k);
      }
    }
    // Altura real das maiusculas: fonte alta (Anton) ou baixa (Georgia) fica centrada na linha.
    for (const l of lines) l.asc = Math.max(...l.words.map((w) => w.asc));
    // Na caixa, as letras que descem (g, j, p) tambem precisam caber.
    const lh = (l) => Math.max(l.px * 1.18, l.asc + l.px * 0.46, pr.box ? l.asc + 2 * Math.max(...l.words.map((w) => w.desc)) + l.px * 0.12 : 0);
    const total = lines.reduce((s, l) => s + lh(l), 0);
    const cy = H * (cfg.pos != null ? cfg.pos : pr.pos || 0.5);
    let y = clamp(cy - total / 2, H * 0.02, Math.max(H * 0.02, H * 0.98 - total));
    for (const l of lines) {
      l.x = pr.align === "left" ? W * 0.08 : (W - l.w) / 2;
      l.y = y;
      l.h = lh(l);
      y += l.h;
    }
    return lines;
  }

  // Trecho em que nada se mexe (entrada cabe em 45 % da duracao; folga para tremor e marca-texto).
  api.textStill = function (cfg) {
    const pr = api.text(cfg.preset);
    if (!pr || pr.glitch || pr.viral) return null;
    return [Math.max(cfg.dur * 0.45, pr.len) + 0.5, cfg.dur - Math.min(0.3, cfg.dur * 0.2)];
  };

  // Desenha um quadro do texto (fundo transparente).
  api.drawText = function (ctx, W, H, t, cfgIn) {
    const cfg = Object.assign({}, api.textDefaults, cfgIn);
    const pr = api.text(cfg.preset) || X[0];
    if (pr.viral && api.drawViral) return api.drawViral(ctx, W, H, t, cfg, pr);
    ctx.clearRect(0, 0, W, H);
    const lines = layout(ctx, pr, cfg, W, H);
    const units = [];
    lines.forEach((l, li) => {
      if (pr.unit === "line") units.push({ l, li, parts: l.words, x: l.x, w: l.w });
      else
        l.words.forEach((w) => {
          if (pr.unit === "word") units.push({ l, li, parts: [w], x: l.x + w.x, w: w.w });
          else {
            ctx.font = cssFont(w.px, w.font, w.weight);
            for (let i = 0; i < w.t.length; i++) {
              const x0 = ctx.measureText(w.t.slice(0, i)).width;
              const cw = ctx.measureText(w.t.slice(0, i + 1)).width - x0;
              units.push({ l, li, parts: [{ t: w.t[i], hl: w.hl, font: w.font, weight: w.weight, px: w.px, x: 0 }], x: l.x + w.x + x0, w: cw, single: true });
            }
          }
        });
    });
    // Textos longos: comprime o atraso para a entrada caber em até 45 % da duração.
    const n = units.length;
    const stag = Math.min(pr.stag, n > 1 ? Math.max(0, cfg.dur * 0.45 - pr.len) / (n - 1) : pr.stag);
    const outLen = Math.min(0.3, cfg.dur * 0.2);
    const outP = clamp((t - (cfg.dur - outLen)) / outLen);
    const ease = EASE[pr.ease] || outCubic;
    const f = pr.from;

    if (pr.bar && lines.length) {
      const top = lines[0].y;
      const h = lines[lines.length - 1].y + lines[lines.length - 1].h - top;
      const g = outExpo(clamp(t / 0.45)) * (1 - inCubic(outP));
      ctx.fillStyle = cfg.accent;
      const bw = Math.max(3, Math.min(W, H) * 0.008);
      ctx.fillRect(W * 0.08 - bw * 2.4, top + (h * (1 - g)) / 2, bw, h * g);
    }
    units.forEach((u, i) => {
      const p = clamp((t - i * stag) / pr.len);
      const e = p <= 0 ? 0 : ease(p);
      const l = u.l;
      const q = 1 - e;
      const a = (f.a != null ? mix(f.a, 1, clamp(p * 1.6)) : p > 0 ? 1 : 0) * (1 - outP);
      if (a <= 0.002) return;
      const side = f.alt && i % 2 ? -1 : 1;
      let dx = (f.dx || 0) * l.px * q * side;
      let dy = (f.dy || 0) * l.px * q;
      if (pr.mask) dy += (f.dy ? f.dy : 0) * l.px * inCubic(outP);
      if (pr.mask && f.dx) dx += f.dx * l.px * inCubic(outP);
      if (pr.shake && p >= 1) {
        const k = clamp(1 - (t - i * stag - pr.len) / 0.25);
        dx += jit((t * 3) % 1, 0) * l.px * 0.08 * k;
        dy += jit((t * 3) % 1, 1) * l.px * 0.08 * k;
      }
      const s = f.s != null ? mix(f.s, 1, e) : 1;
      const r = ((f.r || 0) * q * PI) / 180;
      const blur = (f.b || 0) * l.px * Math.max(0, q) + 0.15 * l.px * outP * (f.b ? 1 : 0);
      const cx = u.x + u.w / 2;
      const cy = l.y + l.h / 2;
      ctx.save();
      ctx.globalAlpha = a;
      if (pr.mask) {
        ctx.beginPath();
        ctx.rect(u.x - l.px * 0.25, l.y, u.w + l.px * 0.5, l.h + (pr.box ? 0 : l.px * 0.12));
        if (pr.box) {
          const g = outExpo(clamp((t - i * stag) / 0.4));
          ctx.save();
          ctx.fillStyle = cfg.boxColor;
          ctx.fillRect(u.x - l.px * 0.22, l.y, (u.w + l.px * 0.44) * g, l.h * 0.98);
          ctx.restore();
        }
        ctx.clip();
      }
      if (pr.hl) {
        const g = outCubic(clamp((t - i * stag - 0.1) / 0.35));
        if (u.parts[0].hl) {
          ctx.fillStyle = cfg.accent;
          const wp = u.parts[0].px;
          const bl = l.y + l.h / 2 + l.asc / 2; // linha de base
          const up = (u.parts[0].asc || wp * 0.7) + wp * 0.14;
          ctx.fillRect(u.x - wp * 0.08, bl - up, (u.w + wp * 0.16) * g, up + wp * 0.14);
        }
      }
      ctx.translate(cx + dx, cy + dy);
      ctx.rotate(r);
      ctx.scale(s, s);
      if (blur > 0.4) ctx.filter = `blur(${blur.toFixed(2)}px)`;
      // Linha de base comum: fontes diferentes na mesma linha ficam alinhadas.
      ctx.textBaseline = "alphabetic";
      ctx.textAlign = "left";
      if (cfg.shadow && !pr.box) {
        ctx.shadowColor = "rgba(0,0,0,.55)";
        ctx.shadowBlur = l.px * 0.14;
        ctx.shadowOffsetY = l.px * 0.04;
      }
      const draw = (ox, oy, color) => {
        for (const w of u.parts) {
          ctx.font = cssFont(w.px, w.font, w.weight);
          ctx.fillStyle = color || (w.hl ? (pr.hl ? "#111111" : cfg.accent) : cfg.color);
          ctx.fillText(w.t, -u.w / 2 + (pr.unit === "line" ? w.x : 0) + ox, oy + l.asc / 2);
        }
      };
      if (pr.glitch) {
        const k = t < 0.5 ? 1 - t / 0.5 : (t * 1.3) % 1 > 0.92 ? 0.5 : 0;
        const j = jit((t * 4) % 1, i);
        if (k > 0) {
          draw(j * l.px * 0.12 * k, 0, "#ff2d55");
          draw(-j * l.px * 0.12 * k, 0, "#00e5ff");
        }
        draw(j * l.px * 0.04 * k, 0);
      } else draw(0, 0);
      ctx.restore();
    });
  };

  // ---------------------------------------------------------------- light leaks

  const LK = [];
  const lk = (id, nome, colors, move, dur) => LK.push({ id, nome, colors, move, dur: dur || 1.2 });
  lk("laranja", "Laranja quente", ["#ff7a18", "#ffb347", "#ff3d00"], "sweep");
  lk("dourado", "Dourado", ["#ffd27a", "#ffae00", "#fff1c9"], "rise");
  lk("vermelho", "Vermelho cinema", ["#ff1f1f", "#ff5e3a", "#b30000"], "sweep");
  lk("rosa", "Rosa pôr do sol", ["#ff4f9a", "#ff9a5a", "#ffd0a0"], "corner");
  lk("azul", "Azul frio", ["#3aa0ff", "#8fd3ff", "#1b4dff"], "sweep");
  lk("violeta", "Violeta", ["#8b5cf6", "#d18bff", "#4f2bff"], "corner");
  lk("arco-iris", "Prisma", ["#ff3d6e", "#ffd23d", "#3dd6ff"], "prism");
  lk("branco", "Branco suave", ["#ffffff", "#fff4e0", "#eaf4ff"], "rise");
  lk("queima", "Queima de filme", ["#fff0b0", "#ff8a00", "#ff2a00"], "burn", 0.9);
  lk("lateral", "Feixe lateral", ["#ffb066", "#ff6a3d", "#ffe2b8"], "beam");
  lk("ambiente", "Ambiente lento", ["#ff8a3d", "#ffc46b", "#ff4f4f"], "drift", 4);
  lk("ambiente-azul", "Ambiente azul lento", ["#4fb0ff", "#7be0ff", "#6a6bff"], "drift", 4);
  api.leaks = LK;
  api.leak = (id) => LK.find((l) => l.id === id || l.nome.toLowerCase() === String(id || "").toLowerCase()) || null;

  const rgba = (hex, a) => {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
  };
  // Desenha em preto (luz somada). Depois toAlpha() troca o preto por transparência.
  api.drawLeak = function (ctx, W, H, t, dur, leak, force) {
    const p = clamp(t / dur);
    const env = leak.move === "drift" ? Math.min(1, Math.min(p, 1 - p) * 6) * (0.75 + 0.25 * Math.sin(t * 2.1)) : Math.pow(Math.sin(PI * p), 1.3);
    const k = env * (force == null ? 1 : force);
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = "lighter";
    const D = Math.max(W, H);
    const blob = (x, y, r, c, a) => {
      const g = ctx.createRadialGradient(x, y, 0, x, y, Math.max(1, r));
      g.addColorStop(0, rgba(c, clamp(a)));
      g.addColorStop(0.45, rgba(c, clamp(a * 0.45)));
      g.addColorStop(1, rgba(c, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    };
    const c = leak.colors;
    const m = leak.move;
    if (m === "sweep") c.forEach((col, i) => blob(W * mix(-0.3, 1.3, p) + (i - 1) * W * 0.25, H * (0.3 + 0.25 * i), D * (0.55 + 0.1 * i), col, k * 0.95));
    else if (m === "rise") c.forEach((col, i) => blob(W * (0.2 + 0.3 * i), H * mix(1.25, 0.15, p) + i * H * 0.08, D * 0.6, col, k * 0.85));
    else if (m === "corner") c.forEach((col, i) => blob(W * mix(1.1, 0.55, p) - i * W * 0.15, H * mix(-0.1, 0.35, p) + i * H * 0.1, D * (0.75 - 0.12 * i), col, k));
    else if (m === "prism") c.forEach((col, i) => blob(W * mix(-0.2 + i * 0.12, 1.1 + i * 0.12, p), H * (0.2 + 0.3 * i), D * 0.42, col, k));
    else if (m === "burn") {
      blob(W * mix(0.1, 0.6, p), H * 0.5, D * mix(0.25, 1.3, env), c[2], k);
      blob(W * mix(0.15, 0.6, p), H * 0.48, D * mix(0.2, 1.0, env), c[1], k);
      blob(W * mix(0.2, 0.6, p), H * 0.5, D * mix(0.1, 0.75, env), c[0], k);
    } else if (m === "beam") {
      const x = W * mix(-0.2, 0.9, p);
      c.forEach((col, i) => {
        for (let j = 0; j < 3; j++) blob(x + i * W * 0.06, H * (0.1 + 0.4 * j), D * 0.34, col, k * 0.6);
      });
    } else c.forEach((col, i) => blob(W * (0.5 + 0.55 * Math.sin(t * 0.7 + i * 2.1)), H * (0.5 + 0.5 * Math.cos(t * 0.6 + i * 1.7)), D * 0.6, col, k * 0.55));
    ctx.globalCompositeOperation = "source-over";
  };
  // Preto vira transparente: a cor fica cheia e o alfa é o brilho (igual a "Screen" sem mexer no modo de mesclagem).
  api.toAlpha = function (data) {
    for (let i = 0; i < data.length; i += 4) {
      const m = Math.max(data[i], data[i + 1], data[i + 2]);
      if (m > 0) {
        const k = 255 / m;
        data[i] *= k;
        data[i + 1] *= k;
        data[i + 2] *= k;
      }
      data[i + 3] = m > 2 && m < 253 ? m + (Math.random() - 0.5) * 3 : m; // ruido leve: evita faixas no degrade
    }
    return data;
  };

  root.Efeitos = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
