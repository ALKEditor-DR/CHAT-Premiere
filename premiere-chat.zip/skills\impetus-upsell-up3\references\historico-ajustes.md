# Histórico de ajustes e por quê

## 2026-11-20: criação (UP 3 HerzPur / GlucoVital / NachtPrime, GER)
- Pedido do usuário: analisar o "UP 1" do projeto (inserts, SFX, LTs, legendas animadas, insert com fundo desfocado, insert com borda arredondada, animações) e editar o "UP 3" seguindo tudo, com um detalhe: o UP 3 tem 3 produtos. Usar os backgrounds do NachtPrime nos momentos-chave como no UP 1; quando falar de HerzPur ou GlucoVital, usar os B-rolls de cada um; **B-rolls do NachtPrime só depois de ele ser apresentado no vídeo**. Mesma trilha, mesmos efeitos, mesmas transições intercaladas. Motions em camadas separadas para poder mexer.
- Efeitos indicados pelo usuário (aba Predefinições): neon = Wonder Glow; desfoque de mockups = Gaussian Blur; B-roll com borda arredondada = "borda arredondada"; inserts em 3D = "EFEITO 3D". Legenda já corrigida por ele (não mexer). Transcrição da timeline anexada.
- Montado pelo painel (ExtendScript + QE) em "UP 3 - MONTADA": 139 B-rolls, 4 cartões, 10 telas de produto, 3 telas de oferta, 4 neons, 42 destaques, 6 zooms, 66 transições, 10 light leaks, vinheta, LT, 5 trilhas, SFX, 12 marcadores.
- Retorno: "o restante está perfeito", exceto as telas de mockup animado (ex.: NachtPrime sobre o BG azul): **trocar o EFEITO 3D por "ZOOM IN 20X" ou "ZOOM OUT 20X"**. O usuário corrigiu a timeline ele mesmo e pediu para só aprender. Regra registrada em `estilo-aprovado.md`.
- Também observado: trilhas do UP 1 em 0 dB no clipe ficariam altas sobre a voz; usado −22,6 dB em todas (sem reclamação). Depoimentos ficaram sem LT por falta dos nomes.
