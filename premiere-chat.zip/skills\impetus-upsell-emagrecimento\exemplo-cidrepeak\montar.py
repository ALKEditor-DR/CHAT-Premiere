"""Monta roteiro.json e projeto.json do upsell Cidrepeak FRA a partir de palavras.json (exemplo real da skill).
Para um vídeo novo: copie para <pasta mãe>/_projeto, troque EXIBIR, DEST, B, as telas de preço, nomes e áudio, e rode.
Os tempos são achados pelas frases faladas (grafia da legenda), então não precisa digitar segundos."""
import json
import os
import re
import shutil
import sys
import unicodedata

sys.stdout.reconfigure(encoding="utf-8")
P = os.path.dirname(os.path.abspath(__file__))
MAE = os.path.dirname(P)
pal = json.load(open(os.path.join(P, "palavras.json"), encoding="utf-8"))


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9%€]", "", s)


# grafia na legenda -> como saiu na transcrição
EXIBIR = {"sidrepeak": "Cidrepeak", "cidrepic": "Cidrepeak", "galpen": "GLP-1", "glpen": "GLP-1", "lucille": "Lucile",
          "ances": "ANSES", "lances": "l'ANSES"}


def achar(frase, depois=0.0):
    alvo = [norm(x) for x in frase.split()]
    for i in range(len(pal)):
        if pal[i][0] < depois - 0.01:
            continue
        if NW[i:i + len(alvo)] == alvo:
            return i, i + len(alvo) - 1
    raise SystemExit(f"não achei: {frase} depois de {depois}")


def t0(frase, depois=0.0):
    return pal[achar(frase, depois)[0]][0]


def t1(frase, depois=0.0):
    return pal[achar(frase, depois)[1]][1]


def exibe(i):
    w = pal[i][2]
    k = norm(w)
    if k in EXIBIR:
        w = EXIBIR[k] + re.sub(r"^[\w%€'’-]+", "", w)
    if k == "premiere" and i + 1 < len(pal) and norm(pal[i + 1][2]).startswith("achat"):
        w = "premier"
    return w


NW = [norm(exibe(i)) for i in range(len(pal))]


# ---------------- destaques (Bebas). frase falada -> cartões ----------------
# cada cartão: lista de linhas "w:TEXTO" (branco), "y:TEXTO" (amarelo), "g:texto" (pequeno). O número de palavras tem que bater.
DEST = [
    ("de loin la décision la plus intelligente", [["w:DE LOIN"], ["w:LA DÉCISION"], ["w:LA PLUS"], ["w:INTELLIGENTE"]], False),
    ("s'il vous plaît, ne fermez pas cette page et ne cliquez pas sur Retour",
     [["w:S'IL VOUS PLAÎT,"], ["w:NE FERMEZ PAS"], ["w:CETTE PAGE"], ["w:ET NE CLIQUEZ PAS"], ["w:SUR RETOUR"]], False),
    ("J'ai besoin que vous restiez avec moi jusqu'à la fin",
     [["w:J'AI BESOIN QUE"], ["w:VOUS RESTIEZ"], ["w:AVEC MOI"], ["w:JUSQU'À LA FIN"]], False),
    ("plus de 160 euros de cadeaux", [["w:PLUS DE"], ["y:160 EUROS"], ["w:DE CADEAUX"]], False),
    ("il existe ce que nous appelons le protocole accéléré.",
     [["w:IL EXISTE CE"], ["w:QUE NOUS APPELONS"], ["w:LE PROTOCOLE"], ["y:ACCÉLÉRÉ."]], False),
    ("C'est trois gélules par jour.", [["w:C'EST TROIS"], ["w:GÉLULES"], ["w:PAR JOUR."]], False),
    ("oui, c'est sans danger.", [["w:OUI,"], ["w:C'EST"], ["w:SANS DANGER."]], False),
    ("c'est exactement là qu'apparaît le problème.", [["w:C'EST EXACTEMENT"], ["w:LÀ QU'APPARAÎT"], ["y:LE PROBLÈME."]], False),
    ("passe à 60 jours.", [["w:PASSE À"], ["y:60 JOURS."]], False),
    ("uniquement sur cette page", [["w:UNIQUEMENT"], ["w:SUR CETTE PAGE"]], False),
    ("livraison gratuite.", [["w:LIVRAISON"], ["w:GRATUITE."]], False),
    ("livraison gratuite.@290", [["w:LIVRAISON"], ["w:GRATUITE."]], False),
    ("Attendez, relisez, calmement,", [["g:Attendez,", "y:RELISEZ", "g:calmement,"]], False),
    ("le plus petit pack est le plus cher.", [["w:LE PLUS PETIT"], ["w:PACK"], ["w:EST LE PLUS CHER."]], False),
    ("6 mois complets", [["w:6 MOIS"], ["y:COMPLETS"]], False),
    ("pas un jour de moins.", [["w:PAS UN JOUR"], ["w:DE MOINS."]], False),
]
d_por_inicio = {}
for frase, cartoes, forcar in DEST:
    depois = 0.0
    if "@" in frase:
        frase, dep = frase.split("@")
        depois = float(dep)
    a, b = achar(frase, depois)
    d_por_inicio[a] = (b, cartoes, forcar)

# ---------------- legendas normais + destaques, na ordem ----------------
MAXC, MAXW = 18, 3
rot = []
atual = []


def fecha():
    global atual
    if atual:
        txt = " ".join(atual)
        txt = txt[0].upper() + txt[1:] if rot == [] or rot[-1][1].rstrip().endswith((".", "?", "!")) else txt
        rot.append(["L", txt])
    atual = []


i = 0
while i < len(pal):
    if i in d_por_inicio:
        fecha()
        b, cartoes, forcar = d_por_inicio[i]
        n_cart = sum(len(l.split(":", 1)[1].split()) for c in cartoes for l in c)
        assert n_cart == b - i + 1, (pal[i][2], n_cart, b - i + 1)
        for c in cartoes:
            rot.append(["D!" if forcar else "D", " / ".join(c)])
        i = b + 1
        continue
    w = exibe(i)
    if norm(w) == "cidre" and i + 1 < len(pal) and norm(pal[i + 1][2]).startswith("epique"):
        w = "Cidrepeak" + re.sub(r"^[\w-]+", "", pal[i + 1][2]) + "{2}"
        i += 1
    gap = pal[i + 1][0] - pal[i][1] if i + 1 < len(pal) else 9
    cand = " ".join(atual + [w])
    if atual and (len(cand) > MAXC or len(atual) >= MAXW):
        fecha()
    atual.append(w)
    if norm(pal[i][2]) == "rythme" and i + 1 < len(pal) and norm(pal[i + 1][2]) == "en":
        atual.append("+accéléré.")  # o Whisper perdeu essa palavra (conferido no áudio)
        fecha()
    if re.search(r"[.,!?;:]$", w) or gap > 0.25:
        fecha()
    i += 1
fecha()
json.dump(rot, open(os.path.join(P, "roteiro.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)

# ---------------- inserts ----------------
os.makedirs(os.path.join(MAE, "Inserts", "broll"), exist_ok=True)


def arq(f):
    f = f.replace("\\", "/")
    if f.startswith(MAE.replace("\\", "/")) or "TESTES DE IA" in f:
        return f
    dst = os.path.join(MAE, "Inserts", "broll", os.path.basename(f))
    if not os.path.exists(dst):
        shutil.copy2(f, dst)
    return "Inserts/broll/" + os.path.basename(f)


# (frase onde começa, frase onde termina, arquivo, opções)
B = [
    ("Cette décision peut", "changer votre vie", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Woman_Weight_Loss_3840x2160.mp4", {}),
    ("et votre corps pour", "pour toujours.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Girl_Slim_3840x2160.mp4", {}),
    ("Votre commande est", "ce moment même.", r"G:/Clientes/IMPETUS/Inserts gerais/Entregas/packing-goods-in-a-cardboard-box-close-up-packagi-2026-01-22-07-22-42-utc.mp4", {}),
    ("s'il vous plaît,", "sur Retour", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Cellphonoe_Glasses_3840x2160.mov", {}),
    ("pendant que le laboratoire", "finalise votre envoi.", r"G:/Clientes/IMPETUS/Inserts gerais/Entregas/scientists-packaging-bottles-in-a-bright-lab-2025-12-17-06-33-30-utc.mov", {}),
    ("n'existe que tant", "est ouvert.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/5934741_Woman_App_3840x2160.mp4", {}),
    ("Il existe une façon", "premiers résultats", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/5294257_Tape_Measure_Woman_3840x2160.mp4", {}),
    ("beaucoup plus vite que", "que d'habitude.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Happy_Woman_3840x2160.mp4", {}),
    ("Et j'ai déjà préparé", "besoin pour cela.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/6 POTES/01.mp4", {}),
    ("C'est ici réservé", "à votre nom attendant", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/05.mp4", {}),
    ("d'entrer dans le même", "même carton", r"G:/Clientes/IMPETUS/Inserts gerais/Entregas/person-taping-box-for-priority-shipping-in-office-2025-12-18-02-04-11-utc.mov", {}),
    ("que le laboratoire est en", "en ce moment.", r"G:/Clientes/IMPETUS/Inserts gerais/Entregas/worker-strapping-and-labeling-cardboard-box-at-fac-2025-12-17-05-01-22-utc.mov", {}),
    ("laissez tout cela", "s'échapper.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Woman_Sad_3840x2160.mp4", {}),
    ("ce qui va se passer", "la première dose.", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/3D VÍDEOS LOST WEIGHT/0_Human_Anatomy_3840x2160.mov", {}),
    ("Vous savez déjà", "perdre du poids", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Overweight_Weight_Gain_3840x2160.mp4", {}),
    ("réside dans les hormones", "GIP et", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/3D VÍDEOS LOST WEIGHT/0_Film_Digestive_3840x2160.mov", {}),
    ("que Cidrepeak réactive", "100% naturelle", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/01.mp4", {}),
    ("en imitant l'effet", "stylos minceur", r"G:/Clientes/IMPETUS/Inserts gerais/Mounjaro/mounjaro.mp4", {}),
    ("et les résultats suivent", "très claire.", r"G:/Clientes/IMPETUS/Inserts gerais/TEMPO. CALENDARIO/1661396_Calendar_Calender_3840x2160.mp4", {}),
    ("Dans les premières", "72 heures,", r"G:/Clientes/IMPETUS/Inserts gerais/TEMPO. CALENDARIO/1917678_Stopwatch_Gears_1920x1080.mp4", {}),
    ("vous remarquez déjà", "gonflement diminué", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Stomach_Hands_4096x2160.mp4", {}),
    ("et l'énergie montée.", "l'énergie montée.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/1102402_1080p_Pretty_1920x1080.mov", {}),
    ("Et entre 3 et 6", "résultats de tous,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/woman-looks-at-herself-in-mirror-at-home-2025-12-17-21-56-54-utc.mov", {}),
    ("avec des femmes rapportant", "40 kg,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/Inserts da Pam Frison/ssstik.io_1786574746281.mp4", {}),
    ("la transformation complète", "effet yo-yo.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/2521432_Happy_Loving_3840x2160.mp4", {}),
    ("En prenant la dose", "c'est le chemin,", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/02.mp4", {}),
    ("La dose standard est", "allez le régler.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/2 POTES/02.mp4", {}),
    ("Mais pour les femmes", "au plus vite,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Happy_Woman_3840x2160.mp4", {"clip_in": 4}),
    ("C'est trois gélules", "par jour.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/3 POTES/03.mp4", {}),
    ("Un le matin,", "Un le matin,", r"G:/Clientes/IMPETUS/Inserts gerais/TEMPO. CALENDARIO/1342015_Retro_Flip_Clock_3840x2160.mp4", {}),
    ("un le midi", "un le midi", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Woman_Eating_3840x2020.mp4", {}),
    ("et un le soir.", "et un le soir.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Woman_Bedroom_3840x2160.mp4", {}),
    ("vous multipliez la vitesse", "corps absorbe", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/3D VÍDEOS LOST WEIGHT/6601077_Intestines_Digestion_1920x1080.mp4", {}),
    ("les ingrédients premium", "de Cidrepeak.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/07.mp4", {}),
    ("Vous accélérez la réactivation", "GLP-1 et GIP.", r"G:/Clientes/IMPETUS/Inserts gerais/Pilulas/0_Molecule_Chemistry_2160x3840.mp4", {}),
    ("Ce qui prendrait des mois", "quelques semaines.", r"G:/Clientes/IMPETUS/Inserts gerais/TEMPO. CALENDARIO/1661394_Calendar_Wall_Calendar_3840x2160.mp4", {}),
    ("Cidrepeak est 100%", "plus strictes", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/05 (2).mp4", {}),
    ("et en conformité avec", "l'ANSES.", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/LABORATORIOS OU CIENTISTAS/0_Scientists_Lab_3840x2160.mp4", {}),
    ("La science derrière", "est simple.", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/LABORATORIOS OU CIENTISTAS/0_Laboratory_Vertical_Video_2160x3840.mov", {}),
    ("ce sont les principes", "de Cidrepeak,", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/02 (2).mp4", {}),
    ("comme la berbérine", "du coptis.", r"G:/Clientes/IMPETUS/Inserts gerais/Pilulas/6036140_Herbal_Capsules_3840x2160.mp4", {}),
    ("Et plus cette activation", "de la journée,", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/3D VÍDEOS LOST WEIGHT/breaking-down-of-fat-cells-structure-2026-01-28-05-20-19-utc (1).mp4", {}),
    ("plus votre corps réagit", "réagit rapidement.", r"G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/3D VÍDEOS LOST WEIGHT/breaking-down-of-fat-cells-structure-2026-01-28-05-20-14-utc (1).mp4", {}),
    ("Ce que beaucoup de femmes", "rythme normal", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/6035165_Woman_Food_3840x2160.mp4", {}),
    ("commence avec le protocole", "quelques jours.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/5294247_Woman_Waist_3840x2160.mp4", {}),
    ("Vous arrivez à la même", "beaucoup plus vite.", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/4767332_Indoors_Fitness_3840x2160.mp4", {}),
    ("mes flacons se sont", "j'espérais.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/1 POTE/03.mp4", {}),
    ("Dans le protocole accéléré,", "au lieu de un.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/3 POTES/02.mp4", {}),
    ("Le stock qui devait", "60 jours.", r"G:/Clientes/IMPETUS/Inserts gerais/TEMPO. CALENDARIO/0_Calendar_Date_1080x1920.mov", {}),
    ("Et s'arrêter dès", "nouveau poids,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/5293500_Bathroom_Scale_Woman_3840x2160.mp4", {}),
    ("Je veux en aucun cas", "meilleur moment,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/0_Woman_Dissatisfied_3840x2160.mp4", {}),
    ("simplement parce que", "est vide.", r"G:/Clientes/IMPETUS/Inserts gerais/Pilulas/0_Pills_Medicine_3840x2160.mp4", {}),
    ("Vous n'achetez pas", "traitement définitif.", r"G:/Clientes/IMPETUS/TESTES DE IA/Inserts/Produto/Animados/6 POTES/02.mp4", {}),
    ("C'est la couverture", "votre transformation,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/woman-examines-figure-in-full-length-mirror-2025-12-17-06-16-58-utc.mov", {}),
    ("du début jusqu'à", "se stabilise,", r"G:/Clientes/IMPETUS/Inserts gerais/EMAGRECIMENTO/5294087_Measurement_Taking_Measure_3840x2160.mp4", {}),
]


def fim_frase(frase, depois):
    return t1(frase, depois)


ins = []
ult = 0.0
for ini, fim, chave, op in B:
    a = t0(ini.replace("Cidrepeak", "sidrepeak") if False else ini, ult - 5)
    b = fim_frase(fim, a)
    d = {"inicio": round(a - 0.05, 3), "fim": round(b + 0.12, 3), "arquivo": arq(chave), "clip_in": op.get("clip_in", 0.5)}
    d.update({k: v for k, v in op.items() if k != "clip_in"})
    ins.append(d)
    ult = a
# não deixa um insert invadir o próximo
ins.sort(key=lambda d: d["inicio"])
for x, y in zip(ins, ins[1:]):
    if x["fim"] > y["inicio"]:
        x["fim"] = y["inicio"]

# ---------------- tela de preço ----------------
MK = "Inserts/Produto/Mockup_CidrePeak FRA {:02d}.png"


def m(n, ini, fim, pos, larg, fase=0):
    return {"arquivo": MK.format(n), "inicio": ini, "fim": fim, "pos": pos, "larg": larg, "fase": fase}


preco = []
# 12 flacons a 19 € / 0,63 €
a = t0("un stock supplémentaire") - 0.05
b = t1("par gélule.") + 0.15
preco.append({"inicio": a, "fim": b, "fundo": "G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/Background/BG YELLOW.mp4",
              "mockups": [m(12, a, b, [0.5, 0.28], 820)],
              "precos": [{"texto": "19€", "cor": "verde", "inicio": t0("19 euros par"), "fim": t0("ce qui revient")},
                         {"texto": "0,63€", "cor": "amarelo", "inicio": t0("63 centimes"), "fim": b}]})
# 9 flacons a 27 € / 243 €
a = t0("options de 9") - 0.05
b = t1("243 euros avec") + 0.1
preco.append({"inicio": a, "fim": b, "fundo": preco[0]["fundo"],
              "mockups": [m(9, a, b, [0.5, 0.27], 860)],
              "precos": [{"texto": "27€", "cor": "verde", "inicio": t0("27 chacun"), "fim": t0("243 euros avec")},
                         {"texto": "243€", "cor": "amarelo", "inicio": t0("243 euros avec"), "fim": b}]})
# 6 flacons a 29 € / 174 €
a = t0("6 flacons pour 29") - 0.05
b = t1("174 euros avec") + 0.1
preco.append({"inicio": a, "fim": b, "fundo": preco[0]["fundo"],
              "mockups": [m(6, a, b, [0.5, 0.27], 820)],
              "precos": [{"texto": "29€", "cor": "verde", "inicio": t0("29 chacun"), "fim": t0("174 euros avec")},
                         {"texto": "174€", "cor": "amarelo", "inicio": t0("174 euros avec"), "fim": b}]})
# pack 9 = 243 / pack 12 = 228
a = t0("le pack de 9 flacons") - 0.05
mid = t0("le pack de 12 flacons")
b = t1("228 euros.") + 0.2
preco.append({"inicio": a, "fim": b, "fundo": preco[0]["fundo"],
              "mockups": [m(9, a, mid, [0.5, 0.27], 860), m(12, mid, b, [0.5, 0.28], 820)],
              "precos": [{"texto": "243€", "cor": "amarelo", "inicio": t0("243 euros,", a), "fim": mid},
                         {"texto": "228€", "cor": "verde", "inicio": t0("228 euros."), "fim": b}]})
# 6 já reservados + 12 de hoje = 18
a = t0("Les 6 flacons que") - 0.05
mid = t0("En ajoutant les 12")
b = t1("18 flacons au total,") + 0.25
preco.append({"inicio": a, "fim": b, "fundo": preco[0]["fundo"],
              "mockups": [m(6, a, b, [0.5, 0.21], 620), m(12, mid, b, [0.5, 0.73], 640, 1.0)],
              "precos": [{"texto": "60 jours", "cor": "amarelo", "inicio": t0("60 jours au"), "fim": mid},
                         {"texto": "18", "cor": "verde", "inicio": t0("18 flacons"), "fim": b, "pos": [0.5, 0.47]}]})
for tp in preco:
    tp["inicio"] = round(tp["inicio"], 3)
    tp["fim"] = round(tp["fim"], 3)
    for x in tp["precos"]:
        x.setdefault("pos", [0.5, 0.56])
# inserts não entram por cima da tela de preço
ins = [d for d in ins if not any(d["inicio"] < tp["fim"] and d["fim"] > tp["inicio"] for tp in preco)]

proj = {
    "mae": MAE.replace("\\", "/"),
    "decupado": "decupado.mp4",
    "roteiro": "roteiro.json",
    "trocas": [["Cidrepeak", "Sidrepeak"], ["Cidrepeak", "CIDREPIC"], ["GLP-1", "Galpen"], ["GLP-1", "GLPEN"], ["Lucile", "Lucille"],
               ["l'ANSES", "l'ANCES"], ["premier", "première"], ["Cidrepeak", "cidreépique"]],
    "nomes": [{"inicio": t0("ici Lisa") , "fim": t0("Lucile Woodward et") - 0.05, "linha1": "Lisa Salis", "linha2": "Responsable du laboratoire"},
              {"inicio": t0("Lucile Woodward et"), "fim": t1("pour votre décision.") , "linha1": "Lucile Woodward", "linha2": "Laboratoire Cidrepeak", "lado": "direita"},
              {"inicio": t0("Lucile Woodward,", 190), "fim": t1("quatre kilos."), "linha1": "Lucile W.", "linha2": "Cliente Cidrepeak"}],
    "inserts": ins,
    "tela_preco": preco,
    "flashes": [round(t0("s'il vous plaît,") , 3), round(t0("Laissez-moi vous"), 3), round(t0("il existe ce que"), 3),
                round(t0("Lucile Woodward,", 190), 3), round(t0("c'est exactement là"), 3), round(t0("un stock supplémentaire") - 0.05, 3),
                round(t0("Attendez,"), 3), round(t0("Les 6 flacons que") - 0.05, 3)],
}
t_dep = round(t0("Lucile Woodward,", 190), 3)
fim_total = pal[-1][1] + 0.5
PICO_WHOOSH = 0.26
proj["audio"] = {
    "alvo_lufs": -17,
    "trilhas": [{"arquivo": "Cinematic & Inspiring Music (No Copyright) - Flowing Energy by @KeysofMoonMusic - 128.mp3", "inicio": 0,
                 "fim": t_dep + 0.4, "arquivo_in": 0, "lu": -18, "fade_in": 0.5, "fade_out": 1.2},
                {"arquivo": "Corporate On Minimal.mp3", "inicio": t_dep, "fim": round(fim_total, 3), "arquivo_in": 0, "lu": -18,
                 "fade_in": 1.0, "fade_out": 1.5}],
    "sfx": [{"arquivo": "mid whoosh.mp3", "t": round(f - PICO_WHOOSH, 3), "ganho_db": -12} for f in proj["flashes"]]
           + [{"arquivo": "swhoosh.mp3", "t": round(tp["inicio"] - 0.56, 3), "ganho_db": -17} for tp in preco
              if not any(abs(tp["inicio"] - f) < 0.5 for f in proj["flashes"])],
}
json.dump(proj, open(os.path.join(P, "projeto.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(rot), "blocos,", len(ins), "inserts,", len(preco), "telas de preço")
