# Estilo do UPsell Memória (Impetus)

Base: tudo de `estilo-aprovado.md` e `padroes-upsell-impetus.md` (legenda, telas de preço, light leak + shutter, nomes, mix) continua valendo. Este arquivo lista **o que muda** quando o produto é de memória/cérebro/demência (público 50+), e o tom é dramático.

Exemplo entregue: Memopower UP1A V1 GER (Digistore), `G:\Clientes\IMPETUS\UPSELL  Memopower  UP1A V1 Memopower  GER  Digistore`
(vídeo em `Finalizado\UP_1A_V1_MemoPower_GER_Digistore_09m19s.mp4`; projeto em `Projeto\...prproj`, sequência 15 é a principal; as 16–19 são versões vazias).
Apresentador único (Dr. Matthias Riedl, médico de jaleco no laboratório). Mockups ainda do MeltPeak (temporários).
Leitura completa insert por insert, com a fala: `aprendizado/memopower/compacto_memopower.txt`. Efeitos por clipe: `aprendizado/memopower/efeitos_memopower.txt`. Quadros: `aprendizado/memopower/quadros_memopower.jpg`.

## Pedido do usuário (2026-11-14), vale para todo material dramático
- Tom mais dramático que o de emagrecimento.
- **Alguns inserts em preto e branco; outros com saturação em 50 %.** Não é o vídeo inteiro: escolha pelos trechos de dor/medo/perda.
- **Granulado**, **vinheta nas bordas**, **VHS** nos trechos dramáticos.
- **LTs maiores na tela.**
- B-roll focado em pessoas **de 50 anos para cima** (idosos, casais idosos, avós com netos). Evitar gente jovem, a não ser em família com o idoso.

## Ritmo (medido no Memopower)
- 14 min 56 s de timeline, 211 inserts, **67 % de cobertura**, insert médio de 2,9 s (um pouco mais longo que no emagrecimento: deixa a cena "respirar").
- Origem: banco 111 (Storyblocks/Pond5 78, Envato 32), IA/mockup gerado 34, sequências em cartão 24 trechos, idosos IA ("Robert 1/2/3", "Idosos desespero", "Idoso Dopado poltrona" etc.) 17, UGC orgânico 15.
- Pastas mais usadas: `Inserts gerais\IDOSO E PÉ EM GERAL` (46), `ARQUIVOS NECESSARIOS\MOCKUPS` (34), `Inserts gerais\Homens` (22), `Inserts gerais\memoria` (17, UGC de TikTok com idosos esquecidos), `Cerebro` (11), `NERVOS` (10), `Pilulas`, `TEMPO. CALENDARIO`, `Medico(a)`, `Entregas`.

## Fala → insert (exemplos do Memopower)
| Fala | Insert |
|---|---|
| "Parabéns pela compra" | idoso feliz (banco) + mão segurando o frasco (IA) |
| "A maioria das pessoas com perda de memória faz o mesmo" | UGC de idoso confuso (`memoria\snaptik_…`) |
| "esperam, convivem e se adaptam" | idoso triste olhando a janela (Envato) |
| "anotam tudo em papéis" | UGC de bilhetes/post-its |
| "evitam encontros sociais / lembrar nomes" | UGC de idosa (`memoria\ssstik…grammymac`) |
| "acordar às 2 da manhã, cabeça confusa, medo de não se reconhecer no espelho" | **sequência em cartão** (insone, mão na testa, idosos desespero, rosto em close), fundo escurecido |
| "o cérebro não coopera mais / neurônios e sinapses / placa neuronal" | cérebro 3D, neurônios (Cerebro, NERVOS) |
| "família vem ajudar, assume seu dia a dia" | enfermeiras ajudando idoso; idoso amparado pela esposa |
| "em 2, 3, 5 anos" | calendário de parede |
| história do paciente (Hans, 64 anos, aposentado) | personagem IA idoso recorrente ("Robert 1/2/3") em várias cenas |
| tratamento / dose / ingredientes | pílulas, farmácia, produto IA na mão |
| "sua família / netos / voltar a viver" | avô com neto, família feliz à mesa (o único momento colorido e alegre) |
| oferta | telas de preço com mockups, setas, neon (iguais ao emagrecimento) |

## Cor e textura (o que fazer)
- **Preto e branco** (`"cor": "pb"` no insert): memória perdida, medo, solidão, "o dia em que não dá mais para adiar", o paciente que parou o tratamento e piorou, demência.
- **Saturação 50 %** (`"cor": "50"`): demais inserts de dor/problema, consultório, idoso triste. Também nas sequências em cartão.
- **Cor normal**: solução, cérebro/ciência, produto, família feliz, oferta. O contraste entre a parte cinza (problema) e a colorida (solução) é o recurso dramático.
- **Granulado** leve em todo o vídeo (`grao` 0,04) e mais forte nos trechos `drama` (`grao_drama` 0,065). Alternativa no Premiere: `Inserts gerais\old-film-grain-overlay-4k-snowman-digital.mp4` em Overlay/Screen; no Memopower a camada de ajuste usa Noise 20 %.
- **Vinheta** sempre (0,72) e forte nos trechos `drama` (0,85). Medido no Memopower: canto com 25–35 % do brilho do centro nas cenas dramáticas. No Premiere: camada "VInheta" (Lumetri, vinheta −5) em todo o vídeo + "VERTICAL VIGNETT" (Vignette com aberração cromática 51) nos trechos fortes.
- **VHS** (`[ini, fim, "vhs"]` em `drama`): sutil: cor separada (vermelho/azul ±3 px), linhas horizontais leves (5 %), tremor de 2 px em 2 faixas, linha de tracking fraca descendo. Usar pouco: flashback, "o dia em que…", lembrança, história do paciente, frase de choque. 3 a 6 trechos curtos (3–8 s) por vídeo.

## LTs (destaques)
- Anton branca, caixa alta, centro em y≈670, palavra a palavra no ritmo da fala (2–3 palavras por cartão), como no Memopower: "UND / SIE SCHIEBEN / ES VOR / SICH HER…".
- **Maiores que no emagrecimento**: `dest_tam` 190 (no Memopower a altura das maiúsculas é ~108 px; o usuário pediu maior). Largura até 960 px.
- Fundo: o apresentador ou o insert fica **desfocado (30) e escurecido** (Lumetri exposição −0,6, realces −100, sombras −51 no Memopower).
- Cada LT dramática ganha `Boom 1.mp3` no início.
- Onde: "e eles adiam até o dia em que não dá mais", "alguém da família tem que assumir", "pessoas como você merecem a verdade", "dos que param antes, boa parte tem volta forte dos sintomas", "não é culpa, é amor, mas dói igual", "o tratamento não pode ser interrompido", "agora preciso te fazer uma oferta", "assim que esta tela fechar…", garantia ("o risco é zero").

## Cartões (sequência de inserts)
- 3 a 5 inserts seguidos dentro de um cartão (82 %, cantos arredondados) sobre uma cópia desfocada e escurecida do próprio insert (`"cartao": true`). No Memopower: 8 sequências (46 s, 2:05, 2:52, 4:09, 6:22, 7:56, 10:26, 12:09), sempre sobre falas longas de dor ou de mecanismo do cérebro.

## Transições
- Light leak + `Camera Shutter Click 12` como no emagrecimento (136 light leaks).
- **Mergulho no preto** (`fade_preto`): a tela escurece em 0,5 s e volta em 0,83 s. Usado ao entrar numa sequência dramática (Memopower: 0:26, 0:43, 0:57, 5:16, 7:02, 10:44, 11:37, 12:51, 13:07).
- Zoom suave no apresentador como no emagrecimento.

## Música (arco dramático)
1. Gancho (0–1:39): `G:\EDIÇÃO\Musicas\Musicas Storytelling\Novas\Cinematic Action Trailer by Infraction [No Copyright Music]  Skylight - 128.mp3`
2. Dor/problema (1:39–5:00): `G:\EDIÇÃO\Musicas\Musicas Storytelling\Dramatic Strings The Epic and Sad Violin Solo Dead Strings Vol 7.mp3` (violino triste)
3. Solução/mecanismo (4:56–8:33): `G:\EDIÇÃO\Musicas\Musicas Storytelling\Inspiring & Uplifting Cinematic Background Music For Videos.mp3`
4. Oferta até o fim (8:37–14:16): `freepik-worlds-apart.mp3` (baixado do Freepik; não está no G:\EDIÇÃO. Se faltar, use Gemini/Skylight da Infraction).

## SFX (Memopower)
| Som | Onde | Arquivo |
|---|---|---|
| Boom 1 | cada LT dramática e virada forte (13×) | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Hits - impacts\Boom 1.mp3` |
| Acute Whoosh | antes de virada de bloco (3×) | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Risers\Acute Whoosh.mp3` |
| Riser + Woosh 02 | primeiro insert / início da oferta | `G:\EDIÇÃO\Copied_TESTE EDIÇÃO\Riser.wav`, `Woosh 02.mp3` |
| Swoosh Transition 28 | entrada de cada tela de preço | pack do Animation Composer (projeto) |
| Cash | preço aparece (5×) | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Diversos\Cash.wav` |
| Notification t1_03 | selo de garantia | `G:\EFEITOS VERSAO NOVA\Copied_Efeitos praticos\Notification t1_03.wav` |
| SFX - Swoosh 08 | zoom suave | `G:\EFEITOS VERSAO NOVA\Copied_Efeitos praticos\SFX - Swoosh 08.mp3` |

## Legenda PT no topo
O Memopower entregue tem a tradução em PT-BR no topo (mono amarelo em caixa escura). É só para acompanhamento do usuário: pergunte se deve ir no vídeo final (`--sem-topo` tira).
