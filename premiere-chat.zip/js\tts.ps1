# Fala um texto com as vozes do próprio Windows (grátis, sem internet).
# Uso:  tts.ps1 -List                      -> lista as vozes (uma por linha)
#       tts.ps1 -TextFile x.txt [-Voice "onecore:Microsoft Daniel"] [-Rate 0]
# As vozes "onecore:" são as do Windows 10/11 (Daniel, Maria...); as outras são as SAPI clássicas.
param([string]$Voice = "", [int]$Rate = 0, [string]$TextFile = "", [switch]$List)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [Text.Encoding]::UTF8

function OneCoreVoices {
    try {
        $null = [Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType = WindowsRuntime]
        return [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices
    } catch { return @() }
}

if ($List) {
    foreach ($v in OneCoreVoices) { "onecore:" + $v.DisplayName + "|" + $v.Language }
    Add-Type -AssemblyName System.Speech
    $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
    foreach ($v in $s.GetInstalledVoices()) { if ($v.Enabled) { $v.VoiceInfo.Name + "|" + $v.VoiceInfo.Culture.Name } }
    exit 0
}

$text = [IO.File]::ReadAllText($TextFile, [Text.Encoding]::UTF8)
if (-not $text.Trim()) { exit 0 }

if ($Voice -like "onecore:*") {
    $name = $Voice.Substring(8)
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $synth = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
    $v = OneCoreVoices | Where-Object { $_.DisplayName -eq $name } | Select-Object -First 1
    if ($v) { $synth.Voice = $v }
    # Rate -5..5 -> velocidade 0,6x..1,6x
    $synth.Options.SpeakingRate = [Math]::Max(0.5, [Math]::Min(3.0, 1.0 + $Rate * 0.12))
    $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    } | Select-Object -First 1
    $task = $asTask.MakeGenericMethod([Windows.Media.SpeechSynthesis.SpeechSynthesisStream]).Invoke($null, @($synth.SynthesizeTextToStreamAsync($text)))
    $task.Wait()
    $stream = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($task.Result)
    $player = New-Object System.Media.SoundPlayer $stream
    $player.PlaySync()
} else {
    Add-Type -AssemblyName System.Speech
    $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
    if ($Voice) { try { $s.SelectVoice($Voice) } catch {} }
    $s.Rate = [Math]::Max(-10, [Math]::Min(10, $Rate * 2))
    $s.SetOutputToDefaultAudioDevice()
    $s.Speak($text)
}
