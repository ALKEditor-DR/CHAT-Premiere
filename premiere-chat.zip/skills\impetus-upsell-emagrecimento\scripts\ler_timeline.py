"""Lê os cortes de uma sequência do .prproj: por faixa, [inicio, fim, arquivo, entrada_no_arquivo] e transições.

python ler_timeline.py projeto.prproj <indice_da_sequencia> saida.json
"""
import gzip
import json
import sys
import xml.etree.ElementTree as ET

TK = 254016000000
root = ET.fromstring(gzip.open(sys.argv[1]).read())
byid = {e.attrib["ObjectID"]: e for e in root.iter() if "ObjectID" in e.attrib}
uid = {e.attrib["ObjectUID"]: e for e in root.iter() if "ObjectUID" in e.attrib}


def ref(e):
    if e is None:
        return None
    if "ObjectRef" in e.attrib:
        return byid.get(e.attrib["ObjectRef"])
    if "ObjectURef" in e.attrib:
        return uid.get(e.attrib["ObjectURef"])
    return e


def caminho_midia(clip):
    src = ref(clip.find("Clip/Source"))
    for e in src.iter() if src is not None else []:
        r = ref(e) if ("ObjectRef" in e.attrib or "ObjectURef" in e.attrib) else None
        if r is not None and r.tag == "Media":
            return r.findtext("ActualMediaFilePath") or r.findtext("FilePath")
    for e in src.iter():
        if e.tag in ("ActualMediaFilePath", "FilePath") and e.text:
            return e.text
    return None


seqs = [x for x in root.iter("Sequence") if x.findtext("Name")]
seq = seqs[int(sys.argv[2])]
out = {"nome": seq.findtext("Name"), "faixas": {}}
for t in seq.find("TrackGroups"):
    g = ref(t.find("Second"))
    if g is None or g.tag not in ("VideoTrackGroup", "AudioTrackGroup"):
        continue
    k = g.tag[0]
    for i, tt in enumerate(g.find(".//Tracks")):
        tr = ref(tt)
        r = tr.find("ClipTrack/ClipItems/TrackItems")
        itens, trans = [], []
        for it in (r if r is not None else []):
            ti = ref(it)
            if ti is None or "ClipTrackItem" not in ti.tag:
                continue
            c = ti.find("ClipTrackItem")
            ts = c.find("TrackItem")
            sc = ref(c.find("SubClip"))
            cl = ref(sc.find("Clip"))
            s, e = int(ts.findtext("Start") or 0) / TK, int(ts.findtext("End") or 0) / TK
            ip = int(cl.findtext("Clip/InPoint") or 0) / TK
            itens.append([round(s, 4), round(e, 4), sc.findtext("Name"), round(ip, 4), caminho_midia(cl)])
        tt2 = tr.find("ClipTrack/TransitionItems/TrackItems")
        for it in (tt2 if tt2 is not None else []):
            x = ref(it)
            q = x.find("TransitionTrackItem/TrackItem")
            trans.append([int(q.findtext("Start") or 0) / TK, int(q.findtext("End") or 0) / TK, x.findtext("TransitionTrackItem/DisplayName")])
        if itens:
            out["faixas"][f"{k}{i + 1}"] = {"itens": itens, "transicoes": trans}
json.dump(out, open(sys.argv[3], "w", encoding="utf-8"), ensure_ascii=False, indent=0)
for k, v in out["faixas"].items():
    print(k, len(v["itens"]), "itens", len(v["transicoes"]), "transições", v["itens"][0], v["itens"][-1][:4])
