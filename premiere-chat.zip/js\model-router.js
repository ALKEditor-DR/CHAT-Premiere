/*
 * Escolha automática do modelo por pedido:
 * - Opus (esforço médio): planejar edição completa, skill de cliente, edição pela copy, montagem com motions/b-roll.
 *   A execução do plano vai para a IA de cada etapa (etapas.js).
 * - Opus (esforço alto): estudo do estilo da pessoa e criação ou melhoria de skill.
 * - Haiku: comando curto e simples (marcador, mutar, travar, ir para um ponto...), falado ou digitado.
 * - Sonnet: todo o resto (organizar, legenda, decupagem, ajustes).
 */
(function () {
  "use strict";

  const norm = (s) =>
    String(s || "")
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase();

  // Pedidos grandes: vários passos, skill, criação de motion ou montagem.
  const HEAVY = [
    /\bskill\b/,
    /\bpadrao (do|da|de)\b/,
    /\bno estilo\b/,
    /\b(edit|edic|monte|montar|monta|finaliz)\w*\b.*\b(video|reels|lead|vsl|upsell|up\b|anuncio|projeto|timeline|sequencia|copy|roteiro|completo|inteiro)/,
    /\bdo comeco ao fim\b|\bde ponta a ponta\b|\bcompleto\b|\binteir[oa]\b/,
    /\b(pela|com base na|seguindo a) (copy|roteiro)\b|\bcorte pela copy\b|\bmonte a estrutura\b/,
    /\bdopamin|\bimpetus\b|\bupsell\b|\blead\b|\bvsl\b/,
    /\bb-?roll|\binserts?\b.*\b(todo|toda|80|%|transcric)/,
    /\bmotion|\blower third\b|\b(lt|lts)\b|\bvinheta\b|\btransic|\bhyperframes\b|\bremotion\b|\banima/,
    /\b(render|renderiz)/,
  ];

  // Pensar a fundo: só aqui vale o esforço alto.
  const LEARN = [
    // Estudo de estilo e aprendizado (só quando o assunto é esse: "analisa a legenda" continua no dia a dia).
    /\b(analis|estud|aprend|entend|mape|copi|replic)\w*\b.*\b(estilo|padrao|jeito|ritmo|identidade|referencias?)\b/,
    /\b(analis|estud|aprend|entend|mape)\w*\b.*\bcomo (eu |a gente |nos )?(edit|cort|mont|sonoriz|legend|decup)\w*/,
    /\b(aprend[ae]|aprender|aprenda)\b.*\b(com|meus?|minhas?|versao|projetos?|correc\w*)\b/,
    /\b(aprimor|melhor|atualiz|refin|cri)\w*\b.*\b(skills|(o )?que (voce )?aprendeu|aprendizado|meu estilo)\b/,
  ];

  // Comandos curtos e diretos (bons para o Haiku).
  const QUICK = [
    /\bmarcador/,
    /\b(muta|mute|desmuta|silencia)\b/,
    /\b(trava|destrava|bloqueia|desbloqueia)\b/,
    /\b(vai|va|leva|pula)\b.*\b(para|pro|pra|ao|ate)\b/,
    /\bagulha\b|\bplayhead\b/,
    /\b(seleciona|selecione|desseleciona)\b/,
    /\b(renomeia|renomeie)\b/,
    /\b(esconde|mostra|oculta|ativa|desativa)\b.*\b(trilha|faixa|clipe)\b/,
    /\b(zoom|aproxima|afasta)\b/,
    /\b(volume|aumenta|abaixa|diminui)\b/,
  ];

  // Com isto no meio, não é comando solto: fala de algo da edição ou do que já foi conversado.
  const NOT_QUICK = /\b(legenda|texto|titulo|fonte|insert|transic|efeito|motion|card|cartao|musica|trilha sonora|sfx|iss[oa]|ess[ea]s?|aquel[ea]s?|voce|ultim[oa]|anterior|mesm[oa]|assunto|moment|transcri|fal[ae]|frase|cada|conforme|quando|onde)/;

  function isQuick(text) {
    const t = norm(text);
    const words = t.split(/\s+/).filter(Boolean).length;
    return words > 0 && words <= 14 && QUICK.some((r) => r.test(t)) && !NOT_QUICK.test(t) && !HEAVY.some((r) => r.test(t)) && !LEARN.some((r) => r.test(t));
  }

  /*
   * -> { stage, model, effort, label }
   * ctx: { text, hasSkill, hasDocs (copy/pdf/docx anexado), byVoice, effort (o do usuário) }
   */
  function pick(ctx) {
    const t = norm(ctx.text);
    const userEffort = ctx.effort || "";
    const E = (typeof window !== "undefined" && window.Etapas) || null;
    const ai = (stage, def) => {
      const on = ctx.settings && ctx.settings.stagesOn !== false;
      // "A mesma da conversa": segue a IA do planejamento.
      const v = on && E ? E.aiFor(stage, ctx.settings) || E.aiFor("planejar", ctx.settings) : def;
      const [model, effort] = v.split("|");
      return { stage, model, effort: model === "haiku" ? "" : userEffort || effort || "" };
    };
    if (LEARN.some((r) => r.test(t))) return { stage: "planejar", model: "opus", effort: userEffort || "high", label: "estudo e aprendizado", deep: true };
    if (ctx.hasSkill || ctx.hasDocs || HEAVY.some((r) => r.test(t))) return Object.assign(ai("planejar", "opus|medium"), { label: "planejar a edição" });
    if (!ctx.hasFiles && isQuick(ctx.text)) return Object.assign(ai("rapido", "haiku|"), { label: "comando rápido" });
    return Object.assign(ai("dia", "sonnet|medium"), { label: "dia a dia" });
  }

  const api = { pick, isQuick };
  if (typeof window !== "undefined") window.ModelRouter = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
