/*
 * Escolha automática do modelo por pedido:
 * - Opus (esforço alto): edição completa, skill de cliente, edição pela copy, montagem com motions/b-roll.
 * - Haiku: comando curto e simples falado (marcador, mutar, travar, ir para um ponto...).
 * - Sonnet: todo o resto (organizar, legenda, decupagem, ajustes).
 */
(function () {
  "use strict";

  const norm = (s) =>
    String(s || "")
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase();

  // Pedidos grandes: vários passos, skill, criação de motion ou montagem.
  const HEAVY = [
    /\bskill\b/,
    /\bpadrao (do|da|de)\b/,
    /\bno estilo\b/,
    /\b(edit|edic|monte|montar|monta|finaliz)\w*\b.*\b(video|reels|lead|vsl|upsell|up\b|anuncio|projeto|timeline|sequencia|copy|roteiro|completo|inteiro)/,
    /\bdo comeco ao fim\b|\bde ponta a ponta\b|\bcompleto\b|\binteir[oa]\b/,
    /\b(pela|com base na|seguindo a) (copy|roteiro)\b|\bcorte pela copy\b|\bmonte a estrutura\b/,
    /\bdopamin|\bjesue\b|\bimpetus\b|\bupsell\b|\blead\b|\bvsl\b/,
    /\bb-?roll|\binserts?\b.*\b(todo|toda|80|%|transcric)/,
    /\bmotion|\blower third\b|\b(lt|lts)\b|\bvinheta\b|\btransic|\bhyperframes\b|\bremotion\b|\banima/,
    /\b(render|renderiz)/,
  ];

  // Comandos curtos e diretos (bons para o Haiku quando vêm pela voz).
  const QUICK = [
    /\bmarcador/,
    /\b(muta|mute|desmuta|silencia)\b/,
    /\b(trava|destrava|bloqueia|desbloqueia)\b/,
    /\b(vai|va|leva|pula)\b.*\b(para|pro|pra|ao|ate)\b/,
    /\bagulha\b|\bplayhead\b/,
    /\b(seleciona|selecione|desseleciona)\b/,
    /\b(renomeia|renomeie)\b/,
    /\b(esconde|mostra|oculta|ativa|desativa)\b.*\b(trilha|faixa|clipe)\b/,
    /\b(zoom|aproxima|afasta)\b/,
    /\b(volume|aumenta|abaixa|diminui)\b/,
  ];

  /*
   * -> { model, effort, label }
   * ctx: { text, hasSkill, hasDocs (copy/pdf/docx anexado), byVoice, effort (o do usuário) }
   */
  function pick(ctx) {
    const t = norm(ctx.text);
    const userEffort = ctx.effort || "";
    if (ctx.hasSkill || ctx.hasDocs || HEAVY.some((r) => r.test(t))) {
      return { model: "opus", effort: userEffort || "high", label: "Opus · edição grande" };
    }
    const words = t.split(/\s+/).filter(Boolean).length;
    if (ctx.byVoice && words <= 14 && QUICK.some((r) => r.test(t))) {
      return { model: "haiku", effort: userEffort, label: "Haiku · comando rápido" };
    }
    return { model: "sonnet", effort: userEffort, label: "Sonnet · dia a dia" };
  }

  const api = { pick };
  if (typeof window !== "undefined") window.ModelRouter = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
