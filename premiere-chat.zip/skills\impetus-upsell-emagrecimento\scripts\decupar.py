#!/usr/bin/env python
"""Etapa 1: decupa os brutos do upsell e monta a fala na ordem.

python decupar.py "<pasta mãe>" [--idioma fr] [--pausa 0.22] [--so-mapa]

- Ordem: número no início do nome do arquivo em Brutas (1, 2, 3...).
- Corta todo silêncio maior que --pausa (padrão 0,22 s), deixando 0,10 s depois da fala e o resto antes.
  O corte é feito pela energia do áudio, então nenhuma sílaba é perdida.
- Enquadra cada bruto em 4:5 (1080x1350, 24 qps). Vertical 9:16: janela a partir de y=150 (cabeças no terço de cima).
  Outros tamanhos: janela centralizada.
- Transcreve cada bruto (cache em _projeto/transc) e leva as palavras para o tempo do decupado.

Saída em <pasta mãe>/_projeto:
  decupado.mp4     fala inteira já cortada, 1080x1350, com áudio
  segmentos.json   cada pedaço: bruto, entrada/saída no bruto, entrada/saída no decupado, quem fala
  palavras.json    [inicio, fim, palavra, bruto] no tempo do decupado
  avisos.txt       frases repetidas (possível regravação) e palavras com baixa confiança
"""
import glob
import json
import os
import re
import subprocess
import sys

import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
MAE = sys.argv[1]
ARGS = sys.argv[2:]
def arg(n, d):
    return type(d)(ARGS[ARGS.index(n) + 1]) if n in ARGS else d
IDIOMA = arg("--idioma", "fr")
PAUSA = arg("--pausa", 0.22)
DEPOIS = 0.10
FPS, W, H = 24, 1080, 1350
Y_VERTICAL = 150
PROJ = os.path.join(MAE, "_projeto")
os.makedirs(os.path.join(PROJ, "transc"), exist_ok=True)

brutos = sorted(glob.glob(os.path.join(MAE, "Brutas", "*.mp4")) + glob.glob(os.path.join(MAE, "Brutas", "*.mov")),
                key=lambda f: int(re.match(r"\s*(\d+)", os.path.basename(f)).group(1)))
print("ORDEM:")
for b in brutos:
    print("  ", os.path.basename(b))


def orador(nome):
    n = nome.upper()
    if "TEMOIGNAGE" in n or "DEPOIMENTO" in n or "TESTIMON" in n:
        return "depoimento"
    for k in ("LISA", "LUCILE"):
        if k in n:
            return k.lower()
    return "?"


def audio(f, sr=16000):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", f, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], stdout=subprocess.PIPE)
    return np.frombuffer(r.stdout, np.float32)


def info(f):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:format=duration",
                        "-of", "json", f], stdout=subprocess.PIPE)
    j = json.loads(r.stdout)
    return j["streams"][0]["width"], j["streams"][0]["height"], float(j["format"]["duration"])


def transcrever(f):
    cache = os.path.join(PROJ, "transc", os.path.basename(f) + ".json")
    if os.path.exists(cache):
        return json.load(open(cache, encoding="utf-8"))
    from faster_whisper import WhisperModel
    global MODELO
    if "MODELO" not in globals():
        MODELO = WhisperModel("medium", device="cpu", compute_type="int8", cpu_threads=8)
    segs, _ = MODELO.transcribe(f, language=IDIOMA, word_timestamps=True, vad_filter=False)
    out = [[w.start, w.end, w.word.strip(), w.probability] for s in segs for w in s.words]
    json.dump(out, open(cache, "w", encoding="utf-8"), ensure_ascii=False)
    return out


def trechos_de_fala(a, sr, dur):
    """Intervalos com fala, pela energia em janelas de 10 ms. Silêncio = 28 dB abaixo do nível da fala."""
    hop = sr // 100
    n = len(a) // hop
    rms = np.sqrt(np.mean(a[: n * hop].reshape(n, hop) ** 2, axis=1) + 1e-12)
    db = 20 * np.log10(rms)
    ref = np.percentile(db, 90)
    fala = db > ref - 28
    # fecha buracos curtos (consoantes surdas)
    k = 6
    idx = np.where(fala)[0]
    if len(idx) == 0:
        return [(0, dur)]
    tr = []
    s = idx[0]
    p = idx[0]
    for i in idx[1:]:
        if i - p > k:
            tr.append((s / 100, (p + 1) / 100))
            s = i
        p = i
    tr.append((s / 100, (p + 1) / 100))
    return tr


def q(t):
    return round(t * FPS) / FPS


segmentos = []
palavras = []
avisos = []
tl = 0.0
for bi, f in enumerate(brutos):
    nome = os.path.basename(f)
    w, h, dur = info(f)
    a = audio(f)
    fala = trechos_de_fala(a, 16000, dur)
    # junta trechos separados por silêncio <= PAUSA
    blocos = []
    for s, e in fala:
        if blocos and s - blocos[-1][1] <= PAUSA:
            blocos[-1][1] = e
        else:
            blocos.append([s, e])
    antes = PAUSA - DEPOIS
    for s, e in blocos:
        i0 = q(max(0.0, s - antes))
        i1 = q(min(dur, e + DEPOIS))
        if segmentos and segmentos[-1]["bruto"] == nome and i0 < segmentos[-1]["src_out"]:
            i0 = segmentos[-1]["src_out"]
        if i1 - i0 < 1 / FPS:
            continue
        segmentos.append({"bruto": nome, "orador": orador(nome), "src_in": i0, "src_out": i1,
                          "tl_in": round(tl, 4), "tl_out": round(tl + i1 - i0, 4), "w": w, "h": h})
        tl += i1 - i0
    # palavras
    ws = transcrever(f)
    segs_b = [s for s in segmentos if s["bruto"] == nome]
    for (s, e, txt, pr) in ws:
        c = (s + e) / 2
        alvo = min(segs_b, key=lambda g: 0 if g["src_in"] <= c <= g["src_out"] else min(abs(c - g["src_in"]), abs(c - g["src_out"])))
        d = alvo["tl_in"] - alvo["src_in"]
        s2 = min(max(s, alvo["src_in"]), alvo["src_out"]) + d
        e2 = min(max(e, alvo["src_in"]), alvo["src_out"]) + d
        palavras.append([round(s2, 3), round(max(e2, s2 + 0.05), 3), txt, nome])
        if pr < 0.5:
            avisos.append(f"baixa confiança: '{txt}' em {s2:.2f}s ({nome})")
    texto = " ".join(x[2] for x in ws)
    frases = [x.strip().lower() for x in re.split(r"[.!?]", texto) if len(x.split()) >= 4]
    for i in range(len(frases) - 1):
        if frases[i] == frases[i + 1]:
            avisos.append(f"frase repetida em {nome}: '{frases[i]}' (regravação?)")
    print(f"{nome}: {dur:.2f}s -> {sum(s['src_out'] - s['src_in'] for s in segs_b):.2f}s em {len(segs_b)} pedaços")

json.dump(segmentos, open(os.path.join(PROJ, "segmentos.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
# junta pedaços que o Whisper separa: elisões ("s" + "'il"), hífens ("Laissez" + "-moi") e "100" + "%"
juntas = []
for p in palavras:
    t = p[2]
    if juntas and juntas[-1][3] == p[3] and (t[:1] in "'’-%" and len(t) > 0) and p[0] - juntas[-1][1] < 0.6:
        juntas[-1][2] += t
        juntas[-1][1] = p[1]
    else:
        juntas.append(list(p))
palavras = juntas
json.dump(palavras, open(os.path.join(PROJ, "palavras.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
open(os.path.join(PROJ, "avisos.txt"), "w", encoding="utf-8").write("\n".join(avisos))
print(f"TOTAL: {tl:.2f}s, {len(segmentos)} pedaços, {len(palavras)} palavras, {len(avisos)} avisos")
if "--so-mapa" in ARGS:
    sys.exit()

# monta o decupado: o vídeo de cada pedaço vira um arquivo curto e o áudio vira um .wav separado com o número EXATO de
# amostras (quadros x 2000 a 48 kHz). Antes o áudio ia dentro do mesmo arquivo e o "-frames:v" fechava o arquivo alguns
# milésimos antes do fim do áudio: cada pedaço perdia ~20 ms de som e, somados, a voz ficava até 0,45 s fora da boca.
# Pedaço que termina no fim do bruto (ou bruto com quadro faltando) repete o último quadro para ter sempre n quadros;
# se faltasse 1 quadro, todo o vídeo depois dele adiantaria 42 ms em relação à voz.
# Pedaço de vídeo que já existe com o número certo de quadros é reaproveitado.
tmp = os.path.join(PROJ, "pedacos")
os.makedirs(tmp, exist_ok=True)
lista_v, lista_a = [], []
SR = 48000
for i, s in enumerate(segmentos):
    src = os.path.join(MAE, "Brutas", s["bruto"])
    if s["h"] / s["w"] > 1.6:
        crop = f"crop={s['w']}:{int(s['w'] * H / W)}:0:{Y_VERTICAL * s['w'] // 1080}"
    else:
        ch = min(s["h"], int(s["w"] * H / W))
        crop = f"crop={int(ch * W / H)}:{ch}:(iw-ow)/2:(ih-oh)/2"
    n = round((s["src_out"] - s["src_in"]) * FPS)
    d = n / FPS
    vid = os.path.join(tmp, f"p{i:04d}.mov")
    wav = os.path.join(tmp, f"p{i:04d}.wav")
    lista_v.append(vid)
    lista_a.append(wav)
    feito = os.path.exists(vid) and subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries", "stream=nb_frames", "-of", "csv=p=0", vid],
        stdout=subprocess.PIPE, text=True).stdout.strip() == str(n)
    if not feito:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{s['src_in']:.4f}", "-t", f"{d + 0.1:.4f}", "-i", src, "-an",
                        "-vf", f"fps={FPS},{crop},scale={W}:{H}:flags=lanczos,setsar=1,tpad=stop_mode=clone:stop={n}", "-frames:v", str(n),
                        "-c:v", "libx264", "-preset", "fast", "-crf", "14", "-pix_fmt", "yuv420p", vid], check=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{s['src_in']:.4f}", "-i", src, "-t", f"{d + 0.2:.4f}", "-vn",
                    "-af", f"aresample={SR},afade=t=in:d=0.008,afade=t=out:st={max(0, d - 0.012):.4f}:d=0.012,apad,"
                           f"atrim=end_sample={n * SR // FPS}",
                    "-ac", "1", "-c:a", "pcm_s16le", wav], check=True)
for nome, lst in (("lista.txt", lista_v), ("lista_audio.txt", lista_a)):
    with open(os.path.join(tmp, nome), "w", encoding="utf-8") as fl:
        for p in lst:
            fl.write(f"file '{p.replace(chr(92), '/')}'\n")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", os.path.join(tmp, "lista.txt"),
                "-f", "concat", "-safe", "0", "-i", os.path.join(tmp, "lista_audio.txt"), "-map", "0:v", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", os.path.join(PROJ, "decupado.mp4")], check=True)
print("OK:", os.path.join(PROJ, "decupado.mp4"))
