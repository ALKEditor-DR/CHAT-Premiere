// impetus-upsell-up3 - biblioteca de montagem (ExtendScript ES3, painel Premiere Chat)
// Uso: $.evalFile(".../scripts/lib.jsx"); $.evalFile(".../plano.jsx"); depois M.<passo>()
// O plano define: U, BROLL, CARDS, P3D, OFERTA, NEON, ZOOMS, CUTS, LEAKS, BGNP, MARCADORES, TRILHAS, CYMBAL_FIM, BOOM, DING, SWOOSH, CASH
var L = {};
L.seq = function () { return app.project.activeSequence; };
L.cache = null;
L.index = function () {
  if (L.cache) return L.cache;
  var m = {};
  PPC.walk(function (it, parent, path) {
    if (PPC.kind(it) == 'bin') return;
    if (!m[it.name]) m[it.name] = [];
    var mp = ''; try { mp = it.getMediaPath(); } catch (e) {}
    m[it.name].push({ it: it, path: (path || ''), mp: mp });
  });
  L.cache = m; return m;
};
L.find = function (name) { var a = L.index()[name]; return a ? a[0].it : null; };
L.byPath = function (p) {
  var m = L.index();
  for (var k in m) { var a = m[k]; for (var i = 0; i < a.length; i++) { if (a[i].mp && a[i].mp.toLowerCase() == p.toLowerCase()) return a[i].it; } }
  var bin = PPC.bin("UP3/Importados", true);
  app.project.importFiles([p], true, bin, false); L.cache = null;
  for (var j = 0; j < bin.children.numItems; j++) { var c = bin.children[j]; try { if (c.getMediaPath().toLowerCase() == p.toLowerCase()) return c; } catch (e) {} }
  return null;
};
L.ref = function (r) {
  if (r.indexOf("n:") == 0) return L.find(r.substr(2));
  if (r.indexOf("U:") == 0) return L.byPath(U + r.substr(2));
  return L.byPath(r);
};
L.dims = function (it) {
  try { var m = it.getProjectMetadata().match(/VideoInfo>([0-9]+) x ([0-9]+)/); if (m) return [parseInt(m[1], 10), parseInt(m[2], 10)]; } catch (e) {}
  return null;
};
L.fill = function (it) {
  var s = L.seq(); var d = L.dims(it); if (!d) return 100;
  return Math.max(s.frameSizeHorizontal / d[0], s.frameSizeVertical / d[1]) * 100;
};
L.clipAt = function (track, start) {
  for (var i = 0; i < track.clips.numItems; i++) { var c = track.clips[i]; if (Math.abs(c.start.seconds - start) < 0.03) return c; }
  return null;
};
L.qeClipAt = function (isVideo, ti, start) {
  app.enableQE(); var qs = qe.project.getActiveSequence();
  var tr = isVideo ? qs.getVideoTrackAt(ti) : qs.getAudioTrackAt(ti);
  for (var i = 0; i < tr.numItems; i++) { var q = tr.getItemAt(i); if (!q || q.type == 'Empty') continue; if (Math.abs(q.start.secs - start) < 0.03) return q; }
  return null;
};
// coloca item na faixa ti (0 = V1/A1) em start, duração dur, a partir de inS (s) da mídia
L.place = function (ti, it, start, dur, inS, video) {
  var s = L.seq(); if (video === undefined) video = true;
  var k = PPC.kind(it); var still = (k == 'image' || k == 'synthetic' || k == 'graphic');
  if (!still) { it.setInPoint(inS || 0, 4); it.setOutPoint((inS || 0) + dur, 4); }
  var tr = video ? s.videoTracks[ti] : s.audioTracks[ti];
  tr.overwriteClip(it, start);
  if (!still) { it.clearInPoint(); it.clearOutPoint(); }
  var c = L.clipAt(tr, start);
  if (c && Math.abs(c.end.seconds - (start + dur)) > 0.02) c.end = PPC.time(start + dur);
  return c;
};
L.comp = function (clip, name) { for (var i = 0; i < clip.components.numItems; i++) { var c = clip.components[i]; if (c.displayName == name || c.matchName == name) return c; } return null; };
L.prop = function (comp, name) { for (var i = 0; i < comp.properties.numItems; i++) { if (comp.properties[i].displayName == name) return comp.properties[i]; } return null; };
L.set = function (comp, name, v) { var p = L.prop(comp, name); if (p) { try { p.setValue(v, true); return true; } catch (e) {} } return false; };
// keyframes [[segundos desde o início do clipe, valor], ...]; ease=true tenta bezier
L.keys = function (clip, comp, name, list, ease) {
  var p = L.prop(comp, name); if (!p) return false;
  p.setTimeVarying(true); var base = clip.inPoint.seconds;
  for (var i = 0; i < list.length; i++) { var t = base + list[i][0]; p.addKey(t); p.setValueAtKey(t, list[i][1], true); if (ease) { try { p.setInterpolationTypeAtKey(t, 5, true); } catch (e) {} } }
  return true;
};
// QE insere o efeito no TOPO da pilha: chame na ordem inversa da desejada
L.fx = function (ti, start, name) { var q = L.qeClipAt(true, ti, start); if (!q) return false; q.addVideoEffect(qe.project.getVideoEffectByName(name)); return true; };
L.motion = function (clip, scale, x, y) { var m = L.comp(clip, 'Motion'); if (scale != null) L.set(m, 'Scale', scale); if (x != null) L.set(m, 'Position', [x, y]); return m; };
L.adj = function () { var r = app.project.rootItem; for (var i = 0; i < r.children.numItems; i++) { if (r.children[i].name == "Adjustment Layer") return r.children[i]; } return null; };
L.up1 = function () { for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (q && q.name == "UP 1") return q; } return null; };
L.fromUP1 = function (isVideo, ti, sub) { var u = L.up1(); if (!u) return null; var tr = isVideo ? u.videoTracks[ti] : u.audioTracks[ti]; for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; if (c && c.name.indexOf(sub) >= 0 && c.projectItem) return c.projectItem; } return null; };

// ---- predefinições do usuário replicadas ----
L.blurBG = function (ti, clip) { // "Gaussian Blur + LUMETRI"
  var st = clip.start.seconds; L.fx(ti, st, 'Lumetri Color'); L.fx(ti, st, 'Gaussian Blur (Legacy)');
  var lc = L.comp(clip, 'Lumetri Color'); if (lc) { L.set(lc, 'Exposure', -0.617); L.set(lc, 'Contrast', 29.97); L.set(lc, 'Highlights', -100); L.set(lc, 'Shadows', -51.13); }
  var gb = L.comp(clip, 'Gaussian Blur (Legacy)'); if (gb) { L.set(gb, 'Blurriness', 30); L.set(gb, 'Repeat Edge Pixels', true); }
};
L.borda = function (ti, clip) { // "borda arredondada" (só funciona em sequência aninhada / quadro inteiro)
  L.fx(ti, clip.start.seconds, 'Roughen Edges'); var r = L.comp(clip, 'Roughen Edges');
  if (r) { L.set(r, 'Edge Type', 0); L.set(r, 'Border', 40); L.set(r, 'Edge Sharpness', 10); L.set(r, 'Fractal Influence', 0); L.set(r, 'Complexity', 2); }
};
L.glow = function (ti, clip) { // "01 Wonder Glow Preset"
  L.fx(ti, clip.start.seconds, 'Wonder Glow'); var g = L.comp(clip, 'Wonder Glow');
  if (g) { L.set(g, 'Intensity', 60); L.set(g, 'Highlights Only', 40); L.set(g, 'Size', 50); L.set(g, 'Vibrance', 10); L.set(g, 'Ambient Amount', 20); L.set(g, 'Chromatic Aberration', 10); }
};
L.zoomT = function (ti, clip, a, b, dur, ease) { // Transform Scale Height a -> b
  L.fx(ti, clip.start.seconds, 'Transform'); var t = L.comp(clip, 'Transform'); if (!t) return;
  L.set(t, 'Uniform Scale', true);
  L.keys(clip, t, 'Scale Height', [[0, a], [dur || clip.duration.seconds, b]], ease);
};
// "ZOOM IN 20X" (100->120) / "ZOOM OUT 20X" (120->100), ~9,97 s com ease, como a predefinição
L.zoom20 = function (ti, clip, saida) { L.zoomT(ti, clip, saida ? 120 : 100, saida ? 100 : 120, 9.97, true); };
// "EFEITO 3D" (Basic 3D + Drop Shadow) - NÃO usar em tela de mockup (usuário reprovou). Mantido só se ele pedir.
L.efeito3d = function (ti, clip) {
  var st = clip.start.seconds; L.fx(ti, st, 'Drop Shadow'); L.fx(ti, st, 'Basic 3D');
  var b = L.comp(clip, 'Basic 3D'); var kd = Math.min(clip.duration.seconds, 4.6);
  if (b) { L.keys(clip, b, 'Swivel', [[0, -21], [kd, 8]]); L.keys(clip, b, 'Tilt', [[0, -20], [kd, -15]]); }
  var ds = L.comp(clip, 'Drop Shadow'); if (ds) { L.set(ds, 'Opacity', 100); L.set(ds, 'Direction', -144); L.set(ds, 'Distance', 26); L.set(ds, 'Softness', 114); }
};
L.audio = function (ti, it, start, dur, inS, level) {
  var c = L.place(ti, it, start, dur, inS, false); if (!c || level == null) return c;
  for (var k = 0; k < c.components.numItems; k++) { var p = L.prop(c.components[k], "Level"); if (p) { try { p.setValue(level, true); } catch (e) {} } }
  return c;
};
L.mgtText = function (clip, propName, txt) {
  var m = clip.getMGTComponent(); var p = L.prop(m, propName); if (!p) return false;
  p.setValue(p.getValue().replace(/"textEditValue":"[^"]*"/, '"textEditValue":"' + txt + '"'), true); return true;
};

// ================= PASSOS =================
var M = { log: [] };
M.V = { BROLL: 1, CARD: 2, BLURADJ: 3, DEST: 4, MOGRT: 5, ZOOM: 6, TRA: 7, TRB: 8, LEAK: 9, VIN: 10 };
M.prepararCopia = function () {
  var s = L.seq(); var before = {}; for (var i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = 1;
  s.clone(); var ns = null; for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (!before[q.sequenceID]) ns = q; }
  ns.name = s.name + " - MONTADA"; app.project.openSequence(ns.sequenceID); app.project.activeSequence = ns;
  app.enableQE(); var qs = qe.project.getActiveSequence();
  var nv = ns.videoTracks.numTracks, na = ns.audioTracks.numTracks;
  qs.addTracks(Math.max(0, 12 - nv), nv, Math.max(0, 8 - na), 1, na);
  return ns.name;
};
M.brollItem = function (a, b, nome, inS) { var it = L.find(nome) || L.ref(nome); if (!it) { M.log.push("FALTA " + nome); return; } var c = L.place(M.V.BROLL, it, a, b - a, inS); if (c) L.motion(c, L.fill(it)); };
M.broll = function (from, to) {
  for (var i = from; i < to && i < BROLL.length; i++) {
    var e = BROLL[i]; var it = L.ref(e[2]); if (!it) { M.log.push("FALTA " + e[2]); continue; }
    var c = L.place(M.V.BROLL, it, e[0], e[1] - e[0], e[3]); if (c) L.motion(c, L.fill(it)); else M.log.push("nao colocou " + e[2]);
  }
  return M.log.join("; ");
};
// cartões: clona uma aninhada 4:5 do UP 1 (padrão "Nested Sequence 01"), esvazia e preenche
M.cartoes = function (modelo) {
  var main = L.seq(); var src = null; modelo = modelo || "Nested Sequence 01";
  for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (q && q.name == modelo) src = q; }
  var bin = PPC.bin("UP3/Cartoes", true); var vig = L.fromUP1(true, 4, "VERTICAL");
  for (var k = 0; k < CARDS.length; k++) {
    var before = {}; for (var i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = 1;
    src.clone(); var ns = null; for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (!before[q.sequenceID]) ns = q; }
    ns.name = "Cartao " + (k + 1);
    for (var t = 0; t < ns.videoTracks.numTracks; t++) { var vt = ns.videoTracks[t]; for (var j = vt.clips.numItems - 1; j >= 0; j--) vt.clips[j].remove(false, false); }
    for (var t = 0; t < ns.audioTracks.numTracks; t++) { var at = ns.audioTracks[t]; for (var j = at.clips.numItems - 1; j >= 0; j--) at.clips[j].remove(false, false); }
    var c0 = CARDS[k][0], its = CARDS[k][2], tr = ns.videoTracks[0];
    for (var j = 0; j < its.length; j++) {
      var e = its[j]; var it = L.ref(e[2]); if (!it) { M.log.push("falta " + e[2]); continue; }
      it.setInPoint(e[3], 4); it.setOutPoint(e[3] + (e[1] - e[0]), 4); tr.overwriteClip(it, e[0] - c0); it.clearInPoint(); it.clearOutPoint();
      var cc = L.clipAt(tr, e[0] - c0); if (cc) L.set(L.comp(cc, 'Motion'), 'Scale', L.fill(it));
    }
    var pi = null; PPC.walk(function (x) { if (x.name == ns.name && PPC.kind(x) == 'sequence') { pi = x; return true; } }); if (pi) pi.moveBin(bin);
    app.project.activeSequence = main;
    var s0 = CARDS[k][0], d = CARDS[k][1] - CARDS[k][0];
    var bg = L.place(M.V.BROLL, pi, s0, d, 0); if (bg) L.blurBG(M.V.BROLL, bg);
    var cd = L.place(M.V.CARD, pi, s0, d, 0); if (cd) { L.motion(cd, 79); L.zoomT(M.V.CARD, cd, 100, 110); L.borda(M.V.CARD, cd); }
    if (vig) { var vv = L.place(M.V.ZOOM, vig, s0, d, 0); if (vv) { L.motion(vv, 148.5185); L.fx(M.V.ZOOM, s0, 'Vignette'); var vc = L.comp(vv, 'Vignette'); if (vc) { L.set(vc, 'Scale', 130); L.set(vc, 'Feather', 65); } } }
  }
  return M.log.join("; ");
};
// telas de produto: fundo em V2, mockup PNG em V3 com ZOOM IN/OUT 20X alternado
M.telasProduto = function () {
  for (var k = 0; k < P3D.length; k++) {
    var e = P3D[k], d = e[1] - e[0]; var bgi = L.ref(e[4]), png = L.ref(e[2]); if (!bgi || !png) { M.log.push("falta " + e[2]); continue; }
    var bg = L.place(M.V.BROLL, bgi, e[0], d, e[5]); if (bg) { L.motion(bg, L.fill(bgi)); if (e[6]) L.blurBG(M.V.BROLL, bg); }
    var pc = L.place(M.V.CARD, png, e[0], d, 0); if (pc) { L.motion(pc, e[3], 0.5, 0.6); L.zoom20(M.V.CARD, pc, k % 2 == 1); }
  }
  return M.log.join("; ");
};
M.ofertas = function () {
  for (var k = 0; k < OFERTA.length; k++) {
    var e = OFERTA[k], d = e[1] - e[0]; var bgi = L.ref(BGNP), png = L.ref(e[2]); if (!png) { M.log.push("falta " + e[2]); continue; }
    var bg = L.place(M.V.BROLL, bgi, e[0], d, k * 4); if (bg) L.motion(bg, L.fill(bgi));
    var pc = L.place(M.V.CARD, png, e[0], d, 0);
    if (pc) { var sc = e[3]; if (!sc) { var dm = L.dims(png); sc = dm ? Math.min(850 / dm[0], 850 / dm[1]) * 100 : 60; }
      var selo = e[2].indexOf("30days") >= 0; L.motion(pc, sc, 0.5, selo ? 0.5 : 0.6); L.zoom20(M.V.CARD, pc, selo); }
  }
  return M.log.join("; ");
};
M.neons = function () {
  var b = PPC.bin("Motion Graphics Template Media", false); var neon = null; for (var i = 0; i < b.children.numItems; i++) if (b.children[i].name.indexOf("Neon") >= 0) neon = b.children[i];
  for (var k = 0; k < NEON.length; k++) {
    var e = NEON[k]; var c = L.place(M.V.MOGRT, neon, e[0], e[1] - e[0], 0); if (!c) continue;
    L.motion(c, 74.259, 0.5, e[3]); L.mgtText(c, "Text", e[2].replace(/€/g, "€"));
    var m = c.getMGTComponent(); var col = L.prop(m, "Text Color"); if (col) col.setColorValue(255, 255, 232, 0, true);
    if (e[2].length > 7) { var ts = L.prop(m, "Text Scale"); if (ts) ts.setValue(210, true); }
  }
};
// destaques: JSON de gerar_destaques.py [{f,s,e,t,g}]
M.destaques = function (jsonPath) {
  var f = new File(jsonPath); f.encoding = "UTF-8"; f.open("r"); var D = eval(f.read()); f.close();
  var bin = PPC.bin("UP3/Motions/Destaques", true); var paths = []; for (var i = 0; i < D.length; i++) paths.push(D[i].f);
  app.project.importFiles(paths, true, bin, false); L.cache = null;
  var byName = {}; for (var i = 0; i < bin.children.numItems; i++) byName[bin.children[i].name] = bin.children[i];
  var grp = {}; for (var i = 0; i < D.length; i++) { var g = D[i].g; if (!grp[g]) grp[g] = [D[i].s, D[i].e]; grp[g][0] = Math.min(grp[g][0], D[i].s); grp[g][1] = Math.max(grp[g][1], D[i].e); }
  var adj = L.adj(); var sc = L.fill(adj);
  for (var g in grp) { var a = L.place(M.V.BLURADJ, adj, grp[g][0], grp[g][1] - grp[g][0]); if (a) { L.motion(a, sc); L.blurBG(M.V.BLURADJ, a); } }
  for (var i = 0; i < D.length; i++) {
    var e = D[i]; var it = byName[e.f.split("\\").pop()]; if (!it) continue;
    var c = L.place(M.V.DEST, it, e.s, e.e - e.s, 0); if (!c) continue;
    L.glow(M.V.DEST, c); L.fx(M.V.DEST, e.s, 'Transform'); var t = L.comp(c, 'Transform'); L.set(t, 'Uniform Scale', true);
    var d = e.e - e.s; L.keys(c, t, 'Scale Height', [[0, 0], [Math.min(0.16, d * 0.4), 100], [d, 118]]);
  }
};
M.zooms = function () {
  var adj = L.adj(), sc = L.fill(adj), riser = L.fromUP1(false, 2, "Riser");
  for (var k = 0; k < ZOOMS.length; k++) {
    var T = ZOOMS[k]; var z = L.place(M.V.ZOOM, adj, T, 1.29);
    if (z) { L.motion(z, sc); L.fx(M.V.ZOOM, T, 'Transform'); var t = L.comp(z, 'Transform'); L.set(t, 'Uniform Scale', true); L.keys(z, t, 'Scale Height', [[0, 153], [0.75, 100]]); L.set(t, "Use Composition's Shutter Angle", false); L.set(t, 'Shutter Angle', 180); }
    if (riser) L.audio(2, riser, T, 0.67, 0, 0.0434);
  }
};
M._par = function (ti, T, nome, dur, frames) {
  var adj = L.adj(), sc = L.fill(adj); var a = L.place(ti, adj, T - dur, dur), b = L.place(ti, adj, T, 0.375);
  if (a) L.motion(a, sc); if (b) L.motion(b, sc);
  var q = L.qeClipAt(true, ti, T - dur); if (q) { try { q.addTransition(qe.project.getVideoTransitionByName(nome), false, "00:00:00:" + (frames < 10 ? "0" : "") + frames, "00:00:00:00", 0.5, false, true); } catch (e) {} }
};
M.transicoes = function () {
  var riser = L.fromUP1(false, 2, "Riser"), pop = L.fromUP1(false, 2, "sound-effect-519"), woosh = L.fromUP1(false, 3, "Woosh 02");
  for (var k = 0; k < CUTS.length; k++) {
    var T = CUTS[k];
    if (k % 3 == 2) { M._par(M.V.TRA, T, "Lens Blur", 0.625, 15); M._par(M.V.TRB, T, "Flash", 0.625, 15); if (riser) L.audio(2, riser, T - 0.3, 0.67, 0, 0.0434); if (woosh) L.audio(3, woosh, T - 0.58, 1.0, 0.083, 0.0397); }
    else { M._par(M.V.TRA, T, "Lens Blur", 0.625, 15); M._par(M.V.TRB, T, "Flash", 0.33, 8); if (pop) L.audio(2, pop, T - 0.62, 0.96, 0.333, 0.1778); }
  }
};
M.leaks = function () {
  var leak = L.fromUP1(true, 9, "Light Leak"), shut = L.fromUP1(false, 2, "Camera Shutter");
  for (var k = 0; k < LEAKS.length; k++) {
    var T = LEAKS[k]; var ab = [L.place(M.V.LEAK, leak, T - 0.375, 0.375), L.place(M.V.LEAK, leak, T, 0.46)];
    for (var j = 0; j < 2; j++) { var c = ab[j]; if (!c) continue; var m = L.comp(c, 'Motion'); L.set(m, 'Uniform Scale', false); L.set(m, 'Scale', 493.78); L.set(m, 'Scale Width', 177.78); }
    if (shut) L.audio(4, shut, T - 0.2, 0.6, 0, 0.1778);
  }
};
M.vinheta = function () {
  var s = L.seq(), END = s.end / 254016000000, vin = L.find("VInheta"); var v = L.place(M.V.VIN, vin, 0, END);
  if (v) { L.motion(v, 148.5185); L.fx(M.V.VIN, 0, 'Lumetri Color'); var lc = L.comp(v, 'Lumetri Color'); if (lc) { L.set(lc, 'Amount', -5); L.set(lc, 'Midpoint', 55); } }
};
M.lt = function (l1, l2) {
  var b = PPC.bin("Motion Graphics Template Media", false); var lt = null; for (var i = 0; i < b.children.numItems; i++) if (b.children[i].name.indexOf("LT_") == 0) lt = b.children[i];
  var c = L.place(M.V.MOGRT, lt, 0, 1.67); if (!c) return;
  L.motion(c, 51.259, 0.418, 0.605); L.mgtText(c, "Text 1", l1); L.mgtText(c, "Text 2", l2); L.mgtText(c, "Text 3", "");
  var lc = L.prop(c.getMGTComponent(), "Line Color"); if (lc) lc.setColorValue(255, 255, 170, 0, true);
  L.fx(M.V.MOGRT, 0, 'Drop Shadow'); var ds = L.comp(c, 'Drop Shadow'); if (ds) { L.set(ds, 'Opacity', 100); L.set(ds, 'Distance', 5); L.set(ds, 'Softness', 37); }
};
M.trilhas = function () {
  var s = L.seq(), END = s.end / 254016000000, LV = 0.0132;
  var fonte = { "epic": L.find("inspire-motivation-epic-2-14997.mp3"), "Inspiring": L.fromUP1(false, 6, "Inspiring"), "TRILHA (7)": L.fromUP1(false, 7, "TRILHA (7)"), "TRILHA (2)": L.fromUP1(false, 6, "TRILHA (2)"), "TRILHA (1)": L.fromUP1(false, 5, "TRILHA (1)") };
  for (var i = 0; i < TRILHAS.length; i++) {
    var e = TRILHAS[i]; var a = e[2], b = e[3] < 0 ? END : e[3]; var c = L.audio(e[0], fonte[e[1]], a, b - a, e[4], LV); if (!c) { M.log.push("trilha " + e[1]); continue; }
    for (var k = 0; k < c.components.numItems; k++) {
      var pr = L.prop(c.components[k], "Level"); if (!pr) continue; pr.setTimeVarying(true); var base = c.inPoint.seconds, d = c.duration.seconds;
      var ks = [[0, 0.0005], [1.5, LV], [d - 2, LV], [d, 0.0005]]; if (a < 0.1) ks = [[0, LV], [d - 2, LV], [d, 0.0005]]; if (b > END - 0.1) ks = [[0, 0.0005], [1.5, LV], [d, LV]];
      for (var q = 0; q < ks.length; q++) { pr.addKey(base + ks[q][0]); pr.setValueAtKey(base + ks[q][0], ks[q][1], true); }
    }
  }
  var cym = L.fromUP1(false, 5, "reverse cymbal"); if (cym) L.audio(5, cym, CYMBAL_FIM - 9.46, 9.46, 0, 0.1778);
};
M.sfxFixos = function () {
  var boom = L.fromUP1(false, 1, "Boom"); if (boom) L.audio(1, boom, BOOM, 6.04, 0, 0.1778);
  var ding = L.fromUP1(false, 2, "Good Idea"); if (ding) L.audio(1, ding, DING, 1.2, 0, 0.151);
  var sw = L.fromUP1(false, 1, "Swoosh"); for (var i = 0; i < SWOOSH.length; i++) if (sw) L.audio(1, sw, SWOOSH[i], 1.25, 0, 0.1778);
  var cash = L.fromUP1(false, 4, "cash"); for (var i = 0; i < CASH.length; i++) if (cash) L.audio(4, cash, CASH[i], 3.46, 0, 0.1778);
};
// B-roll/aninhadas trazem áudio para A2/A3: remova (rodar no fim)
M.limparAudioDeBroll = function () {
  var s = L.seq(), n = 0;
  for (var t = 1; t < s.audioTracks.numTracks; t++) { var tr = s.audioTracks[t]; for (var j = tr.clips.numItems - 1; j >= 0; j--) { var c = tr.clips[j]; var pi = c.projectItem; var k = pi ? PPC.kind(pi) : 'null'; if (k == 'video' || k == 'sequence' || k == 'null') { c.remove(false, false); n++; } } }
  return n;
};
M.marcadores = function (lista) { var s = L.seq(); for (var i = 0; i < lista.length; i++) { var m = s.markers.createMarker(lista[i][0]); m.name = lista[i][1]; } };
M.resumo = function () { var s = L.seq(), r = []; for (var t = 0; t < s.videoTracks.numTracks; t++) r.push("V" + (t + 1) + ":" + s.videoTracks[t].clips.numItems); for (var t = 0; t < s.audioTracks.numTracks; t++) r.push("A" + (t + 1) + ":" + s.audioTracks[t].clips.numItems); return r.join(" ") + (M.log.length ? " | " + M.log.join("; ") : ""); };
