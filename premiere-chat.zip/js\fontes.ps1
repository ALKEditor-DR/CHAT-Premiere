# Lista as fontes instaladas (TrueType e OpenType): uma por linha, "Familia<TAB>400,700,900".
$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
Add-Type -AssemblyName PresentationCore
$en = [Windows.Markup.XmlLanguage]::GetLanguage("en-us")
foreach ($f in [Windows.Media.Fonts]::SystemFontFamilies) {
    $name = $f.FamilyNames[$en]
    if (-not $name) { $name = $f.Source }
    if (-not $name -or $name.StartsWith("@")) { continue }
    $w = @()
    foreach ($t in $f.GetTypefaces()) {
        if ($t.Style.ToString() -eq "Normal" -and -not $t.IsBoldSimulated) { $w += $t.Weight.ToOpenTypeWeight() }
    }
    if (-not $w.Count) { $w = @(400) }
    "$name`t$((($w | Sort-Object -Unique) -join ','))"
}
