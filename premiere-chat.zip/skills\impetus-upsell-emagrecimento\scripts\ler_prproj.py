#!/usr/bin/env python
"""Lê um .prproj do Premiere e lista a timeline: clipes, posição, efeitos, transições e itens desativados.
Serve para aprender o que o usuário mudou no acabamento de cada vídeo.

python ler_prproj.py "projeto.prproj" [--seq 0] > timeline.txt

Itens [DESATIVADO] não aparecem no vídeo exportado; confira sempre antes de copiar um valor.
"""
import gzip
import sys
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
TK = 254016000000
root = ET.fromstring(gzip.open(sys.argv[1]).read())
byid = {e.attrib["ObjectID"]: e for e in root.iter() if "ObjectID" in e.attrib}
uid = {e.attrib["ObjectUID"]: e for e in root.iter() if "ObjectUID" in e.attrib}


def ref(e):
    if e is None:
        return None
    if "ObjectRef" in e.attrib:
        return byid.get(e.attrib["ObjectRef"])
    if "ObjectURef" in e.attrib:
        return uid.get(e.attrib["ObjectURef"])
    return e


CAMPOS = ("Position", "Scale", "Opacity", "Amount", "Midpoint", "Feather", "Exposure", "Blurriness", "Num. Tiles", "Amount of Noise", "Scale Height")


def efeitos(ti):
    co = ti.find("ClipTrackItem/ComponentOwner")
    ch = ref(co.find("Components")) if co is not None else None
    cl = ch.find("ComponentChain/Components") if ch is not None else None
    res = []
    for c0 in (cl if cl is not None else []):
        c = ref(c0)
        if c is None:
            continue
        nome = c.findtext("Component/DisplayName") or c.findtext("DisplayName") or c.tag
        vals = {}
        for p in (c.find("Component/Params") if c.find("Component/Params") is not None else []):
            pp = ref(p)
            if pp is None or not pp.findtext("Name"):
                continue
            sk = pp.findtext("StartKeyframe")
            v = sk.split(",")[1] if sk else pp.findtext("CurrentValue")
            if pp.findtext("IsTimeVarying") == "true" and pp.findtext("Keyframes"):
                ks = [k for k in pp.findtext("Keyframes").split(";") if k]
                v = "KF:" + ";".join(f"{int(k.split(',')[0]) / TK:.2f}={k.split(',')[1][:7]}" for k in ks)[:120]
            if pp.findtext("Name") in CAMPOS and v not in (None, "0.", "100."):
                vals[pp.findtext("Name")] = v[:40]
        res.append(nome + (str(vals) if vals else ""))
    return res


seqs = [x for x in root.iter("Sequence") if x.findtext("Name")]
print("Sequencias:", [s.findtext("Name") for s in seqs])
si = int(sys.argv[sys.argv.index("--seq") + 1]) if "--seq" in sys.argv else 0
grupos = [ref(t.find("Second")) for t in seqs[si].find("TrackGroups")]
for g in grupos:
    if g is None or g.tag not in ("VideoTrackGroup", "AudioTrackGroup"):
        continue
    k = g.tag[0]
    for i, t in enumerate(g.find(".//Tracks")):
        tr = ref(t)
        r = tr.find("ClipTrack/ClipItems/TrackItems")
        if r is None or not len(list(r)):
            continue
        print(f"\n-- {k}{i + 1}")
        for it in r:
            ti = ref(it)
            if ti is None or "ClipTrackItem" not in ti.tag:
                continue
            c = ti.find("ClipTrackItem")
            ts = c.find("TrackItem")
            sc = ref(c.find("SubClip"))
            s, e = int(ts.findtext("Start") or 0) / TK, int(ts.findtext("End") or 0) / TK
            mu = " [DESATIVADO]" if c.findtext("IsMuted") == "true" else ""
            nome = (sc.findtext("Name") if sc is not None else "") or ""
            print(f"  {s:8.2f}-{e:8.2f} {nome[:44]:44}{mu} {efeitos(ti)}")
        tt = tr.find("ClipTrack/TransitionItems/TrackItems")
        for it in (tt if tt is not None else []):
            x = ref(it)
            q = x.find("TransitionTrackItem/TrackItem")
            print(f"  trans {int(q.findtext('Start') or 0) / TK:8.2f}-{int(q.findtext('End') or 0) / TK:8.2f} {x.findtext('TransitionTrackItem/DisplayName')}")
