/*
 * Barra de progresso e tempo estimado (abas Chat e Decupagem).
 *
 * O tempo vem de duas fontes: o andamento real da etapa, quando existe (áudio lido, cortes feitos,
 * render em %), e o tempo que etapas iguais levaram neste computador, que fica guardado e melhora
 * com o uso. A barra nunca anda para trás e só chega a 100 % quando termina de verdade.
 */
(function () {
  "use strict";

  const KEY = "premierechat.tempos";
  let mem = null; // cópia em memória, para o caso de o localStorage não existir

  function load() {
    if (mem) return mem;
    try {
      mem = JSON.parse(localStorage.getItem(KEY) || "null");
    } catch {}
    if (!mem || typeof mem !== "object") mem = {};
    if (!mem.rates) mem.rates = {};
    if (!mem.turns) mem.turns = {};
    return mem;
  }
  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(mem));
    } catch {}
  }

  // Velocidade aprendida (segundos por unidade). Média que dá mais peso ao que é recente.
  function rate(key, def) {
    const v = load().rates[key];
    return typeof v === "number" && isFinite(v) && v > 0 ? v : def;
  }
  function learn(key, value) {
    if (!isFinite(value) || value <= 0) return;
    const r = load().rates;
    r[key] = typeof r[key] === "number" && r[key] > 0 ? r[key] * 0.6 + value * 0.4 : value;
    const names = Object.keys(r);
    if (names.length > 300) delete r[names[0]];
    save();
  }

  // "cerca de 1 min 20 s". Arredonda para não ficar piscando a cada segundo.
  function fmt(s) {
    if (s == null || !isFinite(s)) return "";
    s = Math.max(0, s);
    if (s < 5) return "poucos segundos";
    if (s < 60) return Math.ceil(s / 5) * 5 + " s";
    s = s < 300 ? Math.round(s / 10) * 10 : Math.round(s / 60) * 60;
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    if (h) return h + " h" + (m ? " " + m + " min" : "");
    return m + " min" + (r ? " " + r + " s" : "");
  }
  function fmtClock(s) {
    s = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    const p = (n) => String(n).padStart(2, "0");
    return h ? `${h}:${p(m)}:${p(r)}` : `${m}:${p(r)}`;
  }

  // Quanto falta de uma etapa sem andamento conhecido: segue o previsto; passou dele, avisa (late).
  function remainByTime(elapsed, est) {
    est = Math.max(0.5, est);
    if (elapsed < est * 0.9) return { rem: est - elapsed, late: false };
    return { rem: Math.max(est * 0.1, elapsed * 0.15), late: elapsed > est * 1.6 };
  }
  // Com andamento real (0..1): mistura com o previsto no começo, quando a conta ainda é instável.
  function remain(elapsed, est, f) {
    const t = remainByTime(elapsed, est);
    if (f == null || !(f > 0)) return t;
    if (f >= 1) return { rem: 0, late: false };
    const real = (elapsed * (1 - f)) / f;
    const w = Math.min(1, f * 4);
    const plan = Math.max(est * (1 - f), 0);
    return { rem: w * real + (1 - w) * plan, late: false };
  }

  const clock = { now: () => Date.now() / 1000 };

  // Porcentagem que nunca volta atrás e só chega a 100 no fim.
  function pctOf(state, elapsed, rem) {
    const p = elapsed + rem > 0 ? elapsed / (elapsed + rem) : 0;
    state.pct = Math.max(state.pct || 0, Math.min(0.99, p));
    return state.pct;
  }

  /* Trabalho com etapas conhecidas (Decupagem). list: [{ id, label, est }] em segundos. */
  function stages(list) {
    const t0 = clock.now();
    const st = { list: list.map((s) => Object.assign({}, s)), i: -1, since: t0, f: null, pct: 0 };
    return {
      start(id, label) {
        const i = st.list.findIndex((s) => s.id === id);
        if (i < 0) return;
        st.i = i;
        st.since = clock.now();
        st.f = null;
        if (label) st.list[i].label = label;
      },
      est(id, secs) {
        const s = st.list.find((x) => x.id === id);
        if (s && isFinite(secs)) s.est = secs;
      },
      fraction(f) {
        if (f != null && isFinite(f)) st.f = Math.max(st.f || 0, Math.min(1, f));
      },
      elapsed: () => clock.now() - st.since,
      snapshot() {
        const now = clock.now();
        const cur = st.list[st.i];
        const r = cur ? remain(now - st.since, cur.est, st.f) : { rem: 0, late: false };
        let rem = r.rem;
        for (let k = st.i + 1; k < st.list.length; k++) rem += st.list[k].est;
        return { pct: pctOf(st, now - t0, rem), eta: rem, late: r.late, elapsed: now - t0, label: cur ? cur.label : "" };
      },
    };
  }

  // ------------------------------------------------------------ pedidos do chat

  const DEFAULT_TURN = 45;
  const median = (a) => {
    const s = a.slice().sort((x, y) => x - y);
    return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
  };

  // Duração comum dos pedidos deste tipo (segundos), ou 0 se ainda não há nenhum.
  function typical(key) {
    const h = (load().turns[key] || []).filter((x) => x > 0);
    return h.length ? median(h) : 0;
  }

  // Nome da etapa do plano sem acento, número nem palavra miúda: "Gerar os motions (3)" -> "gerar-motio".
  function stepKey(s) {
    const w = String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z ]+/g, " ").split(/\s+/).filter((x) => x.length > 2);
    return "etapa:" + w.slice(0, 2).map((x) => x.slice(0, 5)).join("-");
  }

  // Lê "42%" ou "120/300" numa linha de saída de programa. -> 0..1 ou null
  function parseFraction(line) {
    const s = String(line || "");
    const pc = s.match(/(\d{1,3}(?:[.,]\d+)?)\s*%/g);
    if (pc) {
      const v = parseFloat(pc[pc.length - 1].replace(",", "."));
      return v >= 0 && v <= 100 ? v / 100 : null;
    }
    const m = s.match(/(?:^|[^\d/.:])(\d{1,7})\s*\/\s*(\d{1,7})(?![\d/.])/);
    if (m && Number(m[2]) >= 3 && Number(m[1]) <= Number(m[2])) return Number(m[1]) / Number(m[2]);
    return null;
  }

  /*
   * Um pedido do chat. key = tipo do pedido (motor, modelo, esforço, com skill ou não).
   * Sem plano: compara com a duração dos pedidos parecidos já feitos neste computador.
   * Com plano (show_plan): etapas, com o tempo que cada uma costuma levar.
   */
  function turn(key, guess) {
    const t0 = clock.now();
    const hist = (load().turns[key] || []).filter((x) => x > 0);
    const st = { pct: 0, paused: 0, pauseAt: null, label: "", plan: null, tool: null };
    const now = () => (st.pauseAt != null ? st.pauseAt : clock.now()) - st.paused; // relógio sem as pausas

    // Duração esperada: entre os parecidos, os que duraram mais do que já passou.
    function expected(elapsed) {
      if (!hist.length) return elapsed < guess * 0.9 ? { total: guess, late: false } : { total: elapsed * 1.2, late: elapsed > guess * 1.6 };
      const longer = hist.filter((d) => d > elapsed * 1.05);
      if (longer.length) return { total: elapsed < median(hist) ? Math.max(median(hist), elapsed * 1.05) : median(longer), late: false };
      return { total: elapsed * 1.2, late: elapsed > Math.max(...hist) * 1.3 };
    }
    function toolRemain(at) {
      const t = st.tool;
      if (!t || t.f == null) return null;
      if (t.f - t.f0 < 0.02) return null;
      return ((t.at - t.t0) * (1 - t.f)) / (t.f - t.f0) - (at - t.at);
    }
    function planEst(i) {
      const p = st.plan;
      const def = Math.max(15, expected(0).total / Math.max(1, p.steps.length));
      const m = Number((p.minutes || [])[i]);
      return rate(stepKey(p.steps[i]), m > 0 ? m * 60 : def);
    }
    function learnStep(i, secs) {
      if (st.plan && st.plan.steps[i]) learn(stepKey(st.plan.steps[i]), secs);
    }

    return {
      label(s) {
        st.label = s || "";
        st.tool = null;
      },
      // Andamento da ferramenta que está rodando (0..1).
      tool(f) {
        if (f == null || !isFinite(f)) return;
        const at = now();
        if (!st.tool || f < st.tool.f - 0.02) st.tool = { f0: f, t0: at, f, at };
        else if (f > st.tool.f) {
          st.tool.f = Math.min(1, f);
          st.tool.at = at;
        }
      },
      plan(steps, done, minutes) {
        const at = now();
        done = Math.max(0, Math.min(steps.length, Number(done) || 0));
        if (!st.plan) st.plan = { steps, done, minutes, since: at };
        else {
          if (done === st.plan.done + 1) learnStep(st.plan.done, at - st.plan.since);
          if (done !== st.plan.done) st.plan.since = at;
          st.plan.steps = steps;
          st.plan.done = done;
          if (minutes && minutes.length) st.plan.minutes = minutes;
        }
      },
      pause(on) {
        if (on && st.pauseAt == null) st.pauseAt = clock.now();
        else if (!on && st.pauseAt != null) {
          st.paused += clock.now() - st.pauseAt;
          st.pauseAt = null;
        }
      },
      snapshot() {
        const at = now();
        const elapsed = at - t0;
        let rem, late = false, label = st.label;
        const tr = toolRemain(at);
        if (st.plan && st.plan.done < st.plan.steps.length) {
          const p = st.plan;
          const r = remainByTime(at - p.since, planEst(p.done));
          rem = r.rem;
          late = r.late && tr == null;
          if (tr != null && tr > rem) rem = tr;
          for (let i = p.done + 1; i < p.steps.length; i++) rem += planEst(i);
          label = `Etapa ${p.done + 1} de ${p.steps.length}: ${p.steps[p.done]}`;
        } else {
          const e = expected(elapsed);
          rem = Math.max(0, e.total - elapsed);
          late = e.late;
          if (st.plan) {
            rem = Math.min(rem, 15); // plano todo pronto: só falta a resposta final
            late = false;
            label = "Finalizando";
          }
          if (tr != null && tr > 0 && tr + 5 > rem) {
            rem = tr + 5;
            late = false;
          }
        }
        return { pct: pctOf(st, elapsed, rem), eta: rem, late, elapsed, label, paused: st.pauseAt != null, known: !!(st.plan || hist.length || tr != null) };
      },
      // ok = terminou bem: a duração entra no histórico.
      end(ok) {
        const at = now();
        if (!ok) return;
        if (st.plan && st.plan.done === st.plan.steps.length - 1) learnStep(st.plan.done, at - st.plan.since);
        const all = load().turns;
        all[key] = (all[key] || []).concat(Math.round((at - t0) * 10) / 10).slice(-20);
        save();
      },
    };
  }

  // Desenha numa barra: { el, label, time, bar }. snap vazio esconde.
  function paint(root, snap, text) {
    root.classList.toggle("hidden", !snap);
    if (!snap) return;
    const pct = Math.round(snap.pct * 100);
    root.querySelector(".pg-fill").style.width = Math.max(1, snap.pct * 100).toFixed(1) + "%";
    root.querySelector(".pg-bar").setAttribute("aria-valuenow", String(pct));
    root.querySelector(".pg-pct").textContent = pct + "%";
    root.querySelector(".pg-label").textContent = text || snap.label || "Trabalhando";
    root.querySelector(".pg-label").title = text || snap.label || "";
    const eta = snap.paused ? "esperando você" : snap.late ? "demorando mais que o normal" : "faltam " + (snap.known === false ? "~" : "") + fmt(snap.eta);
    root.querySelector(".pg-time").textContent = `${eta} · ${fmtClock(snap.elapsed)}`;
    root.classList.toggle("paused", !!snap.paused);
  }

  const api = { rate, learn, typical, fmt, fmtClock, stages, turn, stepKey, parseFraction, paint, DEFAULT_TURN, _clock: clock, _reset: () => (mem = { rates: {}, turns: {} }) };
  if (typeof window !== "undefined") window.Progresso = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
