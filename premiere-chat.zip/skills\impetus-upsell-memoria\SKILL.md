---
name: impetus-upsell-memoria
description: >-
  UPsell Memória. Edita vídeos de upsell do cliente Impetus para produtos de memória, cérebro, foco e demência (Memopower e afins), com público de 50+ e tom dramático: mesmo fluxo do UPsell Emagrecimento (decupar, legendar, B-roll da biblioteca Impetus, LTs, telas de preço com neon, light leak, trilha e SFX), mais inserts em preto e branco ou com 50 % de saturação, granulado, vinheta forte, trechos VHS, mergulho no preto, sequências de inserts em cartão, LTs maiores e B-roll de pessoas mais velhas. Use sempre que o usuário pedir para editar, decupar, legendar ou finalizar um upsell ou "UP" do Impetus de memória/cérebro, ou um material dramático do Impetus, ou aplicar "o padrão do UPsell Memória" ou "do Memopower", mesmo sem citar a skill. Também serve para colocar B-roll, música, SFX e marcadores numa timeline do Premiere (via XML) nesse padrão e para aprender com uma versão do usuário.
---

# UPsell Memória (Impetus)

Antes de usar esta skill em um projeto novo, passe pela skill `novo-projeto-edicao`: pasta mãe, subpastas, conferência e escolha da skill.

Esta skill é a de emagrecimento com tom dramático. **Leia primeiro [references/estilo-memoria.md](references/estilo-memoria.md)**: o que muda (P&B / 50 %, granulado, vinheta, VHS, mergulho no preto, cartões, LTs maiores, B-roll 50+, música em arco triste → esperançoso, Boom nas LTs), com exemplos de fala → insert do Memopower.
Referência entregue: `G:\Clientes\IMPETUS\UPSELL  Memopower  UP1A V1 Memopower  GER  Digistore\Finalizado\UP_1A_V1_MemoPower_GER_Digistore_09m19s.mp4`; leitura insert por insert em `references/aprendizado/memopower/compacto_memopower.txt`.
Para o resto (legenda, telas de preço, nomes, light leak + shutter, mix), siga [references/padroes-upsell-impetus.md](references/padroes-upsell-impetus.md) (4 upsells de emagrecimento entregues; os `compacto_*.txt` e `tipos_*.jpg` deles continuam úteis para produto, oferta e preço).
Valores do render automático em [references/estilo-aprovado.md](references/estilo-aprovado.md). O motivo de cada regra está em [references/historico-ajustes.md](references/historico-ajustes.md); leia quando um pedido novo parecer contrariar uma regra. Formato dos arquivos em [references/formato-projeto.md](references/formato-projeto.md). Projeto completo de exemplo em `exemplo-cidrepeak/`.

## Como o usuário trabalha
- Responda em português do Brasil, direto, sem jargão de programação.
- Para mudança visual nova, mande folha de prints e espere aprovação antes de renderizar: o render completo leva vários minutos.
- Se o usuário apontar um trecho ou um elemento, altere só aquilo. Se o escopo estiver ambíguo, confirme.
- Cada render vira um arquivo novo (`... v1.mp4`, `... v2.mp4`); não sobrescreva versões anteriores.
- Depois do render, confira frames no vídeo final e diga o que não foi conferido.
- Não use projeto antigo do usuário feito com o mesmo material sem perguntar.

## Pergunte no começo (se o usuário não disse)
- Nome do produto como deve aparecer na legenda (a voz de IA costuma pronunciar errado).
- Idioma da fala (padrão `fr`; `--idioma de`, `en`...).
- Nomes e cargos das apresentadoras para a faixa de nome.
- Preços e quantidades da oferta, se não estiverem claros na fala.

## Fluxo
Trabalhe a partir da pasta mãe: brutos em `Brutas`, B-roll em `Inserts` (produto em `Inserts/Produto`), trilhas em `Musicas`, efeitos em `SFX`. Arquivos de trabalho em `<pasta mãe>/_projeto`, vídeo final na pasta mãe. `S` = pasta `scripts` desta skill.

### 1. Decupar
```bash
python "$S/decupar.py" "<pasta mãe>" --idioma fr
```
Ordena os brutos pelo número do nome, corta silêncios maiores que 0,22 s pela energia do áudio, enquadra em 4:5 e transcreve (Whisper medium; ~10 min para 6 min de fala, rode em segundo plano). Use `--so-mapa` para refazer só o mapa de cortes. Leia `avisos.txt` e confira no áudio palavras suspeitas e frases repetidas (regravação: pergunte qual manter).

### 2. Roteiro e escolhas
```bash
python "$S/roteiro_auto.py" "<pasta mãe>/_projeto" --trocas "sidrepeak=Cidrepeak,galpen=GLP-1"
```
Gera legendas normais. Depois marque os destaques (`D`) e monte `projeto.json` com nomes, inserts, telas de preço, clarões e áudio. O jeito mais seguro é copiar `exemplo-cidrepeak/montar.py` para `_projeto` e trocar as frases e arquivos: ele acha os tempos pelas frases faladas, monta roteiro e projeto e copia o B-roll usado para `Inserts/broll`.

Para escolher B-roll, siga `estilo-memoria.md` (pessoas de 50+: `IDOSO E PÉ EM GERAL`, `Homens`, `memoria`, `Cerebro`, `NERVOS`) e `padroes-upsell-impetus.md`, faça folhas de miniaturas das pastas da biblioteca e case cada insert com a frase. Cubra 65–75 % do tempo com inserts curtos (~2,5 s); o apresentador fica nos ganchos, nas frases de olho no olho e embaixo das LTs.

Campos do tom dramático no `projeto.json` (render.py desta skill):
- no insert: `"cor": "pb"` (preto e branco) ou `"cor": "50"` (saturação 50 %); `"cartao": true` (insert em cartão sobre cópia desfocada e escurecida);
- `"drama": [[ini, fim], [ini, fim, "vhs"]]`: granulado e vinheta mais fortes; com `"vhs"` também cor separada, linhas e tremor;
- `"fade_preto": [t, ...]`: mergulho no preto (0,5 s descendo, 0,83 s voltando) centrado em `t`;
- `"estilo": {...}` sobrescreve `grao`, `grao_drama`, `vinheta`, `vinheta_drama`, `vhs_*`, `cartao_*`, `dest_tam`, `sat_drama`.
Nos prints, inclua um insert P&B, um com 50 %, um cartão, um trecho VHS, uma LT grande e um mergulho no preto. Exemplo do resultado em `references/aprendizado/memopower/teste_render_efeitos.jpg`.

```bash
python "$S/render.py" projeto.json --check
```
Acusa palavra que não bate com a transcrição e legenda longa demais. Corrija antes de seguir.

### 3. Prints
```bash
python "$S/render.py" projeto.json --frames 2,14,20.5,53.5,124.5,200.5,273.5,297.5,339 prints/
python "$S/prints.py" prints/ "../Teste prints - v1.jpg" 6
```
Inclua pelo menos: nome na tela, B-roll, destaque sobre apresentador, destaque sobre B-roll, depoimento, cada tela de preço com o neon aceso e o cartão misto. Mande com `SendUserFile` e espere aprovação.

### 4. Render e mixagem
```bash
python "$S/render.py" projeto.json --full video_sem_audio_v1.mp4
python "$S/mix.py" projeto.json video_sem_audio_v1.mp4 "../NOME - v1.mp4"
```
Rode em segundo plano (~15 min para 6 min de vídeo). `mix.py` imprime o loudness final (alvo −17 LUFS). Confira frames do arquivo final antes de entregar.

### 5. Edição no Premiere (quando o usuário quer a timeline lá)
O usuário exporta o XML da sequência já decupada/legendada (File > Export > Final Cut Pro XML). As decisões saem desta skill e os itens entram nesse XML no formato do próprio Premiere (`scripts/aplicar_no_xml.py`; `scripts/ler_timeline.py` e `scripts/ler_legendas.py` leem cortes e legendas do .prproj). Nunca dois clipes sobrepostos na mesma faixa (o Premiere recusa o XML inteiro); legendas não vão no XML. Marque com marcadores nativos onde entram LTs, preços, selos e light leaks.

### 6. Efeitos das referências fora do Premiere
`scripts/efeitos_referencia.py` reproduz LT, legenda, light leak + shutter, zoom no expert, cartões arredondados, tela de preço com neon e setas, Tile, SFX e música dos upsells entregues (receitas em `padroes-upsell-impetus.md` §9). Use como base quando o usuário pedir um vídeo com "os efeitos das referências" renderizado aqui; mande prints lado a lado com a referência antes do render.

### 7. Aprender com a versão do usuário
Quando o usuário devolver um vídeo ou `.prproj` com ajustes:
```bash
python "$S/comparar.py" "versao_entregue.mp4" "versao_do_usuario.mp4"
python "$S/ler_prproj.py" "projeto.prproj" --seq <n> > timeline.txt
python "$S/analisar_prproj.py" "projeto.prproj" --lista                  # sequências
python "$S/analisar_prproj.py" "projeto.prproj" --seq <n> timeline.json  # tudo: arquivos, efeitos, textos de LT, SFX
python "$S/resumo_timeline.py" timeline.json resumo.txt resumo.json        # cada insert com a fala e a origem (UGC/banco/IA)
```
Itens `[DESATIVADO]` não entram no vídeo. Atualize `references/estilo-aprovado.md` e registre o motivo em `historico-ajustes.md`. Para regra que não estiver clara, pergunte.
