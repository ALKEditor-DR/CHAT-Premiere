/*
 * Transcrição local (Whisper via transformers.js) — sem API, tudo no computador.
 *
 * Uso: node transcribe.js <arquivo de áudio/vídeo> --out <saida.json>
 *        [--model onnx-community/whisper-small] [--language portuguese] [--ffmpeg caminho]
 *
 * Progresso vai para stderr como linhas JSON {"progress": "..."}; o resultado
 * ({ text, segments: [{ start, end, text }], words?: [...] }) é gravado em --out.
 */
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");

function arg(name, def) {
  const i = process.argv.indexOf("--" + name);
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

const input = process.argv[2];
const out = arg("out");
const model = arg("model", "onnx-community/whisper-small_timestamped");
const wordLevel = /_timestamped$/.test(model);
const language = arg("language", "portuguese"); // "auto" = detectar pelo áudio
const ffmpeg = arg("ffmpeg", "ffmpeg");
const SR = 16000;

const progress = (msg) => process.stderr.write(JSON.stringify({ progress: msg }) + "\n");

function decodeAudio(file) {
  return new Promise((resolve, reject) => {
    const ff = spawn(ffmpeg, ["-nostdin", "-i", file, "-vn", "-ac", "1", "-ar", String(SR), "-f", "f32le", "-"], {
      windowsHide: true,
    });
    const chunks = [];
    let err = "";
    ff.stdout.on("data", (d) => chunks.push(d));
    ff.stderr.on("data", (d) => (err += d));
    ff.on("error", (e) => reject(new Error("ffmpeg não encontrado: " + e.message)));
    ff.on("close", (code) => {
      if (code !== 0) return reject(new Error("ffmpeg falhou: " + err.slice(-500)));
      const buf = Buffer.concat(chunks);
      const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength - (buf.byteLength % 4));
      resolve(new Float32Array(ab));
    });
  });
}

const r2 = (n) => Math.round(n * 100) / 100;

// Junta palavras em frases: quebra em pontuação final, pausas longas ou ~12 s.
function groupWords(words) {
  const out = [];
  let cur = null;
  for (const w of words) {
    if (cur && (w.start - cur.end > 0.8 || cur.end - cur.start > 12)) {
      out.push(cur);
      cur = null;
    }
    if (!cur) cur = { start: w.start, end: w.end, text: w.text };
    else {
      cur.end = w.end;
      cur.text += " " + w.text;
    }
    if (/[.!?…]$/.test(w.text)) {
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push(cur);
  return out;
}

// O Whisper do transformers.js não detecta idioma sozinho (assume inglês).
// Aqui fazemos a detecção: ouvimos até 3 janelas de 30 s espalhadas pelo áudio,
// pedimos ao decoder só o primeiro token (o de idioma) e somamos as probabilidades.
async function detectLanguage(asr, audio) {
  const win = SR * 30;
  const gc = asr.model.generation_config || {};
  const langToId = gc.lang_to_id;
  if (!langToId) return { code: "pt", prob: 0 };
  const entries = Object.entries(langToId); // ["<|pt|>", id]
  const starts = audio.length <= win ? [0]
    : [0, Math.floor((audio.length - win) / 2), audio.length - win];
  const score = new Map();
  for (const s of starts) {
    const slice = audio.subarray(s, s + win);
    // pula janelas praticamente mudas
    let e = 0;
    for (let i = 0; i < slice.length; i += 16) e += slice[i] * slice[i];
    if (e / (slice.length / 16) < 1e-6) continue;
    const { input_features } = await asr.processor(slice);
    const out = await asr.model({
      input_features,
      decoder_input_ids: new (require_tensor())("int64", BigInt64Array.from([BigInt(gc.decoder_start_token_id)]), [1, 1]),
    });
    const logits = out.logits.data;
    const vocab = out.logits.dims.at(-1);
    const off = logits.length - vocab;
    let max = -Infinity;
    for (const [, id] of entries) max = Math.max(max, logits[off + id]);
    let sum = 0;
    const ps = entries.map(([tok, id]) => { const p = Math.exp(logits[off + id] - max); sum += p; return [tok, p]; });
    for (const [tok, p] of ps) score.set(tok, (score.get(tok) || 0) + p / sum);
  }
  if (!score.size) return { code: "pt", prob: 0 };
  const n = [...score.values()].reduce((a, b) => a + b, 0);
  const [tok, val] = [...score.entries()].sort((a, b) => b[1] - a[1])[0];
  return { code: tok.replace(/[<|>]/g, ""), prob: val / n };
}
let TensorCls = null;
const require_tensor = () => TensorCls;

async function main() {
  if (!input || !out) throw new Error("uso: node transcribe.js <arquivo> --out <saida.json>");
  const { pipeline, env, Tensor } = await import("@huggingface/transformers");
  TensorCls = Tensor;
  env.cacheDir = path.join(os.homedir(), ".premiere-chat", "models");

  progress("Lendo o áudio");
  const audio = await decodeAudio(input);
  const duration = audio.length / SR;

  progress("Carregando o modelo de transcrição (a primeira vez baixa o modelo)");
  let lastPct = -1;
  const asr = await pipeline("automatic-speech-recognition", model, {
    dtype: { encoder_model: "fp32", decoder_model_merged: "q4" },
    progress_callback: (p) => {
      if (p.status === "progress" && p.total > 1e6) {
        const pct = Math.floor(p.progress / 10) * 10;
        if (pct !== lastPct) {
          lastPct = pct;
          progress(`Baixando modelo: ${pct}%`);
        }
      }
    },
  });

  let lang = language;
  let detected = null;
  if (!lang || lang === "auto") {
    progress("Detectando o idioma do áudio");
    detected = await detectLanguage(asr, audio);
    lang = detected.code;
    progress(`Idioma detectado: ${detected.code} (${Math.round(detected.prob * 100)}%)`);
  }

  progress(`Transcrevendo ${Math.round(duration)}s de áudio`);
  const t0 = Date.now();
  // Andamento de verdade: o áudio é lido em janelas de 30 s que andam 20 s por vez.
  const win = SR * 30, jump = SR * 20;
  const total = audio.length <= win ? 1 : Math.ceil((audio.length - win) / jump) + 1;
  let windows = 0;
  const generate = asr.model.generate.bind(asr.model);
  asr.model.generate = async (...a) => {
    const r = await generate(...a);
    windows++;
    process.stderr.write(JSON.stringify({ fraction: Math.min(1, windows / total) }) + "\n");
    return r;
  };
  const res = await asr(audio, {
    language: lang,
    task: "transcribe",
    chunk_length_s: 30,
    stride_length_s: 5,
    return_timestamps: wordLevel ? "word" : true,
  });

  const toItems = (chunks) => (chunks || [])
    .map((c) => ({
      start: r2(c.timestamp[0] ?? 0),
      end: r2(c.timestamp[1] ?? Math.min(duration, (c.timestamp[0] ?? 0) + 5)),
      text: String(c.text || "").trim(),
    }))
    .filter((s) => s.text);

  let words = null;
  let segments;
  if (wordLevel) {
    words = toItems(res.chunks);
    segments = groupWords(words);
  } else {
    segments = toItems(res.chunks);
  }

  fs.writeFileSync(
    out,
    JSON.stringify({ model, language: lang, detectedLanguage: detected, duration: r2(duration), seconds: r2((Date.now() - t0) / 1000), text: String(res.text || "").trim(), segments, words }, null, 1),
    "utf8"
  );
  progress("Pronto");
}

main().catch((e) => {
  process.stderr.write(JSON.stringify({ error: String((e && e.message) || e) }) + "\n");
  process.exit(1);
});
