/*
 * Executor das skills dentro do painel: roda scripts (Python, Node, npx/HyperFrames, ffmpeg)
 * de uma LISTA LIBERADA, sem passar pelo terminal (cmd/PowerShell). Sem terminal não existe
 * encadear comandos, redirecionar saída nem chamar outros programas por fora da lista.
 *
 * Também grava arquivos de texto e copia arquivos, só dentro das pastas liberadas.
 * Cada execução vira um "job": o painel mostra o andamento ao vivo e dá para parar.
 */
(function () {
  "use strict";

  const req = typeof require === "function" ? require : null;
  if (!req) {
    if (typeof window !== "undefined") window.Runner = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const { spawn, spawnSync } = req("child_process");

  const HOME = os.homedir();
  const IS_WIN = process.platform === "win32";
  const api = {};

  function isFile(p) {
    try {
      return fs.statSync(p).isFile();
    } catch {
      return false;
    }
  }
  function isDir(p) {
    try {
      return fs.statSync(p).isDirectory();
    } catch {
      return false;
    }
  }

  function whichAll(name) {
    const exts = IS_WIN ? [".exe", ""] : [""];
    const out = [];
    for (const d of (process.env.PATH || "").split(path.delimiter)) {
      if (!d) continue;
      for (const e of exts) {
        const p = path.join(d, name + e);
        // O "python.exe" da Microsoft Store (WindowsApps) é só um atalho que abre a loja.
        if (isFile(p) && !/WindowsApps/i.test(p)) out.push(p);
      }
    }
    return out;
  }

  // ------------------------------------------------------------ programas liberados

  /*
   * Resolve o nome liberado para { exe, pre: [args antes dos do usuário] } ou null.
   * Local = LocalTools (para achar node e ffmpeg do mesmo jeito que o resto do painel).
   */
  function resolveProgram(name, Local) {
    const node = Local && Local.findNode();
    const ffmpeg = Local && Local.findFfmpeg();
    const npmCli = (file) => {
      if (!node) return null;
      const p = path.join(path.dirname(node), "node_modules", "npm", "bin", file);
      return isFile(p) ? p : null;
    };
    const sysPython = () => {
      const cands = whichAll("python");
      const local = path.join(process.env.LOCALAPPDATA || "", "Programs", "Python");
      if (isDir(local)) {
        for (const d of fs.readdirSync(local).sort().reverse()) {
          const p = path.join(local, d, "python.exe");
          if (isFile(p)) cands.push(p);
        }
      }
      return cands[0] || null;
    };
    switch (name) {
      case "python": {
        // Python da edição (traz as bibliotecas, o ffmpeg e os modelos das skills).
        const p = path.join(HOME, ".claude", "edicao-runtime", "python", "python.exe");
        if (isFile(p)) return { exe: p, pre: [] };
        const s = sysPython();
        return s ? { exe: s, pre: [] } : null;
      }
      case "python-sistema": {
        const s = sysPython();
        return s ? { exe: s, pre: [] } : null;
      }
      case "py": {
        const p = whichAll("py")[0];
        return p ? { exe: p, pre: [] } : null;
      }
      case "node":
        return node ? { exe: node, pre: [] } : null;
      case "npx": {
        const cli = npmCli("npx-cli.js");
        return cli ? { exe: node, pre: [cli] } : null;
      }
      case "npm": {
        const cli = npmCli("npm-cli.js");
        return cli ? { exe: node, pre: [cli] } : null;
      }
      case "ffmpeg":
        return ffmpeg ? { exe: ffmpeg, pre: [] } : null;
      case "ffprobe": {
        if (!ffmpeg) return null;
        const p = path.join(path.dirname(ffmpeg), IS_WIN ? "ffprobe.exe" : "ffprobe");
        return isFile(p) ? { exe: p, pre: [] } : null;
      }
      default:
        return null;
    }
  }
  api.PROGRAMS = ["python", "python-sistema", "py", "node", "npx", "npm", "ffmpeg", "ffprobe"];

  api.programsStatus = function (Local) {
    const out = {};
    for (const n of api.PROGRAMS) {
      const r = resolveProgram(n, Local);
      out[n] = r ? r.pre[0] || r.exe : null;
    }
    return out;
  };

  // ------------------------------------------------------------ pastas liberadas

  const norm = (p) => path.resolve(String(p)).replace(/[\\/]+$/, "").toLowerCase();

  // Pastas onde o chat pode gravar e copiar. A pasta do projeto (e até 2 pastas acima, sem
  // chegar na raiz do disco) entra sempre; as outras vêm das configurações.
  api.allowedRoots = function (projectPath, extra) {
    const roots = [path.join(HOME, ".premiere-chat"), os.tmpdir()];
    if (projectPath) {
      let d = path.dirname(projectPath);
      for (let i = 0; i < 3 && d; i++) {
        if (path.parse(d).root === d || d.length <= 3) break;
        roots.push(d);
        d = path.dirname(d);
      }
    }
    for (const r of extra || []) if (r && String(r).trim()) roots.push(String(r).trim());
    return Array.from(new Set(roots.map((r) => path.resolve(r))));
  };

  // Mesmo dentro das pastas liberadas, nunca mexe nas configurações e skills do Claude.
  const BLOCKED = [path.join(HOME, ".claude"), process.env.WINDIR || "C:\\Windows", process.env.ProgramFiles || "C:\\Program Files", process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)"];

  api.checkWritable = function (target, roots) {
    const t = norm(target);
    for (const b of BLOCKED) {
      const nb = norm(b);
      if (t === nb || t.startsWith(nb + path.sep)) throw new Error(`Gravar em ${b} não é permitido pelo painel.`);
    }
    for (const r of roots) {
      const nr = norm(r);
      if (t === nr || t.startsWith(nr + path.sep)) return true;
    }
    throw new Error(`"${target}" está fora das pastas liberadas para gravar:\n- ${roots.join("\n- ")}\nO usuário pode liberar mais pastas em ⚙ > Skills.`);
  };

  const TEXT_EXT = /\.(json|jsonc|md|txt|srt|vtt|ass|csv|tsv|xml|fcpxml|html?|css|js|mjs|cjs|ts|tsx|jsx|py|yaml|yml|ini|cfg|toml|svg|edl|cube)$/i;

  api.writeTextFile = function (p, content, opts) {
    opts = opts || {};
    if (!path.isAbsolute(p)) throw new Error("Use um caminho absoluto.");
    if (!TEXT_EXT.test(p)) throw new Error("Só arquivos de texto (json, md, srt, html, js, py, xml...) podem ser gravados por aqui.");
    api.checkWritable(p, opts.roots || []);
    const existed = isFile(p);
    if (existed && opts.overwrite === false) throw new Error("O arquivo já existe: " + p);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, String(content), "utf8");
    return { path: p, bytes: Buffer.byteLength(String(content)), replaced: existed };
  };

  api.copyFile = function (src, dest, opts) {
    opts = opts || {};
    if (!path.isAbsolute(src) || !path.isAbsolute(dest)) throw new Error("Use caminhos absolutos.");
    if (!isFile(src)) throw new Error("Arquivo de origem não encontrado: " + src);
    let target = dest;
    if (isDir(dest) || /[\\/]$/.test(dest)) target = path.join(dest, path.basename(src));
    api.checkWritable(target, opts.roots || []);
    if (isFile(target) && !opts.overwrite) throw new Error("Já existe um arquivo em " + target + " (passe overwrite para substituir).");
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(src, target);
    return { path: target, bytes: fs.statSync(target).size };
  };

  api.makeDirs = function (dirs, opts) {
    const out = [];
    for (const d of dirs) {
      if (!path.isAbsolute(d)) throw new Error("Use caminhos absolutos: " + d);
      api.checkWritable(d, (opts && opts.roots) || []);
      fs.mkdirSync(d, { recursive: true });
      out.push(d);
    }
    return out;
  };

  // ------------------------------------------------------------ bloqueio de serviços pagos

  /*
   * Recusa comandos que usam serviço pago ou com créditos: render/publicação na nuvem do
   * HyperFrames (HeyGen, AWS Lambda, Google Cloud Run), voz por IA (TTS), Remotion Lambda/Cloud Run
   * e Higgsfield. Devolve o motivo, ou null se pode rodar.
   */
  const PAID_SUBCOMMANDS = ["cloud", "lambda", "cloudrun", "publish", "tts", "deploy"];
  const PAID_WORDS = /higgsfield|heygen|@remotion\/lambda|@remotion\/cloudrun|elevenlabs|replicate\.com|fal\.ai|runwayml/i;

  api.paidReason = function (program, args) {
    const all = [program].concat(args || []).map((a) => String(a));
    const joined = all.join(" ");
    if (PAID_WORDS.test(joined)) return "usa um serviço pago (" + joined.match(PAID_WORDS)[0] + ")";
    const low = all.map((a) => a.toLowerCase());
    const tool = low.findIndex((a) => /(^|[\\/@])(hyperframes|remotion)(?=$|[\\/@.])/.test(a));
    if (tool >= 0) {
      const rest = low.slice(tool + 1).filter((a) => !a.startsWith("-"));
      const sub = rest[0] || "";
      if (PAID_SUBCOMMANDS.includes(sub)) return `"${sub}" usa a nuvem ou voz por IA (serviço pago/com créditos)`;
    }
    return null;
  };

  // Chaves de serviços pagos não chegam aos scripts: sem chave, nada é cobrado por engano.
  const PAID_ENV = /^(ANTHROPIC_|HEYGEN|HIGGSFIELD|ELEVENLABS|OPENAI|REPLICATE|FAL_|RUNWAY|AWS_|GOOGLE_APPLICATION_CREDENTIALS|REMOTION_AWS|STABILITY)/i;

  // ------------------------------------------------------------ jobs

  const jobs = new Map(); // id -> job
  let seq = 0;
  const TAIL = 12000;

  function killTree(proc) {
    if (!proc || proc.exitCode !== null) return;
    try {
      if (IS_WIN) spawnSync("taskkill", ["/pid", String(proc.pid), "/T", "/F"], { windowsHide: true });
      else proc.kill("SIGTERM");
    } catch {}
  }

  /*
   * Inicia um programa liberado. -> job
   * spec: { program, args[], cwd, env{} }, Local, onOutput(lastLine)
   */
  api.start = function (spec, Local, onOutput) {
    const prog = resolveProgram(spec.program, Local);
    if (!prog) {
      if (!api.PROGRAMS.includes(spec.program)) throw new Error(`Programa "${spec.program}" não liberado. Liberados: ${api.PROGRAMS.join(", ")}.`);
      throw new Error(`Não encontrei "${spec.program}" neste computador. Rode o instalador do painel de novo.`);
    }
    const args = (spec.args || []).map(String);
    const paid = api.paidReason(spec.program, args);
    if (paid) throw new Error("Bloqueado pelo painel: este comando " + paid + ". O painel só usa ferramentas locais e gratuitas; faça o render/voz localmente.");
    const cwd = spec.cwd && isDir(spec.cwd) ? spec.cwd : os.tmpdir();
    const node = Local && Local.findNode();
    const ffmpeg = Local && Local.findFfmpeg();
    const extraPath = [node && path.dirname(node), ffmpeg && path.dirname(ffmpeg), path.dirname(prog.exe)].filter(Boolean);
    const env = Object.assign({}, process.env, spec.env || {}, {
      PATH: extraPath.concat([process.env.PATH || ""]).join(path.delimiter),
      PYTHONIOENCODING: "utf-8",
      PYTHONUTF8: "1",
      FORCE_COLOR: "0",
      NO_COLOR: "1",
    });
    // O painel não pode usar API paga por engano (Claude, HeyGen, Higgsfield, nuvem...).
    for (const k of Object.keys(env)) if (PAID_ENV.test(k)) delete env[k];

    const id = "job" + ++seq;
    const proc = spawn(prog.exe, prog.pre.concat(args), { cwd, env, windowsHide: true, shell: false });
    const job = {
      id,
      label: [spec.program].concat(args).join(" ").slice(0, 200),
      cwd,
      proc,
      out: "",
      lastLine: "",
      status: "running",
      exitCode: null,
      started: Date.now(),
      ended: null,
      waiters: [],
    };
    const take = (d) => {
      const s = d.toString();
      job.out = (job.out + s).slice(-TAIL);
      // Barras de progresso usam \r: a "última linha" é o último pedaço não vazio.
      const parts = s.split(/[\r\n]+/).map((x) => x.trim()).filter(Boolean);
      if (parts.length) {
        job.lastLine = parts[parts.length - 1].slice(0, 160);
        if (onOutput) onOutput(job.lastLine);
      }
    };
    proc.stdout.on("data", take);
    proc.stderr.on("data", take);
    proc.on("error", (e) => {
      job.out += "\n[erro ao iniciar] " + (e.message || e);
    });
    proc.on("close", (code) => {
      job.exitCode = code;
      job.status = job.status === "cancelled" ? "cancelled" : code === 0 ? "done" : "failed";
      job.ended = Date.now();
      job.waiters.splice(0).forEach((w) => w());
    });
    // Prioridade baixa: o Premiere continua respondendo enquanto o render trabalha.
    // No Windows os processos que o script abrir (ffmpeg, Chrome do HyperFrames) herdam essa prioridade.
    if (spec.lowPriority !== false && proc.pid) {
      try {
        os.setPriority(proc.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
        job.lowPriority = true;
      } catch {}
    }
    jobs.set(id, job);
    return job;
  };

  // Espera o job terminar ou o tempo acabar. -> job
  api.wait = function (job, ms) {
    if (job.status !== "running") return Promise.resolve(job);
    return new Promise((resolve) => {
      const done = () => {
        clearTimeout(t);
        resolve(job);
      };
      const t = setTimeout(() => {
        const i = job.waiters.indexOf(done);
        if (i >= 0) job.waiters.splice(i, 1);
        resolve(job);
      }, ms);
      job.waiters.push(done);
    });
  };

  api.get = (id) => jobs.get(id) || null;

  api.cancel = function (id) {
    const job = jobs.get(id);
    if (!job || job.status !== "running") return false;
    job.status = "cancelled";
    killTree(job.proc);
    return true;
  };

  api.cancelAll = function () {
    let n = 0;
    for (const j of jobs.values()) if (j.status === "running" && api.cancel(j.id)) n++;
    return n;
  };

  api.running = () => Array.from(jobs.values()).filter((j) => j.status === "running");

  api.describe = function (job) {
    const secs = Math.round(((job.ended || Date.now()) - job.started) / 1000);
    const head =
      job.status === "running"
        ? `Ainda rodando (${secs} s): job ${job.id}. Chame job_status com esse id para esperar mais ou cancel_job para parar.`
        : job.status === "done"
        ? `Terminou bem (código 0) em ${secs} s.`
        : job.status === "cancelled"
        ? `Cancelado depois de ${secs} s.`
        : `Falhou (código ${job.exitCode}) em ${secs} s.`;
    return `${head}\nComando: ${job.label}\nPasta: ${job.cwd}\n--- saída (final) ---\n${job.out.trim() || "(sem saída)"}`;
  };

  if (typeof window !== "undefined") window.Runner = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
