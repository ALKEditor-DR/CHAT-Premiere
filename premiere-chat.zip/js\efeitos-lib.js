/*
 * Biblioteca de textos da própria pessoa: um projeto do Premiere com os MOGRTs que ela já inseriu, um depois
 * do outro, numa sequência. Aqui só se lê a lista (nome, tempo e os controles que o MOGRT expõe). Nenhum
 * modelo é copiado para o plugin: na hora de inserir, o Premiere usa o próprio projeto.
 */
(function (root) {
  "use strict";
  const req = typeof require === "function" ? require : null;
  const api = {};
  const TK = 254016000000;

  // ---------------------------------------------------------------- leitura do .prproj (XML com gzip)

  function parser(xml) {
    const obj = new Map(); // ObjectID -> { tag, body }
    const uid = new Map();
    // Só os objetos do primeiro nível: abertura até o fechamento na mesma indentação.
    const re = /^\t<(\w+) Object(ID|UID)="([^"]+)"[^>]*>([\s\S]*?)^\t<\/\1>/gm;
    let m;
    while ((m = re.exec(xml))) (m[2] === "ID" ? obj : uid).set(m[3], { tag: m[1], id: m[3], body: m[4] });
    // Valor repetido vem vazio, so com o BinaryHash do primeiro.
    const bin = new Map();
    for (const b of xml.matchAll(/Encoding="base64" BinaryHash="([^"]+)">([^<]+)</g)) if (!bin.has(b[1])) bin.set(b[1], b[2]);
    return { obj, uid, bin };
  }
  const unesc = (s) => String(s == null ? "" : s).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  const tag = (b, t) => {
    const m = new RegExp("<" + t + ">([^<]*)</" + t + ">").exec(b);
    return m ? unesc(m[1]) : null;
  };
  const ref = (b, t) => {
    const m = new RegExp("<" + t + ' ObjectRef="(\\d+)"').exec(b);
    return m ? m[1] : null;
  };

  function textValue(body, pr) {
    const m = /<StartKeyframeValue Encoding="base64"(?: BinaryHash="([^"]*)")?[^>]*?(?:\/>|>([^<]*)<)/.exec(body);
    if (!m) return null;
    const data = (m[2] || "").trim() || pr.bin.get(m[1]);
    if (!data) return null;
    const buf = Buffer.from(data, "base64");
    for (const enc of ["utf16le", "utf8"]) {
      try {
        const s = buf.toString(enc).replace(/\0+$/, "");
        const j = JSON.parse(s.slice(s.indexOf("{"), s.lastIndexOf("}") + 1));
        if (j && typeof j.textEditValue === "string") return j;
      } catch {}
    }
    return null;
  }
  // Cor de 64 bits (AAAA RRRR GGGG BBBB): o byte alto de cada canal.
  function color(v) {
    const n = BigInt(v);
    const c = (s) => Number((n >> BigInt(s)) & 0xffn).toString(16).padStart(2, "0");
    return "#" + c(40) + c(24) + c(8);
  }

  // Controles do MOGRT na ordem em que aparecem em Gráficos Essenciais.
  function controls(pr, compId) {
    const comp = pr.obj.get(compId);
    if (!comp) return null;
    const out = [];
    const seen = {};
    let part = 0;
    for (const m of comp.body.matchAll(/<Param Index="\d+" ObjectRef="(\d+)"/g)) {
      const p = pr.obj.get(m[1]);
      if (!p) continue;
      const name = tag(p.body, "Name") || "";
      const n = (seen[name] = (seen[name] == null ? -1 : seen[name]) + 1); // ocorrência deste nome
      const raw = tag(p.body, "StartKeyframe") || tag(p.body, "CurrentValue") || "";
      const val = raw.includes(",") ? raw.split(",")[1] : raw;
      if (p.tag === "ArbVideoComponentParam") {
        const j = textValue(p.body, pr);
        if (j) out.push({ type: "text", name, n, i: part++, pid: m[1], text: j.textEditValue.replace(/\r\n?/g, "\n"), ps: (j.fontEditValue || [])[0] || "", size: Number((j.fontSizeEditValue || [])[0]) || 0, fontEdit: j.capPropFontEdit !== false, sizeEdit: j.capPropFontSizeEdit === true });
      } else if (p.tag === "VideoComponentParam") {
        if (/^\d{12,}$/.test(val)) {
          // Canal alfa zerado = cor desligada no modelo (ex.: caixa invisível): não mostra.
          if ((BigInt(val) >> 56n & 0xffn) > 0x80n) out.push({ type: "color", name, n, value: color(val) });
        } else if (/^-?[\d.]+$/.test(val) && tag(p.body, "LowerBound") != null) {
          out.push({ type: "num", name, n, value: parseFloat(val), min: parseFloat(tag(p.body, "LowerBound")), max: parseFloat(tag(p.body, "UpperBound")) });
        }
      }
    }
    return out;
  }

  // -> [{ seq, seqId, w, h, items: [{ start, end, name, lines, scale, controls }] }]
  api.parse = function (xml) {
    const pr = parser(xml);
    const seqs = [];
    for (const s of pr.uid.values()) {
      if (s.tag !== "Sequence") continue;
      const items = [];
      // Trilhas de vídeo da sequência -> itens.
      const groups = [...s.body.matchAll(/<Second ObjectRef="(\d+)"/g)].map((m) => pr.obj.get(m[1])).filter((g) => g && g.tag === "VideoTrackGroup");
      let w = 0, h = 0;
      for (const g of groups) {
        const fr = /<FrameRect>(\d+),(\d+),(\d+),(\d+)</.exec(g.body);
        if (fr) (w = Number(fr[3])), (h = Number(fr[4]));
        for (const t of g.body.matchAll(/<Track Index="\d+" ObjectURef="([^"]+)"/g)) {
          const tr = pr.uid.get(t[1]);
          if (!tr) continue;
          for (const ti of tr.body.matchAll(/<TrackItem Index="\d+" ObjectRef="(\d+)"/g)) {
            const it = pr.obj.get(ti[1]);
            if (!it) continue;
            const chain = pr.obj.get(ref(it.body, "Components") || "");
            const sub = pr.obj.get(ref(it.body, "SubClip") || "");
            if (!chain) continue;
            let ctl = null, scale = 100;
            for (const c of chain.body.matchAll(/<Component Index="\d+" ObjectRef="(\d+)"/g)) {
              const co = pr.obj.get(c[1]);
              if (!co) continue;
              const mn = tag(co.body, "MatchName");
              if (mn === "AE.ADBE Capsule") ctl = controls(pr, c[1]);
              else if (mn === "AE.ADBE Motion") {
                for (const m of co.body.matchAll(/<Param Index="\d+" ObjectRef="(\d+)"/g)) {
                  const p = pr.obj.get(m[1]);
                  if (p && tag(p.body, "Name") === "Scale") {
                    const v = tag(p.body, "StartKeyframe") || tag(p.body, "CurrentValue") || "100";
                    scale = parseFloat(v.includes(",") ? v.split(",")[1] : v) || 100;
                  }
                }
              }
            }
            const texts = ctl ? ctl.filter((c) => c.type === "text").length : 0;
            if (!texts) continue;
            const start = Number(tag(it.body, "Start") || 0) / TK;
            const end = Number(tag(it.body, "End") || 0) / TK;
            items.push({ start, end, name: (sub && tag(sub.body, "Name")) || "Texto", lines: texts, scale, controls: ctl });
          }
        }
      }
      if (items.length) seqs.push({ seq: tag(s.body, "Name") || "", seqId: s.id, w, h, items: items.sort((a, b) => a.start - b.start) });
    }
    return seqs;
  };

  api.load = function (file) {
    const fs = req("fs");
    const buf = fs.readFileSync(file);
    const xml = (buf[0] === 0x1f ? req("zlib").gunzipSync(buf) : buf).toString("utf8");
    const seqs = api.parse(xml);
    // A sequência "TEXTO VIRAL" manda; sem ela, a que tiver mais textos.
    const s = seqs.find((x) => /texto ?viral/i.test(x.seq)) || seqs.sort((a, b) => b.items.length - a.items.length)[0];
    if (!s) throw new Error("Não achei textos (MOGRT) nesse projeto. Salve o projeto no Premiere e tente de novo.");
    const count = {};
    s.items.forEach((it) => {
      const g = Math.min(3, it.lines);
      it.lines = g;
      it.group = g === 1 ? "1 linha" : g + " linhas";
      it.n = count[g] = (count[g] || 0) + 1;
      it.id = "lib-" + g + "-" + Math.round(it.start * 100);
    });
    return Object.assign({ file }, s);
  };

  /*
   * Cópia do projeto com outras fontes nos textos (só para gerar as miniaturas; o projeto da pessoa não muda).
   * fonts: { pid: nomePostScript }. Todo texto passa a ter o valor escrito nele, sem depender do repetido.
   */
  api.withFonts = function (file, out, fonts) {
    const fs = req("fs");
    const zlib = req("zlib");
    const buf = fs.readFileSync(file);
    let xml = (buf[0] === 0x1f ? zlib.gunzipSync(buf) : buf).toString("utf8");
    const pr = parser(xml);
    xml = xml.replace(/^\t<ArbVideoComponentParam ObjectID="(\d+)"[^>]*>[\s\S]*?^\t<\/ArbVideoComponentParam>/gm, (full, id) => {
      const m = /<StartKeyframeValue Encoding="base64"(?: BinaryHash="([^"]*)")?[^>]*?(?:\/>|>([^<]*)<\/StartKeyframeValue>)/.exec(full);
      if (!m) return full;
      const data = (m[2] || "").trim() || pr.bin.get(m[1]);
      if (!data) return full;
      let nd = data;
      if (fonts[id]) {
        const raw = Buffer.from(data, "base64");
        const t = raw.toString("utf16le");
        const nt = t.replace(/"fontEditValue":\[[^\]]*\]/, () => '"fontEditValue":[' + JSON.stringify(fonts[id]) + "]");
        if (nt !== t) nd = Buffer.from(nt, "utf16le").toString("base64");
      }
      const hash = req("crypto").randomUUID();
      return full.replace(m[0], () => '<StartKeyframeValue Encoding="base64" BinaryHash="' + hash + '">' + nd + "</StartKeyframeValue>");
    });
    fs.writeFileSync(out, zlib.gzipSync(Buffer.from(xml, "utf8")));
  };

  // ---------------------------------------------------------------- nomes internos (PostScript) das fontes

  function fontName(fs, file) {
    const fd = fs.openSync(file, "r");
    try {
      const rd = (off, len) => {
        const b = Buffer.alloc(len);
        fs.readSync(fd, b, 0, len, off);
        return b;
      };
      const h = rd(0, 12);
      const sig = h.readUInt32BE(0);
      if (sig !== 0x00010000 && sig !== 0x4f54544f && sig !== 0x74727565) return null;
      const n = h.readUInt16BE(4);
      const dir = rd(12, n * 16);
      const t = {};
      for (let i = 0; i < n; i++) t[dir.toString("latin1", i * 16, i * 16 + 4)] = [dir.readUInt32BE(i * 16 + 8), dir.readUInt32BE(i * 16 + 12)];
      if (!t.name) return null;
      const nm = rd(t.name[0], Math.min(t.name[1], 200000));
      const so = nm.readUInt16BE(4);
      const out = {};
      for (let i = 0; i < nm.readUInt16BE(2); i++) {
        const o = 6 + i * 12;
        if (nm.readUInt16BE(o) !== 3) continue;
        const id = nm.readUInt16BE(o + 6);
        if (![1, 2, 6, 16].includes(id)) continue;
        const b = Buffer.from(nm.slice(so + nm.readUInt16BE(o + 10), so + nm.readUInt16BE(o + 10) + nm.readUInt16BE(o + 8)));
        const s = b.swap16().toString("utf16le");
        if (out[id] == null || nm.readUInt16BE(o + 4) === 0x409) out[id] = s;
      }
      let w = 400, italic = false;
      if (t["OS/2"]) {
        const os2 = rd(t["OS/2"][0], 64);
        w = os2.readUInt16BE(4);
        italic = !!(os2.readUInt16BE(62) & 1);
      }
      return { family: out[16] || out[1], legacy: out[1], ps: out[6], w, italic };
    } finally {
      fs.closeSync(fd);
    }
  }
  let psCache = null;
  // Map "família|peso" (minúsculas) -> nome PostScript; e byPs: nome -> { family, w }.
  api.psFonts = function () {
    if (psCache) return psCache;
    const map = new Map();
    const byPs = new Map();
    const fs = req("fs");
    const path = req("path");
    const dirs = [path.join(process.env.WINDIR || "C:\\Windows", "Fonts"), path.join(process.env.LOCALAPPDATA || "", "Microsoft", "Windows", "Fonts")];
    for (const d of dirs) {
      let l = [];
      try {
        l = fs.readdirSync(d);
      } catch {}
      for (const f of l) {
        if (!/\.(ttf|otf)$/i.test(f)) continue;
        try {
          const n = fontName(fs, path.join(d, f));
          if (!n || !n.ps || !n.family) continue;
          if (!byPs.has(n.ps)) byPs.set(n.ps, { family: n.family, w: n.w });
          if (n.italic) continue;
          for (const fam of [n.family, n.legacy]) if (fam && !map.has((fam + "|" + n.w).toLowerCase())) map.set((fam + "|" + n.w).toLowerCase(), n.ps);
        } catch {}
      }
    }
    return (psCache = { map, byPs });
  };
  api.ps = function (family, weight) {
    const { map } = api.psFonts();
    const f = String(family).toLowerCase();
    const exact = map.get(f + "|" + (weight || 400));
    if (exact) return exact;
    let best = null;
    for (const [k, v] of map) {
      const [fam, w] = k.split("|");
      if (fam === f && (!best || Math.abs(w - weight) < Math.abs(best[0] - weight))) best = [Number(w), v];
    }
    return best ? best[1] : "";
  };

  root.TextLib = req ? api : null;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
