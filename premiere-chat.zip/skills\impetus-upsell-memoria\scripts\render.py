#!/usr/bin/env python
"""Etapa 3: renderiza o upsell a partir de projeto.json (formato em references/formato-projeto.md).

python render.py projeto.json --check                     confere roteiro x transcrição e lista os blocos
python render.py projeto.json --frames 12.3,45 pasta       prints de teste (f_<tempo>.jpg)
python render.py projeto.json --full saida.mp4 [--range a,b]   vídeo sem áudio
"""
import json
import os
import re
import subprocess
import sys
import unicodedata

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
CFG_PATH = sys.argv[1]
CFG = json.load(open(CFG_PATH, encoding="utf-8"))
BASE = os.path.dirname(os.path.abspath(CFG_PATH))
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAE = CFG.get("mae", os.path.dirname(BASE))


def caminho(p, pasta=None):
    if os.path.isabs(p):
        return p
    for b in ([pasta] if pasta else []) + [BASE, MAE, os.path.join(MAE, "Inserts")]:
        c = os.path.join(b, p)
        if os.path.exists(c):
            return c
    return os.path.join(MAE, p)


W, H, FPS = 1080, 1350, 24
SRC = caminho(CFG.get("decupado", "decupado.mp4"))
SEGS = json.load(open(caminho("segmentos.json"), encoding="utf-8"))
PAL = json.load(open(caminho("palavras.json"), encoding="utf-8"))
DUR = SEGS[-1]["tl_out"]
N = int(round(DUR * FPS))


def achar_fonte(nome):
    for d in (os.path.expanduser("~/AppData/Local/Microsoft/Windows/Fonts"), "C:/Windows/Fonts"):
        p = os.path.join(d, nome)
        if os.path.exists(p):
            return p
    raise SystemExit("Fonte não encontrada: " + nome)


# ---------- estilo (valores medidos na referência aprovada; ver references/estilo-aprovado.md) ----------
E = {
    "leg_fonte": "Poppins-SemiBold.otf", "leg_tam": 60, "leg_y": 1194, "leg_caixa": (18, 18, 18), "leg_opac": 0.52,
    "leg_pad_x": 22, "leg_pad_y": 12, "leg_raio": 14, "leg_max_px": 900,
    "dest_fonte": "Anton-Regular.ttf", "dest_fonte_peq": "Poppins-SemiBold.otf", "dest_peq_rel": 0.5, "dest_tam": 190, "dest_y": 670, "dest_max_px": 960,
    "dest_blur": 30, "dest_escurecer": 0.55, "dest_rampa": 0.18,
    "amarelo": (238, 255, 45), "verde_neon": (57, 255, 20), "amarelo_neon": (240, 255, 60),
    "nome_fonte": "Poppins-Bold.otf", "nome_tam": 64, "nome_barra": (242, 154, 14),
    "vinheta": 0.72,
    # ---- tom dramático (UPsell Memória; ver references/estilo-memoria.md) ----
    "sat_padrao": 1.0,        # saturação de todo insert sem "cor" (1.0 = original)
    "sat_drama": 0.5,         # "cor": "50" -> 50 % de saturação
    "grao": 0.04,             # granulado em todo o vídeo (desvio do ruído, 0..1 da escala 255); 0 desliga
    "grao_drama": 0.065,       # granulado nos trechos "drama"
    "vinheta_drama": 0.85,    # vinheta nos trechos "drama"
    "vhs_desloc": 3,          # VHS: separação de cor vermelho/azul em px
    "vhs_linhas": 0.05,       # VHS: escurecimento das linhas horizontais
    "vhs_tremor": 2,          # VHS: tremor horizontal em px
    "cartao_escala": 0.82, "cartao_raio": 34, "cartao_fundo_blur": 30, "cartao_fundo_escurecer": 0.45,
    "fade_preto": [0.5, 0.83],  # mergulho no preto: desce 0,5 s, volta 0,83 s (transição "Graphic" com Tint do Memopower)
    # cores das palavras-chave do destaque: amarelo = atenção e urgência (padrão), verde = benefício/resultado.
    # vermelho existe, mas o usuário achou vermelho demais no v2: use só se ele pedir.
    "vermelho": (255, 70, 70), "verde": (105, 255, 95), "vermelho_neon": (255, 55, 55),
    # brilho suave atrás do destaque e animação (entra 115%->100% com desfoque em 0,25 s, cresce 3% parado, sai em 0,10 s)
    "dest_glow": 14, "dest_glow_opac": 0.5, "dest_in": 0.25, "dest_in_escala": 1.15, "dest_in_blur": 8, "dest_cresce": 0.03, "dest_out": 0.10,
    # destaque de impacto (modo DI): maior, contorno, vem de 220% com desfoque horizontal, tranco no fundo ao assentar
    "imp_tam": 210, "imp_max_px": 960, "imp_glow": 18, "imp_glow_opac": 0.55, "imp_in": 0.25, "imp_in_escala": 2.2,
    "imp_escurecer": 0.50, "imp_tranco": 0.035,
    # zoom suave do apresentador (100% -> 106% com aceleração e desaceleração) nos trechos de "zoom_suave"
    "zoom_suave": 0.06,
    # preço em neon: acende letra por letra piscando em 0,35 s, pop leve, sai em fade de 0,15 s
    "neon_acende": 0.35, "neon_out": 0.15,
    # mockup: centralizado (y 0,44) enquanto não tem preço; sobe para a posição alta em 0,45 s quando o preço entra
    "mock_centro": 0.44, "mock_sobe": 0.45, "brilho_potes": 0.45, "brilho_intervalo": 3.5,
}
E.update(CFG.get("estilo", {}))
FONTES = {}


def fonte(nome, tam):
    k = (nome, tam)
    if k not in FONTES:
        FONTES[k] = ImageFont.truetype(achar_fonte(nome), tam)
    return FONTES[k]


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9%€]", "", s)


# ---------- roteiro: blocos alinhados com as palavras da transcrição ----------
TROCAS = {(norm(a), norm(b)) for a, b in CFG.get("trocas", [])}
ROT = json.load(open(caminho(CFG.get("roteiro", "roteiro.json")), encoding="utf-8"))
blocos = []
erros = []
pi = 0
for bi, (modo, txt) in enumerate(ROT):
    linhas = []
    for ln in txt.split(" / "):
        m = re.match(r"^([wygrv]):(.*)$", ln)
        linhas.append((m.group(1), m.group(2)) if m else ("w", ln))
    ini = fim = None
    t_linhas = []  # instante em que cada linha começa a ser falada (cartão misto aparece palavra por palavra)
    for _, l in linhas:
        t_l = None
        for t in l.split():
            t = re.sub(r"^#[wyrv]", "", t)  # cor da palavra (#r vermelho, #v verde, #y amarelo)
            mm = re.match(r"^(.*)\{(\d+)\}$", t)
            if t.startswith("+"):
                continue
            cons = int(mm.group(2)) if mm else 1
            base = mm.group(1) if mm else t
            if pi >= len(PAL):
                erros.append(f"bloco {bi} '{txt}': acabou a transcrição em '{t}'")
                break
            alvo = "".join(norm(PAL[pi + k][2]) for k in range(cons) if pi + k < len(PAL))
            if norm(base) != alvo and (norm(base), alvo) not in TROCAS:
                erros.append(f"bloco {bi}: roteiro '{base}' x transcrição '{' '.join(PAL[pi + k][2] for k in range(cons))}' em {PAL[pi][0]:.2f}s")
            if ini is None:
                ini = PAL[pi][0]
            if t_l is None:
                t_l = PAL[pi][0]
            fim = PAL[pi + cons - 1][1]
            pi += cons
        t_linhas.append(t_l)
    if ini is None:
        ini = blocos[-1]["fim"] if blocos else 0
        fim = ini + 0.4
    t_linhas = [x if x is not None else ini for x in t_linhas]
    linhas = [(c, l.replace("+", "")) for c, l in linhas]
    linhas = [(c, re.sub(r"\{\d+\}", "", l)) for c, l in linhas]
    blocos.append({"modo": modo, "linhas": linhas, "ini": ini, "fim": fim, "t_linhas": t_linhas})
if pi < len(PAL):
    erros.append(f"sobraram {len(PAL) - pi} palavras da transcrição a partir de '{PAL[pi][2]}' em {PAL[pi][0]:.2f}s")
# cada bloco fica até o próximo começar (no máximo 0,6 s depois da última palavra)
for i, b in enumerate(blocos):
    prox = blocos[i + 1]["ini"] if i + 1 < len(blocos) else DUR
    b["ate"] = min(prox, b["fim"] + 0.6) if prox - b["fim"] > 0.6 else prox
    b["ate"] = max(b["ate"], b["ini"] + 0.25)

# trechos de destaque: blocos D consecutivos formam um trecho (fundo desfocado do início ao fim)
TRECHOS_D = []
for b in blocos:
    if b["modo"].startswith("D"):
        if TRECHOS_D and abs(TRECHOS_D[-1][1] - b["ini"]) < 0.05:
            TRECHOS_D[-1][1] = b["ate"]
        else:
            TRECHOS_D.append([b["ini"], b["ate"], b["modo"] == "D!"])
BLOCOS_IMP = [b for b in blocos if b["modo"] == "DI"]


def desfoque_em(t):
    """0..1: quanto o fundo do apresentador está desfocado/escurecido."""
    r = E["dest_rampa"]
    v = 0.0
    for a, b, _ in TRECHOS_D:
        if a - r <= t <= b + r:
            v = max(v, min(1, (t - (a - r)) / r, ((b + r) - t) / r))
    return max(0.0, v)


# ---------- sprites de texto ----------
CACHE = {}


def sprite_legenda(txt):
    k = ("L", txt)
    if k in CACHE:
        return CACHE[k]
    tam = E["leg_tam"]
    f = fonte(E["leg_fonte"], tam)
    while f.getlength(txt) > E["leg_max_px"] and tam > 36:
        tam -= 2
        f = fonte(E["leg_fonte"], tam)
    asc, desc = f.getmetrics()
    tw = int(f.getlength(txt))
    # caixa com altura fixa (97 px na referência), largura pelo texto
    bh = int(round(97 * tam / 60))
    bw = tw + 2 * E["leg_pad_x"]
    im = Image.new("RGBA", (bw + 20, bh + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    a = int(255 * E["leg_opac"])
    d.rounded_rectangle([10, 10, 10 + bw, 10 + bh], E["leg_raio"], fill=E["leg_caixa"] + (a,))
    # sombra do texto
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ds = ImageDraw.Draw(sh)
    y = 10 + bh // 2
    ds.text((10 + E["leg_pad_x"] + 2, y + 3), txt, font=f, fill=(0, 0, 0, 200), anchor="lm")
    sh = sh.filter(ImageFilter.GaussianBlur(3))
    im = Image.alpha_composite(im, sh)
    d = ImageDraw.Draw(im)
    d.text((10 + E["leg_pad_x"], y), txt, font=f, fill=(255, 255, 255, 255), anchor="lm")
    CACHE[k] = im
    return im


# legenda de acompanhamento (tradução) no topo: só para o usuário revisar, não faz parte do padrão do cliente.
# projeto.json -> "legenda_topo": "legenda_ptbr.json" ([[inicio, fim, texto], ...]); render com --sem-topo tira.
LEG_TOPO = []
if CFG.get("legenda_topo") and "--sem-topo" not in sys.argv:
    LEG_TOPO = json.load(open(caminho(CFG["legenda_topo"]), encoding="utf-8"))


def sprite_topo(txt):
    k = ("T", txt)
    if k in CACHE:
        return CACHE[k]
    f = fonte(E["leg_fonte"], 34)
    linhas, cur = [], ""
    for w in txt.split():
        if cur and f.getlength(cur + " " + w) > 940:
            linhas.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    linhas.append(cur)
    lh = 46
    bw = int(max(f.getlength(l) for l in linhas)) + 44
    bh = lh * len(linhas) + 24
    im = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, bw - 1, bh - 1], 14, fill=(0, 0, 0, 165))
    for i, l in enumerate(linhas):
        d.text((bw / 2, 12 + lh * i + lh / 2), l, font=f, fill=(255, 255, 255, 255), anchor="mm")
    CACHE[k] = im
    return im


def desenhar_topo(fr, t):
    for i, (a, b, txt) in enumerate(LEG_TOPO):
        fim = LEG_TOPO[i + 1][0] if i + 1 < len(LEG_TOPO) and LEG_TOPO[i + 1][0] - b < 0.8 else b + 0.3
        if a <= t < fim:
            spr = sprite_topo(txt)
            colar(fr, spr, W / 2, 34 + spr.height / 2)
            return


def cor_rgb(c):
    return {"y": E["amarelo"], "r": E["vermelho"], "v": E["verde"]}.get(c, (255, 255, 255))


def sprite_destaque(linhas, impacto=False):
    """Destaque em Anton com sombra e brilho suave (cartão com cor: branco em Poppins SemiBold, cor em Anton). Linhas: (cor, texto).
    Cor da linha: 'w' branco, 'y' amarelo (atenção), 'r' vermelho (perigo/urgência), 'v' verde (benefício), 'g' pequeno Poppins.
    Palavra com '#r', '#v', '#y' ou '#w' na frente troca a cor só dela.
    Devolve lista [(sprite, deslocamento_y_do_centro)] (uma por linha, para o cartão misto animar linha a linha)."""
    k = ("D", tuple(linhas), impacto)
    if k in CACHE:
        return CACHE[k]
    partes = []
    # cartão misto (linha pequena + palavra grande, como "Lesen Sie das / NOCH EINMAL / in Ruhe"): tudo maior
    misto = any(c == "g" for c, _ in linhas)
    # cartão com linha colorida (amarelo/verde/vermelho): a linha toda branca vira Poppins SemiBold menor, em minúsculas;
    # o resto fica em Anton caixa alta (pedido do usuário no v3)
    tem_cor = any(c in "yrv" for c, _ in linhas) or any(re.match(r"^#[yrv]", w) for _, t in linhas for w in t.split())
    for cor, txt in linhas:
        palavras = []
        for w in txt.split():
            m = re.match(r"^#([wyrv])(.*)$", w)
            palavras.append((m.group(2), m.group(1)) if m else (w, cor))
        if cor == "g":
            f = fonte(E["dest_fonte_peq"], E.get("misto_peq_tam", 92))
            partes.append(([(w, "w" if c == "g" else c, f) for w, c in palavras], f.size * 0.95))
            continue
        tam = E.get("misto_grande_tam", 270) if misto else (E["imp_tam"] if impacto else E["dest_tam"])
        maxpx = E["imp_max_px"] if impacto else E["dest_max_px"]

        def montar_linha(tam):
            fg = fonte(E["dest_fonte"], tam)
            fp = fonte(E["dest_fonte_peq"], int(tam * E["dest_peq_rel"]))
            # linha que mistura branco e cor ("et NE CLIQUEZ PAS") fica toda em Anton; Poppins só na linha toda branca
            # de um cartão que tem outra linha colorida ("UNIQUEMENT" / "sur cette page")
            peq = tem_cor and all(c == "w" for _, c in palavras)
            return [(w.lower(), c, fp) if peq else (w.upper(), c, fg) for w, c in palavras]

        pl = montar_linha(tam)
        while sum(f.getlength(w + " ") for w, _, f in pl) > maxpx and tam > 60:
            tam -= 4
            pl = montar_linha(tam)
        caps = [-f.getbbox("H", anchor="ls")[1] for _, _, f in pl]
        partes.append((pl, max(caps) * 1.3))
    glow_r = E["imp_glow"] if impacto else E["dest_glow"]
    m = int(glow_r * 2.5) + 30
    out = []
    alturas = [int(h) for _, h in partes]
    y_ac = -sum(alturas) / 2
    for (palavras, _), h in zip(partes, alturas):
        cap = max(-f.getbbox("H", anchor="ls")[1] for _, _, f in palavras)
        larg_txt = sum(f.getlength(w) for w, _, f in palavras) + sum(f.getlength(" ") for _, _, f in palavras[:-1])
        larg, alt = int(larg_txt) + 2 * m, h + 2 * m
        base = alt / 2 + cap / 2  # todas as palavras na mesma linha de base
        txt_l = Image.new("RGBA", (larg, alt), (0, 0, 0, 0))
        sh = Image.new("RGBA", (larg, alt), (0, 0, 0, 0))
        d, ds = ImageDraw.Draw(txt_l), ImageDraw.Draw(sh)
        x = m
        for w, c, f in palavras:
            rgb = cor_rgb(c)
            if impacto:  # contorno escuro fino para mais contraste
                d.text((x, base), w, font=f, fill=rgb + (255,), anchor="ls", stroke_width=3, stroke_fill=(20, 20, 20, 255))
            else:
                d.text((x, base), w, font=f, fill=rgb + (255,), anchor="ls")
            ds.text((x + 4, base + 6), w, font=f, fill=(0, 0, 0, 255 if impacto else 230), anchor="ls")
            x += f.getlength(w) + f.getlength(" ")
        sh = sh.filter(ImageFilter.GaussianBlur(10 if impacto else 7))
        # brilho suave da própria cor do texto (blur 14 px a 50%)
        glow = txt_l.filter(ImageFilter.GaussianBlur(glow_r))
        ga = np.asarray(glow, dtype=np.float32).copy()
        ga[..., 3] *= E["imp_glow_opac"] if impacto else E["dest_glow_opac"]
        glow = Image.fromarray(np.clip(ga, 0, 255).astype(np.uint8))
        im = Image.alpha_composite(sh, glow)
        im = Image.alpha_composite(im, txt_l)
        out.append((im, y_ac + h / 2))
        y_ac += h
    CACHE[k] = out
    return out


def sprite_neon(txt, cor):
    k = ("N", txt, cor)
    if k in CACHE:
        return CACHE[k]
    c = {"verde": E["verde_neon"], "vermelho": E["vermelho_neon"]}.get(cor, E["amarelo_neon"])
    f = fonte("Poppins-Bold.otf", 170)
    tw = int(f.getlength(txt))
    im = Image.new("RGBA", (tw + 160, 300), (0, 0, 0, 0))
    x0 = im.width / 2 - f.getlength(txt) / 2
    CACHE[("Nlim", txt)] = [x0 + f.getlength(txt[:i]) for i in range(len(txt) + 1)]  # bordas de cada letra (acender letra a letra)
    base = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    d.text((im.width // 2, 150), txt, font=f, fill=c + (255,), anchor="mm", stroke_width=6, stroke_fill=c + (255,))
    glow1 = base.filter(ImageFilter.GaussianBlur(28))
    glow2 = base.filter(ImageFilter.GaussianBlur(10))
    nucleo = Image.new("RGBA", im.size, (0, 0, 0, 0))
    dn = ImageDraw.Draw(nucleo)
    claro = tuple(int(v + (255 - v) * 0.75) for v in c)
    dn.text((im.width // 2, 150), txt, font=f, fill=(0, 0, 0, 0), anchor="mm", stroke_width=4, stroke_fill=claro + (255,))
    im = Image.alpha_composite(im, glow1)
    im = Image.alpha_composite(im, glow1)
    im = Image.alpha_composite(im, glow2)
    oco = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(oco).text((im.width // 2, 150), txt, font=f, fill=tuple(int(v * 0.30) for v in c) + (200,), anchor="mm")
    im = Image.alpha_composite(im, oco)
    im = Image.alpha_composite(im, nucleo)
    CACHE[k] = im
    return im


def sprite_nome(l1, l2):
    k = ("NOME", l1, l2)
    if k in CACHE:
        return CACHE[k]
    f1 = fonte(E["nome_fonte"], E["nome_tam"])
    f2 = fonte("Poppins-SemiBold.otf", 34)
    w1 = int(f1.getlength(l1))
    w2 = int(f2.getlength(l2)) if l2 else 0
    larg = max(w1, w2) + 120
    im = Image.new("RGBA", (larg, 190), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rectangle([20, 62, 20 + w1 + 50, 62 + 46], fill=E["nome_barra"] + (255,))
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ds = ImageDraw.Draw(sh)
    ds.text((33, 50 + 4), l1, font=f1, fill=(0, 0, 0, 170), anchor="lm")
    if l2:
        ds.text((33, 140 + 3), l2, font=f2, fill=(0, 0, 0, 200), anchor="lm")
    sh = sh.filter(ImageFilter.GaussianBlur(4))
    im = Image.alpha_composite(im, sh)
    d = ImageDraw.Draw(im)
    d.text((30, 50), l1, font=f1, fill=(255, 255, 255, 255), anchor="lm")
    if l2:
        d.text((30, 140), l2, font=f2, fill=(255, 255, 255, 255), anchor="lm")
    CACHE[k] = im
    return im


PM = {}


def pm(spr):
    """Sprite PIL -> matriz RGBA float 0..1 com cor pré-multiplicada (desfoque e escala sem borda escura)."""
    if isinstance(spr, np.ndarray):
        return spr
    k = id(spr)
    if k not in PM:
        a = np.asarray(spr, dtype=np.float32) / 255.0
        PM[k] = (np.dstack([a[..., :3] * a[..., 3:4], a[..., 3:4]]), spr)
    return PM[k][0]


def colar(fr, spr, cx, cy, alfa=1.0, escala=1.0, blur=0.0, blur_h=0.0):
    """Cola sprite (PIL RGBA ou matriz pré-multiplicada) centralizado em (cx, cy) no quadro float32 RGB.
    blur = desfoque gaussiano; blur_h = desfoque de movimento horizontal (px)."""
    if alfa <= 0.003:
        return
    a = pm(spr)
    if abs(escala - 1.0) > 0.002:
        a = cv2.resize(a, (max(1, int(a.shape[1] * escala)), max(1, int(a.shape[0] * escala))),
                       interpolation=cv2.INTER_AREA if escala < 1 else cv2.INTER_LINEAR)
    if blur > 0.3:
        a = cv2.GaussianBlur(a, (0, 0), blur)
    if blur_h > 1.5:
        a = cv2.blur(a, (int(blur_h) * 2 + 1, 1))
    h, w = a.shape[:2]
    x0, y0 = int(round(cx - w / 2)), int(round(cy - h / 2))
    sx0, sy0 = max(0, -x0), max(0, -y0)
    x0c, y0c, x1c, y1c = max(0, x0), max(0, y0), min(W, x0 + w), min(H, y0 + h)
    if x1c <= x0c or y1c <= y0c:
        return
    a = a[sy0:sy0 + y1c - y0c, sx0:sx0 + x1c - x0c]
    reg = fr[y0c:y1c, x0c:x1c]
    reg[:] = reg * (1 - a[..., 3:4] * alfa) + a[..., :3] * 255 * alfa


def clamp01(x):
    return max(0.0, min(1.0, x))


def ease_out(p, pot=3):
    return 1 - (1 - clamp01(p)) ** pot


def ease_in_out(p):
    p = clamp01(p)
    return 3 * p * p - 2 * p * p * p


def ease_out_back(p, s=1.6):
    p = clamp01(p) - 1
    return 1 + (s + 1) * p ** 3 + s * p ** 2


# ---------- apresentador: plano aberto; zoom suave (sem troca seca) nos trechos de "zoom_suave" ----------
FOCO = {"lisa": (0.30, 0.20), "lucile": (0.76, 0.22), "depoimento": (0.5, 0.30)}
FOCO.update({k: tuple(v) for k, v in CFG.get("foco", {}).items()})
ZOOM_SUAVE = CFG.get("zoom_suave", [])  # [[inicio, fim]] (100% -> 106%) ou [[inicio, fim, zoom_ini, zoom_fim]], sempre com aceleração e desaceleração


def seg_em(t):
    for i, s in enumerate(SEGS):
        if t < s["tl_out"]:
            return i
    return len(SEGS) - 1


def zoom_em(t):
    for a, b, *z in CFG.get("zoom_fixo", []):
        if a <= t < b:
            return z[0]
    for zs in ZOOM_SUAVE:
        a, b = zs[0], zs[1]
        if a <= t < b:
            p = ease_in_out((t - a) / max(0.01, b - a))
            if len(zs) >= 4:  # [inicio, fim, zoom_ini, zoom_fim]: zoom in (1.0 -> 1.07) ou zoom out (1.07 -> 1.0)
                return zs[2] + (zs[3] - zs[2]) * p
            amp = zs[2] if len(zs) > 2 else E["zoom_suave"]
            return 1 + amp * p
    return 1.0


def enquadrar(fr, t):
    i = seg_em(t)
    z = zoom_em(t)
    if abs(z - 1.0) < 0.001:
        return fr
    fx, fy = FOCO.get(SEGS[i]["orador"], (0.5, 0.25))
    cw, ch = W / z, H / z
    x0 = min(max(fx * W - cw / 2, 0), W - cw)
    y0 = min(max(fy * H - ch * 0.30, 0), H - ch)
    M = np.array([[z, 0, -x0 * z], [0, z, -y0 * z]], np.float32)
    return cv2.warpAffine(fr, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


# ---------- inserts (vídeo ou foto, cobrindo a tela) ----------
EXT_FOTO = (".png", ".jpg", ".jpeg", ".webp")


class Leitor:
    def __init__(self, d):
        self.d = d
        self.path = caminho(d["arquivo"])
        self.foto = self.path.lower().endswith(EXT_FOTO)
        self.p = None
        self.img = None
        self.f_atual = -1
        self.ult = None

    def _cobrir(self, w0, h0, margem):
        s = max(W / w0, H / h0) * margem
        return int(round(w0 * s / 2) * 2), int(round(h0 * s / 2) * 2)

    def quadro(self, t):
        d = self.d
        push = d.get("push", [1.0, 1.06])
        k = (t - d["inicio"]) / max(0.01, d["fim"] - d["inicio"])
        z = push[0] + (push[1] - push[0]) * min(max(k, 0), 1)
        zmax = max(push) * d.get("escala", 1.0)
        if self.foto:
            if self.img is None:
                im = Image.open(self.path).convert("RGB")
                w2, h2 = self._cobrir(im.width, im.height, zmax)
                self.img = np.asarray(im.resize((w2, h2), Image.LANCZOS), dtype=np.float32)
            base = self.img
        else:
            f = int(round((t - d["inicio"]) * FPS * d.get("vel", 1.0)))
            if self.p is None:
                r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:stream_side_data=rotation",
                                    "-of", "json", self.path], stdout=subprocess.PIPE)
                st = json.loads(r.stdout)["streams"][0]
                w0, h0 = st["width"], st["height"]
                rot = abs(int(float((st.get("side_data_list") or [{}])[0].get("rotation", 0))))
                if rot in (90, 270):
                    w0, h0 = h0, w0
                self.w2, self.h2 = self._cobrir(w0, h0, zmax)
                vel = d.get("vel", 1.0)
                vf = f"setpts=PTS/{vel},fps={FPS},scale={self.w2}:{self.h2}:flags=lanczos"
                if d.get("loop"):
                    args = ["-stream_loop", "-1"]
                else:
                    args = []
                self.p = subprocess.Popen(["ffmpeg", "-v", "error"] + args + ["-ss", f"{d.get('clip_in', 0):.3f}", "-i", self.path, "-vf", vf, "-an",
                                          "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=10 ** 8)
            while self.f_atual < f:
                buf = self.p.stdout.read(self.w2 * self.h2 * 3)
                if len(buf) < self.w2 * self.h2 * 3:
                    break
                self.ult = np.frombuffer(buf, np.uint8).reshape(self.h2, self.w2, 3)
                self.f_atual += 1
            if self.ult is None:
                return None
            base = self.ult.astype(np.float32)
        hh, ww = base.shape[:2]
        z_rel = z * d.get("escala", 1.0) / zmax
        cw, ch = ww * z_rel, hh * z_rel  # tamanho visível na escala atual
        px, py = d.get("pos", [0.5, 0.5])
        cx, cy = ww * px, hh * py
        # recorte de W/z_rel x H/z_rel em torno do centro
        rw, rh = W * ww / cw, H * hh / ch
        x0 = min(max(cx - rw / 2, 0), ww - rw)
        y0 = min(max(cy - rh / 2, 0), hh - rh)
        s = W / rw
        M = np.array([[s, 0, -x0 * s], [0, s, -y0 * s]], np.float32)
        return cv2.warpAffine(base, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

    def fechar(self):
        if self.p:
            self.p.kill()


INSERTS = sorted(CFG.get("inserts", []), key=lambda d: d["inicio"])
LEITORES = {}


def insert_em(t):
    for i, d in enumerate(INSERTS):
        if d["inicio"] <= t < d["fim"]:
            return i, d
    return None, None


# ---------- tela de preço: fundo marrom, potes flutuando e preço em neon ----------
PRECO = CFG.get("tela_preco", [])
MOCKS = {}


def mock(arquivo, larg):
    k = (arquivo, larg)
    if k not in MOCKS:
        im = Image.open(caminho(arquivo)).convert("RGBA")
        bb = im.getbbox()
        im = im.crop(bb)
        h2 = int(im.height * larg / im.width)
        im = im.resize((larg, h2), Image.LANCZOS)
        sh = Image.new("RGBA", (im.width + 80, im.height + 80), (0, 0, 0, 0))
        a = im.split()[3].point(lambda v: int(v * 0.55))
        sombra = Image.new("RGBA", im.size, (0, 0, 0, 255))
        sombra.putalpha(a)
        sh.paste(sombra, (40 + 10, 40 + 22), sombra)
        sh = sh.filter(ImageFilter.GaussianBlur(16))
        sh.alpha_composite(im, (40, 40))
        # máscara só do pote (sem a sombra) e coordenada diagonal para a faixa de luz passar
        prod = np.zeros((sh.height, sh.width), np.float32)
        prod[40:40 + im.height, 40:40 + im.width] = np.asarray(im.split()[3], dtype=np.float32) / 255.0
        gy, gx = np.mgrid[0:sh.height, 0:sh.width].astype(np.float32)
        diag = (gx / sh.width + 0.35 * gy / sh.height) / 1.35
        MOCKS[k] = (sh, prod, diag)
    return MOCKS[k]


def mock_com_brilho(arquivo, larg, dt):
    """Mockup com uma faixa de luz passando pelos potes a cada 'brilho_intervalo' s (dt = tempo desde que o mockup entrou)."""
    sh, prod, diag = mock(arquivo, larg)
    ciclo = (dt - 0.6) % E["brilho_intervalo"] if dt >= 0.6 else -1
    if not (0 <= ciclo < 0.7) or E["brilho_potes"] <= 0:
        return sh
    u = -0.25 + 1.5 * ease_in_out(ciclo / 0.7)
    banda = np.exp(-((diag - u) / 0.06) ** 2) * E["brilho_potes"] * prod
    a = pm(sh).copy()
    a[..., :3] = np.minimum(a[..., :3] + banda[..., None], a[..., 3:4])
    return a


def ocupado_k(tp, t):
    """0 = mockup no centro, 1 = mockup no alto (tem preço ou um segundo mockup embaixo na tela)."""
    ints = [(p["inicio"], p["fim"]) for p in tp.get("precos", [])] + [(m["inicio"], m["fim"]) for m in tp.get("mockups", []) if m["pos"][1] > 0.5]
    d = E["mock_sobe"]
    k = 0.0
    for a, b in ints:
        k = max(k, min(clamp01((t - (a - d * 0.6)) / d), clamp01(((b + d * 0.4) - t) / d) if b < tp["fim"] - 0.05 else 1.0))
    return ease_in_out(k)


def neon_alfa_colunas(p, t, larg):
    """Acende letra por letra, piscando, como letreiro ligando (medido na referência: ~0,35 s)."""
    txt = p["texto"]
    lim = CACHE[("Nlim", txt)]
    n = len(txt)
    seq = [0.75, 0.15, 1.0, 0.35, 1.0]  # um valor por quadro
    passo = max(0.0, E["neon_acende"] - len(seq) / FPS) / max(1, n - 1)
    col = np.ones(larg, np.float32)
    for i in range(n):
        dt = t - (p["inicio"] + i * passo)
        q = int(dt * FPS) if dt >= 0 else -1
        v = 0.0 if q < 0 else (seq[q] if q < len(seq) else 1.0)
        xa = 0 if i == 0 else int(lim[i])
        xb = larg if i == n - 1 else int(lim[i + 1])
        col[xa:xb] = v
    return col


def tela_em(t):
    for tp in PRECO:
        if tp["inicio"] <= t < tp["fim"]:
            return tp
    return None


def desenhar_preco(fr, t):
    for tp in PRECO:
        if not (tp["inicio"] <= t < tp["fim"]):
            continue
        if tp is not tela_em(t):
            continue
        k_alto = ocupado_k(tp, t)
        for m in tp.get("mockups", []):
            if m["inicio"] <= t < m["fim"]:
                k = ease_out((t - m["inicio"]) / 0.3)
                bob = np.sin((t - m["inicio"]) * 2.2 + m.get("fase", 0)) * 10
                spr = mock_com_brilho(m["arquivo"], m.get("larg", 700), t - m["inicio"])
                y_alto = m["pos"][1]
                y = y_alto if y_alto > 0.5 else m.get("centro", E["mock_centro"]) + (y_alto - m.get("centro", E["mock_centro"])) * k_alto
                colar(fr, spr, m["pos"][0] * W, y * H + bob + (1 - k) * 60, alfa=k)
        for p in tp.get("precos", []):
            if p["inicio"] <= t < p["fim"]:
                spr = sprite_neon(p["texto"], p.get("cor", "verde"))
                a = pm(spr) * neon_alfa_colunas(p, t, spr.width)[None, :, None]
                esc = 0.94 + 0.06 * ease_out_back((t - p["inicio"]) / 0.3)
                saida = clamp01((p["fim"] - t) / E["neon_out"]) if p["fim"] < tp["fim"] - 0.05 or p.get("sai") else 1.0
                pos = p.get("pos", [0.5, 0.56])
                colar(fr, a, W * pos[0], H * pos[1], alfa=saida, escala=esc)


# ---------- vinheta e clarão ----------
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
rr = np.sqrt(((xx - W / 2) / (W * 0.62)) ** 2 + ((yy - H / 2) / (H * 0.62)) ** 2)
VIN = (1 - E["vinheta"] * np.clip((rr - 0.55) / 0.6, 0, 1) ** 1.6)[..., None].astype(np.float32)
VIN_DRAMA = (1 - E["vinheta_drama"] * np.clip((rr - 0.45) / 0.6, 0, 1) ** 1.4)[..., None].astype(np.float32)
FLASHES = CFG.get("flashes", [])


def clarao(fr, t):
    for c in FLASHES:
        tc = c if isinstance(c, (int, float)) else c["t"]
        if tc - 0.18 <= t <= tc + 0.32:
            a = (t - (tc - 0.18)) / 0.18 if t < tc else 1 - (t - tc) / 0.32
            a = max(0.0, min(1.0, a)) ** 1.2 * 0.92
            bl = cv2.GaussianBlur(fr, (0, 0), 25)
            fr[:] = fr * (1 - a) + (bl * 0.5 + 255 * 0.5) * a
            fr[:] = np.minimum(fr + 120 * a, 255)


# ---------- tom dramático: cor do insert, cartão, granulado, VHS ----------
def aplicar_cor(q, d):
    c = d.get("cor")
    sat = E["sat_padrao"] if c is None else (0.0 if c == "pb" else E["sat_drama"] if str(c) == "50" else float(c))
    if sat >= 0.999:
        return q
    g = (q[..., 0] * 0.299 + q[..., 1] * 0.587 + q[..., 2] * 0.114)[..., None]
    q = g + (q - g) * sat
    if c == "pb":  # P&B com contraste levemente maior, como filme antigo
        q = (q - 128) * 1.12 + 122
    return q


def em_cartao(q):
    """Insert em cartão arredondado sobre uma cópia dele mesmo desfocada e escurecida (Nested Sequence do Memopower)."""
    fundo = cv2.GaussianBlur(q, (0, 0), E["cartao_fundo_blur"]) * (1 - E["cartao_fundo_escurecer"])
    s = E["cartao_escala"]
    w2, h2 = int(W * s), int(H * s)
    peq = cv2.resize(q, (w2, h2), interpolation=cv2.INTER_AREA)
    m = np.zeros((h2, w2), np.uint8)
    r = E["cartao_raio"]
    cv2.rectangle(m, (r, 0), (w2 - r, h2), 255, -1)
    cv2.rectangle(m, (0, r), (w2, h2 - r), 255, -1)
    for cx, cy in ((r, r), (w2 - r, r), (r, h2 - r), (w2 - r, h2 - r)):
        cv2.circle(m, (cx, cy), r, 255, -1, cv2.LINE_AA)
    a = (cv2.GaussianBlur(m, (0, 0), 0.8).astype(np.float32) / 255)[..., None]
    x0, y0 = (W - w2) // 2, (H - h2) // 2
    sombra = cv2.GaussianBlur(np.pad(a[..., 0], ((y0, H - h2 - y0), (x0, W - w2 - x0))), (0, 0), 18)[..., None]
    fundo = fundo * (1 - 0.5 * sombra)
    reg = fundo[y0:y0 + h2, x0:x0 + w2]
    fundo[y0:y0 + h2, x0:x0 + w2] = reg * (1 - a) + peq * a
    return fundo


DRAMA = CFG.get("drama", [])  # [[inicio, fim]] ou [[inicio, fim, "vhs"]]: granulado e vinheta mais fortes; com "vhs" também cor separada, linhas e tremor
FADES = CFG.get("fade_preto", [])  # instantes em que a tela mergulha no preto e volta (troca de bloco dramático)
RNG = np.random.default_rng(7)


def drama_em(t):
    for d in DRAMA:
        if d[0] <= t < d[1]:
            return d
    return None


def granulado(fr, forca):
    if forca <= 0:
        return fr
    n = RNG.standard_normal((H // 2, W // 2)).astype(np.float32)
    n = cv2.resize(n, (W, H), interpolation=cv2.INTER_LINEAR)
    return fr + n[..., None] * (255 * forca)


LINHAS = (1 - E["vhs_linhas"] * (np.arange(H) % 4 < 2)).astype(np.float32)[:, None, None]


def vhs(fr, t):
    f = int(round(t * FPS))
    d = E["vhs_desloc"]
    out = fr.copy()
    out[..., 0] = np.roll(fr[..., 0], d, axis=1)
    out[..., 2] = np.roll(fr[..., 2], -d, axis=1)
    # tremor horizontal em faixas, mudando a cada 2 quadros
    rng = np.random.default_rng(f // 2)
    for _ in range(2):
        y = rng.integers(0, H - 40)
        hgt = rng.integers(6, 40)
        out[y:y + hgt] = np.roll(out[y:y + hgt], int(rng.integers(-E["vhs_tremor"] * 4, E["vhs_tremor"] * 4 + 1)), axis=1)
    # linha de tracking descendo a tela a cada ~4 s
    yb = int((t % 4.0) / 4.0 * (H + 80)) - 40
    if 0 <= yb < H - 12:
        out[yb:yb + 12] = out[yb:yb + 12] * 0.8 + 255 * 0.12
    return out * LINHAS


def fade_preto(fr, t):
    a, b = E["fade_preto"]
    for tc in FADES:
        if tc - a <= t < tc:
            k = (t - (tc - a)) / a
        elif tc <= t < tc + b:
            k = 1 - (t - tc) / b
        else:
            continue
        return fr * (1 - 0.92 * ease_in_out(clamp01(k)))
    return fr


# ---------- quadro final ----------
def fundo_em(t, fr_ap):
    i, d = insert_em(t)
    if d is not None and d.get("sobre_preco"):  # produto animado intercalado dentro da tela de preço
        if i not in LEITORES:
            LEITORES[i] = Leitor(d)
        q = LEITORES[i].quadro(t)
        if q is not None:
            return q.copy(), True
    for tp in PRECO:
        if tp["inicio"] <= t < tp["fim"]:
            if "fundo" not in LEITORES.setdefault("_fundos", {}):
                LEITORES["_fundos"]["fundo"] = Leitor({"arquivo": tp.get("fundo", "BG YELLOW.mp4"), "inicio": tp["inicio"], "fim": tp["fim"],
                                                       "push": [1.0, 1.0], "loop": True})
            q = LEITORES["_fundos"]["fundo"].quadro(t)
            fr = q.copy() if q is not None else np.full((H, W, 3), 70, np.float32)
            desenhar_preco(fr, t)
            return fr, True
    if d is not None:
        if i not in LEITORES:
            LEITORES[i] = Leitor(d)
        q = LEITORES[i].quadro(t)
        if q is not None:
            q = aplicar_cor(q.copy(), d)
            if d.get("cartao"):
                q = em_cartao(q)
            return q, True
    return enquadrar(fr_ap, t), False


def bloco_em(t):
    for b in blocos:
        if b["ini"] <= t < b["ate"]:
            return b
    return None


def anima_destaque(fr, b, t):
    """Entrada, permanência e saída do destaque (medido na referência Jellyglow)."""
    imp = b["modo"] == "DI"
    partes = sprite_destaque(b["linhas"], impacto=imp)
    dur = max(0.05, b["ate"] - b["ini"])
    d_out = min(E["dest_out"], dur * 0.25)
    saida = clamp01((b["ate"] - t) / d_out)
    cresce = 1 + E["dest_cresce"] * clamp01((t - b["ini"]) / dur)
    misto = any(c == "g" for c, _ in b["linhas"])
    for (spr, dy), (cor, _), t_l in zip(partes, b["linhas"], b["t_linhas"]):
        if misto:
            # cartão misto: cada linha entra quando é falada; linha pequena sobe com fade, palavra grande desliza da direita
            t_l = max(b["ini"], t_l - 0.04)
            if t < t_l:
                continue
            if cor == "g":
                p = ease_out((t - t_l) / 0.15)
                colar(fr, spr, W / 2, E["dest_y"] + dy + (1 - p) * 14, alfa=p * saida, escala=cresce)
            else:
                p = ease_out((t - t_l) / 0.14)
                colar(fr, spr, W / 2 + (1 - p) * 140, E["dest_y"] + dy, alfa=p * saida, escala=cresce, blur_h=(1 - p) * 30)
            continue
        if imp:
            d_in = min(E["imp_in"], dur * 0.6)
            p = (t - b["ini"]) / d_in
            e = ease_out(p, 4)
            esc = E["imp_in_escala"] - (E["imp_in_escala"] - 1) * e
            colar(fr, spr, W / 2, E["dest_y"] + dy * esc, alfa=clamp01(p / 0.35) * saida, escala=esc * cresce,
                  blur=3 * (1 - e), blur_h=70 * (1 - e))
        else:
            d_in = min(E["dest_in"], dur * 0.6)
            p = (t - b["ini"]) / d_in
            e = ease_out(p)
            esc = E["dest_in_escala"] - (E["dest_in_escala"] - 1) * e
            colar(fr, spr, W / 2, E["dest_y"] + dy * esc, alfa=clamp01(p / 0.6) * saida, escala=esc * cresce * (1 + 0.02 * (1 - saida)),
                  blur=E["dest_in_blur"] * (1 - e))


def tranco(fr, t):
    """Destaque de impacto: o fundo dá um tranco de zoom (3,5%) no instante em que o texto assenta."""
    for b in BLOCOS_IMP:
        tl = b["ini"] + min(E["imp_in"], (b["ate"] - b["ini"]) * 0.6)
        if tl <= t < tl + 0.25:
            z = 1 + E["imp_tranco"] * (1 - (t - tl) / 0.25) ** 2
            M = np.array([[z, 0, -(z - 1) * W / 2], [0, z, -(z - 1) * H / 2]], np.float32)
            return cv2.warpAffine(fr, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return fr


def render_frame(f, fr_ap):
    t = f / FPS
    fr, e_insert = fundo_em(t, fr_ap.astype(np.float32))
    k = desfoque_em(t)
    b = bloco_em(t)
    imp = b is not None and b["modo"] == "DI"
    forcar = any(a <= t <= b_ and fz for a, b_, fz in TRECHOS_D)
    if k > 0 and (not e_insert or forcar):
        bl = cv2.GaussianBlur(fr, (0, 0), E["dest_blur"] * k + 0.01)
        fr = bl * (1 - (1 - (E["imp_escurecer"] if imp else E["dest_escurecer"])) * k)
    elif k > 0:
        fr = fr * (1 - (0.45 if imp else 0.25) * k)
    fr = tranco(fr, t)
    dr = drama_em(t)
    if dr is not None and len(dr) > 2 and dr[2] == "vhs":
        fr = vhs(fr, t)
    fr *= VIN_DRAMA if dr is not None else VIN
    fr = granulado(fr, E["grao_drama"] if dr is not None else E["grao"])
    fr = fade_preto(fr, t)
    for nm in CFG.get("nomes", []):
        if nm["inicio"] <= t < nm["fim"]:
            a = min(1, (t - nm["inicio"]) / 0.2, (nm["fim"] - t) / 0.2)
            spr = sprite_nome(nm["linha1"], nm.get("linha2", ""))
            if nm.get("lado") == "direita":
                cx = W - 40 - spr.width / 2 + (1 - a) * 40 + 20
            else:
                cx = 70 + spr.width / 2 + (1 - a) * -40
            colar(fr, spr, cx, nm.get("y", 960), alfa=a)
    if b is not None:
        if b["modo"].startswith("D"):
            anima_destaque(fr, b, t)
        elif b["modo"] == "L":
            # legenda normal: pop rápido de 96% para 100% em 0,08 s
            p = clamp01((t - b["ini"]) / 0.08)
            colar(fr, sprite_legenda(" ".join(l for _, l in b["linhas"])), W / 2, E["leg_y"], escala=0.96 + 0.04 * p)
    clarao(fr, t)
    if LEG_TOPO:
        desenhar_topo(fr, t)
    return np.clip(fr, 0, 255).astype(np.uint8)


def ler_quadro(f):
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{f / FPS:.5f}", "-i", SRC, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                       stdout=subprocess.PIPE)
    return np.frombuffer(r.stdout, np.uint8).reshape(H, W, 3)


if __name__ == "__main__":
    a = sys.argv[2:]
    if "--check" in a:
        for i, b in enumerate(blocos):
            print(f"{i:3d} {b['ini']:7.2f}-{b['ate']:7.2f} {b['modo']:2s} {' / '.join(l for _, l in b['linhas'])}")
        print("\n".join(erros) or "ROTEIRO OK")
        print(f"duração {DUR:.2f}s, {len(blocos)} blocos, {sum(1 for b in blocos if b['modo'].startswith('D'))} destaques, {len(INSERTS)} inserts")
        longos = [b for b in blocos if b["modo"] == "L" and fonte(E["leg_fonte"], E["leg_tam"]).getlength(" ".join(l for _, l in b["linhas"])) > E["leg_max_px"]]
        for b in longos:
            print("LEGENDA LONGA:", b["ini"], b["linhas"])
        # proporção na tela e aparições curtas do apresentador entre inserts (regra: mínimo 2 s)
        tipo = []
        for f in range(N):
            t = f / FPS
            if insert_em(t)[1] is not None or any(tp["inicio"] <= t < tp["fim"] for tp in PRECO):
                tipo.append("I")
            else:
                tipo.append("P" if SEGS[seg_em(t)]["orador"] == "depoimento" else "E")
        n_i, n_e, n_p = tipo.count("I"), tipo.count("E"), tipo.count("P")
        print(f"PROPORÇÃO: inserts/preço {n_i / FPS:.1f}s ({100 * n_i / N:.0f}%), apresentadoras {n_e / FPS:.1f}s ({100 * n_e / N:.0f}%), "
              f"depoimento {n_p / FPS:.1f}s ({100 * n_p / N:.0f}%)")
        f = 0
        curtos = 0
        while f < N:
            g = f
            while g < N and tipo[g] != "I":
                g += 1
            if g > f and f > 0 and g < N and (g - f) / FPS < 2.0:
                print(f"APRESENTADOR CURTO ENTRE INSERTS: {f / FPS:.2f}s ({(g - f) / FPS:.2f}s)")
                curtos += 1
            f = g + 1 if g == f else g
        print(f"{curtos} aparições curtas")
        sys.exit(1 if erros else 0)
    if erros:
        print("\n".join(erros))
        print("Corrija o roteiro antes de renderizar.")
        sys.exit(1)
    if "--frames" in a:
        ts = [float(x) for x in a[a.index("--frames") + 1].split(",")]
        pasta = a[a.index("--frames") + 2]
        os.makedirs(pasta, exist_ok=True)
        for t in ts:
            f = int(round(t * FPS))
            LEITORES.clear()
            img = render_frame(f, ler_quadro(f))
            Image.fromarray(img).save(os.path.join(pasta, f"f_{t:08.2f}.jpg"), quality=92)
            print("print", t)
    elif "--full" in a:
        outp = a[a.index("--full") + 1]
        rng = (0, N)
        if "--range" in a:
            x, y = a[a.index("--range") + 1].split(",")
            rng = (int(float(x) * FPS), min(N, int(float(y) * FPS)))
        dec = subprocess.Popen(["ffmpeg", "-v", "error", "-ss", f"{rng[0] / FPS:.4f}", "-i", SRC, "-frames:v", str(rng[1] - rng[0]),
                                "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE, bufsize=10 ** 8)
        enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                                "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", outp], stdin=subprocess.PIPE)
        ultimo_ins = None
        for f in range(*rng):
            buf = dec.stdout.read(W * H * 3)
            if len(buf) < W * H * 3:
                break
            t = f / FPS
            i, _ = insert_em(t)
            if ultimo_ins is not None and i != ultimo_ins and ultimo_ins in LEITORES:
                LEITORES.pop(ultimo_ins).fechar()
            ultimo_ins = i
            enc.stdin.write(render_frame(f, np.frombuffer(buf, np.uint8).reshape(H, W, 3)).tobytes())
            if f % 240 == 0:
                print(f"{t:.1f}s / {rng[1] / FPS:.1f}s", flush=True)
        enc.stdin.close()
        enc.wait()
        print("OK", outp)
