# Regras do material ED (definidas pelo usuário em 23/11/2026)

Valem para todo vídeo editado com a skill Edição ED. São obrigatórias e vêm antes de qualquer gosto pessoal na escolha de insert.

## Regra 1 – Fala negativa sobre o homem → insert de "derrota" com tratamento dramático

**Quando aplicar:** sempre que a fala tratar de impotência ou de algo negativo sobre o homem. Gatilhos típicos (o material é em alemão):
- impotência e ereção fraca: *Impotenz, Erektionsstörung, erektile Dysfunktion, halbherzige Erektion, schlaff, weich, „mein Soldat ging in Rente", nicht mehr hart*;
- falhar na cama: *versagt, zu früh gekommen, vorzeitige Ejakulation, hat nicht geklappt, nach 2 Minuten fertig*;
- pênis pequeno: *klein, Mikropenis, 7 Zentimeter, zu kurz*;
- vergonha e perda: *meine Frau war enttäuscht, Scheidung, sie hat mich verlassen, sie hat gelacht, ich habe mich geschämt*;
- tentativas que falharam: *Pillen, Pumpen, Testosteron, nichts hat funktioniert*;
- idade e declínio: *nach 40/50 ging es bergab, Testosteron sinkt*.

**Insert obrigatório:** um dos dois tipos, nada além disso no trecho:
1. **homem triste ou frustrado**: na cama de costas para a parceira, sentado na beira da cama, mão no rosto, olhando para baixo, no banheiro, idoso abatido, consultório com notícia ruim;
2. **genitália masculina pequena ou mole** (pênis mole/pequeno, "soft dick", polegar para baixo).

Nada de pornô "de sucesso", mulher satisfeita, homem sorrindo ou produto nesses trechos. O pornô de desempenho volta só quando a fala vira para o resultado/solução.

**Tratamento obrigatório no insert** (tudo junto, só nesses trechos):
- **Saturação 50 %** (Lumetri › Creative/Basic › Saturation 50);
- **Vinheta** forte (a `VERTICAL VIGNETT` das referências: Vignette Scale 130, Feather 65, preto, Chromatic Aberration 51; ou Lumetri Vignette −5 a −3 por cima);
- **VHS** sutil, nos mesmos valores aprovados na skill impetus-upsell-memoria: separação de cor vermelho/azul ±3 px, linhas horizontais 5 %, tremor de 2 px, linha de tracking fraca descendo. Pode somar o granulado `old-film-grain-overlay-4k-snowman-digital.mp4` (blend) e Noise 20, como as referências já fazem nesses trechos.
- O tratamento cobre todo o bloco negativo. Se a fala negativa durar mais que um insert (≈2 s), encadeie 2–4 inserts desse tipo com o mesmo tratamento, em vez de voltar para o apresentador colorido.
- Os destaques Anton e a legenda ficam por cima, sem dessaturar.

**Onde buscar (biblioteca do Impetus):**
- `G:\Clientes\IMPETUS\Inserts gerais\ED`: `MEU_PENIS_MOLE_E_PEQUENO…`, `FETICHE_-_MEU_PENIS_MOLE_E_PEQUENO…`, `Pau mole.mp4`, `Pau_Pequeno___Pênis_Pequeno…`, `Pau_Pequeno_e_Incircunciso_Mole…`, `uobbtmh3e75_Everything is possible even soft dick, Thumbs down.mp4`, `Teen looks Sad by Cock…`, `[PornhubFans 480p] O pau mais mole da Terra…` (no acervo PORN), `[PornhubFans 240p] Eu tentei usar seu pau macio…`, `0_Man_Pain…`, `Bomba peniana.mp4`, `0_Addiction_Analgesic…` (pílulas).
- `G:\Clientes\IMPETUS\Inserts gerais\Homens` (184 arquivos): `0_Man_Bed…`, `0_Bathroom_Man…`, `0_Head_Stern…`, `0_Adult_Male_Aging…`, `0_Doctor_Patient…` e similares de homem abatido.
- `Inserts gerais\mulheres` / `Casal em geral`: só a mulher decepcionada **junto** do homem triste (ex.: casal na cama, ela de costas) – nunca a mulher sozinha feliz.

**Se não houver insert adequado:** não trocar por outro tipo. Aplicar a Regra 2 (placeholder "BAIXAR").

## Regra 2 – Insert que falta → sinalizar na timeline

Quando não houver na biblioteca/pasta do projeto o insert que a fala pede (principalmente **famosos**: atores e atrizes pornô, celebridades, médicos citados pelo nome; mas vale para qualquer insert específico):
- colocar na faixa e no tempo exatos um **placeholder** (slate/cor sólida chamativa) com o texto `BAIXAR: <nome ou descrição> – <o que mostrar>` (ex.: `BAIXAR: Mick Blue – foto em evento/AVN`);
- criar um **marcador vermelho** no mesmo ponto, com o mesmo texto e a frase falada;
- já deixar no placeholder o tratamento que o insert final vai receber (cartão 3D, cartão reto, tela cheia; e o tratamento da Regra 1 se for trecho negativo), para o usuário só trocar a mídia;
- listar todos os "BAIXAR" no relatório final (tempo, nome, sugestão de busca).
- Nunca usar foto ou vídeo de outra pessoa no lugar do famoso citado.
