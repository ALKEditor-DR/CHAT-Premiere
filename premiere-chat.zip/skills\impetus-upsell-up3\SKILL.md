---
name: impetus-upsell-up3
description: UPsell UP 3 (Impetus, multiproduto). Edita direto na timeline do Premiere, em camadas separadas e editáveis, os upsells "UP 3" do Impetus em que o expert apresenta um produto NOVO junto com os produtos já comprados (ex.: HerzPur + GlucoVital + NachtPrime, alemão, 4:5), copiando o padrão do UP 1 do mesmo projeto: B-roll por frase da biblioteca do Impetus, cartões com "borda arredondada" sobre o mesmo insert desfocado, destaques Anton com Wonder Glow palavra a palavra, telas de produto com mockup PNG e "ZOOM IN/OUT 20X", tela de oferta com BG do produto novo e neon amarelo, LT "Dr", transições Lens Blur + Flash em camadas de ajuste, zoom suave, light leak + shutter, vinheta, mesmas trilhas e SFX do UP 1. Use sempre que o usuário pedir para editar/montar um UP 3, um upsell com 2 ou mais produtos, "fazer igual ao UP 1 mas com os outros produtos", ou aplicar "o padrão do UP 3", mesmo sem citar a skill.
---

# UPsell UP 3 – multiproduto (Impetus)

Antes de um projeto novo, passe pela skill `novo-projeto-edicao` (pasta mãe, subpastas, conferência).
Esta skill nasceu do projeto `G:\Clientes\IMPETUS\UPSELL  HerzPur  UP1A V1  Ger  Digistore` (UP 3 HerzPur/GlucoVital/NachtPrime, 9 min, alemão), montado pelo painel Premiere Chat e aprovado pelo usuário ("o restante está perfeito") com um único ajuste: telas de mockup usam ZOOM IN/OUT 20X, nunca o EFEITO 3D.

Leia antes de montar:
- [references/padrao-up3.md](references/padrao-up3.md): faixa por faixa, com todos os valores (escala, blur, keyframes, cores, volumes, SFX, transições).
- [references/estilo-aprovado.md](references/estilo-aprovado.md): regras aprovadas e correções do usuário.
- [references/historico-ajustes.md](references/historico-ajustes.md): o porquê de cada regra.
- [references/plano-exemplo-up3-herzpur.jsx](references/plano-exemplo-up3-herzpur.jsx): o plano completo do UP 3 entregue (frase → insert, cartões, telas, neons, cortes). Use como modelo do formato.

## Regras de ouro (do usuário)
1. Entrega sempre DENTRO do Premiere, em camadas separadas e editáveis (nada de MP4 único queimado). Trabalhe numa cópia: `<sequência> - MONTADA`.
2. Cada produto aparece (B-roll/mockup) no momento em que é citado na fala. O produto NOVO só aparece depois que o expert o apresenta ("Ich präsentiere Ihnen …"). Nunca antes.
3. Use os BGs do produto novo (ex.: `BG NACHTPRIME.mp4`) nas telas-chave: apresentação, ingredientes, "os três pilares", oferta, garantia, CTA final.
4. Mesma trilha, mesmos SFX e mesmas transições do UP 1 do projeto, intercaladas como lá.
5. Efeitos = predefinições do usuário (painel Efeitos > Predefinições): neon/brilho → **Wonder Glow**; desfoque de mockup/fundo → **Gaussian Blur** (+ Lumetri, preset "Gaussian Blur + LUMETRI"); B-roll em cartão → **borda arredondada**; telas de mockup PNG → **ZOOM IN 20X / ZOOM OUT 20X** (alternando). **Não use "EFEITO 3D"** em tela de mockup.
6. Legenda: o usuário já entrega corrigida. Não mexa.
7. Não edite a timeline depois que o usuário disser que ele mesmo ajustou; só aprenda (atualize as referências).

## Fluxo (painel Premiere Chat)
`S` = pasta `scripts` desta skill (`C:/Users/mlkal/.claude/skills/impetus-upsell-up3/scripts`). Arquivos de trabalho em `~/.premiere-chat/work/<projeto>`.

1. **Ler o UP 1 de referência** (se o projeto tiver um):
   `python <skills>/impetus-upsell-emagrecimento/scripts/analisar_prproj.py "<prproj>" --lista`, depois `--seq <n> up1.json`, `resumo_timeline.py up1.json resumo.txt resumo.json` e `python S/resumir_faixas.py up1.json up1_faixas.txt`. Confira se os valores batem com `padrao-up3.md`; se o UP 1 mudou, siga o UP 1.
2. **Palavras com tempo** da sequência do UP 3 (legendas já corrigidas): `analisar_prproj.py ... --seq <n> up3.json` e `python S/dump_leg.py up3.json up3_leg.txt up3_words.json`. Se o projeto não estiver salvo, use `transcribe_sequence`. A transcrição anexada pelo usuário ajuda a entender blocos.
3. **Material**: listar o bin do UP 3 (mockups PNG e animados de cada produto, BG do produto novo, `30days GER.png`), a biblioteca `Inserts gerais` e as predefinições (`python S/ler_presets.py "<Effect Presets and Custom Items.prfpset>" "borda arredondada|ZOOM IN 20X|ZOOM OUT 20X|Gaussian Blur + LUMETRI|01 Wonder Glow Preset"`; o arquivo fica em `Documentos/Adobe/Premiere Pro/<versão>/Profile-*/`).
4. **Plano** (`plano.jsx`, mesmo formato do exemplo): BROLL (frase → insert, ~2–3 s, cobertura ~70 %), CARDS (3–4 blocos narrativos de 9–17 s), P3D (telas de mockup PNG), OFERTA, NEON, ZOOMS, CUTS, LEAKS. Destaques: 8–10 frases de efeito (gancho, perguntas retóricas, "Können Sie mir folgen?", "Das Risiko ist null", "Es gibt nur eine Sache", fechamento).
5. **Destaques**: `python S/gerar_destaques.py up3_words.json destaques_ranges.json "<pasta UP3>/Motions/Destaques" destaques.json` (PNG transparentes 1292x1604, Anton branco, um por trecho da legenda).
6. **Montagem** (run_extendscript, em blocos de ~60 itens):
   ```
   $.evalFile("S/lib.jsx"); $.evalFile("<work>/plano.jsx");
   M.prepararCopia();          // clona a seq, renomeia "- MONTADA", garante 12 V / 8 A
   M.broll(0,60); M.broll(60,999);
   M.cartoes(); M.telasProduto(); M.ofertas(); M.neons();
   M.destaques("<work>/destaques.json");
   M.zooms(); M.transicoes(); M.leaks(); M.vinheta(); M.lt("Dr","Ulrich");
   M.trilhas(); M.sfxFixos(); M.limparAudioDeBroll(); M.marcadores([...]);
   ```
   Itens com acento no nome (ex.: "Senhor Família Feliz.mp4") falham quando lidos do arquivo .jsx: coloque-os com `M.brollItem(ini,fim,"nome",inS)` escrito direto no código do run_extendscript.
7. **Conferir** com `view_frame`: LT (0,8 s), um destaque, um cartão, uma tela de produto, a oferta com neon, uma transição. Relate o que não foi conferido.
8. **Relatório**: faixa por faixa, o que ficou faltando (nomes dos depoimentos para LT, etc.), backup em `~/.premiere-chat/backups`.

## Armadilhas já resolvidas (não repita)
- QE `addVideoEffect` insere o efeito no TOPO da pilha: adicione na ordem inversa (ex.: Transform, depois Roughen, depois Crop → fica Crop, Roughen, Transform).
- "Roughen Edges" (borda arredondada) não arredonda clipe recortado com Crop: o cartão tem de ser uma **sequência aninhada 4:5** (clone de uma aninhada do UP 1, esvaziada) — exatamente como o UP 1.
- A "Adjustment Layer" do projeto é 1080x1920: escale para 119,63 % (Motion) senão o efeito só pega o meio do quadro.
- Transform: a escala é "Scale Height" com "Uniform Scale" ligado.
- Cor de parâmetro de MOGRT: `prop.setColorValue(255, r, g, b, true)` (setValue dá erro). Texto de MOGRT: editar `"textEditValue"` dentro do JSON do parâmetro "Text"; "€" deve ir como `\u20AC`.
- `overwriteClip` de B-roll com som coloca áudio em A2/A3: no fim remova todo áudio cujo projectItem seja vídeo/sequência (`M.limparAudioDeBroll()`).
- Escala de preenchimento 4:5: `max(1292/w, 1604/h)*100` (4K 16:9 = 74,26; 1080p = 148,52; 4K vertical = 59,81; 1080x1920 = 119,63).
- Mockup PNG grande demais: escalas boas = pote único 52–54 %, GlucoVital GE-1 56 %, 3 potes 48 %, 6 potes 50 %, posição Y 0,60 (neon fica em Y 0,23).
- Volume das trilhas: −22,6 dB (0.0132). As duas primeiras do UP 1 aparecem a 0 dB no clipe mas ficariam altas; use −22,6 dB em todas.
