"""Regra 2 da Edição ED: gera um PNG de placeholder "BAIXAR" para cada insert que falta.
Uso: python gerar_placeholders.py faltas.json <pasta_saida> [largura altura]
 faltas.json: [[ini, fim, "nome/descrição", "o que mostrar", "modo", neg], ...]
   ex.: [[63.1, 65.4, "Mick Blue", "foto em evento (AVN)", "card3d", false]]
Saída: <pasta_saida>/BAIXAR_001.png ... e <pasta_saida>/baixar.json no formato de P.BAIXAR do lib_ed.jsx
       [ini, fim, png, modo, texto, neg], além de BAIXAR.txt (lista para o relatório).
"""
import json, os, sys
from PIL import Image, ImageDraw, ImageFont

faltas = json.load(open(sys.argv[1], encoding='utf-8'))
OUT = sys.argv[2]
W = int(sys.argv[3]) if len(sys.argv) > 3 else 1080
H = int(sys.argv[4]) if len(sys.argv) > 4 else 1920
os.makedirs(OUT, exist_ok=True)


def fonte(nome, tam):
    for p in (os.path.expanduser(r'~/AppData/Local/Microsoft/Windows/Fonts/' + nome), r'C:/Windows/Fonts/' + nome):
        if os.path.exists(p):
            return ImageFont.truetype(p, tam)
    return ImageFont.truetype(r'C:/Windows/Fonts/arialbd.ttf', tam)


def quebra(d, txt, f, larg):
    linhas, cur = [], ''
    for w in txt.split():
        t = (cur + ' ' + w).strip()
        if d.textlength(t, font=f) <= larg or not cur:
            cur = t
        else:
            linhas.append(cur); cur = w
    if cur:
        linhas.append(cur)
    return linhas


saida, lista = [], []
for i, e in enumerate(faltas, 1):
    a, b, nome, oque = e[0], e[1], e[2], e[3]
    modo = e[4] if len(e) > 4 else 'cheio'
    neg = bool(e[5]) if len(e) > 5 else False
    im = Image.new('RGB', (W, H), (150, 0, 20))
    d = ImageDraw.Draw(im)
    for x in range(-H, W, 90):  # listras diagonais para não passar despercebido
        d.line([(x, 0), (x + H, H)], fill=(185, 20, 40), width=30)
    d.rectangle([40, 40, W - 40, H - 40], outline=(255, 230, 0), width=14)
    f1, f2, f3 = fonte('Anton-Regular.ttf', int(W * 0.2)), fonte('Anton-Regular.ttf', int(W * 0.09)), fonte('arialbd.ttf', int(W * 0.045))
    y = int(H * 0.28)
    d.text((W / 2, y), 'BAIXAR', font=f1, fill=(255, 230, 0), anchor='mm')
    y += int(W * 0.2)
    for ln in quebra(d, nome.upper(), f2, W * 0.85):
        d.text((W / 2, y), ln, font=f2, fill='white', anchor='mm'); y += int(W * 0.105)
    y += 20
    for ln in quebra(d, oque, f3, W * 0.8):
        d.text((W / 2, y), ln, font=f3, fill='white', anchor='mm'); y += int(W * 0.06)
    d.text((W / 2, H - 120), '%02d:%05.2f - %02d:%05.2f' % (a // 60, a % 60, b // 60, b % 60), font=f3, fill=(255, 230, 0), anchor='mm')
    fn = os.path.abspath(os.path.join(OUT, 'BAIXAR_%03d.png' % i))
    im.save(fn)
    texto = '%s - %s' % (nome, oque)
    saida.append([a, b, fn.replace('\\', '/'), modo, texto, neg])
    lista.append('%02d:%05.2f  %s  (%s%s)' % (a // 60, a % 60, texto, modo, ', trecho negativo' if neg else ''))
json.dump(saida, open(os.path.join(OUT, 'baixar.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
open(os.path.join(OUT, 'BAIXAR.txt'), 'w', encoding='utf-8').write('\n'.join(lista) + '\n')
print(len(saida), 'placeholders em', OUT)
