/*
 * Ponte entre o painel e o ChatGPT, pelo Codex CLI da OpenAI, usando a assinatura ChatGPT
 * (Plus/Pro/Team) do usuário. Nenhuma chave de API: o login é forçado para "chatgpt" e as
 * variáveis OPENAI_/CODEX_ saem do ambiente.
 *
 * Mesma interface da ClaudeBridge (findExe, authStatus, openLogin, runTurn) para o painel
 * trocar de "cérebro" sem mudar o resto. O servidor MCP local é o da ClaudeBridge.
 */
(function (root) {
  "use strict";

  const req = typeof require === "function" ? require : root.require;
  if (typeof req !== "function") {
    root.CodexBridge = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const crypto = req("crypto");
  const { spawn } = req("child_process");

  const IS_WIN = process.platform === "win32";
  const api = {};

  function exists(p) {
    try {
      return fs.statSync(p).isFile();
    } catch {
      return false;
    }
  }
  function safeReaddir(dir) {
    try {
      return fs.readdirSync(dir);
    } catch {
      return [];
    }
  }

  // ---------------------------------------------------------------- localizar o CLI

  // O pacote npm @openai/codex traz o binário nativo em
  // node_modules/@openai/codex-<plataforma>/vendor/<alvo>/bin/codex.exe (às vezes aninhado).
  function nativeUnder(nodeModules) {
    const out = [];
    const scopes = [path.join(nodeModules, "@openai"), path.join(nodeModules, "@openai", "codex", "node_modules", "@openai")];
    for (const scope of scopes) {
      for (const pkg of safeReaddir(scope)) {
        if (!/^codex-(win32|darwin|linux)/.test(pkg)) continue;
        const vendor = path.join(scope, pkg, "vendor");
        for (const target of safeReaddir(vendor)) {
          const exe = path.join(vendor, target, "bin", IS_WIN ? "codex.exe" : "codex");
          if (exists(exe)) out.push(exe);
        }
      }
    }
    return out;
  }

  function findExe(customPath) {
    if (customPath && exists(customPath)) return customPath;
    const home = os.homedir();
    const candidates = [];
    if (IS_WIN) {
      if (process.env.APPDATA) candidates.push(...nativeUnder(path.join(process.env.APPDATA, "npm", "node_modules")));
      candidates.push(path.join(home, ".codex", "bin", "codex.exe"), path.join(home, ".local", "bin", "codex.exe"));
      // App Codex da OpenAI: %LOCALAPPDATA%\OpenAI\Codex\bin\<versão>\codex.exe (usa a mais nova).
      if (process.env.LOCALAPPDATA) {
        const appBin = path.join(process.env.LOCALAPPDATA, "OpenAI", "Codex", "bin");
        const found = safeReaddir(appBin)
          .map((d) => path.join(appBin, d, "codex.exe"))
          .filter(exists)
          .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
        candidates.push(...found);
      }
    } else {
      candidates.push(path.join(home, ".local", "bin", "codex"), "/opt/homebrew/bin/codex", "/usr/local/bin/codex");
    }
    for (const dir of (process.env.PATH || "").split(path.delimiter)) {
      if (!dir) continue;
      candidates.push(path.join(dir, IS_WIN ? "codex.exe" : "codex"));
      // codex.cmd do npm: usa o binário nativo que fica ao lado (sem passar pelo cmd.exe).
      if (IS_WIN && exists(path.join(dir, "codex.cmd"))) candidates.push(...nativeUnder(path.join(dir, "node_modules")));
    }
    return candidates.find(exists) || null;
  }

  // ---------------------------------------------------------------- execução

  // Sem chaves de API no ambiente: o uso sai da assinatura ChatGPT, nunca da API paga.
  function subscriptionEnv(extra) {
    const env = {};
    for (const [k, v] of Object.entries(process.env)) {
      if (/^(OPENAI_|CODEX_API_KEY|AZURE_OPENAI)/.test(k)) continue;
      env[k] = v;
    }
    return Object.assign(env, extra || {});
  }

  function workspaceDir() {
    const dir = path.join(os.homedir(), ".premiere-chat", "workspace");
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  function runSimple(exe, args, timeoutMs) {
    return new Promise((resolve) => {
      let out = "";
      const child = spawn(exe, args, { cwd: workspaceDir(), env: subscriptionEnv(), windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
      const timer = setTimeout(() => child.kill(), timeoutMs || 30000);
      child.stdout.on("data", (d) => (out += d));
      child.stderr.on("data", (d) => (out += d));
      child.on("error", (e) => {
        clearTimeout(timer);
        resolve({ code: -1, out: String(e.message || e) });
      });
      child.on("close", (code) => {
        clearTimeout(timer);
        resolve({ code, out });
      });
    });
  }

  // "Logged in using ChatGPT" / "Logged in using an API key" / "Not logged in"
  async function authStatus(exe) {
    const r = await runSimple(exe, ["login", "status"], 30000);
    const t = r.out.replace(/^WARNING:.*$/gm, "").trim();
    if (/not logged in/i.test(t)) return { loggedIn: false };
    if (/logged in/i.test(t)) return { loggedIn: true, authMethod: /api key/i.test(t) ? "api key" : "chatgpt" };
    return { loggedIn: false, error: t || "sem resposta" };
  }

  // Janela de terminal com o login da conta ChatGPT (abre o navegador).
  function openLogin(exe) {
    if (IS_WIN) {
      spawn("cmd.exe", ["/c", "start", '"Login ChatGPT"', `"${exe}"`, "login"], {
        env: subscriptionEnv(),
        detached: true,
        windowsVerbatimArguments: true,
        stdio: "ignore",
      }).unref();
    } else {
      const script = `tell application "Terminal" to do script "${exe.replace(/"/g, '\\"')} login"`;
      spawn("osascript", ["-e", script], { detached: true, stdio: "ignore" }).unref();
    }
  }

  // Instala o Codex CLI pelo npm numa janela visível (o painel só sugere; a pessoa vê o progresso).
  function openInstall(npmCmd) {
    if (!IS_WIN) return;
    const npm = npmCmd && exists(npmCmd) ? `"${npmCmd}"` : "npm";
    spawn("cmd.exe", ["/c", "start", '"Instalar o motor do ChatGPT (Codex)"', "cmd.exe", "/k", `${npm} install -g @openai/codex && echo. && echo Pronto. Pode fechar esta janela.`], {
      env: subscriptionEnv(),
      detached: true,
      windowsVerbatimArguments: true,
      stdio: "ignore",
    }).unref();
  }

  // Valor TOML para -c chave=valor (string básica: os escapes do JSON valem em TOML).
  const toml = (v) => (Array.isArray(v) ? "[" + v.map(toml).join(",") + "]" : typeof v === "string" ? JSON.stringify(v) : String(v));

  // Converte os blocos do painel (texto/imagem/PDF) em texto + imagens em arquivo (-i).
  function splitPrompt(prompt) {
    const blocks = typeof prompt === "string" ? [{ type: "text", text: prompt }] : prompt;
    const texts = [];
    const images = [];
    const dir = path.join(os.tmpdir(), "premiere-chat-gpt");
    for (const b of blocks) {
      if (b.type === "text") texts.push(b.text);
      else if (b.type === "image" && b.source && b.source.data) {
        fs.mkdirSync(dir, { recursive: true });
        const ext = /png/.test(b.source.media_type) ? ".png" : /webp/.test(b.source.media_type) ? ".webp" : /gif/.test(b.source.media_type) ? ".gif" : ".jpg";
        const f = path.join(dir, "img-" + crypto.randomBytes(6).toString("hex") + ext);
        fs.writeFileSync(f, Buffer.from(b.source.data, "base64"));
        images.push(f);
      } else if (b.type === "document") {
        texts.push(`[PDF anexado "${b.title || "documento"}": o motor ChatGPT não lê PDF anexado. Diga ao usuário para mandar o texto em DOCX/TXT ou prints das páginas.]`);
      }
    }
    return { text: texts.join("\n\n"), images };
  }

  /*
   * Executa um turno no Codex. opts: { exe, mcp, systemPrompt, toolNames, model, effort, sessionId,
   *   onTextStart(), onText(delta), onActivity({kind, label, ok, detail}) }
   * Retorna { promise, cancel } — promise resolve com { result, is_error, errors, session_id, usage }.
   */
  function runTurn(prompt, opts) {
    let { text, images } = splitPrompt(prompt);
    const tokenVar = "PREMIERE_CHAT_MCP_TOKEN";
    // O Windows limita a linha de comando a ~32 mil caracteres: instruções muito longas vão junto da mensagem.
    const sysArg = toml(opts.systemPrompt || "");
    const sysInline = sysArg.length > 26000;
    if (sysInline) text = "<panel_instructions>\n" + opts.systemPrompt + "\n</panel_instructions>\n\n" + text;
    const cfg = {
      approval_policy: "never",
      forced_login_method: "chatgpt",
      "mcp_servers.ppro.url": opts.mcp.url,
      "mcp_servers.ppro.bearer_token_env_var": tokenVar,
      "mcp_servers.ppro.default_tools_approval_mode": "approve",
      "mcp_servers.ppro.tool_timeout_sec": 3600,
      "mcp_servers.ppro.startup_timeout_sec": 30,
    };
    if (!sysInline && opts.systemPrompt) cfg.developer_instructions = opts.systemPrompt;
    if (opts.toolNames && opts.toolNames.length) cfg["mcp_servers.ppro.enabled_tools"] = opts.toolNames;
    if (opts.effort) cfg.model_reasoning_effort = opts.effort === "max" ? "xhigh" : opts.effort;

    // Configuração do usuário ignorada (como o --strict-mcp-config do Claude); o login continua valendo.
    const args = ["exec", "--json", "--skip-git-repo-check", "--ignore-user-config", "-s", "read-only", "-C", workspaceDir()];
    if (opts.sessionId) args.push("resume", opts.sessionId);
    for (const [k, v] of Object.entries(cfg)) args.push("-c", k + "=" + toml(v));
    if (opts.model) args.push("-m", opts.model);
    for (const img of images) args.push("-i", img);
    args.push("-"); // o pedido vai pelo stdin (sem limite de tamanho da linha de comando)

    const child = spawn(opts.exe, args, {
      cwd: workspaceDir(),
      env: subscriptionEnv({ [tokenVar]: opts.mcp.token }),
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });
    let cancelled = false;

    const promise = new Promise((resolve, reject) => {
      let buf = "";
      let stderr = "";
      let sessionId = opts.sessionId || null;
      let lastText = "";
      let failed = null;
      let usage = null;
      const errors = [];
      const shown = new Map(); // id da mensagem -> quanto do texto já foi mostrado

      const showText = (item) => {
        const t = String(item.text || "");
        let n = shown.get(item.id);
        if (n === undefined) {
          if (!t) return;
          n = 0;
          if (opts.onTextStart) opts.onTextStart();
        }
        if (t.length > n && opts.onText) opts.onText(t.slice(n));
        shown.set(item.id, Math.max(n, t.length));
        lastText = t;
      };

      const onEvent = (ev) => {
        if (ev.type === "thread.started" && ev.thread_id) sessionId = ev.thread_id;
        else if (ev.type === "turn.completed") usage = ev.usage || null;
        else if (ev.type === "turn.failed") failed = (ev.error && ev.error.message) || "falha no turno";
        else if (ev.type === "error") {
          if (!/^Reconnecting/i.test(ev.message || "")) errors.push(ev.message);
        } else if (/^item\./.test(ev.type) && ev.item) {
          const it = ev.item;
          if (it.type === "agent_message") showText(it);
          else if (ev.type === "item.completed" && opts.onActivity) {
            if (it.type === "command_execution")
              opts.onActivity({ kind: "command", label: "Leitura: " + String(it.command || "").slice(0, 120), ok: it.exit_code === 0 || it.status === "completed", detail: String(it.aggregated_output || "").slice(-400) });
            else if (it.type === "web_search") opts.onActivity({ kind: "search", label: "Pesquisa na web: " + (it.query || ""), ok: true });
            else if (it.type === "error" && !/Falling back from WebSockets/i.test(it.message || "")) errors.push(it.message);
          }
        }
      };

      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (chunk) => {
        buf += chunk;
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (!line) continue;
          try {
            onEvent(JSON.parse(line));
          } catch {
            /* linha que não é JSON */
          }
        }
      });
      child.stderr.on("data", (d) => (stderr = (stderr + d).slice(-8000)));
      child.on("error", (e) => reject(new Error("Não foi possível iniciar o Codex (ChatGPT): " + (e.message || e))));
      child.on("close", (code) => {
        for (const f of images) {
          try {
            fs.unlinkSync(f);
          } catch {}
        }
        if (cancelled) return resolve({ cancelled: true, session_id: sessionId });
        const errText = stderr
          .split(/\r?\n/)
          .filter((l) => l.trim() && !/^WARNING:|responses_websocket|^\d{4}-\d\d-\d\dT.*\b(WARN|INFO|DEBUG)\b/.test(l))
          .slice(-4)
          .join(" ")
          .trim();
        if (failed || (code !== 0 && !lastText)) {
          return resolve({ is_error: true, result: failed || errText || `Codex saiu com código ${code}`, errors, session_id: sessionId });
        }
        resolve({ is_error: false, result: lastText, errors, session_id: sessionId, usage });
      });

      child.stdin.end(text, "utf8");
    });

    return {
      promise,
      cancel() {
        cancelled = true;
        if (IS_WIN) {
          try {
            spawn("taskkill", ["/pid", String(child.pid), "/T", "/F"], { windowsHide: true });
          } catch {
            child.kill();
          }
        } else child.kill();
      },
    };
  }

  Object.assign(api, { findExe, subscriptionEnv, authStatus, openLogin, openInstall, runTurn, splitPrompt });
  root.CodexBridge = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
