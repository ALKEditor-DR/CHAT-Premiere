"""Gera os destaques do padrão UP 3: um PNG transparente por trecho de legenda.
Uso: python gerar_destaques.py up3_words.json ranges.json <pasta_saida> destaques.json [largura altura]
 - up3_words.json: [[ini, fim, "texto"], ...] (saída de dump_leg.py)
 - ranges.json: [[ini, fim], ...] frases de efeito que viram destaque
Saída: PNGs D001.png... (Anton branco, MAIÚSCULAS, sombra suave, centralizado) e destaques.json [{f,s,e,t,g}] para M.destaques().
"""
import json, os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

words = json.load(open(sys.argv[1], encoding='utf-8'))
ranges = json.load(open(sys.argv[2], encoding='utf-8'))
OUT = sys.argv[3]; JS = sys.argv[4]
W = int(sys.argv[5]) if len(sys.argv) > 5 else 1292
H = int(sys.argv[6]) if len(sys.argv) > 6 else 1604
FONT = os.path.expanduser(r'~/AppData/Local/Microsoft/Windows/Fonts/Anton-Regular.ttf')
if not os.path.exists(FONT): FONT = r'C:/Windows/Fonts/Anton-Regular.ttf'
os.makedirs(OUT, exist_ok=True)
items = []; n = 0
for gi, (a, b) in enumerate(ranges):
    ch = [w for w in words if w[0] >= a - 0.02 and w[0] < b - 0.05]
    for i, w in enumerate(ch):
        st = w[0]; en = ch[i + 1][0] if i + 1 < len(ch) else b
        txt = w[2].upper().replace('„', '').replace('“', '').replace('"', '')
        n += 1; fn = os.path.join(OUT, 'D%03d.png' % n)
        size = 150
        while True:
            f = ImageFont.truetype(FONT, size); bb = f.getbbox(txt)
            if bb[2] - bb[0] <= W * 0.867 or size <= 70: break
            size -= 6
        im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sh = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        tw = bb[2] - bb[0]; th = bb[3] - bb[1]; x = (W - tw) / 2 - bb[0]; y = (H - th) / 2 - bb[1]
        ImageDraw.Draw(sh).text((x + 4, y + 6), txt, font=f, fill=(0, 0, 0, 170))
        im = Image.alpha_composite(im, sh.filter(ImageFilter.GaussianBlur(6)))
        ImageDraw.Draw(im).text((x, y), txt, font=f, fill=(255, 255, 255, 255))
        im.save(fn)
        items.append({'f': os.path.abspath(fn).replace('/', '\\'), 's': round(st, 3), 'e': round(en, 3), 't': txt, 'g': gi})
json.dump(items, open(JS, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print(len(items), 'destaques')
for it in items: print(it['s'], it['e'], it['t'])
