#!/usr/bin/env python
"""Folha de miniaturas de uma pasta de B-roll, numeradas, para escolher inserts.

python folha_inserts.py "<pasta>" saida.jpg [max=60]
Gera também saida.jpg.txt com o número e o caminho de cada arquivo.
"""
import sys,os,glob,subprocess,io
from PIL import Image,ImageDraw,ImageFont
pasta,saida=sys.argv[1],sys.argv[2]
ext=('.mp4','.mov','.png','.jpg','.jpeg','.webp')
fs=sorted([f for f in glob.glob(pasta+"/**/*",recursive=True) if f.lower().endswith(ext)])[:int(sys.argv[3]) if len(sys.argv)>3 else 60]
T=200;fnt=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",11)
cols=8;rows=(len(fs)+cols-1)//cols
sheet=Image.new("RGB",(cols*T,rows*(T+28)),(20,20,20));d=ImageDraw.Draw(sheet)
for i,f in enumerate(fs):
    try:
        if f.lower().endswith(('.mp4','.mov')):
            b=subprocess.run(["ffmpeg","-v","error","-ss","1","-i",f,"-frames:v","1","-f","image2pipe","-vcodec","png","-"],capture_output=True).stdout
            im=Image.open(io.BytesIO(b))
        else: im=Image.open(f)
        im=im.convert("RGB");im.thumbnail((T,T))
        x,y=(i%cols)*T,(i//cols)*(T+28)
        sheet.paste(im,(x+(T-im.width)//2,y+(T-im.height)//2))
        d.text((x+2,y+T+2),f"{i}:"+os.path.relpath(f,pasta)[:34],font=fnt,fill=(255,255,0))
        d.text((x+2,y+T+14),os.path.relpath(f,pasta)[34:68],font=fnt,fill=(255,255,0))
    except Exception as e: print("erro",f,e)
sheet.save(saida,quality=80)
open(saida+".txt","w",encoding="utf-8").write("\n".join(f"{i}\t{f}" for i,f in enumerate(fs)))
print(len(fs))
