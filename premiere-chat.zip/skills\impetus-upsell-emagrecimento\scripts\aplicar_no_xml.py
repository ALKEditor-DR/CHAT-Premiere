"""Aplica o plano (B-roll, telas, música, SFX, marcadores) dentro do XML que o próprio Premiere exportou.
Mantém tudo o que veio do Premiere e só acrescenta itens no mesmo formato dele.

python aplicar_no_xml.py plano.json "entrada exportada.xml" "saida.xml"
"""
import json
import os
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import quote
from xml.sax.saxutils import escape

PLANO, ENT, SAI = sys.argv[1:4]
P = json.load(open(PLANO, encoding="utf-8"))
TK = 254016000000
SEQ_FPS = 24
W, H = P["w"], P["h"]
AUD = (".mp3", ".wav", ".m4a", ".aif", ".aiff")
EST = (".png", ".jpg", ".jpeg")

tree = ET.parse(ENT)
root = tree.getroot()
seq = root.find("sequence")
SEQ_TB = seq.find("rate/timebase").text  # o Premiere escreveu "23" para esta sequência de 24 qps: repetimos igual


def fr(t):
    return int(round(t * SEQ_FPS))


SONDA = {}


def sonda(p):
    if p not in SONDA:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height,sample_rate,channels,r_frame_rate:format=duration",
                            "-of", "json", p], stdout=subprocess.PIPE, text=True)
        j = json.loads(r.stdout or "{}")
        st = j.get("streams", [])
        v = next((x for x in st if x.get("codec_type") == "video"), None)
        a = next((x for x in st if x.get("codec_type") == "audio"), None)
        fps = SEQ_FPS
        if v and not p.lower().endswith(AUD + EST):
            n, d = v.get("r_frame_rate", "24/1").split("/")
            fps = int(n) / max(1, int(d))
        SONDA[p] = {"v": v, "a": a, "fps": fps, "dur": float(j.get("format", {}).get("duration", 0) or 0)}
    return SONDA[p]


def rate_xml(fps):
    tb = int(round(fps))
    ntsc = "TRUE" if abs(fps - tb) > 0.01 else "FALSE"
    if abs(fps - SEQ_FPS) < 0.01:
        tb, ntsc = SEQ_TB, "FALSE"
    return f"<rate><timebase>{tb}</timebase><ntsc>{ntsc}</ntsc></rate>"


def url(p):
    p = p.replace("\\", "/")
    drive, resto = p[:2], p[2:]
    return "file://localhost/" + drive.replace(":", "%3a") + quote(resto, safe="/")


# ids que já existem no XML do Premiere
todos = ET.tostring(root, encoding="unicode")
n_clip = [max(int(x) for x in __import__("re").findall(r'clipitem-(\d+)', todos))]
n_file = [max(int(x) for x in __import__("re").findall(r'file-(\d+)', todos))]
n_master = [max(int(x) for x in __import__("re").findall(r'masterclip-(\d+)', todos))]
ARQ = {}  # caminho -> (file id, masterclip id)


def file_xml(p):
    if p in ARQ:
        return f'<file id="{ARQ[p][0]}"/>', ARQ[p][1]
    n_file[0] += 1
    n_master[0] += 1
    fid, mid = f"file-{n_file[0]}", f"masterclip-{n_master[0]}"
    ARQ[p] = (fid, mid)
    s = sonda(p)
    est = p.lower().endswith(EST)
    med = ""
    if s["v"] and not p.lower().endswith(AUD):
        med += (f"<video><samplecharacteristics>{rate_xml(s['fps'])}<width>{s['v'].get('width')}</width><height>{s['v'].get('height')}</height>"
                f"<anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></video>")
    if s["a"] and not est:
        ch = int(s["a"].get("channels", 2))
        med += (f"<audio><samplecharacteristics><depth>16</depth><samplerate>{s['a'].get('sample_rate', 48000)}</samplerate></samplecharacteristics>"
                f"<channelcount>{ch}</channelcount>" + "".join(f"<audiochannel><sourcechannel>{c + 1}</sourcechannel></audiochannel>" for c in range(ch)) + "</audio>")
    dur = "" if est else f"<duration>{int(round(s['dur'] * s['fps']))}</duration>"
    tc = (f"<timecode>{rate_xml(s['fps'])}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>")
    return (f'<file id="{fid}"><name>{escape(os.path.basename(p))}</name><pathurl>{url(p)}</pathurl>{rate_xml(s["fps"])}{dur}{tc}'
            f"<media>{med}</media></file>"), mid


def motion(esc, pos):
    x, y = pos or (0.5, 0.5)
    return ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid><effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
            "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
            f'<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name><valuemin>0</valuemin><valuemax>1000</valuemax><value>{esc:.2f}</value></parameter>'
            f'<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name><value><horiz>{(x - 0.5) * 2:.4f}</horiz><vert>{(y - 0.5) * 2:.4f}</vert></value></parameter>'
            "</effect></filter>")


def nivel(db):
    return ("<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid><effectcategory>audiolevels</effectcategory>"
            "<effecttype>audiolevels</effecttype><mediatype>audio</mediatype><pproBypass>false</pproBypass>"
            f'<parameter authoringApp="PremierePro"><parameterid>level</parameterid><name>Level</name><valuemin>0</valuemin><valuemax>3.98109</valuemax>'
            f"<value>{10 ** (db / 20):.5f}</value></parameter></effect></filter>")


def clipitem(c, canal=None):
    p = c["arquivo"].replace("\\", "/")
    s = sonda(p)
    est = p.lower().endswith(EST)
    fa = s["fps"]
    n_clip[0] += 1
    fx, mid = file_xml(p)
    ini, fim = fr(c["ini"]), fr(c["fim"])
    durf = int(round(s["dur"] * fa)) if not est else 86400
    a = int(round(c.get("clip_in", 0) * fa))
    o = a + int(round((fim - ini) / SEQ_FPS * fa))
    if not est:
        o = min(o, durf)
    ti = int(round(c.get("clip_in", 0) * TK))
    to = int(round((c.get("clip_in", 0) + (fim - ini) / SEQ_FPS) * TK))
    extra = ""
    if canal is not None:
        extra += f"<sourcetrack><mediatype>audio</mediatype><trackindex>{canal}</trackindex></sourcetrack>"
        extra += nivel(c.get("ganho_db", 0))
    else:
        esc = c.get("escala")
        if not esc:
            vw, vh = s["v"]["width"], s["v"]["height"]
            esc = max(W / vw, H / vh) * 100
        extra += motion(esc, c.get("pos"))
    nome = c.get("nome") or os.path.basename(p)
    attr = f' premiereChannelType="{"mono" if canal and s["a"] and int(s["a"].get("channels", 2)) == 1 else "stereo"}"' if canal else ""
    return ET.fromstring(
        f'<clipitem id="clipitem-{n_clip[0]}"{attr}><masterclipid>{mid}</masterclipid><name>{escape(nome)}</name><enabled>TRUE</enabled>'
        f"<duration>{durf}</duration>{rate_xml(fa)}<start>{ini}</start><end>{fim}</end><in>{a}</in><out>{o}</out>"
        f"<pproTicksIn>{ti}</pproTicksIn><pproTicksOut>{to}</pproTicksOut>"
        + ("<alphatype>straight</alphatype>" if est else "<alphatype>none</alphatype>")
        + f"<pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>{fx}{extra}</clipitem>")


def fade(ini, fim, alinh):
    return ET.fromstring(
        f"<transitionitem><start>{ini}</start><end>{fim}</end><alignment>{alinh}</alignment>{rate_xml(SEQ_FPS)}"
        "<effect><name>Cross Fade (+3dB)</name><effectid>KGAudioTransCrossFade3dB</effectid><effecttype>transition</effecttype>"
        "<mediatype>audio</mediatype><wipecode>0</wipecode><wipeaccuracy>100</wipeaccuracy><startratio>0</startratio><endratio>1</endratio>"
        "<reverse>FALSE</reverse></effect></transitionitem>")


def inserir(track, elems):
    """Itens entram antes de <enabled>, ordenados por início."""
    k = list(track).index(track.find("enabled")) if track.find("enabled") is not None else len(track)
    for e in elems:
        track.insert(k, e)
        k += 1


med = seq.find("media")
vtracks = med.find("video").findall("track")
while len(vtracks) < 3:
    t = ET.SubElement(med.find("video"), "track")
    ET.SubElement(t, "enabled").text = "TRUE"
    ET.SubElement(t, "locked").text = "FALSE"
    vtracks = med.find("video").findall("track")
for n in (2, 3):
    itens = sorted([v for v in P["video"] if v["faixa"] == n], key=lambda v: v["ini"])
    inserir(vtracks[n - 1], [clipitem(v) for v in itens])

# áudio: no XML do Premiere cada faixa estéreo vira 2 <track> (canal 1 e canal 2). A1 = track 0; A2 = 1-2; A3 = 3-4; A4 = 5-6; A5 = criar
audio = med.find("audio")
atracks = audio.findall("track")
modelo = atracks[-2]
while len(atracks) < 9:
    for idx in (0, 1):
        t = ET.SubElement(audio, "track", dict(modelo.attrib, currentExplodedTrackIndex=str(idx), totalExplodedTrackCount="2"))
        ET.SubElement(t, "enabled").text = "TRUE"
        ET.SubElement(t, "locked").text = "FALSE"
        ET.SubElement(t, "outputchannelindex").text = str(idx + 1)
    atracks = audio.findall("track")
PAR = {2: (1, 2), 3: (3, 4), 4: (5, 6), 5: (7, 8)}
for n, (e, d) in PAR.items():
    itens = sorted([a for a in P["audio"] if a["faixa"] == n], key=lambda a: a["ini"])
    for lado, ti in ((1, e), (2, d)):
        elems = []
        for c in itens:
            s = sonda(c["arquivo"].replace("\\", "/"))
            ch = int(s["a"].get("channels", 2)) if s["a"] else 1
            if c.get("fade_in"):
                elems.append(fade(fr(c["ini"]), fr(c["ini"] + c["fade_in"]), "start-black"))
            elems.append(clipitem(c, canal=min(lado, ch)))
            if c.get("fade_out"):
                elems.append(fade(fr(c["fim"] - c["fade_out"]), fr(c["fim"]), "end-black"))
        inserir(atracks[ti], elems)

# marcadores da sequência
k = list(seq).index(seq.find("media")) + 1
for m in sorted(P["marcadores"], key=lambda m: m["t"], reverse=True):
    out = fr(m["t"] + m["dur"]) if m.get("dur") else -1
    seq.insert(k, ET.fromstring(f"<marker><comment>{escape(m.get('comentario', ''))}</comment><name>{escape(m['nome'])}</name>"
                                f"<in>{fr(m['t'])}</in><out>{out}</out></marker>"))

# sequência nova (não confunde com a original no mesmo projeto)
seq.find("name").text = "HerzPur UP1A V1 - CORTADA + brolls (Claude)"
if seq.find("uuid") is not None:
    seq.find("uuid").text = str(uuid.uuid4())

xml = ET.tostring(root, encoding="unicode")
open(SAI, "w", encoding="utf-8").write('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n' + xml)
print("OK", SAI, "| V2:", len([v for v in P["video"] if v["faixa"] == 2]), "V3:", len([v for v in P["video"] if v["faixa"] == 3]),
      "| áudio:", len(P["audio"]), "| marcadores:", len(P["marcadores"]))
