// edicao-ed – biblioteca de montagem no Premiere (ExtendScript ES3, painel Premiere Chat)
// Uso (run_extendscript):
//   $.evalFile("C:/Users/mlkal/.claude/skills/impetus-upsell-up3/scripts/lib.jsx");  // helpers L.* (place, fx, keys, glow, efeito3d...)
//   $.evalFile("C:/Users/mlkal/.claude/skills/edicao-ed/scripts/lib_ed.jsx");
//   $.evalFile("<_projeto>/plano_ed.jsx");                                            // define P (ver references/plano-exemplo-ed.jsx)
//   E.prep(); E.inserts(0,40); E.inserts(40,999); ...
// Itens que só existem nos projetos de referência (camadas de ajuste com preset, MOGRT de título, glitch, light leak,
// mockup de celular) são buscados numa sequência de referência importada no projeto (P.REF, ex. "L4 - CORTADA").

var E = { log: [] };
E.V = { BRUTA: 0, BROLL: 1, CARD: 2, NEG: 3, BLUR: 4, DEST: 5, TIT: 6, ZOOM: 7, WARP: 8, LEAK: 9, GRAO: 10, VIN: 11, GLITCH: 12, BAIXAR: 13 };
E.A = { VOZ: 0, INS: 1, SFX1: 2, SFX2: 3, SFX3: 4, SFX4: 5, TR1: 6, TR2: 7 };
E.lv = function (db) { return 0.17782794 * Math.pow(10, db / 20); }; // Premiere: 0,1778 = 0 dB
E.end = function () { return L.seq().end / 254016000000; };

// ---------- referência ----------
E.ref = function () { for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (q && q.name == P.REF) return q; } return null; };
// primeiro clipe da sequência de referência cujo nome contém sub (vídeo ou áudio) -> projectItem
E.fromRef = function (isVideo, sub) {
  var r = E.ref(); if (!r) { E.log.push("sem sequência de referência " + P.REF); return null; }
  var tt = isVideo ? r.videoTracks : r.audioTracks;
  for (var t = 0; t < tt.numTracks; t++) { var tr = tt[t]; for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; if (c && c.name.indexOf(sub) >= 0 && c.projectItem) return c.projectItem; } }
  E.log.push("não achei na referência: " + sub); return null;
};
E.item = function (r) { // "ref:<nome>" na sequência de referência, "n:<nome>" no projeto, ou caminho de arquivo
  if (r.indexOf("ref:") == 0) return E.fromRef(true, r.substr(4)) || E.fromRef(false, r.substr(4));
  return L.ref(r);
};

// ---------- preparação ----------
E.prep = function () {
  var s = L.seq(); var before = {}; for (var i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = 1;
  s.clone(); var ns = null; for (var i = 0; i < app.project.sequences.numSequences; i++) { var q = app.project.sequences[i]; if (!before[q.sequenceID]) ns = q; }
  ns.name = s.name + " - MONTADA ED"; app.project.openSequence(ns.sequenceID); app.project.activeSequence = ns;
  app.enableQE(); var qs = qe.project.getActiveSequence(); var nv = ns.videoTracks.numTracks, na = ns.audioTracks.numTracks;
  qs.addTracks(Math.max(0, 14 - nv), nv, Math.max(0, 8 - na), 1, na);
  return ns.name;
};

// ---------- tratamentos ----------
E.exp = function (ti, c, v) { L.fx(ti, c.start.seconds, 'Lumetri Color'); var lc = L.comp(c, 'Lumetri Color'); if (lc) L.set(lc, 'Exposure', v); };
// Regra 1 (regras-material-ed.md): saturação 50 % no próprio insert; vinheta + VHS vêm da camada E.V.NEG (E.negativos)
E.sat50 = function (ti, c) { L.fx(ti, c.start.seconds, 'Lumetri Color'); var lc = L.comp(c, 'Lumetri Color'); if (lc) { L.set(lc, 'Saturation', 50); } };
E.cartao3d = function (ti, c, esc) { L.motion(c, esc || 82); L.efeito3d(ti, c); L.borda(ti, c); };              // Basic 3D -21→8 / -20→-15, sombra -144/26/114, Roughen 40
E.cartaoReto = function (ti, c, esc) { L.motion(c, esc || 83); L.borda(ti, c); L.zoomT(ti, c, 110, 100); };
E.fundoDesfocado = function (a, b) { // apresentador desfocado atrás do cartão (cópia da bruta em V2 com blur 30 + exposição −0,62)
  var adj = L.adj(); if (!adj) return; var z = L.place(E.V.BLUR, adj, a, b - a); if (z) { L.motion(z, L.fill(adj)); L.blurBG(E.V.BLUR, z); }
};

// ---------- inserts ----------
// P.INS: [ini, fim, ref, inS, modo, neg, somDb]
//   modo: "cheio" | "card3d" | "cardreto" | "dividida" (metade de baixo) ; neg: true aplica Regra 1 ; somDb: null = mudo, número = áudio do insert em dB
E.inserts = function (from, to) {
  for (var i = from; i < to && i < P.INS.length; i++) {
    var e = P.INS[i], a = e[0], b = e[1], modo = e[4] || "cheio";
    var it = E.item(e[2]); if (!it) { E.log.push("FALTA " + e[2] + " @" + a); continue; }
    var ti = (modo == "card3d" || modo == "cardreto") ? E.V.CARD : E.V.BROLL;
    var c = L.place(ti, it, a, b - a, e[3]); if (!c) { E.log.push("não colocou " + e[2]); continue; }
    if (modo == "cheio") L.motion(c, L.fill(it));
    else if (modo == "card3d") { E.fundoDesfocado(a, b); E.cartao3d(ti, c); }
    else if (modo == "cardreto") { E.fundoDesfocado(a, b); E.cartaoReto(ti, c); }
    else if (modo == "dividida") { var s = L.seq(); L.motion(c, Math.max(s.frameSizeHorizontal / (L.dims(it) || [1, 1])[0], (s.frameSizeVertical / 2) / (L.dims(it) || [1, 1])[1]) * 100, 0.5, 0.75); }
    if (e[5]) E.sat50(ti, c);
    if (e[6] != null && PPC.kind(it) == 'video') { var ac = L.audio(E.A.INS, it, a, b - a, e[3], E.lv(e[6])); }
  }
  return E.log.join("; ");
};

// Regra 1: camada de ajuste por trecho negativo com vinheta forte + VHS (Noise, Wave Warp leve, separação de cor)
// P.NEG: [[ini, fim], ...] – os inserts do trecho já vêm com neg=true (saturação 50 %)
E.negativos = function () {
  var adj = L.adj(); if (!adj) { E.log.push("sem Adjustment Layer no projeto"); return; } var sc = L.fill(adj);
  for (var k = 0; k < P.NEG.length; k++) {
    var a = P.NEG[k][0], b = P.NEG[k][1]; var z = L.place(E.V.NEG, adj, a, b - a); if (!z) continue; L.motion(z, sc);
    // ordem inversa (QE põe no topo): fica Lumetri, Noise, Wave Warp, Vignette
    L.fx(E.V.NEG, a, 'Vignette'); L.fx(E.V.NEG, a, 'Wave Warp'); L.fx(E.V.NEG, a, 'Noise (Legacy)'); L.fx(E.V.NEG, a, 'Lumetri Color');
    var lc = L.comp(z, 'Lumetri Color'); if (lc) { L.set(lc, 'Amount', -5); L.set(lc, 'Midpoint', 55); }
    var nz = L.comp(z, 'Noise (Legacy)'); if (nz) { L.set(nz, 'Amount of Noise', 20); L.set(nz, 'Noise Type', true); }
    var ww = L.comp(z, 'Wave Warp'); if (ww) { L.set(ww, 'Wave Height', 2); L.set(ww, 'Wave Width', 600); L.set(ww, 'Direction', 0); L.set(ww, 'Wave Speed', 1.5); }
    var vg = L.comp(z, 'Vignette'); if (vg) { L.set(vg, 'Scale', 130); L.set(vg, 'Feather', 65); L.set(vg, 'Chromatic Aberration', 51); }
    var gr = L.ref(P.GRAO); if (gr) { var g = L.place(E.V.GRAO, gr, a, b - a, 0); if (g) { L.motion(g, L.fill(gr)); try { L.set(L.comp(g, 'Opacity'), 'Blend Mode', 4); } catch (x) {} } }
  }
};

// ---------- Regra 2: placeholders "BAIXAR" ----------
// P.BAIXAR: [ini, fim, png (de gerar_placeholders.py), modo, texto, neg]
E.baixar = function () {
  var s = L.seq();
  for (var k = 0; k < P.BAIXAR.length; k++) {
    var e = P.BAIXAR[k], a = e[0], b = e[1]; var it = L.byPath(e[2]); var ti = (e[3] == "card3d" || e[3] == "cardreto") ? E.V.CARD : E.V.BROLL;
    var c = it ? L.place(ti, it, a, b - a, 0) : null;
    if (c) { L.motion(c, L.fill(it)); if (e[3] == "card3d") { E.fundoDesfocado(a, b); E.cartao3d(ti, c); } else if (e[3] == "cardreto") { E.fundoDesfocado(a, b); E.cartaoReto(ti, c); } if (e[5]) E.sat50(ti, c); }
    var m = s.markers.createMarker(a); m.end = b; m.name = "BAIXAR: " + e[4]; m.comments = "Trocar o placeholder pela mídia: " + e[4];
    try { m.setColorByIndex(1); } catch (x) {} // 1 = vermelho
  }
};

// ---------- destaques grandes (Anton + Wonder Glow) ----------
// JSON de impetus-upsell-up3/scripts/gerar_destaques.py (gerado no tamanho da sequência)
E.destaques = function (jsonPath, desfocar) {
  var f = new File(jsonPath); f.encoding = "UTF-8"; f.open("r"); var D = eval(f.read()); f.close();
  var bin = PPC.bin("ED/Destaques", true); var paths = []; for (var i = 0; i < D.length; i++) paths.push(D[i].f);
  app.project.importFiles(paths, true, bin, false); L.cache = null;
  var byName = {}; for (var i = 0; i < bin.children.numItems; i++) byName[bin.children[i].name] = bin.children[i];
  var grp = {}; for (var i = 0; i < D.length; i++) { var g = D[i].g; if (!grp[g]) grp[g] = [D[i].s, D[i].e]; grp[g][0] = Math.min(grp[g][0], D[i].s); grp[g][1] = Math.max(grp[g][1], D[i].e); }
  if (desfocar) for (var g in grp) if (desfocar[g]) E.fundoDesfocado(grp[g][0], grp[g][1]); // só nos grupos marcados (fundo = apresentador)
  var cam = L.ref(P.SFX.shutter);
  for (var i = 0; i < D.length; i++) {
    var e = D[i]; var it = byName[e.f.split("\\").pop().split("/").pop()]; if (!it) continue;
    var c = L.place(E.V.DEST, it, e.s, e.e - e.s, 0); if (!c) continue;
    L.glow(E.V.DEST, c); L.fx(E.V.DEST, e.s, 'Transform'); var t = L.comp(c, 'Transform'); L.set(t, 'Uniform Scale', true);
    var d = e.e - e.s; L.keys(c, t, 'Scale Height', [[0, 0], [Math.min(0.15, d * 0.4), 100], [d, 120]]);
    if (cam) L.audio(E.A.SFX3, cam, e.s, 0.4, 0, E.lv(0));
  }
};

// ---------- títulos MOGRT (gancho e frases-título) ----------
// P.TIT: [ini, fim, "ref:<nome do clipe na referência>", escala, x, y] – o texto é trocado à mão (MOGRT com 4 campos TEXTO 1..4)
E.titulos = function () {
  for (var k = 0; k < P.TIT.length; k++) {
    var e = P.TIT[k]; var it = E.item(e[2]); if (!it) continue; var c = L.place(E.V.TIT, it, e[0], e[1] - e[0], 0);
    if (c) L.motion(c, e[3] || 60, e[4] || 0.5, e[5] || 0.58);
    var m = L.seq().markers.createMarker(e[0]); m.name = "TÍTULO: trocar texto"; m.comments = e[6] || ""; try { m.setColorByIndex(4); } catch (x) {}
  }
};

// ---------- movimento e transições ----------
// P.ZOOM: [[t, tipo]] tipo "entrada" (153/126,8→100 em 0,75 s) | "lento" (100→107 em 7 s)
E.zooms = function () {
  var adj = L.adj(), sc = L.fill(adj);
  for (var k = 0; k < P.ZOOM.length; k++) {
    var T = P.ZOOM[k][0], tipo = P.ZOOM[k][1] || "entrada", dur = tipo == "lento" ? (P.ZOOM[k][2] || 4) : 0.9;
    var z = L.place(E.V.ZOOM, adj, T, dur); if (!z) continue; L.motion(z, sc);
    L.fx(E.V.ZOOM, T, 'Transform'); var t = L.comp(z, 'Transform'); L.set(t, 'Uniform Scale', true); L.set(t, "Use Composition's Shutter Angle", false); L.set(t, 'Shutter Angle', 180);
    if (tipo == "lento") L.keys(z, t, 'Scale Height', [[0, 100], [dur, 107]]); else L.keys(z, t, 'Scale Height', [[0, k % 2 ? 126.8 : 153], [0.75, 100]]);
  }
};
// zoom 100↔120 na própria bruta, nos trechos sem insert: P.ZBRUTA: [[ini, fim, entrada?]]
E.zoomBruta = function () {
  var tr = L.seq().videoTracks[E.V.BRUTA];
  for (var k = 0; k < P.ZBRUTA.length; k++) { var e = P.ZBRUTA[k]; var c = L.clipAt(tr, e[0]); if (!c) { E.log.push("zoom bruta sem clipe @" + e[0]); continue; } L.zoomT(E.V.BRUTA, c, e[2] ? 120 : 100, e[2] ? 100 : 120); }
};
// WarpShort_Up (chicote vertical 0,4 s) + [T]_Pan - Warp_Short: P.WARP [t, ...]
E.warps = function () {
  var adj = L.adj(), sc = L.fill(adj), sfx = L.ref(P.SFX.warp);
  for (var k = 0; k < P.WARP.length; k++) {
    var T = P.WARP[k]; var z = L.place(E.V.WARP, adj, T - 0.2, 0.4); if (!z) continue; L.motion(z, sc);
    L.fx(E.V.WARP, T - 0.2, 'Offset'); L.fx(E.V.WARP, T - 0.2, 'Directional Blur');
    var o = L.comp(z, 'Offset'); var s = L.seq(); if (o) L.keys(z, o, 'Shift Center To', [[0, [0.5, 0.5]], [0.4, [0.5, -0.5]]], true);
    var db = L.comp(z, 'Directional Blur'); if (db) { L.set(db, 'Direction', 0); L.keys(z, db, 'Blur Length', [[0, 0], [0.2, 120], [0.4, 0]]); }
    if (sfx) L.audio(E.A.SFX2, sfx, T - 0.25, 0.7, 0, E.lv(0));
  }
};
// clarão: light leak da referência (0,35 s antes e 0,45 s depois do corte) + shutter
E.leaks = function () {
  var leak = E.fromRef(true, "Light Leak"), cam = L.ref(P.SFX.shutter);
  for (var k = 0; k < P.LEAK.length; k++) {
    var T = P.LEAK[k]; var cs = [L.place(E.V.LEAK, leak, T - 0.35, 0.35), L.place(E.V.LEAK, leak, T, 0.45)];
    for (var j = 0; j < 2; j++) if (cs[j]) { var m = L.comp(cs[j], 'Motion'); L.set(m, 'Uniform Scale', false); L.set(m, 'Scale', 493.78); L.set(m, 'Scale Width', 177.78); }
    if (cam) L.audio(E.A.SFX4, cam, T - 0.15, 0.4, 0, E.lv(0));
  }
};
// abertura: glitch [G]_Digital_01 (0,4 s) + Glitch Digital_02 + Boom 1
E.abertura = function () {
  var g = E.fromRef(true, "[G]_Digital_01"); if (g) { var c = L.place(E.V.GLITCH, g, 0, 0.4); if (c) L.motion(c, 140); }
  var s1 = L.ref(P.SFX.glitch); if (s1) L.audio(E.A.SFX1, s1, 0, 0.43, 0.267, E.lv(0));
  var s2 = L.ref(P.SFX.boom); if (s2) L.audio(E.A.SFX2, s2, 0, 5.17, 0, E.lv(0));
};
// vinheta geral (VERTICAL VIGNETT) e granulado em blocos
E.vinheta = function () {
  var adj = L.adj(); var z = L.place(E.V.VIN, adj, 0, E.end()); if (!z) return; L.motion(z, L.fill(adj));
  L.fx(E.V.VIN, 0, 'Vignette'); var vg = L.comp(z, 'Vignette'); if (vg) { L.set(vg, 'Scale', 130); L.set(vg, 'Feather', 65); L.set(vg, 'Chromatic Aberration', 51); }
};
E.grao = function () { var gr = L.ref(P.GRAO); for (var k = 0; k < P.GRAOS.length; k++) { var e = P.GRAOS[k]; var g = L.place(E.V.GRAO, gr, e[0], e[1] - e[0], 0); if (g) { L.motion(g, L.fill(gr)); try { L.set(L.comp(g, 'Opacity'), 'Blend Mode', 4); } catch (x) {} } } };

// ---------- áudio ----------
// P.TRILHAS: [faixa(0/1), arquivo, ini, fim(-1 = até o fim), inS, dB]  – alterna faixas para não sobrepor
E.trilhas = function () {
  var END = E.end();
  for (var i = 0; i < P.TRILHAS.length; i++) {
    var e = P.TRILHAS[i], a = e[2], b = e[3] < 0 ? END : e[3], LV = E.lv(e[5]); var it = L.ref(e[1]); if (!it) { E.log.push("trilha " + e[1]); continue; }
    var c = L.audio(e[0] ? E.A.TR2 : E.A.TR1, it, a, b - a, e[4], LV); if (!c) continue;
    for (var k = 0; k < c.components.numItems; k++) { var pr = L.prop(c.components[k], "Level"); if (!pr) continue; pr.setTimeVarying(true); var base = c.inPoint.seconds, d = c.duration.seconds;
      var ks = [[0, a < 0.1 ? LV : 0.0005], [a < 0.1 ? 0.01 : 1.0, LV], [d - 1.5, LV], [d, b > END - 0.1 ? LV : 0.0005]];
      for (var q = 0; q < ks.length; q++) { pr.addKey(base + ks[q][0]); pr.setValueAtKey(base + ks[q][0], ks[q][1], true); } }
  }
};
// P.SFXL: [t, chave de P.SFX ou caminho, dB, faixa(0..3), dur, inS]
E.sfx = function () {
  var tr = [E.A.SFX1, E.A.SFX2, E.A.SFX3, E.A.SFX4];
  for (var i = 0; i < P.SFXL.length; i++) { var e = P.SFXL[i]; var it = L.ref(P.SFX[e[1]] || e[1]); if (!it) { E.log.push("sfx " + e[1]); continue; } L.audio(tr[e[3] || 0], it, e[0], e[4] || 1, e[5] || 0, E.lv(e[2] || 0)); }
};
// marcadores de bloco: [[t, nome, cor]] cor: 0 verde, 1 vermelho, 4 amarelo
E.marcadores = function (lista) { var s = L.seq(); for (var i = 0; i < lista.length; i++) { var m = s.markers.createMarker(lista[i][0]); m.name = lista[i][1]; try { m.setColorByIndex(lista[i][2] || 0); } catch (x) {} } };
E.resumo = function () { return M.resumo() + (E.log.length ? " | " + E.log.join("; ") : ""); };
