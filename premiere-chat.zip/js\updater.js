/*
 * Atualização do Premiere Chat pelo GitHub.
 *
 * Publicar = subir UM arquivo (premiere-chat.zip) no repositório configurado em update-config.json.
 * A mensagem do commit vira a nota da atualização. Cada máquina compara o último commit desse arquivo
 * com o que ela instalou (~/.premiere-chat/update-state.json); só instala quando a pessoa clica.
 *
 * Instalar: baixa o zip daquele commit, extrai, confere que é o Premiere Chat, guarda a versão atual
 * em ~/.premiere-chat/plugin-backups (últimas 5) e espelha os arquivos na pasta da extensão.
 */
(function () {
  "use strict";
  if (typeof require !== "function") {
    window.Updater = null;
    return;
  }
  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  const https = require("https");
  const http = require("http");
  const { spawn } = require("child_process");

  const HOME = path.join(os.homedir(), ".premiere-chat");
  const STATE = path.join(HOME, "update-state.json");
  const USER_CFG = path.join(HOME, "update-config.json"); // opcional: troca o repositório só nesta máquina
  const BUNDLE_ID = "com.premierechat.claude";
  const KEEP_BACKUPS = 5;

  let extDir = null;
  const api = {};

  function readJson(p, def) {
    try {
      return JSON.parse(fs.readFileSync(p, "utf8").replace(/^﻿/, ""));
    } catch {
      return def;
    }
  }
  function writeJson(p, obj) {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p + ".tmp", JSON.stringify(obj, null, 2), "utf8");
    fs.renameSync(p + ".tmp", p);
  }

  api.init = function (dir) {
    extDir = dir;
  };

  api.config = function () {
    const base = { repo: "", branch: "main", file: "premiere-chat.zip", apiBase: "https://api.github.com", rawBase: "https://raw.githubusercontent.com" };
    const fromExt = extDir ? readJson(path.join(extDir, "update-config.json"), {}) : {};
    const fromUser = readJson(USER_CFG, {});
    const cfg = Object.assign(base, fromExt, fromUser);
    cfg.repo = String(cfg.repo || "")
      .trim()
      .replace(/^https?:\/\/github\.com\//i, "")
      .replace(/\.git$/i, "")
      .replace(/\/+$/, "");
    return cfg;
  };

  api.state = () => readJson(STATE, {});

  api.installed = function () {
    const v = extDir ? readJson(path.join(extDir, "version.json"), {}) : {};
    const st = api.state();
    return { version: v.version || "?", sha: st.sha || null, installedAt: st.installedAt || null, message: st.message || "" };
  };

  // GET com redirecionamentos. Devolve Buffer, ou grava em `file`.
  function get(url, opts, depth) {
    opts = opts || {};
    depth = depth || 0;
    return new Promise((resolve, reject) => {
      const mod = url.startsWith("https:") ? https : http;
      const req = mod.get(
        url,
        { headers: Object.assign({ "User-Agent": "premiere-chat-updater", Accept: opts.accept || "*/*" }, opts.headers || {}), timeout: opts.timeout || 30000 },
        (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && depth < 5) {
            res.resume();
            return resolve(get(new URL(res.headers.location, url).toString(), opts, depth + 1));
          }
          if (res.statusCode !== 200) {
            let body = "";
            res.on("data", (d) => (body += d));
            res.on("end", () => {
              let msg = `HTTP ${res.statusCode}`;
              if (res.statusCode === 404) msg = "não encontrado (404). Confira o nome do repositório e se ele é público.";
              else if (res.statusCode === 403 && /rate limit/i.test(body)) msg = "o GitHub limitou as consultas desta internet por agora. Tente de novo em alguns minutos.";
              const err = new Error(msg);
              err.status = res.statusCode;
              reject(err);
            });
            return;
          }
          const total = Number(res.headers["content-length"]) || 0;
          let got = 0;
          if (opts.file) {
            fs.mkdirSync(path.dirname(opts.file), { recursive: true });
            const out = fs.createWriteStream(opts.file);
            res.on("data", (d) => {
              got += d.length;
              if (opts.onProgress) opts.onProgress(got, total);
            });
            res.pipe(out);
            out.on("finish", () => out.close(() => resolve(opts.file)));
            out.on("error", reject);
            res.on("error", reject);
          } else {
            const chunks = [];
            res.on("data", (d) => chunks.push(d));
            res.on("end", () => resolve(Buffer.concat(chunks)));
            res.on("error", reject);
          }
        }
      );
      req.on("timeout", () => req.destroy(new Error("a internet não respondeu (tempo esgotado).")));
      req.on("error", reject);
    });
  }

  // Último commit que mexeu no arquivo da atualização.
  api.check = async function () {
    const cfg = api.config();
    const installed = api.installed();
    if (!cfg.repo) return { configured: false, installed };
    const url = `${cfg.apiBase}/repos/${cfg.repo}/commits?path=${encodeURIComponent(cfg.file)}&sha=${encodeURIComponent(cfg.branch)}&per_page=1`;
    let buf;
    try {
      buf = await get(url, { accept: "application/vnd.github+json", timeout: 20000 });
    } catch (e) {
      // 409 = repositório ainda vazio (nada publicado).
      if (e.status === 409) return { configured: true, repo: cfg.repo, installed, latest: null, available: false };
      throw e;
    }
    let arr;
    try {
      arr = JSON.parse(buf.toString("utf8"));
    } catch {
      throw new Error("resposta inesperada do GitHub.");
    }
    const st = api.state();
    st.lastCheck = new Date().toISOString();
    try {
      writeJson(STATE, st);
    } catch {}
    if (!Array.isArray(arr) || !arr.length) return { configured: true, repo: cfg.repo, installed, latest: null, available: false };
    const c = arr[0];
    const latest = {
      sha: c.sha,
      date: (c.commit && (c.commit.committer || c.commit.author) && (c.commit.committer || c.commit.author).date) || null,
      message: (c.commit && c.commit.message) || "",
      author: (c.commit && c.commit.author && c.commit.author.name) || "",
    };
    return { configured: true, repo: cfg.repo, installed, latest, available: latest.sha !== installed.sha };
  };

  function psQuote(s) {
    return "'" + String(s).replace(/'/g, "''") + "'";
  }

  function run(exe, args) {
    return new Promise((resolve) => {
      const p = spawn(exe, args, { windowsHide: true });
      let out = "";
      p.stdout.on("data", (d) => (out += d));
      p.stderr.on("data", (d) => (out += d));
      p.on("close", (code) => resolve({ code, out }));
      p.on("error", (e) => resolve({ code: -1, out: e.message }));
    });
  }

  async function expand(zip, dest) {
    fs.rmSync(dest, { recursive: true, force: true });
    fs.mkdirSync(dest, { recursive: true });
    const r = await run("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", `$ProgressPreference='SilentlyContinue'; Expand-Archive -LiteralPath ${psQuote(zip)} -DestinationPath ${psQuote(dest)} -Force`]);
    if (r.code !== 0) throw new Error("não consegui abrir o arquivo da atualização: " + r.out.trim().slice(0, 300));
  }

  // Acha a pasta que tem CSXS/manifest.xml do Premiere Chat (o zip pode ter uma pasta por fora).
  function findRoot(dir, depth) {
    const man = path.join(dir, "CSXS", "manifest.xml");
    if (fs.existsSync(man)) {
      const txt = fs.readFileSync(man, "utf8");
      if (txt.includes(BUNDLE_ID) && fs.existsSync(path.join(dir, "index.html")) && fs.existsSync(path.join(dir, "js", "main.js"))) return dir;
    }
    if (depth >= 3) return null;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) {
        const r = findRoot(path.join(dir, e.name), depth + 1);
        if (r) return r;
      }
    }
    return null;
  }

  async function robocopy(src, dst, extra) {
    const r = await run("robocopy.exe", [src, dst, ...extra, "/R:2", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP"]);
    if (r.code < 0 || r.code >= 8) throw new Error("falha ao copiar os arquivos (robocopy " + r.code + "): " + r.out.trim().slice(0, 300));
  }

  function pruneBackups(dir) {
    try {
      const list = fs
        .readdirSync(dir, { withFileTypes: true })
        .filter((e) => e.isDirectory())
        .map((e) => e.name)
        .sort();
      while (list.length > KEEP_BACKUPS) fs.rmSync(path.join(dir, list.shift()), { recursive: true, force: true });
    } catch {}
  }

  // Baixa e instala o commit `latest`. onStatus(texto) para o painel mostrar o andamento.
  api.install = async function (latest, onStatus) {
    const say = onStatus || (() => {});
    if (!extDir || !fs.existsSync(path.join(extDir, "CSXS", "manifest.xml"))) throw new Error("não achei a pasta do plugin.");
    if (!latest || !latest.sha) throw new Error("nenhuma versão para instalar.");
    const cfg = api.config();
    const work = path.join(HOME, "updates");
    const zip = path.join(work, latest.sha.slice(0, 12) + ".zip");
    const tmp = path.join(work, latest.sha.slice(0, 12));
    const url = `${cfg.rawBase}/${cfg.repo}/${latest.sha}/${cfg.file.split("/").map(encodeURIComponent).join("/")}`;

    say("Baixando…");
    await get(url, {
      file: zip,
      timeout: 60000,
      onProgress: (got, total) => say("Baixando… " + (total ? Math.round((got / total) * 100) + "%" : Math.round(got / 1024) + " KB")),
    });
    const head = Buffer.alloc(2);
    const fd = fs.openSync(zip, "r");
    fs.readSync(fd, head, 0, 2, 0);
    fs.closeSync(fd);
    if (head.toString("latin1") !== "PK") throw new Error("o arquivo baixado não é um .zip.");

    say("Abrindo o pacote…");
    await expand(zip, tmp);
    const root = findRoot(tmp, 0);
    if (!root) throw new Error("o .zip não tem o Premiere Chat dentro (falta CSXS/manifest.xml, index.html ou js/main.js).");
    const newVersion = readJson(path.join(root, "version.json"), {}).version || "?";

    say("Guardando a versão atual…");
    const cur = api.installed().version;
    const backups = path.join(HOME, "plugin-backups");
    const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    const backup = path.join(backups, `${stamp}-v${cur}`);
    await robocopy(extDir, backup, ["/E"]);
    pruneBackups(backups);

    say("Instalando…");
    try {
      await robocopy(root, extDir, ["/MIR"]);
    } catch (e) {
      // Volta o que estava antes se a cópia falhar no meio.
      try {
        await robocopy(backup, extDir, ["/MIR"]);
      } catch {}
      throw e;
    }

    const st = api.state();
    Object.assign(st, { sha: latest.sha, version: newVersion, message: latest.message || "", installedAt: new Date().toISOString(), backup });
    writeJson(STATE, st);
    try {
      fs.rmSync(tmp, { recursive: true, force: true });
      fs.rmSync(zip, { force: true });
    } catch {}
    return { version: newVersion, backup };
  };

  // Para quem acabou de publicar desta máquina: marca o commit como já instalado.
  api.markInstalled = function (latest) {
    const st = api.state();
    Object.assign(st, { sha: latest.sha, version: api.installed().version, message: latest.message || "", installedAt: new Date().toISOString() });
    writeJson(STATE, st);
  };

  window.Updater = api;
})();
