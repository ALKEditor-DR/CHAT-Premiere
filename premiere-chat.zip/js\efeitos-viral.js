/*
 * Texto Viral: modelos próprios de 1, 2 e 3 linhas. Cada campo do editor é uma linha do modelo, e cada
 * linha tem estilo (fonte, proporção, enfeite) e animação próprios. O que a pessoa muda no campo
 * (texto, cor, fonte, peso, escala) vale por cima do modelo.
 *
 * Linha do modelo: { f: fonte, w: peso, i: itálico, k: proporção, hl: destaque, st: [estilos], an: animação,
 *   d: atraso, rot: graus, dx: deslocamento lateral, gap: distância da linha de cima }
 * Estilos: glow | extrude | outline | outfill (contorno que enche) | shine (brilho passando) | tag (etiqueta) |
 *          skewtag (etiqueta inclinada) | under (sublinhado) | strike (risco) | frame (moldura) | hard (sombra dura) | grad
 */
(function (root) {
  "use strict";
  const E = root.Efeitos;
  if (!E) return;
  const PI = Math.PI;
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  const mix = (a, b, t) => a + (b - a) * t;
  const outCubic = (u) => 1 - Math.pow(1 - u, 3);
  const outExpo = (u) => (u >= 1 ? 1 : 1 - Math.pow(2, -10 * u));
  const inCubic = (u) => u * u * u;
  const outBack = (u) => 1 + 2.7 * Math.pow(u - 1, 3) + 1.7 * Math.pow(u - 1, 2);
  const elastic = (u) => (u <= 0 ? 0 : u >= 1 ? 1 : Math.pow(2, -9 * u) * Math.sin((u * 9 - 0.75) * ((2 * PI) / 3)) + 1);
  const bounce = (u) => (u < 0.36 ? 7.6 * u * u : u < 0.73 ? 7.6 * (u -= 0.545) * u + 0.75 : u < 0.91 ? 7.6 * (u -= 0.818) * u + 0.94 : 7.6 * (u -= 0.955) * u + 0.985);
  const EASE = { outCubic, outExpo, outBack, elastic, bounce };
  // Número fixo por posição: a prévia e o vídeo saem iguais.
  const rnd = (i, s) => {
    const x = Math.sin(i * 127.1 + s * 311.7) * 43758.5453;
    return (x - Math.floor(x)) * 2 - 1;
  };

  // ---------------------------------------------------------------- animações de entrada (por unidade)
  const AN = {
    sobe: { u: "line", len: 0.5, e: "outExpo", from: { dy: 1.2 }, mask: true },
    desce: { u: "line", len: 0.5, e: "outExpo", from: { dy: -1.2 }, mask: true },
    esquerda: { u: "line", len: 0.5, e: "outExpo", from: { dx: -5, a: 0, b: 0.2 } },
    direita: { u: "line", len: 0.5, e: "outExpo", from: { dx: 5, a: 0, b: 0.2 } },
    soco: { u: "line", len: 0.3, e: "outExpo", from: { s: 2.6, a: 0, b: 0.15 }, hit: true },
    pop: { u: "word", len: 0.4, stag: 0.1, e: "outBack", from: { s: 0, a: 0 } },
    elastico: { u: "line", len: 0.9, e: "elastic", from: { s: 0.2, a: 0 } },
    quica: { u: "line", len: 0.7, e: "bounce", from: { dy: -1.8, a: 0 } },
    foco: { u: "word", len: 0.55, stag: 0.1, e: "outCubic", from: { b: 0.4, a: 0, s: 1.3 } },
    letras: { u: "char", len: 0.4, stag: 0.03, e: "outBack", from: { dy: 0.8, a: 0, s: 0.5 } },
    chuva: { u: "char", len: 0.45, stag: 0.035, e: "outBack", from: { dy: -1.3, r: 25, a: 0 } },
    espalha: { u: "char", len: 0.6, stag: 0.012, e: "outExpo", from: { a: 0, b: 0.15, scatter: 2.4 } },
    digita: { u: "char", len: 0.01, stag: 0.045, e: "outCubic", from: { a: 0 } },
    tracking: { u: "char", len: 0.8, stag: 0, e: "outExpo", from: { a: 0, spread: 0.9, b: 0.1 } },
    cortina: { u: "line", len: 0.5, e: "outExpo", from: {}, wipe: true },
    carimbo: { u: "line", len: 0.28, e: "outExpo", from: { s: 3, a: 0, r: 12 }, hit: true },
    palavras: { u: "word", len: 0.4, stag: 0.11, e: "outExpo", from: { dy: 0.9, a: 0, b: 0.15 } },
    gira: { u: "word", len: 0.5, stag: 0.1, e: "outBack", from: { r: -40, s: 0.3, a: 0 } },
    abre: { u: "line", len: 0.5, e: "outBack", from: { sy: 0, a: 0 } },
  };

  const A = "VT Anton", B = "VT Bebas", M = "VT Montserrat", P = "VT Poppins", F = "VT Abril", G = "Georgia";
  const V = [];
  const add = (n, id, nome, sample, lines, o) => V.push(Object.assign({ id: "viral-" + n + "-" + id, cat: "Texto Viral", sub: n === 1 ? "1 linha" : n + " linhas", nome, viral: lines, sample, unit: "line", len: 0.5, stag: 0.1, from: {}, ease: "outExpo" }, o));
  const h = (t) => "*" + t + "*";

  // ---------------------------------------------------------------- 1 linha
  add(1, "soco", "Soco", h("IMPACTO"), [{ f: A, hl: 1, k: 1.7, st: ["extrude"], an: "soco" }], { drift: 0.06 });
  add(1, "neon", "Neon", h("AGORA"), [{ f: M, w: 900, hl: 1, k: 1.4, st: ["glow"], an: "foco" }], { flicker: true });
  add(1, "contorno", "Contorno que enche", "VERDADE", [{ f: A, k: 1.7, st: ["outfill"], an: "cortina" }]);
  add(1, "etiqueta", "Etiqueta inclinada", h("URGENTE"), [{ f: M, w: 900, hl: 1, k: 1.3, st: ["skewtag"], an: "esquerda" }]);
  add(1, "brilho", "Brilho passando", h("EXCLUSIVO"), [{ f: M, w: 900, hl: 1, k: 1.25, st: ["shine"], an: "sobe" }], { drift: 0.05 });
  add(1, "elastico", "Elástico", h("OLHA ISSO"), [{ f: A, hl: 1, k: 1.5, st: ["hard"], an: "elastico" }]);
  add(1, "explosao", "Explosão de letras", "INCRÍVEL", [{ f: A, k: 1.6, an: "espalha" }], { drift: 0.06 });
  add(1, "carimbo", "Carimbo", h("PROIBIDO"), [{ f: A, hl: 1, k: 1.35, st: ["frame"], an: "carimbo", rot: -6 }]);
  add(1, "cinema", "Cinema", "O COMEÇO", [{ f: B, k: 1.3, an: "tracking" }], { drift: 0.08 });
  add(1, "elegante", "Elegante", h("perfeito"), [{ f: F, hl: 1, k: 1.5, an: "foco" }], { drift: 0.04 });
  add(1, "sublinhado", "Sublinhado", "SEM SEGREDO", [{ f: M, w: 900, k: 1.1, st: ["under"], an: "palavras" }]);
  add(1, "quica", "Quica", h("GRÁTIS"), [{ f: A, hl: 1, k: 1.7, st: ["extrude"], an: "quica" }]);
  add(1, "degrade", "Degradê", h("PREMIUM"), [{ f: M, w: 900, hl: 1, k: 1.35, st: ["grad"], an: "letras" }], { drift: 0.05 });

  // ---------------------------------------------------------------- 2 linhas
  add(2, "manchete", "Manchete", "isso muda\n" + h("TUDO"), [{ f: P, w: 500, k: 0.65, an: "sobe" }, { f: A, hl: 1, k: 1.9, an: "soco", d: 0.2, gap: -0.12 }], { drift: 0.05 });
  add(2, "contraste", "Contraste", "o segredo\n" + h("REVELADO"), [{ f: G, i: 1, k: 0.85, an: "foco" }, { f: M, w: 900, hl: 1, k: 1.15, an: "sobe", d: 0.18, gap: -0.05 }]);
  add(2, "etiqueta", "Etiqueta", "VOCÊ PRECISA\n" + h("VER ISSO"), [{ f: M, w: 900, k: 0.95, an: "palavras" }, { f: M, w: 900, hl: 1, k: 1.05, st: ["tag"], an: "cortina", d: 0.25, gap: 0.12 }]);
  add(2, "neon", "Neon duplo", "NUNCA\n" + h("DESISTA"), [{ f: B, k: 1.2, an: "foco" }, { f: M, w: 900, hl: 1, k: 1.3, st: ["glow"], an: "foco", d: 0.2 }], { flicker: true });
  add(2, "lados", "Dos lados", "ANTES\n" + h("DEPOIS"), [{ f: A, k: 1.4, an: "esquerda" }, { f: A, hl: 1, k: 1.4, an: "direita", d: 0.08, gap: -0.1 }], { drift: 0.04 });
  add(2, "contorno", "Vazado e cheio", "SEM\n" + h("LIMITE"), [{ f: A, k: 1.6, st: ["outline"], an: "desce" }, { f: A, hl: 1, k: 1.6, an: "sobe", d: 0.12, gap: -0.14 }]);
  add(2, "risco", "Riscado", "CARO\n" + h("SIMPLES"), [{ f: M, w: 900, k: 1, st: ["strike"], an: "palavras" }, { f: M, w: 900, hl: 1, k: 1.35, an: "pop", d: 0.6 }]);
  add(2, "assinatura", "Assinatura", "FEITO PARA\n" + h("você"), [{ f: B, k: 1.05, an: "tracking" }, { f: F, hl: 1, k: 1.7, an: "foco", d: 0.3, gap: -0.12, rot: -3 }]);
  add(2, "degraus", "Degraus", "PASSO\n" + h("A PASSO"), [{ f: M, w: 900, k: 1.1, an: "sobe", dx: -0.7 }, { f: M, w: 900, hl: 1, k: 1.1, an: "sobe", d: 0.15, dx: 0.7 }]);
  add(2, "bloco", "Bloco", "PARE DE\n" + h("ERRAR"), [{ f: A, k: 1.15, an: "cortina" }, { f: A, hl: 1, k: 1.9, st: ["extrude"], an: "quica", d: 0.2, gap: -0.1 }]);
  add(2, "maquina", "Digitado", "eu não\n" + h("ACREDITEI"), [{ f: P, w: 500, k: 0.8, an: "digita" }, { f: A, hl: 1, k: 1.5, an: "soco", d: 0.55, gap: -0.05 }]);
  add(2, "gira", "Giro", "VIRADA\n" + h("DE JOGO"), [{ f: A, k: 1.4, an: "gira" }, { f: A, hl: 1, k: 1.4, an: "gira", d: 0.2, gap: -0.1 }]);
  add(2, "brilho", "Luxo", "edição\n" + h("LIMITADA"), [{ f: G, i: 1, k: 0.8, an: "foco" }, { f: B, hl: 1, k: 1.7, st: ["shine"], an: "tracking", d: 0.15, gap: -0.05 }], { drift: 0.05 });
  add(2, "chuva", "Chuva de letras", "CHEGOU\n" + h("A HORA"), [{ f: A, k: 1.3, an: "chuva" }, { f: A, hl: 1, k: 1.6, st: ["hard"], an: "chuva", d: 0.2, gap: -0.08 }]);
  add(2, "carimbo", "Carimbo", "RESULTADO\n" + h("REAL"), [{ f: M, w: 900, k: 0.95, an: "palavras" }, { f: A, hl: 1, k: 1.7, st: ["frame"], an: "carimbo", d: 0.35, rot: -5, gap: 0.1 }]);
  add(2, "subtitulo", "Título e apoio", h("MÉTODO") + "\nque funciona de verdade", [{ f: A, hl: 1, k: 1.8, an: "sobe" }, { f: P, w: 500, k: 0.5, an: "tracking", d: 0.3 }], { drift: 0.04 });

  // ---------------------------------------------------------------- 3 linhas
  add(3, "sanduiche", "Sanduíche", "isso vai\n" + h("MUDAR") + "\na sua vida", [{ f: P, w: 500, k: 0.6, an: "sobe" }, { f: A, hl: 1, k: 2, an: "soco", d: 0.18, gap: -0.12 }, { f: P, w: 500, k: 0.6, an: "desce", d: 0.4, gap: -0.08 }], { drift: 0.05 });
  add(3, "escada", "Escada", "MAIS\nFORÇA\n" + h("MAIS VIDA"), [{ f: A, k: 1.1, an: "esquerda", dx: -0.8 }, { f: A, k: 1.1, an: "esquerda", d: 0.12, gap: -0.08 }, { f: A, hl: 1, k: 1.1, an: "esquerda", d: 0.24, dx: 0.8, gap: -0.08 }]);
  add(3, "torre", "Torre", "NINGUÉM\nTE CONTA\n" + h("ISSO"), [{ f: B, k: 1.1, an: "sobe" }, { f: B, k: 1.1, an: "sobe", d: 0.1, gap: -0.16 }, { f: A, hl: 1, k: 2, st: ["extrude"], an: "quica", d: 0.25, gap: -0.16 }]);
  add(3, "revista", "Revista", "a verdade\n" + h("SOBRE") + "\no seu corpo", [{ f: G, i: 1, k: 0.8, an: "foco" }, { f: F, hl: 1, k: 1.6, an: "sobe", d: 0.15, gap: -0.08 }, { f: G, i: 1, k: 0.8, an: "foco", d: 0.4, gap: -0.02 }], { drift: 0.04 });
  add(3, "etiquetas", "Etiquetas", "3 ERROS\n" + h("QUE TODO MUNDO") + "\nCOMETE", [{ f: A, k: 1.3, an: "pop" }, { f: M, w: 900, hl: 1, k: 0.85, st: ["tag"], an: "cortina", d: 0.2, gap: 0.1 }, { f: A, k: 1.3, an: "pop", d: 0.45, gap: 0.12 }]);
  add(3, "contorno", "Eco vazado", "FOCO\n" + h("FOCO") + "\nFOCO", [{ f: A, k: 1.3, st: ["outline"], an: "desce", d: 0.2 }, { f: A, hl: 1, k: 1.3, an: "soco", gap: -0.16 }, { f: A, k: 1.3, st: ["outline"], an: "sobe", d: 0.2, gap: -0.16 }], { drift: 0.05 });
  add(3, "neon", "Neon triplo", "QUEM\n" + h("PROVA") + "\nNÃO VOLTA", [{ f: B, k: 1, an: "foco" }, { f: M, w: 900, hl: 1, k: 1.5, st: ["glow"], an: "foco", d: 0.2 }, { f: B, k: 1, an: "foco", d: 0.45 }], { flicker: true });
  add(3, "zigue", "Zigue-zague", "PENSE\n" + h("DIFERENTE") + "\nHOJE", [{ f: M, w: 900, k: 1, an: "esquerda" }, { f: M, w: 900, hl: 1, k: 1, an: "direita", d: 0.12 }, { f: M, w: 900, k: 1, an: "esquerda", d: 0.24 }]);
  add(3, "oferta", "Oferta", "SÓ HOJE\n" + h("50% OFF") + "\naproveite", [{ f: M, w: 900, k: 0.7, an: "sobe" }, { f: A, hl: 1, k: 2, st: ["hard"], an: "elastico", d: 0.15, gap: -0.06 }, { f: P, w: 500, k: 0.6, st: ["under"], an: "palavras", d: 0.6 }]);
  add(3, "luxo", "Luxo", "coleção\n" + h("OURO") + "\n2027", [{ f: G, i: 1, k: 0.7, an: "foco" }, { f: F, hl: 1, k: 1.9, st: ["shine"], an: "foco", d: 0.15, gap: -0.06 }, { f: B, k: 0.8, an: "tracking", d: 0.4, gap: -0.04 }], { drift: 0.05 });
  add(3, "lista", "Lista", "RÁPIDO\nFÁCIL\n" + h("BARATO"), [{ f: M, w: 900, k: 0.95, an: "cortina" }, { f: M, w: 900, k: 0.95, an: "cortina", d: 0.3 }, { f: M, w: 900, hl: 1, k: 0.95, st: ["tag"], an: "cortina", d: 0.6, gap: 0.1 }]);
  add(3, "pergunta", "Pergunta", "você ainda\n" + h("ACREDITA") + "\nnisso?", [{ f: P, w: 500, k: 0.65, an: "digita" }, { f: M, w: 900, hl: 1, k: 1.2, an: "letras", d: 0.5 }, { f: P, w: 500, k: 0.65, an: "palavras", d: 0.9 }]);
  add(3, "virada", "Virada", "ERA CARO\nERA DIFÍCIL\n" + h("AGORA NÃO"), [{ f: M, w: 900, k: 0.8, st: ["strike"], an: "palavras" }, { f: M, w: 900, k: 0.8, st: ["strike"], an: "palavras", d: 0.4 }, { f: A, hl: 1, k: 1.5, an: "soco", d: 1 }]);
  add(3, "explosao", "Explosão", "ISSO É\n" + h("SURREAL") + "\nDEMAIS", [{ f: A, k: 1.1, an: "espalha" }, { f: A, hl: 1, k: 1.6, st: ["extrude"], an: "espalha", d: 0.2, gap: -0.1 }, { f: A, k: 1.1, an: "espalha", d: 0.4, gap: -0.1 }]);

  E.texts.push(...V);
  E.virals = V;
  // Campos prontos ao escolher o modelo: mantém o que já está escrito e põe fonte, peso e destaque do modelo.
  E.viralSegs = function (pr, current) {
    const lines = pr.sample.split("\n").map((l) => l.replace(/\*/g, ""));
    const old = (current || []).filter((s) => String(s.t).trim());
    const last = pr.viral.length - 1;
    // Sobrou texto do modelo anterior: continua na última linha (nada do que foi escrito se perde).
    return pr.viral.map((l, i) => ({ t: i < last ? (old[i] ? old[i].t : "") : old.slice(last).map((s) => s.t).join(" "), ph: lines[i] || "", hl: !!l.hl, font: l.f, weight: l.w || 400, size: 100 }));
  };
  E.viralSample = (pr) => pr.viral.map((l, i) => ({ t: pr.sample.split("\n")[i].replace(/\*/g, ""), hl: !!l.hl, font: l.f, weight: l.w || 400 }));

  const shade = (hex, k) => {
    const n = parseInt(String(hex).slice(1), 16) || 0;
    return "rgb(" + [n >> 16, (n >> 8) & 255, n & 255].map((v) => Math.round(k < 0 ? v * (1 + k) : mix(v, 255, k))).join(",") + ")";
  };
  const lum = (hex) => {
    const n = parseInt(String(hex).slice(1), 16) || 0;
    return 0.3 * (n >> 16) + 0.59 * ((n >> 8) & 255) + 0.11 * (n & 255);
  };

  // ---------------------------------------------------------------- desenho
  E.drawViral = function (ctx, W, H, t, cfg, pr) {
    ctx.clearRect(0, 0, W, H);
    // Enter dentro de um campo também vira linha.
    const segs = (cfg.segs && cfg.segs.length ? cfg.segs : E.toSegs(cfg.text)).flatMap((s) => String(s.t || "").split(/\r?\n/).map((t) => Object.assign({}, s, { t }))).filter((s) => s.t.trim());
    const base = Math.min(W, H) * 0.13 * (cfg.size / 100);
    const font = (px, l) => (l.i ? "italic " : "") + E.cssFont(px, l.font, l.weight);
    const lines = segs.map((s, i) => {
      const md = pr.viral[Math.min(i, pr.viral.length - 1)];
      const hl = s.hl != null ? !!s.hl : !!md.hl;
      const fo = E.fontOf(s, hl, md.f, md.w);
      const l = { md, hl, font: fo.f, weight: fo.w, i: md.i && fo.f === md.f, // itálico só na fonte do modelo
         t: String(s.t).replace(/\s+/g, " ").trim(), px: base * md.k * clamp((Number(s.size) || 100) / 100, 0.2, 4) };
      const measure = () => {
        ctx.font = font(l.px, l);
        l.w = ctx.measureText(l.t).width;
        l.asc = ctx.measureText("H").actualBoundingBoxAscent || l.px * 0.7;
      };
      measure();
      const st = md.st || [];
      const pad = (st.includes("tag") || st.includes("skewtag") || st.includes("frame") ? l.px * 0.8 : st.includes("extrude") || st.includes("hard") ? l.px * 0.25 : 0) + Math.abs(md.dx || 0) * l.px * 2;
      const k = (W * 0.9) / (l.w + pad);
      if (k < 1) {
        l.px *= k;
        measure();
      }
      l.st = st;
      l.h = Math.max(l.px * 1.12, l.asc + l.px * 0.36);
      return l;
    });
    if (!lines.length) return;
    lines.forEach((l, i) => (l.gap = i ? (l.md.gap || 0) * Math.max(l.px, lines[i - 1].px) : 0));
    let total = lines.reduce((s, l) => s + l.h + l.gap, 0);
    const cy = H * (cfg.pos != null ? cfg.pos : 0.5);
    // Não cabe na altura: reduz o bloco inteiro.
    const fit = Math.min(1, (H * 0.94) / total);
    total *= fit;
    const top = clamp(cy - total / 2, H * 0.03, Math.max(H * 0.03, H * 0.97 - total));
    const outLen = Math.min(0.28, cfg.dur * 0.2);
    const outP = clamp((t - (cfg.dur - outLen)) / outLen);
    // Entradas somadas não passam de 55 % da duração.
    const AT = lines.map((l) => {
      const an = AN[l.md.an] || AN.sobe;
      const n = an.u === "char" ? l.t.replace(/ /g, "").length : an.u === "word" ? l.t.split(" ").length : 1;
      return { an, n, start: l.md.d || 0, stag: an.stag || 0, len: an.len };
    });
    const end = Math.max(...AT.map((a) => a.start + a.len + a.stag * Math.max(0, a.n - 1)));
    const sp = Math.min(1, (cfg.dur * 0.55) / end);

    ctx.save();
    ctx.translate(W / 2, top + total / 2);
    const drift = 1 + (pr.drift || 0) * clamp(t / cfg.dur);
    // Pancada: o bloco treme de leve quando uma linha bate.
    let sx = 0, sy = 0;
    AT.forEach((a, i) => {
      if (!a.an.hit) return;
      const k = (t - (a.start + a.len * 0.75) * sp) / 0.22;
      if (k > 0 && k < 1) {
        const f = Math.floor(t * 30);
        sx += rnd(f, i) * lines[i].px * 0.05 * (1 - k);
        sy += rnd(f, i + 7) * lines[i].px * 0.05 * (1 - k);
      }
    });
    ctx.translate(sx, sy);
    ctx.scale(fit * drift * mix(1, 0.92, inCubic(outP)), fit * drift * mix(1, 0.92, inCubic(outP)));
    ctx.globalAlpha = 1 - outP;
    const baseAlpha = ctx.globalAlpha;

    let y = -total / fit / 2;
    lines.forEach((l, li) => {
      y += l.gap;
      const { an, stag, start, len } = AT[li];
      const t0 = (t - start * sp) / sp;
      const color = l.hl ? cfg.accent : cfg.color;
      const has = (s) => l.st.includes(s);
      const f = an.from;
      ctx.save();
      ctx.translate((l.md.dx || 0) * l.px, y + l.h / 2);
      if (l.md.rot) ctx.rotate((l.md.rot * PI) / 180);
      const lineP = clamp(t0 / (an.u === "line" ? len : len + stag * (AT[li].n - 1)));
      const open = outExpo(clamp(t0 / 0.45));
      const x0 = -l.w / 2;
      const bl = l.asc / 2; // linha de base

      // Enfeites atrás do texto
      if (t0 > 0 && (has("tag") || has("skewtag"))) {
        const px = l.px * 0.3, py = l.px * 0.2;
        ctx.save();
        if (has("skewtag")) ctx.transform(1, 0, -0.18, 1, 0, 0);
        ctx.fillStyle = color;
        ctx.fillRect(x0 - px, -l.asc / 2 - py, (l.w + px * 2) * open, l.asc + py * 2);
        ctx.restore();
      }
      if (t0 > 0 && has("frame")) {
        const e = outExpo(clamp(t0 / len));
        ctx.save();
        ctx.globalAlpha = baseAlpha * clamp(t0 / 0.12);
        ctx.scale(mix(2.2, 1, e), mix(2.2, 1, e));
        ctx.strokeStyle = color;
        ctx.lineWidth = l.px * 0.07;
        ctx.strokeRect(x0 - l.px * 0.28, -l.asc / 2 - l.px * 0.24, l.w + l.px * 0.56, l.asc + l.px * 0.48);
        ctx.restore();
      }

      // Unidades
      ctx.font = font(l.px, l);
      const units = [];
      if (an.u === "line") units.push({ t: l.t, x: x0, w: l.w });
      else {
        let pos = 0;
        for (const w of l.t.split(" ")) {
          const wx = x0 + ctx.measureText(l.t.slice(0, pos)).width;
          if (an.u === "word") units.push({ t: w, x: wx, w: ctx.measureText(w).width });
          else
            for (let c = 0; c < w.length; c++) {
              const a = x0 + ctx.measureText(l.t.slice(0, pos + c)).width;
              units.push({ t: w[c], x: a, w: x0 + ctx.measureText(l.t.slice(0, pos + c + 1)).width - a });
            }
          pos += w.length + 1;
        }
      }
      if (an.mask || an.wipe) {
        const pad = l.px * 0.35;
        ctx.beginPath();
        if (an.wipe) ctx.rect(x0 - pad, -l.h, (l.w + pad * 2) * open, l.h * 2);
        else ctx.rect(x0 - pad * 3, -l.h / 2 - l.px * 0.06, l.w + pad * 6, l.h + l.px * 0.16);
        ctx.clip();
      }
      units.forEach((u, i) => {
        const p = an.wipe ? (t0 > 0 ? 1 : 0) : clamp((t0 - i * stag) / len);
        if (p <= 0) return;
        const e = (EASE[an.e] || outCubic)(p);
        const q = 1 - e;
        const al = (f.a != null ? clamp(p * (an.e === "elastic" || an.e === "bounce" ? 6 : 2.2)) : 1) * (an.u === "char" && len < 0.05 ? (p >= 1 ? 1 : 0) : 1);
        ctx.save();
        ctx.globalAlpha = baseAlpha * al;
        let dx = (f.dx || 0) * l.px * q, dy = (f.dy || 0) * l.px * q;
        if (f.scatter) {
          dx += rnd(i, li) * l.px * f.scatter * q;
          dy += rnd(i, li + 3) * l.px * f.scatter * q;
        }
        if (f.spread) dx += (u.x + u.w / 2) * f.spread * q;
        ctx.translate(u.x + u.w / 2 + dx, dy);
        const r = (f.r || 0) * q + (f.scatter ? rnd(i, li + 5) * 60 * q : 0);
        if (r) ctx.rotate((r * PI) / 180);
        const s = f.s != null ? mix(f.s, 1, e) : 1;
        ctx.scale(s, f.sy != null ? Math.max(0.001, mix(f.sy, 1, e)) : s);
        const blur = (f.b || 0) * l.px * Math.max(0, q);
        if (blur > 0.4) ctx.filter = `blur(${blur.toFixed(2)}px)`;
        ctx.font = font(l.px, l);
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.lineJoin = "round";
        paint(u, l, color, has, t0, lineP, x0, bl);
        ctx.restore();
      });

      // Enfeites na frente
      const after = clamp((t0 - (len + stag * (AT[li].n - 1)) * 0.8) / 0.35);
      if (after > 0 && has("under")) {
        ctx.fillStyle = cfg.accent;
        ctx.fillRect(x0, bl + l.px * 0.16, l.w * outExpo(after), l.px * 0.09);
      }
      if (after > 0 && has("strike")) {
        ctx.fillStyle = cfg.accent;
        ctx.fillRect(x0 - l.px * 0.12, -l.px * 0.05, (l.w + l.px * 0.24) * outExpo(after), l.px * 0.11);
      }
      ctx.restore();
      y += l.h;
    });
    ctx.restore();

    function paint(u, l, color, has, t0, lineP, x0, bl) {
      const x = -u.w / 2;
      const put = (ox, oy) => ctx.fillText(u.t, x + ox, bl + oy);
      const tag = has("tag") || has("skewtag");
      let fill = tag ? (lum(color) > 120 ? "#111111" : "#ffffff") : color;
      if (cfg.shadow && !tag && !has("glow") && !has("extrude") && !has("hard") && !has("outline")) {
        ctx.shadowColor = "rgba(0,0,0,.5)";
        ctx.shadowBlur = l.px * 0.14;
        ctx.shadowOffsetY = l.px * 0.04;
      }
      if (has("extrude")) {
        const n = 10;
        ctx.fillStyle = shade(color, -0.55);
        for (let i = n; i > 0; i--) put((l.px * 0.09 * i) / n, (l.px * 0.09 * i) / n);
      }
      if (has("hard")) {
        ctx.fillStyle = "#111111";
        put(l.px * 0.07, l.px * 0.07);
        ctx.strokeStyle = "#111111";
        ctx.lineWidth = l.px * 0.08;
        ctx.strokeText(u.t, x, bl);
      }
      if (has("glow")) {
        const fl = pr.flicker && t0 < 0.5 ? (rnd(Math.floor(t0 * 24), 2) > -0.1 ? 1 : 0.35) : 1;
        ctx.globalAlpha *= fl;
        ctx.shadowColor = color;
        for (const b of [0.6, 0.28]) {
          ctx.shadowBlur = l.px * b;
          ctx.fillStyle = color;
          put(0, 0);
        }
        ctx.shadowBlur = 0;
        ctx.shadowColor = "transparent";
        fill = shade(color, 0.72);
      }
      if (has("outline")) {
        ctx.strokeStyle = color;
        ctx.lineWidth = Math.max(1, l.px * 0.035);
        ctx.strokeText(u.t, x, bl);
        return;
      }
      if (has("outfill")) {
        ctx.strokeStyle = color;
        ctx.lineWidth = Math.max(1, l.px * 0.035);
        ctx.strokeText(u.t, x, bl);
        const g = outCubic(clamp((t0 - 0.45) / 0.6));
        if (g > 0) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(x - l.px, bl + l.px * 0.3 - (l.asc + l.px * 0.5) * g, u.w + l.px * 2, (l.asc + l.px * 0.5) * g);
          ctx.clip();
          ctx.fillStyle = color;
          put(0, 0);
          ctx.restore();
        }
        return;
      }
      if (has("shine") || has("grad")) {
        // Degradê na linha inteira (cada letra pega o seu pedaço).
        const off = -(u.x + u.w / 2);
        const g = has("grad") ? ctx.createLinearGradient(0, bl - l.asc, 0, bl) : ctx.createLinearGradient(x0 + off, 0, x0 + l.w + off, l.px * 0.4);
        if (has("grad")) {
          g.addColorStop(0, shade(color, 0.65));
          g.addColorStop(0.55, color);
          g.addColorStop(1, shade(color, -0.35));
        } else {
          const c = ((Math.max(0, t0 - 0.35) / 1.6) % 1) * 1.6 - 0.3;
          g.addColorStop(0, shade(color, 0));
          for (const [d, k] of [[-0.14, 0], [0, 0.85], [0.14, 0]]) g.addColorStop(clamp(c + d), shade(color, c > -0.14 && c < 1.14 ? k : 0));
          g.addColorStop(1, shade(color, 0));
        }
        fill = g;
      }
      ctx.fillStyle = fill;
      put(0, 0);
    }
  };
})(typeof window !== "undefined" ? window : globalThis);
