/*
 * Uma IA para cada etapa do trabalho: planejar na mais capaz, executar na mais barata que dá conta.
 * Aqui ficam só as contas (preço, tempo estimado, qual IA usar); o chat e a aprovação estão em main.js.
 */
(function () {
  "use strict";

  // Etapas. `tools` limita as ferramentas (null = todas as de edição): menos instruções para a IA ler.
  const STAGES = {
    planejar: { label: "Planejar a edição", verb: "planejar", ai: "opus|medium", hint: "O que entra no vídeo e os pontos de entrada e saída." },
    aplicar: { label: "Aplicar efeitos, inserts e transições", verb: "aplicar", ai: "opus|low", run: true, tools: null },
    conferir: { label: "Conferir o resultado", verb: "conferir", ai: "sonnet|low", run: true, tools: ["get_project_state", "view_frame", "run_extendscript", "read_text_file", "list_effects", "show_images"] },
    legenda: { label: "Legenda", verb: "fazer a legenda", ai: "sonnet|low", run: true, tools: ["get_project_state", "transcribe_sequence", "create_caption_track", "view_frame", "read_text_file", "read_document", "write_text_file", "run_extendscript"] },
    organizar: { label: "Organizar e renomear", verb: "organizar", ai: "haiku|", run: true, tools: ["get_project_state", "run_extendscript", "request_import_approval"] },
    dia: { label: "Pedidos do dia a dia", verb: "fazer este pedido", ai: "sonnet|medium" },
    rapido: { label: "Comandos rápidos", verb: "fazer este comando", ai: "haiku|", tools: ["get_project_state", "run_extendscript", "view_frame", "request_import_approval"] },
  };
  // Ferramentas que só a conversa principal usa.
  const MAIN_ONLY = ["run_stage", "show_plan", "update_skill"];

  // US$ por milhão de tokens: novo, gravado na memória da conversa (1 h), relido, escrito.
  const PRICES = {
    opus: { in: 4, write: 8, read: 0.2, out: 20 },
    sonnet: { in: 2, write: 4, read: 0.1, out: 10 },
    haiku: { in: 0.1, write: 0.2, read: 0.01, out: 0.5 },
    haikuLong: { in: 0.5, write: 1, read: 0.05, out: 2.5 }, // acima de 100 mil tokens de conversa
  };
  // Pontos de partida (Opus médio = 1); o tempo e o gasto reais deste computador substituem com o uso.
  const TIME = { "opus|high": 1.3, "opus|": 1.1, "opus|medium": 1, "opus|low": 0.8, "sonnet|high": 1.5, "sonnet|": 1.4, "sonnet|medium": 1.3, "sonnet|low": 1.2, "haiku|": 0.5 };
  const COST = { "opus|high": 1.25, "opus|": 1.1, "opus|medium": 1, "opus|low": 0.8, "sonnet|high": 0.65, "sonnet|": 0.55, "sonnet|medium": 0.5, "sonnet|low": 0.4, "haiku|": 0.06 };
  const EFFORT = { low: "baixo", medium: "médio", high: "alto", xhigh: "muito alto", max: "máximo" };
  const NAMES = { opus: "Opus 5.5", sonnet: "Sonnet 5.5", haiku: "Haiku 5.5", fable: "Fable" };
  const OPTIONS = ["opus|high", "opus|medium", "opus|low", "sonnet|medium", "sonnet|low", "haiku|"];

  const family = (m) => {
    m = String(m || "").toLowerCase();
    return /opus/.test(m) ? "opus" : /sonnet/.test(m) ? "sonnet" : /haiku/.test(m) ? "haiku" : /fable/.test(m) ? "fable" : m;
  };
  const key = (model, effort) => family(model) + "|" + (family(model) === "haiku" ? "" : effort || "");
  const split = (k) => {
    const p = String(k || "").split("|");
    return { model: p[0] || "", effort: p[1] || "" };
  };
  // "Opus 5.5 (baixo)"
  function name(k) {
    const a = split(k);
    const n = NAMES[a.model] || a.model || "IA padrão da conta";
    return n + (a.effort ? " (" + (EFFORT[a.effort] || a.effort) + ")" : "");
  }
  // "claude-opus-5-5" -> "Opus 5.5": o nome do modelo que respondeu de verdade.
  function realName(id) {
    const m = String(id || "").match(/claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?!\d)/i);
    return m ? m[1][0].toUpperCase() + m[1].slice(1) + " " + m[2] + (m[3] ? "." + m[3] : "") : NAMES[family(id)] || id || "";
  }

  // IA configurada para a etapa; null = a mesma da conversa.
  function aiFor(stage, settings) {
    const v = ((settings && settings.stageAI) || {})[stage];
    if (v === "main") return null;
    return OPTIONS.includes(v) ? v : STAGES[stage].ai;
  }

  // ---------------------------------------------------------------- gasto

  const FIELDS = ["in", "write", "read", "out"];
  // calls: [{ model, in, write, read, out }]
  function spend(calls) {
    const s = { calls: 0, in: 0, write: 0, read: 0, out: 0, usd: 0, priced: true, models: [] };
    for (const c of calls || []) {
      s.calls++;
      for (const k of FIELDS) s[k] += c[k] || 0;
      const f = family(c.model);
      const p = f === "haiku" && (c.in || 0) + (c.write || 0) + (c.read || 0) > 100000 ? PRICES.haikuLong : PRICES[f];
      if (p) for (const k of FIELDS) s.usd += ((c[k] || 0) * p[k]) / 1e6;
      else s.priced = false;
      const n = realName(c.model);
      if (n && !s.models.includes(n)) s.models.push(n);
    }
    return s;
  }
  function add(list) {
    const t = { calls: 0, in: 0, write: 0, read: 0, out: 0, usd: 0, priced: true };
    for (const s of list) {
      for (const k of FIELDS.concat("calls", "usd")) t[k] += s[k] || 0;
      if (s.priced === false) t.priced = false;
    }
    return t;
  }
  const kTok = (n) => (n >= 999500 ? (n / 1e6).toFixed(1).replace(".", ",") + " mi" : n >= 1000 ? Math.round(n / 1000) + " mil" : String(Math.round(n || 0)));
  const usd = (v) => (v > 0 && v < 0.01 ? "menos de US$ 0,01" : "US$ " + v.toFixed(2).replace(".", ","));
  const tokens = (s) => kTok((s.in || 0) + (s.write || 0)) + " novos · " + kTok(s.read) + " relidos · " + kTok(s.out) + " escritos";

  // ---------------------------------------------------------------- tempo e escolha

  const unitsOf = (o) => Math.max(1, Number(o && o.items) || 1);

  /*
   * Compara a IA da etapa (ai) com a da conversa (ref). o: { items, minutes, secs }. R = Progresso (rate/learn).
   * -> { secs, refSecs, extra, saving (0..1), slower, known }
   */
  function compare(stage, ai, ref, o, R) {
    const units = unitsOf(o);
    const rate = (kind, k) => R.rate(kind + ":" + stage + ":" + k, 0);
    const est = (kind, table, k, base) => {
      const own = rate(kind, k);
      if (own) return { v: own * units, known: true };
      // Sem histórico desta IA: parte da outra do par, já medida, ou do previsto no plano.
      const other = k === ai ? ref : ai;
      const r = rate(kind, other);
      if (r) return { v: (r * units * (table[k] || 1)) / (table[other] || 1), known: false };
      return { v: (base * (table[k] || 1)) / (table[ref] || 1), known: false };
    };
    const base = Number(o && o.minutes) > 0 ? Number(o.minutes) * 60 : Number(o && o.secs) > 0 ? Number(o.secs) : Math.max(30, units * 8);
    const a = est("ia", TIME, ai, base);
    const b = est("ia", TIME, ref, base);
    const ca = est("usd", COST, ai, 1);
    const cb = est("usd", COST, ref, 1);
    const extra = a.v - b.v;
    const saving = cb.v > 0 ? Math.max(0, 1 - ca.v / cb.v) : 0;
    return { secs: a.v, refSecs: b.v, extra, saving, slower: extra >= 10 && extra >= b.v * 0.1, known: a.known && b.known };
  }
  // Guarda o tempo e o gasto reais da etapa.
  function learn(stage, ai, o, secs, cost, R) {
    if (secs > 0) R.learn("ia:" + stage + ":" + ai, secs / unitsOf(o));
    if (cost > 0) R.learn("usd:" + stage + ":" + ai, cost / unitsOf(o));
  }

  // Aprovação já dada? "projeto", "sempre" ou "". Trocar a IA da etapa pede de novo.
  const okKey = (stage, ai) => stage + ":" + ai;
  function approved(stage, ai, projectList, globalList) {
    const k = okKey(stage, ai);
    return (globalList || []).includes(k) ? "sempre" : (projectList || []).includes(k) ? "projeto" : "";
  }

  // Ferramentas de uma etapa (perfil do servidor local). Sem perfil: conversa principal, com tudo.
  function toolAllowed(profile, tool) {
    const st = STAGES[profile];
    if (!st || (!st.run && !st.tools)) return true;
    return st.tools ? st.tools.includes(tool) : !MAIN_ONLY.includes(tool);
  }

  const api = { STAGES, OPTIONS, PRICES, TIME, COST, EFFORT, family, key, split, name, realName, aiFor, spend, add, kTok, usd, tokens, compare, learn, okKey, approved, toolAllowed };
  if (typeof window !== "undefined") window.Etapas = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
