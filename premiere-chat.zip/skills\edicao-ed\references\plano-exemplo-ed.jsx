// Exemplo de plano da Edição ED (formato de P para lib_ed.jsx), baseado no começo do L4_V1 (Sal de Cavalo, GER).
// Tempos em segundos da sequência. Copie para <pasta mãe>/_projeto/plano_ed.jsx e troque tudo.
var U = "G:/Clientes/IMPETUS/";
var P = {
  REF: "L4 - CORTADA",            // sequência de referência importada no projeto (de onde vêm glitch, light leak e títulos MOGRT)
  GRAO: "G:/Clientes/IMPETUS/Inserts gerais/old-film-grain-overlay-4k-snowman-digital.mp4",
  SFX: {
    boom: "G:/EDIÇÃO/Copied_TESTE EDIÇÃO/Boom 1.mp3",
    glitch: "G:/Clientes/IMPETUS/TESTE DE EFEITOS PRATICOS/EFEITOS PRONTOS DE ML ED/[T]_Glitch - Digital_02.wav",
    riser: "G:/EDIÇÃO/Copied_TESTE EDIÇÃO/Riser.wav",
    swoosh28: "G:/Clientes/IMPETUS/TESTE DE EFEITOS PRATICOS/EFEITOS PRONTOS DE ML ED/Swoosh Transition 28.wav",
    swoosh08: "G:/Clientes/IMPETUS/TESTE DE EFEITOS PRATICOS/EFEITOS PRONTOS DE ML ED/SFX - Swoosh 08.mp3",
    woosh02: "G:/EDIÇÃO/Copied_TESTE EDIÇÃO/Woosh 02.mp3",
    acute: "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Risers/Acute Whoosh.mp3",
    bell: "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Risers/Reverse Bell 1.wav",
    shutter: "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Cameras/Camera Shutter Click 12.wav",
    warp: "G:/Clientes/IMPETUS/TESTE DE EFEITOS PRATICOS/EFEITOS PRONTOS DE ML ED/[T]_Pan - Warp_Short.wav"
  },
  // [ini, fim, ref, inS, modo, neg, somDb]
  INS: [
    [2.17, 4.13, U + "Videos finalizados/ED/Copiado_PORN ACERVO_1/<arquivo>.mp4", 457.9, "dividida", false, -12],
    [7.87, 14.20, U + "Inserts gerais/ED/<arquivo>.mp4", 12.0, "card3d", false, 0],          // promessa + destaques Anton por cima
    [28.57, 31.57, U + "Inserts gerais/ED/uobbtmh3e75_Everything is possible even soft dick, Thumbs down.mp4", 541.5, "cheio", true, null], // "mein Soldat ging in Rente" -> Regra 1
    [31.57, 34.57, U + "Inserts gerais/Homens/0_Man_Bed_3840x2160.mov", 2.0, "cheio", true, null],               // "Scheidung" -> Regra 1
    [39.43, 40.17, U + "Inserts gerais/ED/0_Addiction_Analgesic_4096x2304.mov", 1.9, "cheio", true, null],      // "Pillen" -> Regra 1
    [40.07, 40.93, U + "Inserts gerais/ED/Bomba peniana.mp4", 39.8, "cheio", true, null],                       // "Pumpen" -> Regra 1
    [42.20, 45.13, U + "Inserts gerais/ED/MEU_PENIS_MOLE_E_PEQUENO_-_XVIDEOS.COM.mp4", 10.0, "cheio", true, null] // "habe ich versagt" -> Regra 1
  ],
  NEG: [[28.57, 45.13]],                       // trechos negativos: vinheta + VHS + granulado por cima
  BAIXAR: [],                                  // preenchido com o baixar.json de gerar_placeholders.py
  TIT: [[0.0, 2.17, "ref:Mach diesen / Porno-Trick", 60, 0.47, 0.585, "Mach diesen / PORNO-TRICK / mit Pferdesalz / nicht,"]],
  ZOOM: [[0.0, "entrada"], [14.2, "entrada"], [25.63, "entrada"], [20.3, "lento", 3.7]],
  ZBRUTA: [[14.20, 17.67, true]],
  WARP: [],
  LEAK: [5.47, 17.67],
  GRAOS: [[28.57, 34.57], [39.43, 45.13]],
  // [faixa, arquivo, ini, fim, inS, dB]
  TRILHAS: [[0, "G:/Clientes/IMPETUS/Inserts gerais/MÚSICAS/vibedepot-free-rock-446606.mp3", 0, 45.1, 0, -19],
            [1, "G:/Clientes/IMPETUS/Inserts gerais/MÚSICAS/vibedepot-rock-free-446609.mp3", 44.67, 98.17, 8.63, -19]],
  // [t, chave, dB, faixa, dur, inS]
  SFXL: [[7.27, "riser", -12.2, 1, 0.67], [13.6, "woosh02", -13, 2, 0.97, 0.1], [17.5, "swoosh28", -5, 0, 0.7]]
};
var MARCADORES = [[0, "GANCHO", 4], [14.2, "HISTÓRIA", 0], [28.57, "NEGATIVO (Regra 1)", 1]];
