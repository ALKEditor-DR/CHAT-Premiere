/*
 * Som das transições, com o ponto mais forte exatamente no corte.
 * 1) Animation Composer instalado neste PC: usa os WAV que já estão lá, por referência (nada é copiado).
 * 2) Sem ele (ou se a pessoa preferir): som próprio, sintetizado na medida da transição.
 */
(function (root) {
  "use strict";
  const node = typeof require === "function";
  const fs = node ? require("fs") : null;
  const path = node ? require("path") : null;
  const os = node ? require("os") : null;
  const api = {};
  const SR = 48000;

  // ------------------------------------------------------------- sons instalados do Animation Composer

  const AC = {
    Zoom: ["Swoosh Transition 03", "Swoosh 04 - 02"],
    Deslizar: ["Soft Slide 02", "Hard Slide 01", "Swoosh 04 - 02"],
    Chicote: ["Swoosh 04 - 02", "Swoosh 01 - 01"],
    Giro: ["Swoosh Transition 28", "Swoosh Transition 03"],
    Desfoque: ["Transition Basic 03", "Soft Slide 02"],
    Luz: ["Transition Basic 03", "Swoosh Transition 03"],
    Impacto: ["Powerful Blockbuster Hit 01", "Medium Cinematic Boom 14"],
  };
  const AC_ID = {
    "zoom-atravessa": ["Swoosh Transition 23"],
    "zoom-suave": ["Soft Slide 02"],
    queda: ["Hard Slide 01"],
    apagar: ["Medium Cinematic Boom 04"],
    tremor: ["Medium Cinematic Boom 14"],
    elastico: ["Elastic Soft Rubber Creak 01"],
    glitch: [], // só o som próprio
  };
  let acFiles = null;
  function acDir() {
    const base = process.platform === "win32" ? process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local") : path.join(os.homedir(), "Library", "Application Support");
    return path.join(base, "MisterHorse", "ProductManager", "AssetPacks");
  }
  api._acDir = null; // teste
  function acList() {
    if (acFiles) return acFiles;
    acFiles = [];
    const walk = (d, deep) => {
      let l = [];
      try {
        l = fs.readdirSync(d, { withFileTypes: true });
      } catch {}
      for (const x of l) {
        const p = path.join(d, x.name);
        if (x.isDirectory()) deep < 6 && walk(p, deep + 1);
        else if (/\.wav$/i.test(x.name)) acFiles.push({ name: x.name.replace(/ #[0-9a-f]+\.wav$|\.wav$/i, ""), file: p });
      }
    };
    if (node) walk(api._acDir || acDir(), 0);
    return acFiles;
  }
  api.hasComposer = () => acList().length > 0;
  function composerFile(tr) {
    for (const want of AC_ID[tr.id] || AC[tr.cat] || []) {
      const hit = acList().find((x) => x.name === want || x.name.indexOf(want + " ") === 0);
      if (hit) return hit.file;
    }
    return null;
  }

  // ------------------------------------------------------------- leitura: duração, pico e onde ele está

  const cache = new Map();
  // -> { dur, peakDb, at (segundos do ponto mais forte) } ou null (não é um WAV que dá para ler).
  api.measure = function (file) {
    let key = file;
    try {
      key = file + fs.statSync(file).mtimeMs;
    } catch {
      return null;
    }
    if (cache.has(key)) return cache.get(key);
    let r = null;
    try {
      r = measureWav(fs.readFileSync(file));
    } catch {}
    cache.set(key, r);
    return r;
  };
  function measureWav(b) {
    if (b.toString("latin1", 0, 4) !== "RIFF" || b.toString("latin1", 8, 12) !== "WAVE") return null;
    let fmt = null;
    let data = null;
    for (let p = 12; p + 8 <= b.length; ) {
      const id = b.toString("latin1", p, p + 4);
      const len = b.readUInt32LE(p + 4);
      if (id === "fmt ") fmt = { tag: b.readUInt16LE(p + 8), ch: b.readUInt16LE(p + 10), rate: b.readUInt32LE(p + 12), bits: b.readUInt16LE(p + 22), sub: len >= 26 ? b.readUInt16LE(p + 32) : 0 };
      if (id === "data") data = { at: p + 8, len: Math.min(len, b.length - p - 8) };
      p += 8 + len + (len % 2);
    }
    if (!fmt || !data) return null;
    const bytes = fmt.bits / 8;
    const float = fmt.tag === 3 || (fmt.tag === 0xfffe && fmt.sub === 3);
    const get = float ? (bytes === 8 ? (o) => b.readDoubleLE(o) : (o) => b.readFloatLE(o)) : bytes === 1 ? (o) => (b[o] - 128) / 128 : (o) => b.readIntLE(o, bytes) / Math.pow(2, fmt.bits - 1);
    const step = bytes * fmt.ch;
    const n = Math.floor(data.len / step);
    if (!n) return null;
    const win = Math.max(1, Math.round(fmt.rate * 0.02));
    let peak = 0;
    let best = -1;
    let at = 0;
    for (let i = 0; i < n; i += win) {
      let e = 0;
      const end = Math.min(n, i + win);
      for (let k = i; k < end; k++)
        for (let c = 0; c < fmt.ch; c++) {
          const v = get(data.at + k * step + c * bytes);
          const a = v < 0 ? -v : v;
          if (a > peak) peak = a;
          e += v * v;
        }
      if (e > best * 1.0001) {
        best = e;
        at = (i + end) / 2 / fmt.rate;
      }
    }
    return { dur: n / fmt.rate, peakDb: peak > 0 ? 20 * Math.log10(peak) : -90, at };
  }

  // ------------------------------------------------------------- som próprio

  // Cada som: faixas de ruído que varrem de grave a agudo até o corte, e camadas de graves/brilho.
  const KIND = {
    Zoom: { f: [220, 2600, 500], q: 0.9, sub: 0.35 },
    Deslizar: { f: [500, 3200, 700], q: 1.1, pan: 1 },
    Chicote: { f: [700, 5200, 900], q: 1.3, pan: 1, fast: 1 },
    Giro: { f: [300, 3400, 380], q: 1.6, pan: 0.7, flutter: 9 },
    Desfoque: { f: [160, 1200, 220], q: 0.7, soft: 1 },
    Luz: { f: [900, 7000, 1600], q: 0.8, shine: 1 },
    Impacto: { f: [200, 1500, 180], q: 0.8, sub: 1, hit: 1 },
  };
  const ID = {
    "zoom-suave": { f: [140, 900, 260], q: 0.7, soft: 1 },
    queda: { f: [600, 2400, 200], q: 1, sub: 0.6, hit: 0.5 },
    apagar: { f: [300, 700, 120], q: 0.8, sub: 0.8, soft: 1 },
    glitch: { f: [1200, 4200, 2000], q: 1.2, crush: 1 },
    elastico: { f: [300, 1400, 400], q: 1.4, flutter: 14, sub: 0.3 },
  };
  api.synth = function (tr, out, inn) {
    const k = ID[tr.id] || KIND[tr.cat] || KIND.Zoom;
    const lead = Math.max(0.12, out * 1.15);
    const tail = Math.max(0.25, inn * (k.hit ? 2 : 1.15));
    const n = Math.round((lead + tail) * SR);
    const nl = Math.round(lead * SR);
    const L = new Float32Array(n);
    const R = new Float32Array(n);
    let seed = 7;
    for (const c of tr.id) seed = (seed * 31 + c.charCodeAt(0)) >>> 0;
    const rnd = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 2147483648 - 1;
    };
    const side = /esquerda/.test(tr.id) ? -1 : 1;
    const st = [0, 0, 0, 0];
    let ph = 0;
    let ph2 = 0;
    let hold = 0;
    let held = [0, 0];
    for (let i = 0; i < n; i++) {
      const t = (i - nl) / SR;
      const u = Math.max(0, t < 0 ? 1 + t / lead : 1 - t / tail); // 0..1..0, com o topo no corte
      const env = t < 0 ? Math.pow(u, k.soft ? 2 : k.fast ? 4.5 : 3) : Math.pow(u, k.soft ? 1.8 : 2.6);
      const f = t < 0 ? k.f[0] * Math.pow(k.f[1] / k.f[0], Math.pow(u, 1.6)) : k.f[2] * Math.pow(k.f[1] / k.f[2], Math.pow(u, 2));
      // Filtro de estado variável estável (varre a frequência sem estourar).
      const g = Math.tan((Math.PI * Math.min(f, 18000)) / SR);
      const d = 1 / k.q;
      const a1 = 1 / (1 + g * (g + d));
      const ns = [rnd(), rnd()];
      let a = env * (k.flutter ? 0.75 + 0.25 * Math.sin(2 * Math.PI * k.flutter * t) : 1);
      const v = [0, 0];
      for (let c = 0; c < 2; c++) {
        const v3 = ns[c] - st[c * 2 + 1];
        const band = a1 * st[c * 2] + g * a1 * v3;
        const low = st[c * 2 + 1] + g * band;
        st[c * 2] = 2 * band - st[c * 2];
        st[c * 2 + 1] = 2 * low - st[c * 2 + 1];
        v[c] = (band * 0.9 + low * 0.35) * a;
      }
      if (k.shine) {
        const s = rnd() * 0.18 * Math.pow(env, 1.5);
        v[0] += s;
        v[1] -= s;
      }
      if (k.sub) {
        ph += (2 * Math.PI * (t < 0 ? 45 + 30 * u : 42 + 45 * Math.pow(u, 6))) / SR;
        const s = Math.sin(ph) * k.sub * 0.7 * (t < 0 ? Math.pow(u, 5) * 0.5 : Math.pow(u, k.hit ? 2.2 : 3.5));
        v[0] += s;
        v[1] += s;
      }
      if (k.hit && t >= 0 && t < 0.06) {
        ph2 += (2 * Math.PI * 160) / SR;
        const s = (Math.sin(ph2) * 0.5 + rnd() * 0.5) * k.hit * Math.pow(1 - t / 0.06, 2);
        v[0] += s;
        v[1] += s;
      }
      if (k.crush) {
        const gate = Math.sin(t * 190) * Math.sin(t * 71) > -0.15 ? 1 : 0.1;
        if (hold-- <= 0) {
          hold = 3 + Math.floor((rnd() + 1) * 5);
          held = [v[0] * gate, v[1] * gate];
        }
        v[0] = held[0];
        v[1] = held[1];
      }
      const pan = k.pan ? side * k.pan * Math.max(-1, Math.min(1, t / Math.max(out, inn))) : 0;
      L[i] = v[0] * Math.sqrt((1 - pan * 0.8) / 2) * 1.41;
      R[i] = v[1] * Math.sqrt((1 + pan * 0.8) / 2) * 1.41;
    }
    // Sem estalo no começo e no fim; pico em -1 dB.
    const fade = Math.round(SR * 0.006);
    let pk = 0;
    for (let i = 0; i < n; i++) {
      const e = Math.min(1, i / fade, (n - 1 - i) / fade);
      L[i] *= e;
      R[i] *= e;
      pk = Math.max(pk, Math.abs(L[i]), Math.abs(R[i]));
    }
    const gain = pk ? 0.89 / pk : 0;
    const buf = Buffer.alloc(44 + n * 4);
    buf.write("RIFF", 0);
    buf.writeUInt32LE(36 + n * 4, 4);
    buf.write("WAVEfmt ", 8);
    buf.writeUInt32LE(16, 16);
    buf.writeUInt16LE(1, 20);
    buf.writeUInt16LE(2, 22);
    buf.writeUInt32LE(SR, 24);
    buf.writeUInt32LE(SR * 4, 28);
    buf.writeUInt16LE(4, 32);
    buf.writeUInt16LE(16, 34);
    buf.write("data", 36);
    buf.writeUInt32LE(n * 4, 40);
    for (let i = 0; i < n; i++) {
      buf.writeInt16LE(Math.round(L[i] * gain * 32767), 44 + i * 4);
      buf.writeInt16LE(Math.round(R[i] * gain * 32767), 46 + i * 4);
    }
    return { buf, lead, dur: n / SR };
  };

  /*
   * O som desta transição: mode = "auto" (Animation Composer, senão o próprio), "proprio", "off" ou um arquivo da pessoa.
   * -> { file, lead (do começo até o corte), dur, peakDb, own } ou null (sem som).
   */
  api.pick = function (tr, out, inn, mode, dir) {
    if (!node || mode === "off") return null;
    const own = () => {
      const f = path.join(dir, `${tr.id}-${Math.round(out * 100)}-${Math.round(inn * 100)}.wav`);
      const s = api.synth(tr, out, inn);
      if (!fs.existsSync(f)) {
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(f, s.buf);
      }
      return { file: f, lead: s.lead, dur: s.dur, peakDb: -1, own: true };
    };
    if (mode === "proprio") return own();
    const file = mode && mode !== "auto" ? mode : composerFile(tr);
    if (!file || !fs.existsSync(file)) {
      if (mode && mode !== "auto") throw new Error("Não achei o som escolhido: " + file);
      return own();
    }
    const m = api.measure(file);
    if (!m) return mode && mode !== "auto" ? { file, lead: null, dur: null, peakDb: null } : own();
    return { file, lead: m.at, dur: m.dur, peakDb: m.peakDb };
  };

  root.SomTransicao = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
