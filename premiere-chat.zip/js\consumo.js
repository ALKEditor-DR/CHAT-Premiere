/*
 * Consumo: quanto resta do limite de cada conta, quantos tokens o chat aberto já gastou e a compactação da conversa.
 * Os limites vêm dos comandos oficiais (claude /usage e codex app-server), que não gastam tokens nem leem senhas.
 */
(function (root) {
  "use strict";
  const req = typeof require === "function" ? require : null;
  const fs = req && req("fs");
  const path = req && req("path");
  const os = req && req("os");
  const cp = req && req("child_process");

  const clampPct = (n) => Math.max(0, Math.min(100, Math.round(n)));

  // ---------------------------------------------------------------- limites das contas

  const MES = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const two = (n) => String(n).padStart(2, "0");
  // "Nov 25, 6:39pm (America/Sao_Paulo)" -> "25/11 às 18:39"
  function resetText(s) {
    const m = String(s || "").match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2})(?:,| at)? *(\d{1,2})(?::(\d{2}))? *(am|pm)/i);
    if (!m || !MES[m[1].toLowerCase()]) {
      const h = String(s || "").match(/^(\d{1,2})(?::(\d{2}))? *(am|pm)/i);
      if (h) return "às " + two((+h[1] % 12) + (/pm/i.test(h[3]) ? 12 : 0)) + ":" + (h[2] || "00");
      return String(s || "").replace(/\s*\(.*\)$/, "").trim();
    }
    return `${two(+m[2])}/${two(MES[m[1].toLowerCase()])} às ${two((+m[3] % 12) + (/pm/i.test(m[5]) ? 12 : 0))}:${m[4] || "00"}`;
  }
  const resetUnix = (sec) => {
    const d = new Date(sec * 1000);
    return `${two(d.getDate())}/${two(d.getMonth() + 1)} às ${two(d.getHours())}:${two(d.getMinutes())}`;
  };

  // Texto do /usage -> [{ label, used, left, reset }]
  function parseClaude(text) {
    const out = [];
    for (const line of String(text || "").split("\n")) {
      const m = line.match(/^\s*Current (session|week)(?: \(([^)]*)\))?: *([\d.]+)% used(?:.*?resets? (.+))?/i);
      if (!m) continue;
      const extra = m[2] && !/all models/i.test(m[2]) ? " " + m[2].replace(/ only$/i, "") : "";
      const used = clampPct(+m[3]);
      out.push({ label: (/session/i.test(m[1]) ? "5 h" : "semana") + extra, used, left: 100 - used, reset: resetText(m[4]) });
    }
    return out;
  }
  // Resposta do account/rateLimits/read do Codex
  function parseCodex(r) {
    const l = (r && (r.rateLimits || r.rate_limits)) || r || {};
    const out = [];
    for (const w of [l.primary, l.secondary]) {
      if (!w) continue;
      const pct = w.usedPercent != null ? w.usedPercent : w.used_percent;
      const min = w.windowDurationMins || w.window_minutes || 0;
      const at = w.resetsAt || w.resets_at;
      if (pct == null) continue;
      const used = clampPct(pct);
      const label = min >= 40000 ? "mês" : min >= 9000 ? "semana" : min >= 1400 ? Math.round(min / 1440) + " d" : min ? Math.round(min / 60) + " h" : "limite";
      out.push({ label, used, left: 100 - used, reset: at ? resetUnix(at) : "" });
    }
    return out;
  }

  function claudeLimits(bridge, exe) {
    return bridge.runSimple(exe, ["-p", "/usage", "--output-format", "json", "--strict-mcp-config", "--no-session-persistence"], 40000).then((r) => {
      try {
        return parseClaude(JSON.parse(r.out).result);
      } catch {
        return [];
      }
    });
  }
  function codexLimits(bridge, exe) {
    return new Promise((resolve) => {
      let done = false;
      let buf = "";
      let child;
      const end = (v) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        try {
          child.kill();
        } catch {}
        resolve(v);
      };
      const timer = setTimeout(() => end([]), 20000);
      try {
        child = cp.spawn(exe, ["app-server"], { cwd: os.tmpdir(), env: bridge.subscriptionEnv(), windowsHide: true, stdio: ["pipe", "pipe", "ignore"] });
      } catch {
        return end([]);
      }
      const send = (o) => child.stdin.write(JSON.stringify(o) + "\n");
      child.on("error", () => end([]));
      child.on("close", () => end([]));
      child.stdin.on("error", () => end([]));
      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (d) => {
        buf += d;
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          let m = null;
          try {
            m = JSON.parse(buf.slice(0, nl));
          } catch {}
          buf = buf.slice(nl + 1);
          if (!m) continue;
          if (m.id === 1) {
            send({ method: "initialized" });
            send({ id: 2, method: "account/rateLimits/read" });
          } else if (m.id === 2) end(m.result ? parseCodex(m.result) : []);
        }
      });
      send({ id: 1, method: "initialize", params: { clientInfo: { name: "premiere-chat", version: "1" } } });
    });
  }

  // ---------------------------------------------------------------- tokens do chat

  const ZERO = () => ({ calls: 0, in: 0, write: 0, read: 0, out: 0, usd: 0, priced: true });
  const total = (s) => (s ? (s.in || 0) + (s.write || 0) + (s.read || 0) + (s.out || 0) : 0);

  // Chat que já existia antes desta contagem: soma o que o Claude Code registrou na conversa.
  function sessionCalls(text) {
    const byId = new Map();
    for (const line of String(text).split("\n")) {
      if (line.indexOf('"usage"') < 0) continue;
      let e;
      try {
        e = JSON.parse(line);
      } catch {
        continue;
      }
      const m = e.type === "assistant" && e.message;
      if (!m || !m.usage || /synthetic/.test(m.model || "")) continue;
      const u = m.usage;
      const c = { model: m.model || "", in: u.input_tokens || 0, write: u.cache_creation_input_tokens || 0, read: u.cache_read_input_tokens || 0, out: u.output_tokens || 0 };
      const old = byId.get(m.id || e.uuid);
      if (old) c.out = Math.max(c.out, old.out);
      byId.set(m.id || e.uuid, c);
    }
    return [...byId.values()];
  }
  function readSession(sessionId, done) {
    if (!fs || !/^[\w-]{8,}$/.test(sessionId || "")) return done(null);
    const base = path.join(process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), ".claude"), "projects");
    fs.readdir(base, (err, list) => {
      if (err) return done(null);
      const file = list.map((d) => path.join(base, d, sessionId + ".jsonl")).find((f) => fs.existsSync(f));
      if (!file) return done(null);
      fs.readFile(file, "utf8", (e2, t) => done(e2 ? null : sessionCalls(t)));
    });
  }

  // ---------------------------------------------------------------- compactar

  const KEEP =
    "Resuma esta conversa em português, sem perder nada que ainda importe para continuar a edição. Mantenha com os valores exatos (copie, não arredonde): " +
    "1) todos os pedidos do usuário, com as palavras dele quando forem regra ou preferência, e o que ele recusou ou corrigiu; " +
    "2) decisões tomadas, regras e skill do cliente em uso; " +
    "3) planos aprovados com pontos de entrada e saída, trilhas, textos e valores (cores, fontes, tamanhos, volumes, durações); " +
    "4) nomes e caminhos completos de arquivos, projetos, sequências, bins e presets; " +
    "5) o que já foi feito na timeline e como conferir; 6) o que falta fazer, em ordem; " +
    "7) erros encontrados, como foram resolvidos e os que seguem pendentes; 8) o que foi aprovado ou não para importar. " +
    "Corte só repetição, saídas longas de ferramenta, tentativas descartadas e imagens já analisadas.";

  // Conversa inteira em texto, guardada antes de compactar.
  function transcript(tab, title) {
    const out = ["# " + title, "Conversa completa guardada antes de compactar em " + new Date().toLocaleString("pt-BR") + ".", ""];
    for (const e of tab.log) {
      if (e.t === "u") out.push("## Usuário", e.text + (e.atts && e.atts.length ? `\n[anexos: ${e.atts.join(", ")}]` : ""), "");
      else if (e.t === "a" && e.text) out.push("## Chat", e.text, "");
      else if (e.t === "s") out.push(`- ${e.ok === false ? "FALHOU: " : ""}${e.label}` + (e.out ? "\n  " + String(e.out).slice(0, 1200).replace(/\n/g, "\n  ") : ""));
      else if (e.t === "ap") out.push(`- Aprovação: ${e.title} ${e.detail || ""} → ${e.result === true ? "aprovado" : e.result === false ? "recusado" : String(e.result)}`);
      else if (e.t === "ch") out.push("- Escolha: " + JSON.stringify(e).slice(0, 1500));
      else if (e.t === "plan") out.push("- Plano: " + JSON.stringify(e).slice(0, 8000));
      else if (e.t === "e") out.push("- Erro: " + e.text);
      else if (e.t === "n") out.push("- Aviso: " + e.text);
    }
    return out.join("\n");
  }
  function saveTranscript(tab, title) {
    const dir = path.join(os.homedir(), ".premiere-chat", "historico", "compactados");
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${tab.key}-${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14)}.md`);
    fs.writeFileSync(file, transcript(tab, title), "utf8");
    return file;
  }

  const api = { parseClaude, parseCodex, resetText, claudeLimits, codexLimits, sessionCalls, readSession, transcript, saveTranscript, total, ZERO, KEEP };
  if (typeof window !== "undefined") window.Consumo = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(this);
