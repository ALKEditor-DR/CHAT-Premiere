// PLANO DE EXEMPLO: UP 3 HerzPur/GlucoVital/NachtPrime (GER), aprovado 2026-11-20.
// Tempos em segundos da sequencia. Refs: "n:<nome do item no projeto>" ou "U:<caminho relativo a U>".
// P3D: [ini, fim, png, escala%, fundo, inS fundo, desfocarFundo] -> mockup com ZOOM IN/OUT 20X (alternado).
// Destaques: faixas em destaques_ranges.json (ver gerar_destaques.py).
var U = "G:\\Clientes\\IMPETUS\\UPSELL  HerzPur  UP1A V1  Ger  Digistore\\UP3\\";
var HP1 = "U:Mockup HerzPur\\ANIMADOS\\1 pote\\", HP2 = "U:Mockup HerzPur\\ANIMADOS\\2 potes\\", HP3 = "U:Mockup HerzPur\\ANIMADOS\\3 potes\\", HP6 = "U:Mockup HerzPur\\ANIMADOS\\6 potes\\";
var GV1 = "U:Mockup Gluco Vital\\MOCKUP ANIMADO\\Horizontal\\1 POTE\\magnific_", GV2 = "U:Mockup Gluco Vital\\MOCKUP ANIMADO\\Horizontal\\2 POTES\\magnific_", GV3 = "U:Mockup Gluco Vital\\MOCKUP ANIMADO\\Horizontal\\3 POTES\\magnific_";
var NP1 = "U:Mockup NachtPrime\\Animados\\1 POTE\\", NP2 = "U:Mockup NachtPrime\\Animados\\2 POTE\\", NP3 = "U:Mockup NachtPrime\\Animados\\3 POTE\\", NP6 = "U:Mockup NachtPrime\\Animados\\6 POTE\\";
var PNG_HP = "U:Mockup HerzPur\\Mockup_HerzPur GER 01.png", PNG_GV = "U:Mockup Gluco Vital\\GlucoVital GE-1.png", PNG_NP = "U:Mockup NachtPrime\\Mockup_NachtPrime 01.png";
var PNG_NP3 = "U:Mockup NachtPrime\\Mockup_NachtPrime GER 03.png", PNG_NP6 = "U:Mockup NachtPrime\\Mockup_NachtPrime GER 06.png";
var BGNP = "n:BG NACHTPRIME.mp4";
// B-roll V2: [ini, fim, ref, inS]
var BROLL = [
[4.29,6.21,"n:smiling-man-watching-video-on-mobile-phone-2026-10-03-05-26-27-utc.mp4",0],
[6.21,8.38,"n:scientists-packaging-bottles-in-a-bright-lab-2025-12-17-06-33-30-utc.mov",0],
[8.38,10.75,"n:packing-goods-in-a-cardboard-box-close-up-packagi-2026-01-22-07-22-42-utc.mp4",0],
[10.75,12.79,"n:worker-strapping-and-labeling-cardboard-box-at-fac-2025-12-17-05-01-22-utc.mov",0],
[12.79,14.42,HP1+"7.mp4",0],
[14.42,16.21,"n:3d-animation-of-red-blood-cells-flowing-through-ar-2026-05-20-21-08-06-utc.mp4",0],
[16.21,18.92,"n:0_Visual_Abstract_2160x3840.mov",0],
[18.92,21.0,HP2+"3.mp4",0],
[21.0,22.92,"n:man-checking-blood-pressure-using-a-digital-machin-2025-12-17-07-21-47-utc.mov",0],
[24.50,26.62,GV1+"slow-cinematic-zoom-in-fo_nVTRBwGYQD.mp4",0],
[26.62,28.29,"n:cholesterol-buildup-in-artery-with-blood-flow-3d-a-2026-01-28-02-46-25-utc.mov",0],
[28.29,30.79,"n:0_Thrombus_Angioplasty_3840x2160.mp4",0],
[30.79,33.17,"n:0_Red_Blood_Cells_Blood_2160x3840.mp4",0],
[33.17,34.75,GV2+"slow-cinematic-pushin-zoo_BhmMOjvoQR.mp4",0],
[37.29,39.88,"n:doctor-writing-prescription-for-patient-in-office-2025-12-17-16-45-13-utc.mov",0],
[39.88,46.29,"n:senior-man-sleeping-peacefully-in-bed-at-home-2025-12-17-20-44-54-utc.mov",0],
[65.08,67.62,"n:tired-senior-man-with-hand-on-forehead-2025-12-17-08-27-29-utc.mov",0],
[67.62,69.62,"n:old-man-back-pain-and-getting-up-in-nursing-home-2025-12-17-22-42-07-utc.mov",0],
[69.62,72.29,"n:senior-man-using-walker-in-modern-kitchen-2026-10-03-01-55-51-utc.mp4",0],
[75.17,77.00,"n:1111161_Stress_Upset_3840x2160.mp4",0],
[77.00,78.42,"n:futuristic-3d-human-anatomy-with-beating-heart-ani-2026-01-28-03-33-15-utc.mov",0],
[78.42,81.71,"n:5994212_Scientist_Laboratory_3840x2160.mp4",0],
[81.71,84.12,"n:0_Microscope_Micro_2160x3840.mp4",0],
[84.12,86.25,"n:5383215_Coll_wavebreak_Hospital_3840x2160.mp4",0],
[88.29,89.88,"n:senior-man-s-face-in-striking-close-up-2025-12-17-13-27-05-utc.mov",0],
[89.88,92.75,"n:Mielina Close.mp4",0],
[92.75,95.29,"n:senior-man-looking-sadly-out-window-2025-12-17-14-35-01-utc.mov",0],
[108.88,111.92,"n:upset-man-and-woman-sit-on-couch-2025-12-17-08-13-13-utc.mov",0],
[111.92,113.29,"n:0_Head_Stern_3840x2160.mov",0],
[113.29,115.46,"n:senior-adult-sleeping-peacefully-in-bed-at-night-2025-12-17-08-59-59-utc.mov",0],
[115.46,117.58,"n:man-taking-blood-pressure-at-home-close-up-2025-12-17-23-45-47-utc.mov",0],
[117.58,119.79,"n:0_Blood_Vessels_Red_2160x3840.mp4",0],
[119.79,121.42,"n:14919230_1920_1080_30fps.mp4",0],
[123.12,125.21,"n:0_Elderly_Woman_Headache_3840x2160.mov",0],
[125.21,127.88,"n:High Blood Pressure.mov",0],
[127.88,129.46,"n:blood-vessel-plaque-build-up-and-blood-flow-2026-04-27-00-07-41-utc.mp4",0],
[129.46,132.25,"n:animated-blood-flow-through-clogged-artery-with-pl-2026-04-27-00-07-40-utc.mp4",0],
[132.25,133.92,HP1+"10.mp4",0],
[133.92,136.04,"n:senior-man-experiencing-sudden-chest-pain-while-si-2026-06-24-16-51-16-utc.mov",0],
[136.04,137.92,GV1+"very-slow-pushin-zoom-on-_tCfdb47mZJ.mp4",0],
[139.96,142.08,"n:senior-man-experiencing-chest-pain-on-sofa-2026-01-27-20-27-27-utc.mp4",1],
[148.50,150.42,"n:senior-man-looking-out-window-thoughtful-2026-01-20-22-52-36-utc.mp4",0],
[150.42,152.50,"n:0_Elderly_Man_Old_Man_2160x3840.mp4",0],
[154.71,156.71,HP2+"5.mp4",0],
[156.71,158.67,GV2+"very-slow-orbital-camera-_lJ71WdWgv9.mp4",0],
[161.04,163.46,"n:4642082_Alone_Apartment_3840x2160.mp4",0],
[163.46,165.96,"n:3995-176277710.mp4",0],
[168.29,170.08,"n:3d-medical-animation-of-atherosclerosis-and-arteri-2026-04-05-09-56-13-utc.mov",0],
[170.08,173.13,"n:0_Vertical_Video_Orange_1080x1920.mp4",0],
[173.13,175.38,"n:senior-man-standing-thoughtfully-by-window-2026-01-21-02-25-41-utc.mp4",0],
[175.38,177.63,"n:close-up-of-a-pensive-senior-man-with-hand-on-chin-2026-05-05-19-49-31-utc.mp4",0],
[178.67,180.63,"n:0_Pharmaceutical_Production_3840x2160.mov",0],
[188.54,189.63,NP1+"04.mp4",0],
[189.63,191.67,"n:0_Pills_Bottle_3840x2160.mp4",0],
[191.67,193.58,"n:0_Woman_Hands_3840x2160.mp4",0],
[193.58,196.25,NP2+"01.mp4",0],
[196.25,198.08,"n:senior-man-sleeping-peacefully-in-bed-at-home-2025-12-17-20-44-54-utc.mov",3],
[198.08,201.17,NP1+"09.mp4",0],
[217.46,219.46,"n:Mielina Close.mp4",3],
[219.46,222.50,"n:senior-adult-sleeping-peacefully-in-bed-at-night-2025-12-17-08-59-59-utc.mov",3],
[222.50,225.38,"n:0_Man_Bed_3840x2160.mov",0],
[225.38,229.46,"n:Idosos desespero.mp4",0],
[229.46,232.58,"n:senior-man-sleeping-peacefully-in-bed-at-home-2025-12-17-20-44-54-utc.mov",6],
[238.21,240.83,"n:senior-man-relaxing-in-chair-with-tea-2026-10-02-23-15-52-utc.mp4",0],
[240.83,243.00,"n:6457854_Retired_Senior_3840x2160.mp4",0],
[243.00,245.25,"n:4860556_Happy_Elderly_3840x2160.mp4",0],
[245.25,248.25,"n:3d-animation-of-red-blood-cells-flowing-through-ar-2026-05-20-21-08-06-utc.mp4",3],
[249.46,251.79,"n:Senhor Família Feliz.mp4",0],
[251.79,254.38,NP1+"13.mp4",0],
[258.21,260.92,"n:grandfather-and-grandchildren-sharing-a-moment-out-2026-10-02-08-36-41-utc.mov",0],
[265.92,268.42,"n:0_Elderly_Man_Hospital_Bed_2160x3840.mp4",0],
[268.42,270.29,"n:Senhor Andador.mp4",0],
[271.83,275.13,"n:0_Chest_Pain_Chest_1920x1080.mp4",0],
[275.13,278.17,NP1+"14.mp4",0],
[278.17,280.08,"n:senior-adult-sleeping-peacefully-in-bed-at-night-2025-12-17-08-59-59-utc.mov",7],
[282.00,284.21,"n:man-getting-blood-pressure-checked-by-healthcare-p-2025-12-18-01-48-13-utc.mp4",0],
[284.21,287.04,"n:adult-measuring-blood-pressure-at-home-with-pills-2025-12-17-04-15-14-utc.mov",0],
[288.21,290.96,"n:Idoso Levantanto bem.mp4",0],
[291.50,294.88,"n:doctor-examines-senior-man-s-arm-in-office-2026-10-05-01-05-38-utc.mp4",0],
[294.88,297.75,"n:cholesterol-buildup-in-artery-with-blood-flow-3d-a-2026-01-28-02-46-25-utc.mov",3],
[303.42,306.92,"n:2033437_Pills_Pharmacy_3840x2160.mp4",0],
[307.83,311.04,"n:doctor-consults-with-senior-patient-in-hospital-be-2025-12-17-11-04-16-utc.mov",0],
[311.04,313.38,"n:animated-atherosclerosis-cholesterol-plaques-bloc-2026-01-28-05-24-52-utc.mp4",0],
[313.38,315.63,"n:man-getting-blood-pressure-measured-in-hospital-2025-12-17-09-15-56-utc.mov",0],
[315.63,318.29,"n:senior-man-walking-for-exercise-on-city-street-2026-10-03-11-54-34-utc.mp4",0],
[319.17,321.42,"n:man-checking-blood-pressure-using-a-digital-machin-2025-12-17-07-21-47-utc.mov",4],
[321.42,322.71,HP2+"7.mp4",0],
[322.71,324.21,GV2+"smooth-slow-zoom-out-from_CqHtOWgEEy.mp4",0],
[330.00,332.13,NP1+"02.mp4",0],
[332.13,333.88,"n:fitness-senior-man-and-hiking-in-forest-for-trave-2025-12-17-19-12-55-utc.mov",0],
[333.88,336.79,"n:animated-digital-blood-pressure-monitor-with-high-2026-01-28-03-08-17-utc.mp4",0],
[336.79,338.71,"n:grandfather-and-grandson-during-walk-through-field-2025-12-17-09-15-39-utc.mov",0],
[354.54,356.21,"n:grandfather-lifting-grandson-with-legs-indoors-2025-12-17-04-32-24-utc.mov",0],
[356.21,359.54,"n:senior-man-sleeping-peacefully-in-bed-at-home-2025-12-17-20-44-54-utc.mov",9],
[359.54,362.92,"n:loving-family-hugging-grandfather-at-christmas-2025-12-17-22-26-53-utc.mov",0],
[365.58,368.29,NP1+"05.mp4",0],
[368.29,370.04,"n:2033437_Pills_Pharmacy_3840x2160.mp4",5],
[370.04,371.29,"n:smiling-man-watching-video-on-mobile-phone-2026-10-03-05-26-27-utc.mp4",3],
[373.13,375.21,"n:scientists-packaging-bottles-in-a-bright-lab-2025-12-17-06-33-30-utc.mov",4],
[375.21,378.17,"n:5791001_Coll_wavebreak_Warehouse_3840x2160.mp4",0],
[378.17,381.17,NP3+"01.mp4",0],
[397.08,399.83,"n:1661394_Calendar_Wall_Calendar_3840x2160.mp4",0],
[401.38,404.08,"n:doctor-examining-senior-patient-with-stethoscope-a-2026-10-06-14-06-11-utc.mp4",0],
[404.08,406.29,"n:0_Blood_Vessels_Red_2160x3840.mp4",4],
[406.29,409.46,"n:futuristic-3d-human-anatomy-with-beating-heart-ani-2026-01-28-03-33-15-utc.mov",4],
[409.46,412.17,NP6+"03.mp4",0],
[414.17,416.54,"n:1661396_Calendar_Calender_3840x2160.mp4",0],
[416.54,418.71,"n:0_Anxiety_Man_3840x2160.mp4",3],
[418.71,420.46,"n:blood-vessel-plaque-build-up-and-blood-flow-2026-04-27-00-07-41-utc.mp4",4],
[420.46,422.50,"n:man-getting-blood-pressure-checked-by-healthcare-p-2025-12-18-01-48-13-utc.mp4",3],
[422.50,425.38,NP6+"05 (1).mp4",0],
[430.42,432.92,"n:senior-adult-sleeping-peacefully-in-bed-at-night-2025-12-17-08-59-59-utc.mov",10],
[432.92,436.71,"n:happy-senior-couple-walking-through-the-park-2025-12-17-03-26-25-utc.mov",0],
[436.71,439.58,"n:woman-wearing-headset-working-in-bright-office-2026-01-22-02-19-58-utc.mp4",0],
[447.75,450.79,NP2+"02.mp4",0],
[450.79,454.38,"n:packing-goods-in-a-cardboard-box-close-up-packagi-2026-01-22-07-22-42-utc.mp4",4],
[456.33,458.50,"n:Senhor Cartão.mp4",0],
[460.71,462.13,"n:smiling-man-watching-video-on-mobile-phone-2026-10-03-05-26-27-utc.mp4",6],
[462.13,464.71,"n:worker-strapping-and-labeling-cardboard-box-at-fac-2025-12-17-05-01-22-utc.mov",3],
[471.67,472.63,HP1+"11.mp4",0],
[472.63,474.13,GV1+"slow-zoom-in-toward-the-s_vQuokwHa47.mp4",0],
[474.13,476.46,"n:Idosos desespero.mp4",4],
[476.46,478.21,"n:1111161_Stress_Upset_3840x2160.mp4",4],
[478.21,480.83,"n:senior-man-looking-sadly-out-window-2025-12-17-14-35-01-utc.mov",4],
[480.83,483.63,"n:0_Man_Bed_3840x2160.mov",5],
[486.29,488.08,"n:0_Elderly_Man_Sad_2160x3840.mp4",0],
[488.08,488.96,HP2+"4.mp4",0],
[488.96,491.21,GV1+"gentle-counterclockwise-s_s7wkNHJl8e.mp4",0],
[496.29,499.08,HP1+"12.mp4",0],
[499.08,502.04,GV1+"slow-cinematic-zoom-out-f_EbqmjpMuuO.mp4",0],
[504.13,506.29,"n:4821638_Confident_Senior_3840x2160.mp4",0],
[506.29,509.38,"n:senior-man-ascending-stairs-with-walking-cane-indo-2025-12-17-19-59-09-utc.mov",0],
[509.38,511.08,"n:fitness-senior-man-and-hiking-in-forest-for-trave-2025-12-17-19-12-55-utc.mov",4],
[513.04,515.34,"n:packing-goods-in-a-cardboard-box-close-up-packagi-2026-01-22-07-22-42-utc.mp4",8],
[515.34,518.04,NP1+"06.mp4",0],
[518.04,521.38,"n:scientists-packaging-bottles-in-a-bright-lab-2025-12-17-06-33-30-utc.mov",7],
[524.34,528.04,NP3+"02.mp4",0],
[532.46,535.96,"n:senior-man-sleeping-peacefully-in-bed-at-home-2025-12-17-20-44-54-utc.mov",12],
[535.96,539.46,"n:Senhor Família Feliz.mp4",4]
];
// cartões arredondados: [ini, fim, [[ini,fim,ref,inS],...]]
var CARDS = [
[48.42,65.08,[[48.42,51.21,"n:contemplative-senior-man-sitting-with-hands-claspe-2025-12-18-01-47-15-utc.mov",0],[51.21,53.75,"n:0_Man_Bed_3840x2160.mov",0],[53.75,56.29,"n:Idosos desespero.mp4",0],[56.29,58.62,"n:Escada escura.mp4",0],[58.62,61.92,"n:0_Anxiety_Man_3840x2160.mp4",0],[61.92,65.08,"n:0_Elderly_Man_Sad_2160x3840.mp4",3]]],
[95.29,105.46,[[95.29,97.12,"n:0_Anxiety_Man_2160x3840.mov",0],[97.12,99.17,"n:animated-digital-blood-pressure-monitor-with-high-2026-01-28-03-08-17-utc.mp4",0],[99.17,102.42,"n:animated-atherosclerosis-cholesterol-plaques-bloc-2026-01-28-05-24-52-utc.mp4",0],[102.42,105.46,"n:senior-man-looking-out-window-with-cane-2025-12-17-11-14-02-utc.mov",0]]],
[203.17,217.46,[[203.17,205.96,NP1+"11.mp4",0],[205.96,208.29,"n:2033437_Pills_Pharmacy_3840x2160.mp4",2],[208.29,210.67,"n:5994212_Scientist_Laboratory_3840x2160.mp4",4],[210.67,213.42,"n:0_Pharmaceutical_Production_3840x2160.mov",3],[213.42,215.38,"n:DOCTOR.mp4",0],[215.38,217.46,NP1+"12.mp4",0]]],
[340.00,349.17,[[340.00,343.67,"n:man-taking-blood-pressure-at-home-close-up-2025-12-17-23-45-47-utc.mov",3],[343.67,346.67,"n:3d-animation-of-red-blood-cells-flowing-through-ar-2026-05-20-21-08-06-utc.mp4",8],[346.67,349.17,"n:0_Shield_Protection_3840x2160.mov",0]]]
];
// telas de produto 3D (PNG com EFEITO 3D sobre fundo): [ini, fim, png, escalaPNG, fundo, inS fundo, desfocarFundo]
var P3D = [
[158.67,161.04,PNG_HP,52,HP1+"12.mp4",0,true],
[165.96,168.29,PNG_GV,56,GV1+"slow-subtle-camera-rotati_VXdnhQKMMU.mp4",0,true],
[182.17,186.21,PNG_NP,54,BGNP,0,false],
[234.25,238.21,PNG_NP3,48,BGNP,3,false],
[349.17,350.92,PNG_HP,52,HP1+"9.mp4",0,true],
[350.92,352.13,PNG_GV,56,GV1+"slow-gradual-zoom-out-sho_VXdnEnYMMU.mp4",0,true],
[352.13,354.54,PNG_NP,54,BGNP,5,false],
[464.71,466.17,PNG_HP,52,HP1+"5.mp4",0,true],
[466.17,467.67,PNG_GV,56,GV1+"smooth-slow-dollyout-from_Ifae1YCtvE.mp4",0,true],
[467.67,470.17,PNG_NP,54,BGNP,7,false]
];
// telas de oferta (fundo NachtPrime + mockup 6 potes): [ini, fim, png, escala]
var OFERTA = [
[388.63,397.08,PNG_NP6,50],
[425.38,430.42,"n:30days GER.png",0],
[528.04,532.46,PNG_NP6,50]
];
// neon: [ini, fim, texto, posY]
var NEON = [[183.33,186.21,"NACHTPRIME",0.2294],[391.54,393.42,"19 €",0.2294],[393.42,397.08,"114 €",0.2294],[529.00,532.46,"114 €",0.2294]];
// zoom suave (camada de ajuste, 153%->100% em 0,75 s) + riser
var ZOOMS = [0.0, 46.29, 144.29, 180.63, 362.92, 494.17];
// transicoes (adj. layers Lens Blur + Flash) nos cortes
var CUTS = [4.29,12.79,24.50,37.29,39.88,48.42,65.08,75.17,78.42,88.29,95.29,108.88,113.29,123.12,129.46,139.96,148.50,154.71,161.04,168.29,173.13,178.67,188.54,193.58,203.17,217.46,222.50,238.21,243.00,251.79,258.21,265.92,275.13,282.00,291.50,303.42,311.04,315.63,321.42,330.00,332.13,340.00,349.17,354.54,365.58,368.29,375.21,397.08,401.38,409.46,414.17,422.50,430.42,436.71,447.75,456.33,460.71,471.67,478.21,486.29,496.29,504.13,513.04,518.04,524.34,532.46];
// light leaks + shutter (bloco de oferta)
var LEAKS = [388.63,397.08,425.38,430.42,447.75,464.71,496.29,515.34,528.04,532.46];

// faixas de destaque (ini, fim) usadas no UP 3
var DESTAQUE_RANGES = [[2.08,4.29],[43.21,46.29],[72.29,73.96],[73.96,75.17],[105.46,108.88],[177.63,178.67],[254.38,255.67],[384.17,388.63],[442.54,443.79],[491.21,494.17]];
var MARCADORES = [[0,"Abertura - 3 produtos"],[34.75,"Problema: o sono"],[86.25,"Melatonina e cortisol"],[182.17,"Apresentacao NachtPrime"],[201.17,"Mecanismos"],[263.25,"Depoimentos"],[328.54,"Resultados com NachtPrime"],[362.92,"Oferta"],[388.63,"Preco 6 frascos 114 EUR"],[425.38,"Garantia 30 dias"],[443.79,"Nao e nova compra"],[494.17,"Fechamento / CTA"]];
// SFX fixos e trilhas do UP 3
var TRILHAS = [[7,"epic",0,186.2,0],[6,"Inspiring",182.17,267,1.583],[7,"TRILHA (7)",263.25,332.5,0],[6,"TRILHA (2)",328.54,447.5,27.833],[5,"TRILHA (1)",443.79,-1,60.667]];
var CYMBAL_FIM = 182.17; var BOOM = 2.08; var DING = 183.33; var SWOOSH = [388.43,425.18,527.84]; var CASH = [391.54,393.42,529.0];
