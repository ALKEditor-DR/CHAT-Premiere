import sys, re, json
import xml.etree.ElementTree as ET
p = sys.argv[1]; nomes = sys.argv[2].split('|')
root = ET.parse(p).getroot()
byid = {}
for el in root:
    oid = el.get('ObjectID')
    if oid: byid[oid] = el
res = {}
for el in root:
    if el.tag != 'TreeItem': continue
    n = el.find('./TreeItemBase/Name')
    if n is None or n.text not in nomes: continue
    data = byid[el.find('./TreeItemBase/Data').get('ObjectRef')]
    efs = []
    for fp in data.findall('./FilterPresets/FilterPreset'):
        f = byid[fp.get('ObjectRef')]
        comp = byid[f.find('Component').get('ObjectRef')]
        disp = comp.find('./Component/DisplayName').text
        params = []
        for pr in comp.findall('./Component/Params/Param'):
            pe = byid[pr.get('ObjectRef')]
            nm = pe.findtext('Name'); sk = pe.findtext('StartKeyframe') or ''; kf = pe.findtext('Keyframes') or ''
            v = sk.split(',')[1] if ',' in sk else sk
            params.append([nm, v, kf.strip()])
        efs.append({'match': f.findtext('FilterMatchName'), 'nome': disp, 'outTicks': f.findtext('AnchorOutPoint'), 'params': params})
    res[n.text] = efs
print(json.dumps(res, ensure_ascii=False, indent=1))
