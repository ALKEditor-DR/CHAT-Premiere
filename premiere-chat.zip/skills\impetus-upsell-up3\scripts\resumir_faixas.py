import json, sys, collections
d = json.load(open(sys.argv[1], encoding='utf-8'))
out = open(sys.argv[2], 'w', encoding='utf-8')
P = lambda *a: print(*a, file=out)
P('chaves topo:', list(d.keys()))
INTERESSE = ['Scale','Position','Blurriness','Opacity','Scale Height','Scale Width','Exposure','Saturation','Amount','Roundness','Feather','Midpoint','Glow','Radius','Intensity','Color','Fill','Stroke','Tint','Amount to Tint','Noise','Distance','Softness','Direction','Angle','Size','Corner','Rotation','Edge Thickness','Border','Brightness','Strength','Mode','Blend']
for nome, f in d['faixas'].items():
    itens = f.get('itens', [])
    P('\n==========', nome, len(itens), 'itens')
    cont = collections.Counter(i.get('nome') for i in itens)
    P('nomes:', cont.most_common(12))
    efc = collections.Counter()
    for i in itens:
        for e in i.get('efeitos', []) or []:
            efc[e['efeito'] + (' [OFF]' if e.get('desligado') else '')] += 1
    P('efeitos:', efc.most_common(20))
    ks = [k for k in itens[0].keys()] if itens else []
    P('campos:', ks)
    durs = sorted(round(i['fim']-i['ini'],2) for i in itens)
    if durs: P('dur min/med/max', durs[0], durs[len(durs)//2], durs[-1])
    # amostras: até 4 itens com efeitos distintos
    vistos = set(); n = 0
    for i in itens:
        sig = tuple(sorted(e['efeito'] for e in (i.get('efeitos') or [])))
        if sig in vistos: continue
        vistos.add(sig); n += 1
        if n > 6: break
        P('--- ex %.2f-%.2f %s' % (i['ini'], i['fim'], i.get('nome')))
        for k, v in i.items():
            if k in ('efeitos','arquivo','ini','fim','nome'): continue
            s = str(v)
            P('    %s: %s' % (k, s[:300]))
        for e in i.get('efeitos') or []:
            vals = e.get('valores', {})
            sel = {k: v for k, v in vals.items() if any(t.lower() in k.lower() for t in INTERESSE) and str(v) not in ('0.','false','100.','0')}
            P('    > %s%s %s' % (e['efeito'], ' [OFF]' if e.get('desligado') else '', json.dumps(sel, ensure_ascii=False)[:600]))
for k in d:
    if k != 'faixas':
        P('\n== topo', k, str(d[k])[:1500])
