"""
Servidor de voz natural do Premiere Chat (Chatterbox Multilingual, licença MIT).

Deixa o modelo carregado na placa de vídeo e gera a fala frase a frase, para a primeira
frase sair rápido. Só escuta em 127.0.0.1 e exige o token passado pelo painel.

Uso: python servidor_voz.py --port 0 --token XYZ [--idle-min 15]
Imprime "PRONTO <porta>" quando o modelo termina de carregar.

POST /falar  {"text": "...", "out": "C:/.../frase.wav", "ref": "voz.wav"|null,
              "exaggeration": 0.5, "cfg_weight": 0.5, "temperature": 0.8}
  -> {"ok": true, "path": "...", "seconds": 2.1, "ms": 900}
GET  /saude  -> {"ok": true}
"""
import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = os.path.join(os.path.expanduser("~"), ".premiere-chat", "voz-natural")
os.environ.setdefault("HF_HOME", os.path.join(BASE, "modelos"))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
for k in list(os.environ):
    if k.upper().startswith("ANTHROPIC_"):
        del os.environ[k]

import torch  # noqa: E402
import torchaudio as ta  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--port", type=int, default=0)
ap.add_argument("--token", required=True)
ap.add_argument("--idle-min", type=float, default=15)
ap.add_argument("--pack", default="ptbr", choices=["ptbr", "multi"])
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
args = ap.parse_args()

t0 = time.time()
from chatterbox.mtl_tts import ChatterboxMultilingualTTS  # noqa: E402

MODEL = ChatterboxMultilingualTTS.from_pretrained(device=args.device)

# Pacote treinado para português do Brasil (ResembleAI/Chatterbox-Multilingual-pt-br, MIT):
# troca os pesos do T3 e do decodificador. Se não der, segue com o multilíngue padrão.
if args.pack == "ptbr":
    try:
        from huggingface_hub import hf_hub_download
        from safetensors.torch import load_file

        repo = "ResembleAI/Chatterbox-Multilingual-pt-br"
        st = load_file(hf_hub_download(repo, "t3_pt_br.safetensors"))
        if "model" in st:
            st = st["model"][0]
        MODEL.t3.load_state_dict(st, strict=True)
        # O decodificador v3 não traz os filtros fixos (mel/janela), que ficam os do modelo base.
        MODEL.s3gen.load_state_dict(load_file(hf_hub_download(repo, "s3gen_v3.safetensors")), strict=False)
        MODEL.t3.to(args.device).eval()
        MODEL.s3gen.to(args.device).eval()
        PACK = "ptbr"
    except Exception as e:  # noqa: BLE001
        print("AVISO: pacote pt-BR não carregou, usando o multilíngue:", str(e)[:200], flush=True)
        PACK = "multi"
else:
    PACK = "multi"

LOCK = threading.Lock()
last_use = time.time()


def gerar(body):
    global last_use
    text = str(body.get("text", "")).strip()
    out = body.get("out")
    if not text or not out:
        raise ValueError("faltou text ou out")
    kw = {"language_id": "pt"}
    ref = body.get("ref")
    if ref and os.path.isfile(ref):
        kw["audio_prompt_path"] = ref
    for k in ("exaggeration", "cfg_weight", "temperature"):
        if body.get(k) is not None:
            kw[k] = float(body[k])
    t = time.time()
    with LOCK:
        try:
            wav = MODEL.generate(text, **kw)
        except TypeError:
            kw.pop("temperature", None)
            wav = MODEL.generate(text, **kw)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    ta.save(out, wav.cpu() if hasattr(wav, "cpu") else wav, MODEL.sr)
    last_use = time.time()
    return {"ok": True, "path": out, "seconds": round(wav.shape[-1] / MODEL.sr, 2), "ms": int((time.time() - t) * 1000)}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _auth(self):
        return self.headers.get("Authorization", "") == "Bearer " + args.token

    def do_GET(self):
        if not self._auth():
            return self._send(401, {"ok": False})
        if self.path.startswith("/saude"):
            return self._send(200, {"ok": True, "device": args.device})
        self._send(404, {"ok": False})

    def do_POST(self):
        if not self._auth():
            return self._send(401, {"ok": False})
        if not self.path.startswith("/falar"):
            return self._send(404, {"ok": False})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
            self._send(200, gerar(body))
        except Exception as e:  # noqa: BLE001
            self._send(500, {"ok": False, "error": str(e)[:500]})


srv = ThreadingHTTPServer(("127.0.0.1", args.port), H)


def vigia():
    # Sem uso por um tempo: encerra e libera a memória da placa de vídeo para o Premiere.
    while True:
        time.sleep(30)
        if time.time() - last_use > args.idle_min * 60:
            os._exit(0)


threading.Thread(target=vigia, daemon=True).start()
print(f"PRONTO {srv.server_address[1]} {args.device} {PACK} {round(time.time() - t0, 1)}s", flush=True)
srv.serve_forever()
