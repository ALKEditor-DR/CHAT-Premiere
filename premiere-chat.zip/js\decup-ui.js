/* Aba Decupagem: controles, prévia da forma de onda e aplicação dos cortes na timeline. */
(function () {
  "use strict";

  const D = window.Decupagem;
  const PARAMS_KEY = "premierechat.decup";
  const PRESETS_KEY = "premierechat.decup.presets";
  const NUM_KEYS = ["threshold", "autoOffset", "minSilence", "padBefore", "padAfter", "minSpeech", "hysteresis", "minCut"];

  let ctx = null; // { host, enc, inPremiere, Local, hostAppPath, backup, runInPremiere }
  let params = null;
  let analysis = null; // { ...D.analyze(), seqId, seqName }
  let result = null;
  let busy = false;
  let job = null; // trabalho em andamento (análise ou aplicação): { owner, stopped, ... }
  const $ = (id) => document.getElementById(id);

  function store(key, val) {
    try {
      if (val === undefined) return JSON.parse(localStorage.getItem(key) || "null");
      localStorage.setItem(key, JSON.stringify(val));
    } catch {
      return null;
    }
  }

  function userPresets() {
    return store(PRESETS_KEY) || {};
  }

  let tuned = null; // último resultado de D.autoTune (preset "auto")

  function presetValues(id) {
    if (id === "auto") return tuned ? tuned.values : null;
    if (D.PRESETS[id]) return D.PRESETS[id];
    const u = userPresets()[id];
    return u ? u.values : null;
  }

  function fmtTime(s) {
    if (s == null || !isFinite(s)) return "—";
    s = Math.max(0, s);
    const m = Math.floor(s / 60);
    const r = s - m * 60;
    return m ? `${m}:${r.toFixed(1).padStart(4, "0")}` : `${r.toFixed(1)} s`;
  }

  // ------------------------------------------------------------ controles

  function buildControls() {
    document.querySelectorAll("#decup .dc-ctl").forEach((row) => {
      const key = row.dataset.key;
      const range = document.createElement("input");
      range.type = "range";
      range.min = row.dataset.min;
      range.max = row.dataset.max;
      range.step = row.dataset.step;
      const num = document.createElement("input");
      num.type = "number";
      num.min = row.dataset.min;
      num.max = row.dataset.max;
      num.step = row.dataset.step;
      const unit = document.createElement("span");
      unit.className = "dc-unit";
      unit.textContent = row.dataset.unit;
      const line = document.createElement("div");
      line.className = "dc-line";
      line.append(range, num, unit);
      row.append(line);
      const set = (v, fromNum) => {
        v = Number(String(v).replace(",", "."));
        if (!isFinite(v)) return;
        params[key] = v;
        range.value = v;
        if (!fromNum) num.value = v; // não mexe no campo enquanto a pessoa digita
        // Mexer no limiar desliga o automático (e o ajuste fino liga), para o controle valer na hora.
        if (key === "threshold" && params.auto) params.auto = false;
        if (key === "autoOffset" && !params.auto) params.auto = true;
        markCustom();
        render();
        update();
      };
      // "input" enquanto arrasta, "change" ao soltar e "pointermove" para o CEP que só avisa no fim.
      range.addEventListener("input", () => set(range.value));
      range.addEventListener("change", () => set(range.value));
      range.addEventListener("pointermove", (e) => {
        if (e.buttons & 1 && Number(range.value) !== params[key]) set(range.value);
      });
      num.addEventListener("input", () => {
        if (num.value !== "" && !/[.,-]$/.test(num.value)) set(num.value, true);
      });
      num.addEventListener("change", () => set(num.value));
      row._range = range;
      row._num = num;
    });
  }

  function fillPresetSelect() {
    const sel = $("dc-preset");
    sel.innerHTML = "";
    const add = (value, label) => {
      const o = document.createElement("option");
      o.value = value;
      o.textContent = label;
      sel.append(o);
    };
    add("auto", "🪄 Automático (ajusta pelo áudio)");
    for (const [id, p] of Object.entries(D.PRESETS)) add(id, p.label);
    for (const [id, p] of Object.entries(userPresets())) add(id, "★ " + p.label);
    add("custom", "Personalizado");
    sel.value = params.preset === "auto" || params.preset in D.PRESETS || params.preset in userPresets() ? params.preset : "custom";
    $("dc-auto-note").classList.toggle("hidden", !(params.preset === "auto" && tuned));
    $("dc-del-preset").style.visibility = params.preset in userPresets() ? "visible" : "hidden";
  }

  function render() {
    document.querySelectorAll("#decup .dc-ctl").forEach((row) => {
      row._range.value = params[row.dataset.key];
      if (document.activeElement !== row._num) row._num.value = params[row.dataset.key];
    });
    $("dc-auto").checked = !!params.auto;
    $("dc-trim").checked = !!params.trimEdges;
    $("dc-mode").value = params.mode;
    $("dc-newseq").checked = !!params.newSequence;
    $("dc-protect").checked = params.protectWords !== false;
    document.querySelector('#decup .dc-ctl[data-key="autoOffset"]').classList.toggle("off", !params.auto);
    document.querySelector('#decup .dc-ctl[data-key="threshold"]').classList.toggle("off", !!params.auto);
    fillPresetSelect();
  }

  function markCustom() {
    const base = presetValues(params.preset);
    if (!base) return;
    const differs = NUM_KEYS.some((k) => !(k === "threshold" && params.auto && base.auto) && Math.abs(Number(base[k]) - Number(params[k])) > 1e-6) || !!base.auto !== !!params.auto || !!base.trimEdges !== !!params.trimEdges;
    if (differs) params.preset = "custom";
  }

  // Preset automático: recalcula a partir da análise atual.
  function autoTuneNow() {
    params.preset = "auto";
    if (!analysis) {
      tuned = null;
      fillPresetSelect();
      status("Ajuste automático escolhido: clique em Analisar áudio e ele se ajusta sozinho.");
      return false;
    }
    tuned = D.autoTune(analysis);
    $("dc-auto-note").textContent = "🪄 " + tuned.notes;
    applyPreset("auto");
    return true;
  }

  function applyPreset(id) {
    if (id === "auto" && !tuned) return void autoTuneNow();
    const v = presetValues(id);
    if (!v) return;
    for (const k of NUM_KEYS) params[k] = v[k] != null ? v[k] : D.DEFAULTS[k];
    params.auto = !!v.auto;
    params.trimEdges = !!v.trimEdges;
    params.preset = id;
    render();
    update();
  }

  // ------------------------------------------------------------ prévia

  function update() {
    store(PARAMS_KEY, params);
    if (!analysis) {
      $("dc-apply").disabled = true;
      drawWave();
      return;
    }
    result = D.computeCuts(analysis, params);
    if (params.auto) {
      const row = document.querySelector('#decup .dc-ctl[data-key="threshold"]');
      params.threshold = result.threshold; // ao desligar o automático, parte do valor que estava valendo
      row._range.value = result.threshold;
      if (document.activeElement !== row._num) row._num.value = result.threshold;
    }
    const pct = analysis.duration ? Math.round((result.removed / analysis.duration) * 100) : 0;
    $("dc-st-cuts").textContent = String(result.cuts.length);
    $("dc-st-removed").textContent = `${fmtTime(result.removed)} (${pct}%)`;
    $("dc-st-final").textContent = `${fmtTime(result.finalDuration)}`;
    const pw = $("dc-protect").closest("label");
    if (pw) pw.title = result.protectedWords != null ? `${result.protectedWords} palavras protegidas nesta análise.` : analysis.wordsNote || "Transcreve o áudio no seu PC e nunca corta onde há palavra.";
    $("dc-apply").disabled = busy || !result.cuts.length;
    drawWave();
  }

  // ------------------------------------------------------------ forma de onda (zoom e arrastar)

  const WAVE_H = 110; // altura da área da onda
  const RULER_H = 16; // régua de tempo embaixo
  const view = { t0: 0, t1: 0 }; // trecho visível, em segundos
  let waveMsg = ""; // texto mostrado na área da onda enquanto não há análise

  // Redesenha no próximo quadro de tela: vários ajustes seguidos viram um desenho só.
  // Desenha na hora (é rápido), para a prévia acompanhar cada ajuste sem atraso.
  function drawWave() {
    paintWave();
  }

  function fullView() {
    view.t0 = 0;
    view.t1 = analysis ? analysis.duration : 0;
  }

  function clampView() {
    const dur = analysis ? analysis.duration : 0;
    const minSpan = Math.min(dur, 1);
    let span = Math.max(minSpan, Math.min(dur, view.t1 - view.t0));
    let t0 = Math.max(0, Math.min(dur - span, view.t0));
    view.t0 = t0;
    view.t1 = t0 + span;
  }

  function zoomAt(factor, t) {
    if (!analysis) return;
    const span = view.t1 - view.t0;
    const ns = span * factor;
    const rel = (t - view.t0) / span;
    view.t0 = t - rel * ns;
    view.t1 = view.t0 + ns;
    clampView();
    drawWave();
  }

  function niceStep(span, width) {
    const target = span / Math.max(1, width / 70);
    const steps = [0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
    return steps.find((s) => s >= target) || 600;
  }

  function tickLabel(t, step) {
    const m = Math.floor(t / 60);
    const s = t - m * 60;
    const dec = step < 1 ? 1 : 0;
    const ss = s.toFixed(dec).padStart(dec ? 4 : 2, "0");
    return `${m}:${ss}`;
  }

  function paintWave() {
    const cv = $("dc-wave");
    const w = Math.max(200, cv.clientWidth || 300);
    const H = WAVE_H + RULER_H;
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(H * dpr);
    cv.style.height = H + "px";
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, H);
    const css = getComputedStyle(document.documentElement);
    const col = (n, f) => css.getPropertyValue(n).trim() || f;
    const label = $("dc-zoom-label");
    if (!analysis) {
      g.fillStyle = col("--muted", "#999");
      g.font = "11px Segoe UI, sans-serif";
      g.textAlign = "center";
      g.fillText(waveMsg || "A forma de onda aparece depois da análise", w / 2, H / 2 + 4);
      label.textContent = "—";
      return;
    }
    if (!(view.t1 > view.t0)) fullView();
    const { db, duration, hop } = analysis;
    const { t0, t1 } = view;
    const span = t1 - t0;
    const xOf = (t) => ((t - t0) / span) * w;
    const h = WAVE_H;
    const MIN = -70;
    const y = (v) => h - Math.max(0, Math.min(1, (v - MIN) / -MIN)) * (h - 4);
    const cuts = result ? result.cuts : [];

    // Pausas detectadas: a parte protegida pelas margens aparece em amarelo claro
    g.fillStyle = col("--pause-bg", "rgba(224,160,48,0.16)");
    for (const pz of result ? result.pauses || [] : []) {
      if (pz.end < t0 || pz.start > t1) continue;
      const x0 = xOf(pz.start), x1 = xOf(pz.end);
      g.fillRect(x0, 0, Math.max(1, x1 - x0), h);
    }

    // Fundo dos trechos cortados
    g.fillStyle = col("--cut-bg", "rgba(255,107,107,0.18)");
    for (const c of cuts) {
      if (c.end < t0 || c.start > t1) continue;
      const x0 = xOf(c.start), x1 = xOf(c.end);
      g.fillRect(x0, 0, Math.max(1, x1 - x0), h);
    }

    // Barras de volume: o máximo das janelas de 10 ms dentro de cada coluna
    const secPerPx = span / w;
    let ci = 0;
    const keepCol = col("--accent", "#9999ff"), cutCol = col("--err", "#ff6b6b");
    for (let x = 0; x < w; x++) {
      const ta = t0 + x * secPerPx, tb = ta + secPerPx;
      const a = Math.floor(ta / hop), b = Math.max(a + 1, Math.ceil(tb / hop));
      let mx = -100;
      for (let i = Math.max(0, a); i < b && i < db.length; i++) if (db[i] > mx) mx = db[i];
      const t = ta + secPerPx / 2;
      while (ci < cuts.length && cuts[ci].end < t) ci++;
      const inCut = ci < cuts.length && cuts[ci].start <= t && t < cuts[ci].end;
      g.fillStyle = inCut ? cutCol : keepCol;
      const top = y(mx);
      g.fillRect(x, top, 1, h - top);
    }

    // Bordas de cada corte quando há zoom suficiente para ver
    if (span <= 60) {
      g.fillStyle = cutCol;
      for (const c of cuts) {
        if (c.end < t0 || c.start > t1) continue;
        g.fillRect(Math.round(xOf(c.start)), 0, 1, h);
        g.fillRect(Math.round(xOf(c.end)) - 1, 0, 1, h);
      }
    }

    // Linha do limiar
    if (result) {
      g.strokeStyle = col("--warn", "#e0a030");
      g.setLineDash([4, 3]);
      g.beginPath();
      g.moveTo(0, y(result.threshold) + 0.5);
      g.lineTo(w, y(result.threshold) + 0.5);
      g.stroke();
      g.setLineDash([]);
    }

    // Régua de tempo
    g.fillStyle = col("--panel-2", "#2f2f2f");
    g.fillRect(0, h, w, RULER_H);
    const step = niceStep(span, w);
    g.fillStyle = col("--muted", "#9a9a9a");
    g.font = "10px Segoe UI, sans-serif";
    g.textAlign = "left";
    for (let t = Math.ceil(t0 / step) * step; t <= t1 + 1e-9; t += step) {
      const x = Math.round(xOf(t));
      g.fillRect(x, h, 1, 4);
      if (x < w - 30) g.fillText(tickLabel(t, step), x + 3, h + 12);
    }

    // Miniatura: posição do trecho visível no vídeo inteiro
    if (span < duration - 0.01) {
      g.fillStyle = col("--accent", "#9999ff");
      g.globalAlpha = 0.8;
      g.fillRect((t0 / duration) * w, 0, Math.max(3, (span / duration) * w), 3);
      g.globalAlpha = 1;
    }
    const z = duration / span;
    label.textContent = `${fmtTime(t0)} – ${fmtTime(t1)}` + (z > 1.05 ? ` · zoom ${z < 10 ? z.toFixed(1).replace(".", ",") : Math.round(z)}×` : "");
  }

  function waveTime(ev) {
    const rect = $("dc-wave").getBoundingClientRect();
    const rel = Math.max(0, Math.min(1, (ev.clientX - rect.left) / rect.width));
    return view.t0 + rel * (view.t1 - view.t0);
  }

  function setupWaveInput() {
    const cv = $("dc-wave");
    cv.addEventListener(
      "wheel",
      (ev) => {
        if (!analysis) return;
        ev.preventDefault();
        const span = view.t1 - view.t0;
        if (ev.shiftKey || Math.abs(ev.deltaX) > Math.abs(ev.deltaY)) {
          const d = (ev.shiftKey ? ev.deltaY : ev.deltaX) || ev.deltaY;
          view.t0 += (d / cv.clientWidth) * span;
          view.t1 += (d / cv.clientWidth) * span;
          clampView();
          drawWave();
        } else zoomAt(Math.exp(ev.deltaY * 0.0015), waveTime(ev));
      },
      { passive: false }
    );
    let drag = null;
    // Linha do limiar: arrastar para cima/baixo muda o limiar na hora.
    const lineY = () => (result ? WAVE_H - Math.max(0, Math.min(1, (result.threshold + 70) / 70)) * (WAVE_H - 4) : -99);
    const yOf = (ev) => ev.clientY - cv.getBoundingClientRect().top;
    const nearLine = (ev) => result && Math.abs(yOf(ev) - lineY()) <= 7;
    cv.addEventListener("pointerdown", (ev) => {
      if (!analysis || ev.button !== 0) return;
      drag = { x: ev.clientX, t0: view.t0, t1: view.t1, moved: false, thr: nearLine(ev) };
      cv.setPointerCapture(ev.pointerId);
    });
    cv.addEventListener("pointermove", (ev) => {
      if (!drag) {
        cv.classList.toggle("on-line", !!nearLine(ev));
        return;
      }
      if (drag.thr) {
        drag.moved = true;
        const yy = Math.max(0, Math.min(WAVE_H, yOf(ev)));
        const v = Math.round(-70 + ((WAVE_H - yy) / (WAVE_H - 4)) * 70);
        if (v !== Math.round(result.threshold)) {
          params.auto = false;
          params.threshold = Math.max(-70, Math.min(-10, v));
          markCustom();
          render();
          update();
        }
        return;
      }
      const dx = ev.clientX - drag.x;
      if (Math.abs(dx) > 3) drag.moved = true;
      if (!drag.moved) return;
      cv.classList.add("dragging");
      const dt = (dx / cv.clientWidth) * (drag.t1 - drag.t0);
      view.t0 = drag.t0 - dt;
      view.t1 = drag.t1 - dt;
      clampView();
      drawWave();
    });
    const end = (ev) => {
      if (!drag) return;
      const wasClick = !drag.moved;
      drag = null;
      cv.classList.remove("dragging");
      if (wasClick && ev.type === "pointerup") onWaveClick(ev);
    };
    cv.addEventListener("pointerup", end);
    cv.addEventListener("pointercancel", end);
    cv.addEventListener("dblclick", () => {
      fullView();
      drawWave();
    });
    $("dc-zoom-in").addEventListener("click", () => zoomAt(0.5, (view.t0 + view.t1) / 2));
    $("dc-zoom-out").addEventListener("click", () => zoomAt(2, (view.t0 + view.t1) / 2));
    $("dc-zoom-all").addEventListener("click", () => {
      fullView();
      drawWave();
    });
  }

  function status(text, cls) {
    const el = $("dc-status");
    el.textContent = text;
    el.className = "hint" + (cls ? " " + cls : "");
  }

  // ------------------------------------------------------------ progresso e botão de parar

  const P = window.Progresso;
  const STOPPED = "Parado por você.";

  /*
   * Começa um trabalho com barra de progresso. owner: "aba" ou "chat".
   * kills: o que precisa ser encerrado ao parar (ffmpeg, transcrição).
   */
  function beginJob(owner, list, onFraction) {
    const j = { owner, stopped: false, applying: false, kills: [], steps: P.stages(list) };
    j.abort = new Promise((_, reject) => (j.reject = reject));
    j.abort.catch(() => {});
    j.check = () => {
      if (j.stopped) throw new Error(STOPPED);
    };
    // Espera p, mas larga na hora se a pessoa clicar em Parar.
    j.race = (p) => Promise.race([p, j.abort]);
    j.register = (kill) => j.kills.push(kill);
    job = j;
    busy = true;
    $("dc-analyze").disabled = true;
    $("dc-apply").disabled = true;
    const b = $("dc-stop");
    b.disabled = false;
    b.textContent = "■ Parar";
    const paint = () => {
      const s = j.steps.snapshot();
      P.paint($("dc-progress"), s, j.stopped ? "Parando…" : s.label);
      if (onFraction && !j.stopped) onFraction(s.pct);
    };
    j.timer = setInterval(paint, 300);
    j.paint = paint;
    paint();
    return j;
  }

  function endJob(j) {
    clearInterval(j.timer);
    if (job !== j) return;
    job = null;
    busy = false;
    P.paint($("dc-progress"), null);
    $("dc-analyze").disabled = false;
    update();
  }

  // Parar. O Parar do chat só encerra a decupagem que o próprio chat começou.
  function stop(who) {
    const j = job;
    if (!j || j.stopped || (who === "chat" && j.owner !== "chat")) return false;
    j.stopped = true;
    $("dc-stop").disabled = true;
    $("dc-stop").textContent = "Parando…";
    for (const k of j.kills.splice(0)) {
      try {
        k();
      } catch {}
    }
    // Durante os cortes espera a etapa em andamento acabar, para desfazer direito.
    if (!j.applying) j.reject(new Error(STOPPED));
    j.paint();
    return true;
  }

  function analysisStages(dur) {
    const list = [
      { id: "exportar", label: "Exportando o áudio da sequência", est: 1 + dur * P.rate("dc-exportar", 0.03) },
      { id: "medir", label: "Medindo o volume", est: 0.5 + dur * P.rate("dc-medir", 0.004) },
    ];
    if (params.protectWords !== false && ctx.Local && ctx.Local.transcribe) list.push({ id: "transcrever", label: "Transcrevendo para proteger as palavras", est: 8 + dur * P.rate("dc-transcrever", 0.33) });
    return list;
  }
  function applyEst(cuts, mode) {
    return {
      backup: P.rate("dc-backup", 3),
      preparar: P.rate("dc-preparar", 2),
      lamina: 0.5 + cuts * P.rate("dc-lamina", 0.2),
      tirar: 0.3 + cuts * P.rate("dc-tirar", 0.05),
      fechar: mode === "ripple" ? 0.3 + cuts * P.rate("dc-fechar", 0.12) : 0,
      marcadores: cuts * P.rate("dc-marcadores", 0.03),
    };
  }
  function applyStages(cuts, mode) {
    const e = applyEst(cuts, mode);
    const list = [
      { id: "backup", label: "Salvando o projeto e o backup", est: e.backup },
      { id: "preparar", label: "Preparando a sequência", est: e.preparar },
    ];
    if (mode === "markers") list.push({ id: "marcadores", label: "Marcando os silêncios", est: e.marcadores });
    else {
      list.push({ id: "lamina", label: "Passando a lâmina", est: e.lamina });
      list.push({ id: "tirar", label: mode === "disable" ? "Desativando os silêncios" : "Tirando os silêncios", est: e.tirar });
      if (mode === "ripple") list.push({ id: "fechar", label: "Fechando os buracos", est: e.fechar });
    }
    return list;
  }

  // ------------------------------------------------------------ análise e aplicação

  async function seqInfo() {
    if (!ctx.inPremiere) return { ok: true, result: { name: "Prévia (sem Premiere)", id: "demo", duration: 90 } };
    return ctx.host("PPC_seqInfo");
  }

  // Exporta o áudio da sequência ativa e mede o volume, sempre do zero. seq: PPC_seqInfo; j: trabalho (beginJob).
  async function analyzeSequence(j, seq, onProgress) {
    $("dc-seq-name").textContent = `${seq.name} · ${fmtTime(seq.duration)}`;
    const dur = seq.duration || 0;
    let a;
    if (!ctx.inPremiere || !ctx.Local) {
      a = D.demoAnalysis(90);
    } else {
      const fs = require("fs");
      const Local = ctx.Local;
      const ffmpeg = Local.findFfmpeg();
      if (!ffmpeg) throw new Error("ffmpeg não encontrado. Rode o instalador de novo.");
      const preset = Local.findWavPreset(ctx.hostAppPath());
      if (!preset) throw new Error("Preset de WAV do Premiere não encontrado.");
      const wav = Local.workFile("decupagem-" + Date.now() + ".wav");
      const size = () => {
        try {
          return fs.statSync(wav).size;
        } catch {
          return 0;
        }
      };
      const clean = () => {
        try {
          fs.unlinkSync(wav);
        } catch {}
      };
      const took = (id) => {
        if (dur > 1) P.learn("dc-" + id, j.steps.elapsed() / dur);
      };

      onProgress("exportando o áudio da sequência…");
      j.steps.start("exportar");
      // O WAV cresce enquanto o Premiere exporta: o tamanho dele dá o andamento.
      const bps = P.rate("dc-wav-bytes", 192000);
      const poll = setInterval(() => {
        const f = dur > 0 ? size() / (dur * bps) : 0;
        if (f > 0.01 && f < 0.98) j.steps.fraction(f);
      }, 300);
      const exporting = ctx.host("PPC_exportAudio", ctx.enc(wav), ctx.enc(preset));
      try {
        const ex = await j.race(exporting);
        if (!ex.ok) throw new Error(ex.error);
        if (!(await j.race(Local.waitForFile(wav, 300000)))) throw new Error("O Premiere não exportou o áudio.");
        took("exportar");
        if (dur > 1) P.learn("dc-wav-bytes", size() / dur);

        onProgress("medindo o volume…");
        j.steps.start("medir");
        a = await j.race(D.analyze(wav, ffmpeg, onProgress, { duration: dur, onFraction: (f) => j.steps.fraction(f), register: j.register }));
        j.check();
        took("medir");

        if (params.protectWords !== false && Local.transcribe) {
          onProgress("transcrevendo para proteger as palavras (no seu PC)…");
          j.steps.start("transcrever");
          try {
            const tr = await j.race(
              Local.transcribe(wav, {
                language: "auto", // sem isso ia como português e travava em áudio de outra língua
                onProgress: (m) => {
                  onProgress("transcrevendo: " + m);
                  if (/modelo/i.test(m)) j.steps.start("transcrever", "Transcrevendo: " + m.toLowerCase());
                  else if (/^transcrevendo/i.test(m)) j.steps.start("transcrever", "Transcrevendo para proteger as palavras");
                },
                onFraction: (f) => j.steps.fraction(f),
                register: j.register,
              })
            );
            a.words = (tr.words || []).filter((w) => isFinite(w.start) && isFinite(w.end));
            if (!tr.words) a.wordsNote = "a transcrição veio sem tempo por palavra";
            took("transcrever");
          } catch (e) {
            j.check();
            a.wordsNote = "não deu para transcrever (" + (e.message || e) + "): cortei só pelo som";
          }
        }
      } finally {
        clearInterval(poll);
        // Parou no meio da exportação: o Premiere ainda termina o arquivo; apaga quando ele acabar.
        if (j.stopped) exporting.then(clean, clean).then(() => setTimeout(clean, 2000));
        else clean();
      }
      j.check();
    }
    a.seqId = seq.id;
    a.seqName = seq.name;
    a.seqDuration = seq.duration;
    analysis = a;
    fullView();
    return a;
  }

  // Esquece a análise anterior: onda, cortes, zoom, números e ajuste automático.
  function resetAnalysis(msg) {
    analysis = null;
    result = null;
    tuned = null;
    view.t0 = view.t1 = 0;
    waveMsg = msg || "";
    for (const id of ["dc-st-cuts", "dc-st-removed", "dc-st-final"]) $(id).textContent = "—";
    $("dc-levels").textContent = "Ruído de fundo e nível da fala aparecem depois da análise.";
    $("dc-auto-note").textContent = "";
    $("dc-auto-note").classList.add("hidden");
    $("dc-apply").disabled = true;
    drawWave();
  }

  function showLevels() {
    if (!analysis) return;
    $("dc-levels").textContent = `Ruído de fundo ${analysis.noise} dB · fala ${analysis.speech} dB · limiar sugerido ${analysis.suggested} dB` + (analysis.demo ? " (áudio de demonstração)" : "");
  }

  async function onAnalyze() {
    if (busy) return;
    busy = true; // antes de qualquer espera, para dois cliques não começarem duas análises
    $("dc-analyze").disabled = true;
    let j = null;
    try {
      resetAnalysis("Analisando a timeline do zero…");
      status("Analisando a timeline do zero…");
      const info = await seqInfo();
      if (!info.ok) throw new Error(info.error);
      j = beginJob("aba", analysisStages(info.result.duration || 0));
      await analyzeSequence(j, info.result, (m) => {
        if (j.stopped) return;
        status(m);
        waveMsg = m;
        drawWave();
      });
      showLevels();
      if (params.preset === "auto") autoTuneNow();
      status(`Pronto: ${fmtTime(analysis.duration)} de áudio analisado. Ajuste os controles e confira na forma de onda.`, "ok");
    } catch (e) {
      if (j && j.stopped) {
        waveMsg = "Análise parada. Clique em Analisar áudio para recomeçar.";
        status("Análise parada. Nada mudou na timeline. Se o Premiere estava exportando o áudio, ele ainda pode levar alguns segundos para terminar.", "warn");
      } else {
        waveMsg = "Não deu para analisar. Veja a mensagem acima.";
        status(e.message || String(e), "bad");
      }
    } finally {
      if (j) endJob(j);
      else {
        busy = false;
        $("dc-analyze").disabled = false;
        update();
      }
    }
  }

  // Volta a timeline ao que era antes dos cortes. -> texto do que aconteceu, ou null se não dá para voltar e é melhor terminar.
  async function rollback(j, p) {
    for (;;) {
      const r = await ctx.host("PPC_decupCancel", "500");
      if (!r.ok) throw new Error("Parei, mas não consegui voltar a timeline sozinho (" + r.error + "). Use Ctrl+Z ou o backup do projeto.");
      const c = r.result;
      if (c.more) {
        status(`Parando: desfazendo os cortes (${c.done} passos)…`, "warn");
        continue;
      }
      if (c.restored) return p.newSequence && c.left ? `Parado. A sequência original está intacta; apague a cópia "${c.left}" se não quiser ficar com ela.` : "Parado. A timeline está como antes da decupagem.";
      if (c.touched) throw new Error("Parei no meio e o Premiere não desfez tudo. Use Ctrl+Z até o começo ou abra o backup do projeto.");
      return null; // o Premiere não desfaz por aqui: terminar é mais seguro que deixar pela metade
    }
  }

  // Aplica os cortes na timeline, em etapas curtas (dá para parar). Devolve o resumo do host.
  async function applyCuts(res, p, j) {
    if (!ctx.inPremiere) return { sequence: "Prévia", cuts: res.cuts.length, removedSeconds: res.removed, mode: p.mode, preview: true };
    const n = Math.max(1, res.cuts.length);
    j.applying = true;
    j.steps.start("backup");
    if (ctx.backup) await ctx.backup(true);
    P.learn("dc-backup", j.steps.elapsed());
    j.check(); // ainda não mexeu em nada

    j.steps.start("preparar");
    const payload = JSON.stringify({ cuts: res.cuts.map((c) => [c.start, c.end]), mode: p.mode, newSequence: !!p.newSequence, seqId: analysis ? analysis.seqId : "" });
    let r = await ctx.host("PPC_decupStart", ctx.enc(payload));
    if (!r.ok) throw new Error(r.error);
    P.learn("dc-preparar", j.steps.elapsed());

    let phase = "", forced = false, note = "";
    for (;;) {
      if (j.stopped && !forced) {
        const back = await rollback(j, p);
        if (back) {
          const e = new Error(back);
          e.rolledBack = true;
          throw e;
        }
        forced = true; // não dá para desfazer por aqui: termina os cortes que faltam
        note = "Os cortes já tinham começado e o Premiere não deixou desfazer daqui, então terminei para não deixar a timeline pela metade. Ctrl+Z desfaz passo a passo.";
        status("O Premiere não deixou desfazer daqui: terminando os cortes…", "warn");
      }
      const st = r.result;
      if (st.finished && st.result) {
        if (phase) P.learn("dc-" + phase, j.steps.elapsed() / n);
        // A sequência mudou (ou é outra): a próxima análise começa do zero.
        analysis = null;
        result = null;
        return note ? Object.assign({}, st.result, { forced: note }) : st.result;
      }
      if (st.phase !== phase) {
        if (phase) P.learn("dc-" + phase, j.steps.elapsed() / n);
        phase = st.phase;
        j.steps.start(phase);
      }
      if (st.total > 0) j.steps.fraction(st.done / st.total);
      // Um respiro entre as etapas: o Premiere redesenha a tela.
      await new Promise((z) => setTimeout(z, 15));
      r = await ctx.host("PPC_decupStep", "500");
      if (!r.ok) {
        // Deu erro no meio: com cópia, some com ela; direto na original, quem desfaz é a pessoa.
        if (p.newSequence) await ctx.host("PPC_decupCancel", "500");
        throw new Error(r.error + (p.newSequence ? " A sequência original está intacta." : " Use Ctrl+Z ou o backup do projeto."));
      }
    }
  }

  function describe(r) {
    if (r.note) return r.note;
    const what = { ripple: "cortados e com os buracos fechados", gap: "cortados (buracos mantidos)", disable: "cortados e desativados", markers: "marcados" }[r.mode] || "aplicados";
    let s = `${r.cuts} silêncios ${what} em "${r.sequence}".`;
    if (r.removedSeconds) s += ` ${fmtTime(r.removedSeconds)} a menos.`;
    if (r.preview) s += " (prévia: nada foi alterado)";
    return s;
  }

  async function onApply() {
    if (busy || !result || !result.cuts.length) return;
    const j = beginJob("aba", applyStages(result.cuts.length, params.mode));
    try {
      status(`Aplicando ${result.cuts.length} cortes… Não mexa na timeline até terminar.`);
      const r = await applyCuts(result, Object.assign({}, params), j);
      if (r.forced) status(describe(r) + " " + r.forced, "warn");
      else status(describe(r) + (params.mode !== "markers" && !r.preview ? " Ctrl+Z desfaz passo a passo; há um backup do projeto antes da decupagem." : ""), "ok");
      if (!r.preview) {
        drawWave();
        $("dc-st-cuts").textContent = "—";
        $("dc-st-removed").textContent = "—";
        $("dc-st-final").textContent = "—";
      }
    } catch (e) {
      if (e.rolledBack) status(e.message, "warn");
      else if (j.stopped && e.message === STOPPED) status("Parado antes de cortar. Nada mudou na timeline.", "warn");
      else status("Erro ao aplicar: " + (e.message || e), "bad");
    } finally {
      endJob(j);
    }
  }

  // Clique na forma de onda: leva a agulha do Premiere até o ponto.
  function onWaveClick(ev) {
    if (!analysis || !ctx.inPremiere) return;
    const t = waveTime(ev);
    ctx.runInPremiere(`app.project.activeSequence.setPlayerPosition(PPC.ticks(${t.toFixed(3)}))`);
  }

  // ------------------------------------------------------------ chamada pelo chat

  /*
   * Ferramenta do chat: decupa a sequência ativa com o preset/valores pedidos.
   * args: { preset, threshold_db, min_silence, pad_before, pad_after, min_speech, mode, new_sequence, dry_run }
   */
  async function runFromChat(args, onProgress, onFraction) {
    if (busy) throw new Error("A aba Decupagem já está trabalhando. Espere terminar ou clique em Parar lá.");
    busy = true;
    let j = null;
    try {
      const info = await seqInfo();
      if (!info.ok) throw new Error(info.error);
      const dur = info.result.duration || 0;
      // Ainda não se sabe quantos cortes serão: conta um a cada 5 s até a análise terminar.
      const list = analysisStages(dur).concat(args.dry_run ? [] : applyStages(Math.max(1, Math.round(dur / 5)), args.mode || params.mode));
      j = beginJob("chat", list, onFraction);
      return await chatJob(args, (m) => j.stopped || onProgress(m), j, info.result);
    } catch (e) {
      if (j && j.stopped && e.message === STOPPED) throw new Error("Decupagem parada pelo usuário. Nada mudou na timeline.");
      throw e;
    } finally {
      if (j) endJob(j);
      else busy = false;
    }
  }

  async function chatJob(args, onProgress, j, seq) {
    resetAnalysis("O chat está analisando a timeline…");
    const a = await analyzeSequence(j, seq, onProgress); // sempre do zero: a timeline pode ter mudado
    showLevels();
    const p = Object.assign({}, params);
    let autoNote = "";
    if (args.preset === "auto" || (!args.preset && params.preset === "auto")) {
      tuned = D.autoTune(a);
      $("dc-auto-note").textContent = "🪄 " + tuned.notes;
      Object.assign(p, tuned.values, { preset: "auto" });
      autoNote = `\nAjuste automático: ${tuned.notes}. Valores: limiar ${tuned.values.threshold} dB, silêncio mínimo ${tuned.values.minSilence} s, margens ${tuned.values.padBefore}/${tuned.values.padAfter} s.`;
    } else if (args.preset && presetValues(args.preset)) Object.assign(p, presetValues(args.preset), { preset: args.preset });
    if (args.threshold_db === "auto") p.auto = true;
    else if (args.threshold_db != null && isFinite(Number(args.threshold_db))) {
      p.auto = false;
      p.threshold = Number(args.threshold_db);
    }
    const map = { min_silence: "minSilence", pad_before: "padBefore", pad_after: "padAfter", min_speech: "minSpeech", auto_offset_db: "autoOffset" };
    for (const [a, k] of Object.entries(map)) if (args[a] != null && isFinite(Number(args[a]))) p[k] = Number(args[a]);
    if (args.mode) p.mode = args.mode;
    if (args.new_sequence != null) p.newSequence = !!args.new_sequence;
    const res = D.computeCuts(a, p);
    const pct = a.duration ? Math.round((res.removed / a.duration) * 100) : 0;
    const summary = `Análise: ${a.duration.toFixed(1)} s · ruído ${a.noise} dB · fala ${a.speech} dB · limiar usado ${res.threshold} dB · ${res.cuts.length} silêncios · ${res.removed.toFixed(1)} s (${pct}%) a remover · duração final ${res.finalDuration.toFixed(1)} s.` + (res.protectedWords != null ? ` ${res.protectedWords} palavras protegidas pela transcrição.` : a.wordsNote ? ` (${a.wordsNote})` : "") + autoNote;
    if (args.dry_run || !res.cuts.length) {
      update();
      const list = res.cuts.slice(0, 40).map((c) => `${c.start.toFixed(2)}-${c.end.toFixed(2)}`).join(", ");
      return summary + (res.cuts.length ? "\nPrimeiros cortes (s): " + list : "");
    }
    onProgress(`aplicando ${res.cuts.length} cortes`);
    const est = applyEst(res.cuts.length, p.mode);
    for (const k of Object.keys(est)) j.steps.est(k, est[k]);
    const r = await applyCuts(res, p, j);
    update();
    return summary + "\n" + describe(r) + (r.forced ? " " + r.forced : "");
  }

  // ------------------------------------------------------------ início

  function init(c) {
    ctx = c;
    params = Object.assign({}, D.DEFAULTS, store(PARAMS_KEY) || {});
    buildControls();
    render();
    update();

    $("dc-preset").addEventListener("change", (e) => {
      if (e.target.value === "custom") {
        params.preset = "custom";
        fillPresetSelect();
      } else if (e.target.value === "auto") autoTuneNow();
      else applyPreset(e.target.value);
    });
    $("dc-autotune").addEventListener("click", async () => {
      if (!analysis) await onAnalyze();
      if (analysis) {
        autoTuneNow();
        status("Ajustado pelo áudio. Confira na forma de onda; dá para mexer em qualquer controle.", "ok");
      }
    });
    $("dc-auto").addEventListener("change", (e) => {
      params.auto = e.target.checked;
      markCustom();
      render();
      update();
    });
    $("dc-protect").addEventListener("change", (e) => {
      params.protectWords = e.target.checked;
      if (params.protectWords && analysis && !analysis.words && !analysis.demo) status("Clique em Analisar áudio de novo para transcrever e proteger as palavras.", "warn");
      update();
    });
    $("dc-trim").addEventListener("change", (e) => {
      params.trimEdges = e.target.checked;
      markCustom();
      render();
      update();
    });
    $("dc-mode").addEventListener("change", (e) => {
      params.mode = e.target.value;
      update();
    });
    $("dc-newseq").addEventListener("change", (e) => {
      params.newSequence = e.target.checked;
      update();
    });
    $("dc-reset").addEventListener("click", () => (params.preset === "auto" ? autoTuneNow() : applyPreset(params.preset in D.PRESETS || params.preset in userPresets() ? params.preset : D.DEFAULTS.preset)));
    $("dc-save-preset").addEventListener("click", () => {
      $("dc-save-row").classList.toggle("hidden");
      $("dc-preset-name").focus();
    });
    $("dc-preset-name").addEventListener("keydown", (e) => {
      if (e.key === "Enter") $("dc-preset-ok").click();
    });
    $("dc-preset-ok").addEventListener("click", () => {
      const name = $("dc-preset-name").value;
      $("dc-preset-name").value = "";
      $("dc-save-row").classList.add("hidden");
      const label = name.trim() || "Meu preset " + (Object.keys(userPresets()).length + 1);
      const all = userPresets();
      const id = "u" + Date.now();
      const values = {};
      for (const k of NUM_KEYS) values[k] = params[k];
      values.auto = params.auto;
      values.trimEdges = params.trimEdges;
      all[id] = { label, values };
      store(PRESETS_KEY, all);
      params.preset = id;
      render();
      update();
    });
    $("dc-del-preset").addEventListener("click", () => {
      const all = userPresets();
      if (!all[params.preset]) return;
      delete all[params.preset];
      store(PRESETS_KEY, all);
      params.preset = "custom";
      render();
      update();
    });
    $("dc-analyze").addEventListener("click", onAnalyze);
    $("dc-apply").addEventListener("click", onApply);
    $("dc-stop").addEventListener("click", () => stop("aba"));
    setupWaveInput();
    window.addEventListener("resize", drawWave);
  }

  function shown() {
    drawWave();
    seqInfo().then((info) => {
      if (info.ok) $("dc-seq-name").textContent = `${info.result.name} · ${fmtTime(info.result.duration)}`;
    });
  }

  window.DecupUI = { init, shown, runFromChat, stop, running: () => !!job };
})();
