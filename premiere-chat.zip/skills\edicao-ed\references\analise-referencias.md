# Análise das referências – Edição ED (Impetus, leads/microleads de ED, alemão, 9:16)

Feita em 23/11/2026 a partir das timelines dos .prproj (valores exatos) e de prints dos MP4 finais.

| Ref | Final | Sequência no .prproj | Duração | Formato |
|---|---|---|---|---|
| L4_V1 | `Funil 1 … Titan Prime … \FINALIZA\L4_V1.mp4` | `Funil 1 … \Projeto\Funil 1 ….prproj` → seq nº 8 "L4 - CORTADA" | 297 s | 1080x1910, 30 fps |
| PBU_V2 | `…\FINALIZA\PBU_V2.mp4` | mesmo projeto → seq nº 6 "PBU - CORTADA - CORTADA" | 403 s | 1080x1910, 30 fps |
| L6_V2 | `[LEADS] Funil 3 … L 06 …\FINALIZADO\L6_V2.mp4` | `…\Projeto\[LEADS] Funil 3 ….prproj` → seq nº 1 "L6-1-F" | 323 s | 720x1280, 30 fps |
| ML 01 | `Funil 6 … Horse Gelatin …\Finalizado\ML 01.mp4` | `…\Projeto\Funil 6 ….prproj` → seq nº 13 "ML1-FINAL" | 80 s | 1080x1920, 30 fps |
| ML 02 | `…\Finalizado\ML 02.mp4` | mesmo projeto → seq nº 12 "ML2_720p" | 183 s | 720x1280, 25 fps |
| ML 04 | `…\Finalizado\ML 04.mp4` | mesmo projeto → seq nº 14 "ML4_720p" | 124 s | 720x1280, 25 fps |

Ler uma sequência: `python <skills>/impetus-upsell-emagrecimento/scripts/analisar_prproj.py "<prproj>" --seq <n> saida.json`,
resumo: `python <skills>/impetus-upsell-up3/scripts/resumir_faixas.py saida.json faixas.txt`,
ganho dos áudios: `python <skills>/edicao-ed/scripts/niveis_audio.py "<prproj>" <n>`.

## 1. Estrutura e ritmo
- Apresentador falando (expert de jaleco/camisa, ator pornô conhecido, atriz pornô, garota de "selfie"). Brutas em V1/A1, cortadas sem respiro.
- **1 corte na bruta a cada 2–3 s** (ML 02: a cada 1,9 s). Zoom-in/out (Transform Scale 100↔120 em 2–3,5 s) nos trechos sem insert, para não ficar parado.
- **Inserts cobrem 62–69 % do tempo**, duração mediana **1,7–2,8 s**, trocando a cada frase/meia frase. A cara do apresentador aparece pouco: entra em respiros de 2–4 s.
- Vídeo começa com glitch `[G]_Digital_01` (0,33–0,4 s, empilhado em 3–4 faixas: Wave Warp + Mirror + Replicate / Color Emboss + Tint em blend / ProcAmp piscando) + SFX `[T]_Glitch - Digital_02.wav` + `Boom 1.mp3`.

## 2. Gancho (0–15 s) – fórmula fixa
1. 0–2,2 s: apresentador + **título MOGRT de 3–4 linhas** (ex.: "Mach diesen / PORNO TRICK / mit Pferdesalz / nicht," / "Legen Sie / dieses weiße / PULVER UNTER / Ihre Zunge," / "jede Frau / auf deinem / SCHWANZ / dreimal"). Linha de destaque em Anton amarelo (#FFE600-ish, gradiente amarelo) ou vermelho (ML 02), demais linhas em fonte fina branca/itálico. Escala 40–78 %, entra palavra a palavra.
2. Junto do título: **insert em círculo** (sequência aninhada com borda branca `Stroke` 6 px) subindo de baixo (Transform Position Y 2,36→0,5 em 0,72 s, Shutter 360) e crescendo 100→110 %. Mostra o "truque" (sal/gelatina na colher) ou cena picante.
3. ~2,2–7 s: **tela dividida** – apresentador na metade de cima, insert pornô na metade de baixo, linha branca separando, legenda pequena na divisória.
4. Depois: sequência de 3–5 inserts pornô com as frases-promessa em **destaque grande Anton** (ver §4) sobre o insert.
5. Volta ao apresentador; "Pass auf, hol dir einen Stift…" com zoom suave.

## 3. Legendas (duas camadas)
- **Legenda corrida (LEG1, caption track do Premiere)**: 1–3 palavras por bloco (0,3–0,6 s).
  - Leads com expert (L4, PBU, L6): Poppins Bold branca, sem caixa, sombra escura, tamanho pequeno, no meio da tela (L4/PBU, Y ≈ 0,55) ou embaixo (L6, Y ≈ 0,8).
  - Microleads (ML 01/02/04): **Poppins SemiBold branca em caixa magenta #D00890** (cantos retos), embaixo (Y ≈ 0,8).
  - LEG2 = tradução em português, só referência do editor (não aparece no final).
- **Destaque grande ("Graphic" Anton-Regular, branco, caixa alta)**: 2–5 palavras por bloco, palavra/expressão a palavra (0,25–0,9 s cada), em sequências de 4–20 blocos nas frases de efeito. Nesses trechos a legenda corrida é desligada.
  - Efeitos: Wonder Glow (Intensity 60, Size 50, Color #FFDFB3, Ambient #FF4746 a 20, Chromatic Aberration 10) + Transform pop (Scale 0→100 em 0,1–0,3 s, Shutter 360) + Transform crescendo 100→120 ao longo do bloco. Text Position 0,125:0,35.
  - Fundo do destaque: o próprio insert pornô, OU o apresentador desfocado (Gaussian Blur 30–92 + Lumetri Exposure −0,62) – "tela de impacto".
  - Variante com Shape + Mirror (L6): caixa por trás do texto, entrada com Scale 360→100 e saída encolhendo 100→50/espelhada; WarpShort_Up entre blocos.
- Frases-título no meio do vídeo ("Klingt verrückt, oder?", "Ich zeige es also ein letztes Mal.", "Das Ergebnis?", "Und raten Sie mal?", "Ich bin Lena Nitro,") usam o mesmo MOGRT do gancho.

## 4. Apresentação dos inserts
- **Tela cheia** (maioria): pornô, UGC de TikTok, 3D médico, banco (Envato/Storyblocks), cavalos, sal/gelatina. Escala de preenchimento; Lumetri Exposure −0,42 a −0,62 em vários.
- **Cartão inclinado 3D** (assinatura do estilo): sequência aninhada com Motion 82–89 %, **Basic 3D Swivel −21→8 e Tilt −20→−15** ao longo do clipe (movimento contínuo), **Drop Shadow** preta (Direção −144, Distância 26, Suavidade 114), **Roughen Edges** (Border 40 = cantos arredondados) – fundo: o apresentador desfocado/escuro ou fundo cinza. Usado para fotos de famosos, prints, depoimentos, pornô "contado como história".
- **Cartão reto com borda arredondada** (Roughen Edges 40/109/122 + Transform 110→100 ou 100→110): fotos de famosos ("Mein Name ist LUCY CAT", Mick Blue, Johnny Sins) e cenas.
- **Celular mockup** ("LAYOUT + VIDEO", seq. aninhada) com vídeo de TikTok dentro (pixelado/mosaico quando é nu), sobre `fundo_singular_05.png` (Escala 276, Rotação 90, Turbulent Displace 15/15) + textura `afb5ef45…jpg` (Opacity 11 %, blend) – usado quando a fala cita "vídeo que postei / viral / TikTok".
- **Tela dividida** apresentador/insert (gancho e momentos-chave).
- **Selo verde ✓ "100 %"** sobre o insert quando afirma resultado.
- Overlay `old-film-grain-overlay-4k-snowman-digital.mp4` (blend 4, Escala cheia) em blocos de 6 s; camadas de ajuste com Lumetri (Amount −5, Midpoint 55) + **Noise 20** em trechos dramáticos.
- **Tarja preta com "3 MONATE"** (Anton amarelo) no fechamento da oferta (PBU).

> Regras obrigatórias do usuário (fala negativa sobre o homem → homem triste/genitália pequena com 50 % de saturação, vinheta e VHS; insert que falta → placeholder "BAIXAR"): ver [regras-material-ed.md](regras-material-ed.md).

## 5. Famosos e pessoas reais
- Quando a fala cita alguém (Riccardo Schicchi, Arnold Schwarzenegger, Mick Blue, Johnny Sins, Lucy Cat, Dr. citado em estudo), entra **foto ou vídeo da pessoa**: foto em cartão (3D inclinado ou reto) ou trecho de entrevista em tela cheia (Arnold veio como bruta separada "4 L4 ARNOLD").
- **Regra nova do usuário**: se não houver mídia da pessoa na biblioteca/pasta Inserts, **não substituir por outra coisa**: colocar um placeholder na timeline (slate colorido com "BAIXAR: <nome> – <o que mostrar>") na faixa e no tempo exatos, + marcador vermelho com o mesmo texto, para o usuário baixar e encaixar.

## 6. Transições e movimento
- `Zoom suave` (camada de ajuste com Transform): zoom-in de entrada 126,8/153→100 % em 0,75 s (Shutter 180) nas trocas de cena; zoom lento 100→107 % ao longo de ~7 s; 100→119 % com leve deslocamento.
- `ZOOM Para LTs` (camada de ajuste, Shrink 50 %) ao entrar um cartão/LT.
- `WarpShort_Up` (camada de ajuste: Directional Blur + Offset, e Levels + Lens Distortion) – chicote vertical de 0,4 s, com SFX `[T]_Pan - Warp_Short.wav`.
- `Generated Light Leak 9 (242bee85)` (aegraphic, 0,3–0,4 s) nos cortes de bloco – clarão.
- `Map - Digital 1 v2` (aegraphic, 0,23 s) – glitch digital pontual.
- `fade preto` no fim.
- **Vinheta** em tudo: `VERTICAL VIGNETT` (Vignette Scale 130/150, Feather 65, Chromatic Aberration 51 → borda RGB que se vê nos prints).

## 7. Música
- Pasta `G:\Clientes\IMPETUS\Inserts gerais\MÚSICAS`. Rock/eletrônico enérgico, trocando a cada 40–90 s:
  - L4: `vibedepot-free-rock-446606.mp3` → `vibedepot-rock-free-446609.mp3` → `Sport Trailer 80 MIX Instrumental.mp3`.
  - L6: `Electro Fight - Kwon … [SDA].mp3` (0–40 s e depois) + `prettyjohn1-sport-action-rock-484392.mp3`.
  - ML 02/ML 04: `Electro Fight - Kwon`.
  - PBU (mais emocional/depoimento): `Fundos Musicais Inspiradores…` (−23,6 a −27 dB) e `Cinematic Dramatic Epic Classical Sci-Fi…` (−24,7 dB).
- Clipes de rock/Electro Fight ficam a 0 dB no clipe (ajuste na faixa/Essential Sound "music"); no final a trilha fica presente, ~6–8 LU abaixo da voz. Loudness final: ML 02 ≈ −13 LUFS momentâneo médio, ML 04 −15,8 LUFS, L6 −17,9 LUFS, L4 −22 LUFS. Alvo sugerido: −16 LUFS.

## 8. SFX (arquivo → uso → ganho do clipe; 0 dB = sem ajuste)
Obs.: o Premiere guarda o Level com 15 dB de deslocamento (valor 0,1778 = 0 dB); `niveis_audio.py` já converte.
- `Boom 1.mp3` (0 dB) – início do vídeo e grandes revelações.
- `[T]_Glitch - Digital_02.wav` (0 dB) – glitch de abertura.
- `Riser.wav` (−12,2 dB, às vezes velocidade 900 %) – antes de destaque/revelação; `Reverse Bell 1.wav` / `reverse cymbal transition.wav` (0 dB) – subida para bloco novo.
- `Swoosh Transition 28.wav` (−5 dB) – entrada de insert/cartão (o mais usado nos ML e L6).
- `SFX - Swoosh 08.mp3` (0 dB), `Woosh 02.mp3` (−13 dB), `Acute Whoosh.mp3` (0 dB) – trocas e zooms.
- `[T]_Pan - Warp_Short.wav` (0 dB) – junto do WarpShort_Up.
- `Camera Shutter Click 12.wav` (0 dB) – a cada bloco do destaque grande / foto entrando.
- `sound-effect-519.mp3` (0 dB, L4) – "pop" de cada palavra do destaque; `camera-01.mp3` (PBU) igual.
- `Soft Glitchy Hiss 02.wav` (−18 dB com keyframes), `Cash Register (Kaching)` (preço), `-Notification t1_03.wav` (celular), `ui clicks sfx.mp3`.
- **Áudio dos próprios inserts pornô fica ligado** (gemidos) a 0 dB, ou −11 a −18 dB quando há fala por cima.
- Pastas: `G:\EDIÇÃO\Copied_TESTE EDIÇÃO`, `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\{Cameras,Risers}`, `G:\EDIÇÃO\Musicas\SFX`, `G:\Clientes\IMPETUS\TESTE DE EFEITOS PRATICOS\EFEITOS PRONTOS DE ML ED` (kit com SFX, light leak e templates), `D:\PACK ALK\…\SFX\SWOOSH`.

## 9. Bibliotecas de inserts usadas
- `G:\Clientes\IMPETUS\Videos finalizados\ED\Copiado_PORN ACERVO_1` (59 arqs) e `G:\Clientes\IMPETUS\ARQUIVOS NECESSARIOS\SEXO\{03, NOVO 1}`.
- `G:\Clientes\IMPETUS\Inserts gerais\ED` (+ `GANCHOS ED`), `\Medico(a)`, `\TRUQUES\…`, `\mulheres`, `\Cavalo`, `\Corpo humano`, `\Celulas. Sangue`, etc.
- `G:\Clientes\IMPETUS\ARQUIVOS NECESSARIOS\Background\Grid_02.mp4` (fundo).
- Inserts específicos de cada projeto na pasta do projeto (ex.: `AJUSTES VINI\Copied_TITANPRIME_L3_02_11`, `ML 1 e 4 … \Bruta 4\inserts`).

## 10. O que pede confirmação do usuário antes de virar regra
- Formato da entrega: XML/timeline do Premiere em camadas (como as outras skills Impetus) ou MP4.
- Qual legenda usar por tipo: branca sem caixa (lead com expert) x caixa magenta (microlead).
- Volume final da trilha (o projeto não guarda o fader; medido no render).
