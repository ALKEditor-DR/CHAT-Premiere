import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
f = d['faixas']
out = open(sys.argv[2], 'w', encoding='utf-8')
it = sorted([x for x in f['LEG1']['itens'] if x.get('texto')], key=lambda x: x['ini'])
line = []
for x in it:
    line.append('%.2f %s' % (x['ini'], x['texto'].replace(' | ', ' ')))
    if len(line) == 8:
        out.write(' / '.join(line) + '\n'); line = []
if line: out.write(' / '.join(line) + '\n')
json.dump([[round(x['ini'],3), round(x['fim'],3), x['texto'].replace(' | ',' ')] for x in it], open(sys.argv[3],'w',encoding='utf-8'), ensure_ascii=False)
