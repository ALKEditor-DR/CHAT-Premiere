/*
 * Skills que viajam junto com o plugin.
 *
 * 1. importNew(): skills que o próprio painel criou em ~/.premiere-chat/skills-novas/<id> (o chat não
 *    pode gravar direto em ~/.claude/skills) entram em ~/.claude/skills e na lista clientes.json.
 * 2. syncBundle(extDir): a pasta "skills" do plugin (gerada pelo PUBLICAR ATUALIZACAO a partir das
 *    skills do PC de origem) é instalada em ~/.claude/skills de cada máquina:
 *      - arquivo que falta: copiado;
 *      - arquivo que mudou no pacote: a versão da máquina vai para o backup e entra a nova;
 *      - arquivo que só mudou na máquina (pacote igual ao da última vez): fica o da máquina;
 *      - clientes.json: junta as listas (não apaga nada nem troca a skill padrão);
 *      - caminhos do PC de origem (pasta do usuário, G:\Clientes quando a máquina usa D:\Clientes)
 *        são trocados pelos desta máquina.
 *    No PC de origem (arquivo ~/.premiere-chat/skills-origem) não faz nada: lá as skills são a fonte.
 */
(function (root) {
  "use strict";
  if (typeof require !== "function") {
    root.SkillsSync = null;
    return;
  }
  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  const crypto = require("crypto");

  const api = {};
  const home = () => os.homedir();
  const PC = () => path.join(home(), ".premiere-chat");
  const SKILLS = () => path.join(home(), ".claude", "skills");
  const NOVAS = () => path.join(PC(), "skills-novas");
  const STATE = () => path.join(PC(), "skills-sync.json");
  const ORIGEM = () => path.join(PC(), "skills-origem");
  const BASE = () => path.join(PC(), "skills-sync-base"); // última versão do pacote dos arquivos de aprendizado
  const CLIENTES_REL = path.join("novo-projeto-edicao", "clientes.json");
  const LEARN = /[\\/](historico-ajustes|estilo-aprovado)\.md$/i;
  const TEXT = /\.(md|txt|json|py|js|jsx|mjs|cjs|css|html?|ps1|cmd|bat|ya?ml|xml|srt|csv|ini|cfg|toml)$/i;

  const sha = (buf) => crypto.createHash("sha1").update(buf).digest("hex");
  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[-:]/g, "").replace("T", "_");

  function listFiles(dir, base = dir) {
    let out = [];
    let ents = [];
    try {
      ents = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return out;
    }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name === "__pycache__" || e.name === "node_modules" || e.name === ".git") continue;
        out = out.concat(listFiles(p, base));
      } else if (!/\.(bak|tmp|pyc)$/i.test(e.name)) out.push(path.relative(base, p));
    }
    return out;
  }

  function copyDir(src, dst) {
    for (const rel of listFiles(src)) {
      const to = path.join(dst, rel);
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(path.join(src, rel), to);
    }
  }

  function readJson(file, fallback) {
    try {
      return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
    } catch {
      return fallback;
    }
  }
  const writeJson = (file, obj) => {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(obj, null, 1) + "\n", "utf8");
  };

  function backupFile(backupDir, rel, from) {
    const to = path.join(backupDir, rel);
    fs.mkdirSync(path.dirname(to), { recursive: true });
    fs.copyFileSync(from, to);
  }

  // ---------------------------------------------------------------- clientes.json

  // Junta "extra" na lista desta máquina. Só acrescenta: cliente novo ou skill nova num cliente.
  function mergeClientes(local, extra) {
    let changed = false;
    for (const [cliente, info] of Object.entries(extra || {})) {
      const skills = (info && info.skills) || [];
      if (!local[cliente]) {
        local[cliente] = { skills: skills.map((s) => Object.assign({}, s)) };
        changed = true;
        continue;
      }
      const lst = (local[cliente].skills = local[cliente].skills || []);
      for (const s of skills) {
        if (lst.some((x) => x.id === s.id)) continue;
        lst.push(Object.assign({}, s, { padrao: !!s.padrao && !lst.some((x) => x.padrao) }));
        changed = true;
      }
    }
    return changed;
  }

  function saveClientes(obj, backupDir) {
    const file = path.join(SKILLS(), CLIENTES_REL);
    if (fs.existsSync(file) && backupDir) backupFile(backupDir, CLIENTES_REL, file);
    writeJson(file, obj);
  }

  // Cliente de uma skill nova: o mesmo das skills com o mesmo começo de nome (cliente-...).
  function guessClient(clientes, id) {
    const pre = id.split("-")[0].toLowerCase();
    for (const [cliente, info] of Object.entries(clientes)) {
      if (((info && info.skills) || []).some((s) => s.id.split("-")[0].toLowerCase() === pre)) return cliente;
    }
    return null;
  }

  function skillTitle(dir, id) {
    try {
      const md = fs.readFileSync(path.join(dir, "SKILL.md"), "utf8");
      const m = md.match(/^description:\s*["']?([^.\n"']{3,60})/m);
      if (m) return m[1].trim();
    } catch {}
    return id;
  }

  // ---------------------------------------------------------------- 1. skills criadas pelo painel

  api.importNew = function () {
    const out = { importadas: [], erros: [] };
    let ents = [];
    try {
      ents = fs.readdirSync(NOVAS(), { withFileTypes: true });
    } catch {
      return out;
    }
    const clientesFile = path.join(SKILLS(), CLIENTES_REL);
    const clientes = readJson(clientesFile, null);
    let clientesChanged = false;
    for (const e of ents) {
      if (!e.isDirectory() || e.name.startsWith(".") || e.name.startsWith("_")) continue;
      const id = e.name;
      const src = path.join(NOVAS(), id);
      if (!fs.existsSync(path.join(src, "SKILL.md"))) continue;
      try {
        const dst = path.join(SKILLS(), id);
        const bk = path.join(PC(), "skill-backups", "antes-importar_" + stamp());
        if (fs.existsSync(dst)) for (const rel of listFiles(dst)) backupFile(bk, path.join(id, rel), path.join(dst, rel));
        copyDir(src, dst);
        // Guarda o original fora da fila, para não importar de novo.
        const done = path.join(NOVAS(), "_importadas", id + "_" + stamp());
        fs.mkdirSync(path.dirname(done), { recursive: true });
        fs.renameSync(src, done);
        if (clientes) {
          const already = Object.values(clientes).some((c) => ((c && c.skills) || []).some((s) => s.id === id));
          const cliente = !already && guessClient(clientes, id);
          if (cliente) {
            mergeClientes(clientes, { [cliente]: { skills: [{ nome: skillTitle(dst, id), id, padrao: false }] } });
            clientesChanged = true;
          }
        }
        out.importadas.push(id);
      } catch (err) {
        out.erros.push(id + ": " + err.message);
      }
    }
    if (clientesChanged) saveClientes(clientes, path.join(PC(), "skill-backups", "antes-importar_" + stamp()));
    return out;
  };

  // ---------------------------------------------------------------- 2. skills que vêm no plugin

  function rewriter(manifest) {
    const pairs = [];
    const fromHome = manifest && manifest.origemHome;
    const toHome = home();
    if (fromHome && path.normalize(fromHome).toLowerCase() !== path.normalize(toHome).toLowerCase()) {
      const a = fromHome.replace(/[\\/]+$/, "");
      const b = toHome.replace(/[\\/]+$/, "");
      pairs.push([a.replace(/\\/g, "\\\\"), b.replace(/\\/g, "\\\\")]); // C:\\Users\\x (escapado em JSON/código)
      pairs.push([a, b]); // C:\Users\x
      pairs.push([a.replace(/\\/g, "/"), b.replace(/\\/g, "/")]); // C:/Users/x
    }
    const clientesDrive = () => {
      if (fs.existsSync("G:\\Clientes")) return null;
      for (const d of "DEFHIJ") if (fs.existsSync(d + ":\\Clientes")) return d;
      return null;
    };
    const drive = manifest && manifest.origemClientes && /^G:/i.test(manifest.origemClientes) ? clientesDrive() : null;
    return (buf, rel) => {
      if (!TEXT.test(rel) || (!pairs.length && !drive)) return buf;
      let s = buf.toString("utf8");
      for (const [a, b] of pairs) s = s.replace(new RegExp(a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), () => b);
      if (drive) s = s.replace(/\bG:(\\\\|\\|\/)Clientes/g, drive + ":$1Clientes");
      return Buffer.from(s, "utf8");
    };
  }

  api.syncBundle = function (extDir) {
    const res = { pulado: null, novas: [], atualizadas: [], arquivos: 0, mantidos: 0, mesclados: [], removidas: [], mantidasAqui: [], backup: null, erros: [] };
    const bundle = path.join(extDir || "", "skills");
    if (!extDir || !fs.existsSync(bundle)) return ((res.pulado = "sem-pacote"), res);
    if (fs.existsSync(ORIGEM())) return ((res.pulado = "origem"), res);
    const manifest = readJson(path.join(bundle, "manifest.json"), {});
    const state = readJson(STATE(), { files: {} });
    state.files = state.files || {};
    const rewrite = rewriter(manifest);
    const bk = path.join(PC(), "skill-backups", "antes-plugin-" + String(manifest.versao || "").replace(/[^0-9A-Za-z._-]/g, "") + "_" + stamp());
    const touched = new Set();
    let ids = [];
    try {
      ids = fs.readdirSync(bundle, { withFileTypes: true }).filter((d) => d.isDirectory() && !d.name.startsWith("_")).map((d) => d.name);
    } catch {}
    for (const id of ids) {
      const isNew = !fs.existsSync(path.join(SKILLS(), id, "SKILL.md"));
      for (const r of listFiles(path.join(bundle, id))) {
        const rel = path.join(id, r);
        const key = rel.replace(/\\/g, "/");
        if (key.toLowerCase() === CLIENTES_REL.replace(/\\/g, "/").toLowerCase()) continue; // juntado abaixo
        try {
          const nb = rewrite(fs.readFileSync(path.join(bundle, rel)), rel);
          const h = sha(nb);
          const dst = path.join(SKILLS(), rel);
          let cur = null;
          try {
            cur = fs.readFileSync(dst);
          } catch {}
          if (cur && cur.equals(nb)) {
            state.files[key] = h;
            if (LEARN.test(rel) && !fs.existsSync(path.join(BASE(), rel))) {
              fs.mkdirSync(path.dirname(path.join(BASE(), rel)), { recursive: true });
              fs.writeFileSync(path.join(BASE(), rel), nb);
            }
            continue;
          }
          if (cur) {
            if (state.files[key] === h) {
              res.mantidos++; // pacote igual ao da última vez: a mudança é desta máquina
              continue;
            }
            // Versão "portátil" desta máquina (usa o Python do edicao-runtime) e o pacote não: mantém.
            if (TEXT.test(rel) && /edicao-runtime/.test(cur.toString("utf8")) && !/edicao-runtime/.test(nb.toString("utf8"))) {
              res.mantidos++;
              continue;
            }
            backupFile(bk, rel, dst);
            res.backup = bk;
          }
          let out = nb;
          // Aprendizados que o painel gravou nesta máquina: entra o do pacote e as linhas daqui que
          // ele não tem ficam no fim, para não perder nada.
          if (cur && LEARN.test(rel)) {
            // Linhas que já existiam antes (a versão que esta máquina recebeu da última vez, ou a do
            // instalador) não contam como aprendizado daqui: assim regra antiga não volta duplicada.
            const lines = (b) => b.toString("utf8").split(/\r?\n/).map((l) => l.trim());
            const have = new Set(lines(nb));
            for (const baseFile of [path.join(BASE(), rel), path.join(bundle, "_base", rel)]) {
              try {
                for (const l of lines(rewrite(fs.readFileSync(baseFile), rel))) have.add(l);
                break;
              } catch {}
            }
            const extra = cur
              .toString("utf8")
              .split(/\r?\n/)
              .filter((l) => l.trim() && !have.has(l.trim()) && !/^## Aprendizados desta máquina/.test(l.trim()));
            if (extra.length) {
              out = Buffer.from(nb.toString("utf8").replace(/\s*$/, "") + "\n\n## Aprendizados desta máquina (mantidos na atualização do plugin)\n" + extra.join("\n") + "\n", "utf8");
              res.mesclados.push(rel);
            }
          }
          fs.mkdirSync(path.dirname(dst), { recursive: true });
          fs.writeFileSync(dst, out);
          if (LEARN.test(rel)) {
            fs.mkdirSync(path.dirname(path.join(BASE(), rel)), { recursive: true });
            fs.writeFileSync(path.join(BASE(), rel), nb);
          }
          state.files[key] = h;
          res.arquivos++;
          touched.add(id);
        } catch (err) {
          res.erros.push(rel + ": " + err.message);
        }
      }
      if (isNew && fs.existsSync(path.join(SKILLS(), id, "SKILL.md"))) res.novas.push(id);
    }
    // Lista de clientes: junta.
    const extra = readJson(path.join(bundle, CLIENTES_REL), null);
    if (extra) {
      const file = path.join(SKILLS(), CLIENTES_REL);
      const local = readJson(file, {});
      if (mergeClientes(local, extra)) {
        try {
          saveClientes(local, fs.existsSync(file) ? bk : null);
          if (fs.existsSync(file)) res.backup = bk;
          touched.add("novo-projeto-edicao");
        } catch (err) {
          res.erros.push("clientes.json: " + err.message);
        }
      }
    }
    removeRetired(manifest, state, res, ids);
    res.atualizadas = [...touched].filter((id) => !res.novas.includes(id));
    state.versao = manifest.versao || null;
    state.quando = new Date().toISOString();
    try {
      writeJson(STATE(), state);
    } catch {}
    return res;
  };

  // ---------------------------------------------------------------- 3. skills retiradas do pacote

  /*
   * Tira desta máquina SÓ as skills citadas em manifest.removidas, e só quando foi o plugin que as pôs:
   * todo arquivo da pasta precisa ser um que o plugin gravou e que continua igual (os de aprendizado
   * podem ter mudado: vão para o backup). Um arquivo que o plugin não gravou, ou que alguém mudou,
   * basta para a pasta inteira ficar como está. Nenhuma outra skill é tocada. Roda uma vez por máquina.
   */
  function removeRetired(manifest, state, res, bundleIds) {
    const done = (state.removidas = state.removidas || {});
    const ids = (Array.isArray(manifest.removidas) ? manifest.removidas : []).filter((id) => typeof id === "string" && /^[a-z0-9][a-z0-9-]*$/i.test(id) && !bundleIds.includes(id));
    const gone = [];
    for (const id of ids) {
      if (done[id]) continue;
      const dir = path.join(SKILLS(), id);
      try {
        let st = null;
        try {
          st = fs.lstatSync(dir);
        } catch {}
        if (!st) {
          done[id] = "ausente";
          gone.push(id);
        } else {
          const files = st.isDirectory() && !st.isSymbolicLink() ? rawFiles(dir) : null;
          const tracked = Object.keys(state.files).some((k) => k.startsWith(id + "/"));
          const learned = [];
          let foreign = !files || !tracked;
          for (const rel of files || []) {
            if (/\.pyc$/i.test(rel)) continue;
            const key = id + "/" + rel.replace(/\\/g, "/");
            const same = !!state.files[key] && state.files[key] === sha(fs.readFileSync(path.join(dir, rel)));
            if (same) continue;
            if (state.files[key] && LEARN.test(path.join(id, rel))) learned.push(rel);
            else foreign = true;
          }
          if (foreign) {
            done[id] = "mantida";
            res.mantidasAqui.push(id);
          } else {
            const bk = path.join(PC(), "skill-backups", "removida-" + id + "_" + stamp());
            for (const rel of learned) backupFile(bk, path.join(id, rel), path.join(dir, rel));
            for (const rel of files) fs.unlinkSync(path.join(dir, rel));
            removeEmptyDirs(dir);
            for (const k of Object.keys(state.files)) if (k.startsWith(id + "/")) delete state.files[k];
            done[id] = "removida";
            gone.push(id);
            res.removidas.push(id);
          }
        }
        // Cópias que o próprio plugin guardou ao se atualizar (o pacote antigo inteiro).
        if (done[id] !== "mantida") fs.rmSync(path.join(BASE(), id), { recursive: true, force: true });
        let olds = [];
        try {
          olds = fs.readdirSync(path.join(PC(), "plugin-backups"));
        } catch {}
        for (const o of olds) {
          fs.rmSync(path.join(PC(), "plugin-backups", o, "skills", id), { recursive: true, force: true });
          fs.rmSync(path.join(PC(), "plugin-backups", o, "skills", "_base", id), { recursive: true, force: true });
        }
      } catch (err) {
        delete done[id]; // tenta de novo na próxima abertura
        res.erros.push("retirar " + id + ": " + err.message);
      }
    }
    // Lista de clientes: sai a skill retirada; o cliente só sai se ficou sem nenhuma skill.
    const names = Array.isArray(manifest.clientesRemovidos) ? manifest.clientesRemovidos : [];
    const todo = names.filter((n) => !done["cliente:" + n]);
    if (!gone.length && !todo.length) return;
    try {
      const file = path.join(SKILLS(), CLIENTES_REL);
      const local = readJson(file, null);
      if (!local) return;
      let changed = false;
      for (const info of Object.values(local)) {
        if (!info || !Array.isArray(info.skills)) continue;
        const keep = info.skills.filter((s) => !s || !gone.includes(s.id));
        if (keep.length !== info.skills.length) {
          info.skills = keep;
          changed = true;
        }
      }
      for (const n of todo) {
        const info = local[n];
        if (info && Object.keys(info).every((k) => k === "skills") && Array.isArray(info.skills) && !info.skills.length) {
          delete local[n];
          changed = true;
        }
        done["cliente:" + n] = "ok";
      }
      if (changed) saveClientes(local, path.join(PC(), "skill-backups", "antes-retirar_" + stamp()));
    } catch (err) {
      for (const n of todo) delete done["cliente:" + n];
      res.erros.push("clientes.json: " + err.message);
    }
  }

  // Todos os arquivos, sem filtro (o que não for reconhecido impede a remoção).
  function rawFiles(dir, base = dir) {
    let out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) out = out.concat(rawFiles(p, base));
      else out.push(path.relative(base, p));
    }
    return out;
  }
  function removeEmptyDirs(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) if (e.isDirectory()) removeEmptyDirs(path.join(dir, e.name));
    fs.rmdirSync(dir); // só apaga pasta vazia
  }

  // Uma linha para o chat (ou "" se nada mudou).
  api.describe = function (imp, syn) {
    const parts = [];
    if (imp && imp.importadas.length) parts.push("skill nova instalada: " + imp.importadas.join(", "));
    if (syn && syn.novas.length) parts.push("skills novas do plugin: " + syn.novas.join(", "));
    if (syn && syn.atualizadas.length) parts.push("skills atualizadas: " + syn.atualizadas.join(", "));
    if (syn && syn.removidas.length) parts.push("skills retiradas do plugin: " + syn.removidas.join(", "));
    const errs = [].concat((imp && imp.erros) || [], (syn && syn.erros) || []);
    if (!parts.length && !errs.length) return "";
    let s = "🧩 " + (parts.length ? parts.join(" · ") : "Problema ao instalar skills");
    if (syn && syn.backup) s += ". As versões anteriores ficaram em " + syn.backup;
    if (errs.length) s += ". Não consegui instalar: " + errs.slice(0, 3).join("; ");
    return s + ".";
  };

  api.paths = { skills: SKILLS, novas: NOVAS, state: STATE, origem: ORIGEM };
  root.SkillsSync = api;
})(typeof window !== "undefined" ? window : globalThis);
