"""Extrai as legendas (faixas de legenda do Premiere) de um .prproj: lista de faixas, cada uma [[inicio, fim, texto], ...]."""
import base64
import gzip
import json
import re
import sys
import xml.etree.ElementTree as ET

TK = 254016000000
root = ET.fromstring(gzip.open(sys.argv[1]).read())
byid = {e.attrib["ObjectID"]: e for e in root.iter() if "ObjectID" in e.attrib}
PADRAO = re.compile(rb"(?:[\x20-\x7e]|[\xc2-\xf4][\x80-\xbf]+){2,}")
FONTE = re.compile(r"^(Poppins|LucidaConsole|Arial|Montserrat|Inter|Roboto)")


def texto(b64):
    raw = base64.b64decode(b64)
    toks = [t.decode("utf-8", "replace") for t in PADRAO.findall(raw)]
    k = max((i for i, t in enumerate(toks) if FONTE.match(t)), default=-1)  # o texto vem depois do nome da fonte
    out = [t.strip() for t in toks[k + 1:] if re.search(r"[A-Za-zÀ-ÿ0-9]", t) and "�" not in t]
    while out and len(out[-1]) <= 2 and not out[-1].isdigit():  # lixo binário no fim ("pB", "@B")
        out.pop()
    return " ".join(out)


# o Premiere guarda o conteúdo repetido uma vez só e as outras legendas apontam para ele pelo BinaryHash
POR_HASH = {fd.attrib.get("BinaryHash"): fd.text.strip() for fd in root.iter("FormattedTextData") if fd.text and fd.text.strip()}


def achar_texto(el, visto=None):
    visto = visto or set()
    for fd in el.iter("FormattedTextData"):
        b = fd.text.strip() if fd.text and fd.text.strip() else POR_HASH.get(fd.attrib.get("BinaryHash"))
        if b:
            return texto(b)
    for e in el.iter():
        r = e.attrib.get("ObjectRef")
        if r and r not in visto:
            visto.add(r)
            t = achar_texto(byid[r], visto)
            if t:
                return t
    return ""


res = []
for tr in root.iter("CaptionDataClipTrack"):
    itens = []
    for ti in tr.iter("TrackItem"):
        if "ObjectRef" not in ti.attrib:
            continue
        it = byid[ti.attrib["ObjectRef"]]
        st = it.find(".//TrackItem/Start")
        en = it.find(".//TrackItem/End")
        a = int(st.text) / TK if st is not None else 0.0
        b = int(en.text) / TK
        blk = byid[it.find(".//BlockVectorItem").attrib["ObjectRef"]]
        itens.append([round(a, 3), round(b, 3), achar_texto(blk)])
    res.append(itens)
json.dump(res, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=0)
for r in res:
    print(len(r), "itens, fim", r[-1][1] if r else None, "vazios:", sum(1 for x in r if not x[2]))
