#!/usr/bin/env python
"""Transforma o JSON de analisar_prproj.py num resumo legível: cada insert com a fala dita enquanto ele aparece,
origem do arquivo (orgânico/UGC, banco de imagens, IA, mockup...) e a pasta da biblioteca. Também resume música, SFX,
textos de LT e transições.

python resumo_timeline.py timeline.json resumo.txt [resumo.json]
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
J = json.load(open(sys.argv[1], encoding="utf-8"))
F = J["faixas"]


def origem(nome, cam):
    n = (nome or "") + " " + (cam or "")
    nl = n.lower()
    if re.search(r"ssstik|snaptik|tiktok|musicaldown|snapinsta|instagram|insta_|reels?_|@\w|whatsapp|y2mate|x2download|savefrom|screen ?recording|"
                 r"gravação de tela|download \(\d+\)|\(720p|\(1080p|\(360p|youtube|shorts", nl):
        return "ORGÂNICO (UGC/rede social)"
    if re.search(r"freepik_|kling|grok-video|magnific|runway|hailuo|veo|sora|midjourney|_ia\b|-ia\.|\bia\b|gemini", nl):
        return "IA (gerado)"
    if re.search(r"mockup|bottle|frasco|pote|capsul|maxheart|\bbg\b|fundo", nl):
        return "MOCKUP/FUNDO"
    if re.search(r"-utc\.(mov|mp4)|envato", nl):
        return "BANCO (Envato)"
    if re.search(r"gettyimages", nl):
        return "BANCO (Getty)"
    if re.search(r"^0_|\\0_|/0_|coll_wavebreak|\d{5,}_[a-z]", nl):
        return "BANCO (Storyblocks/Pond5)"
    if re.search(r"\d+-(uhd|hd|sd)_\d+_\d+_\d+fps|\d{6,}_\d+_\d+_\d+fps|pexels|pixabay", nl):
        return "BANCO (Pexels/Pixabay)"
    if re.search(r"\.(png|jpe?g|webp)$", nl):
        return "IMAGEM"
    return "OUTRO"


IDX = {}
_ip = os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), "indice_biblioteca.json")
if os.path.exists(_ip):
    IDX = json.load(open(_ip, encoding="utf-8"))


def pasta(cam):
    if not cam:
        return ""
    c = cam.replace("\\", "/")
    b = os.path.basename(c).lower()
    if "Inserts gerais" not in c and "ARQUIVOS NECESSARIOS" not in c and b in IDX:  # projeto coletado: acha a pasta original na biblioteca
        return IDX[b] + " (biblioteca)"
    m = re.search(r"Inserts gerais/([^/]+)", c)
    if m:
        return "Inserts gerais/" + m.group(1)
    m = re.search(r"ARQUIVOS NECESSARIOS/([^/]+)", c)
    if m:
        return "ARQUIVOS NECESSARIOS/" + m.group(1)
    return "/".join(c.split("/")[-3:-1])


def legenda(k, a, b):
    if k not in F:
        return ""
    t = [x.get("texto", "") for x in F[k]["itens"] if x.get("texto") and x["ini"] < b - 0.05 and x["fim"] > a + 0.05 and not x.get("desativado")]
    return " ".join(t)


# qual faixa de legenda é a fala original e qual é a tradução (a de PT tem palavras como "você", "não", "que")
legs = [k for k in F if k.startswith("LEG")]
pt = None
for k in legs:
    txt = " ".join(x.get("texto", "") for x in F[k]["itens"][:80]).lower()
    if re.search(r"\b(você|não|que|está|para)\b", txt):
        pt = k
orig = next((k for k in legs if k != pt), None)

AJUSTE = re.compile(r"^(adjustment layer|zoom suave|zoom|vinheta|vInheta|graphic|black video|color matte|transparent video|camada de ajuste)", re.I)
linhas, dados = [], []
vfaixas = sorted([k for k in F if k.startswith("V") and k != "V1"], key=lambda k: int(k[1:]))
for k in vfaixas:
    for x in F[k]["itens"]:
        if x.get("desativado"):
            continue
        nome = x.get("aninhada") or x["nome"]
        cam = x.get("arquivo", "")
        if AJUSTE.match(x["nome"]) and not x.get("aninhada"):
            continue
        if "aegraphic" in (cam or "").lower():
            continue
        tipo = "SEQ ANINHADA" if x.get("aninhada") else origem(x["nome"], cam if cam and not cam.isdigit() else "")
        esc = ""
        for f in x.get("efeitos", []):
            if f["efeito"] == "Motion" and f["valores"].get("Scale"):
                esc = f"esc {f['valores']['Scale'][:6]}"
        d = {"faixa": k, "ini": x["ini"], "fim": x["fim"], "dur": round(x["fim"] - x["ini"], 2), "nome": nome, "tipo": tipo, "pasta": pasta(cam),
             "fala": legenda(orig, x["ini"], x["fim"]), "pt": legenda(pt, x["ini"], x["fim"]) if pt else "", "escala": esc,
             "velocidade": x.get("velocidade", "")}
        dados.append(d)
dados.sort(key=lambda d: d["ini"])
dur = max(x["fim"] for v in F.values() for x in v["itens"])
linhas.append(f"SEQUÊNCIA: {J['sequencia']}  ({dur:.0f}s)   legenda original={orig} tradução={pt}")
linhas.append("\n== INSERTS (fora V1) com a fala ==")
for d in dados:
    mm, ss = divmod(d["ini"], 60)
    linhas.append(f"{int(mm):02d}:{ss:05.2f} {d['dur']:5.2f}s {d['faixa']:4} [{d['tipo']}] {d['nome'][:70]}  ({d['pasta']}) {d['escala']} {('vel ' + d['velocidade']) if d['velocidade'] else ''}")
    if d["fala"]:
        linhas.append(f"        fala: {d['fala'][:230]}")
    if d["pt"]:
        linhas.append(f"        PT:   {d['pt'][:230]}")

# cobertura
cob = sorted((d["ini"], d["fim"]) for d in dados if d["tipo"] not in ("IMAGEM",))
tot, f_ = 0, 0
for a, b in cob:
    if b > f_:
        tot += b - max(a, f_)
        f_ = b
linhas.append(f"\nCOBERTURA de inserts: {tot:.0f}s de {dur:.0f}s ({tot / dur * 100:.0f}%)")
c = Counter(d["tipo"] for d in dados)
linhas.append("ORIGEM: " + ", ".join(f"{k}: {v}" for k, v in c.most_common()))
linhas.append("PASTAS: " + ", ".join(f"{k}: {v}" for k, v in Counter(d["pasta"] for d in dados).most_common(25)))
durs = [d["dur"] for d in dados if d["tipo"].startswith(("BANCO", "ORG", "IA"))]
if durs:
    durs.sort()
    linhas.append(f"DURAÇÃO dos B-rolls: mediana {durs[len(durs) // 2]:.1f}s, min {durs[0]:.1f}s, max {durs[-1]:.1f}s")

# gráficos (LTs)
linhas.append("\n== TEXTOS EM GRÁFICOS (LTs / destaques) ==")
gfx = []
for k in F:
    if k.startswith("V"):
        for x in F[k]["itens"]:
            if x.get("texto") and not x.get("desativado"):
                efs = [f["efeito"] for f in x.get("efeitos", [])]
                gfx.append((x["ini"], k, x["texto"], ",".join(e for e in efs if e not in ("Opacity", "Motion")), ",".join(x.get("fontes", []))))
gfx.sort()
for t, k, txt, efs, fo in gfx:
    mm, ss = divmod(t, 60)
    linhas.append(f"{int(mm):02d}:{ss:05.2f} {k:4} {txt[:80]:80} | {efs[:60]} | {fo[:40]}")

# áudio
linhas.append("\n== ÁUDIO ==")
for k in sorted([k for k in F if k.startswith("A") and k != "A1"], key=lambda k: int(k[1:])):
    cnt = Counter(x["nome"] for x in F[k]["itens"] if not x.get("desativado"))
    linhas.append(f"{k}: " + "; ".join(f"{n} x{v}" for n, v in cnt.most_common(12)))
musicas = [x for k in F if k.startswith("A") and k != "A1" for x in F[k]["itens"] if x["fim"] - x["ini"] > 20]
linhas.append("MÚSICAS (>20 s): " + "; ".join(f"{x['ini']:.0f}-{x['fim']:.0f} {x['nome']}" for x in sorted(musicas, key=lambda x: x["ini"])))

# transições
linhas.append("\n== TRANSIÇÕES ==")
tc = Counter(t["nome"] for v in F.values() for t in v["transicoes"])
linhas.append(", ".join(f"{k}: {v}" for k, v in tc.most_common()))
mg = Counter(x["nome"] for k in F if k.startswith("V") for x in F[k]["itens"] if "aegraphic" in (x.get("arquivo") or "").lower() or AJUSTE.match(x["nome"]))
linhas.append("Camadas de efeito/gráfico: " + ", ".join(f"{k} x{v}" for k, v in mg.most_common(15)))
ef = Counter(f["efeito"] for k in F if k.startswith("V") for x in F[k]["itens"] for f in x.get("efeitos", []))
linhas.append("Efeitos usados: " + ", ".join(f"{k} x{v}" for k, v in ef.most_common(25)))

open(sys.argv[2], "w", encoding="utf-8").write("\n".join(linhas))
if len(sys.argv) > 3:
    json.dump(dados, open(sys.argv[3], "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("\n".join(linhas[:3]))
print("...", len(dados), "inserts")
