---
name: novo-projeto-edicao
description: >-
  Regra principal para começar qualquer projeto de edição de vídeo de cliente: pede a pasta mãe, cria Brutas, SFX, Inserts e Musicas, confere o material, avisa sobre pastas vazias e pergunta qual skill usar, sugerindo só as do cliente. Use sempre que o usuário pedir para editar, começar ou fazer um novo Reels ou vídeo de cliente (Impetus ou outro), antes de qualquer outra skill de edição e antes de tocar em qualquer arquivo, mesmo que uma skill já tenha sido citada. Use também ao criar uma skill nova de cliente, para colocá-la na lista.
---

# Início de projeto de edição

Esta é a regra principal do usuário. A edição só começa depois destes passos, porque o usuário quer o material organizado e a chance de notar o que esqueceu antes de gastar tempo em render.

`P` abaixo é a pasta `scripts` desta skill.

## 1. Pedir a pasta mãe
Peça o caminho da pasta mãe do projeto. Não escolha nem invente uma, mesmo que o vídeo já esteja em outro lugar. Se a pasta informada não existir, confirme o caminho antes de criá-la.

## 2. Criar as subpastas
```bash
python "$P/pasta_mae.py" criar "<pasta mãe>"
```
Cria `Brutas`, `SFX`, `Inserts` e `Musicas` e não mexe no que já existe. Diga o que deve ir em cada uma e aguarde o usuário avisar que colocou tudo:

- **Brutas**: o vídeo do Reels, já decupado
- **SFX**: efeitos sonoros
- **Inserts**: vídeos e fotos de B-roll
- **Musicas**: trilhas

## 3. Conferir
Quando o usuário avisar, rode:
```bash
python "$P/pasta_mae.py" conferir "<pasta mãe>"
```
Diga o que encontrou em cada pasta. Para cada pasta vazia, avise pelo nome e pergunte se está certo mesmo ou se faltou importar algo. Não siga com pasta vazia sem resposta do usuário: assumir errado custa um render inteiro.

Se `Brutas` estiver vazia e o usuário confirmar, explique que sem vídeo não há como editar. Com mais de um vídeo em `Brutas`, pergunte qual usar ou se cada um é um Reels.

## 4. Perguntar qual skill usar
Antes de iniciar, pergunte qual skill usar com `AskUserQuestion`, mesmo que só exista uma, e deixe a marcada `[PADRÃO]` como primeira opção recomendada.

Mostre só as skills do cliente da pasta, que o script identifica pelo nome logo depois de `Clientes` no caminho. Skill de um cliente nunca é sugerida para outro: cada uma carrega a identidade daquele cliente.

- Cliente sem skill: diga isso e pergunte como seguir.
- Cliente não identificado: pergunte de qual cliente é o projeto.

## 5. Começar
Carregue a skill escolhida e siga o fluxo dela, com o material da pasta mãe. Arquivos de trabalho ficam em `<pasta mãe>/_projeto`, e o vídeo final na própria pasta mãe.

## Adicionar uma skill à lista
Ao criar uma skill de edição nova, acrescente-a em `clientes.json`, no cliente certo:
```json
{"nome": "Cliente reels 02", "id": "cliente-reels-02", "padrao": false}
```
`nome` é como o usuário a chama e `id` é o nome da pasta da skill. Deixe só uma como `padrao` por cliente. Não troque o padrão sem o usuário pedir. Cliente novo vira uma entrada nova, com o nome da pasta do cliente em `G:\Clientes`.
