---
name: edicao-ed
description: >-
  Edição ED (Impetus, leads e microleads picantes de disfunção erétil/ED em alemão, 9:16). Monta direto na timeline do Premiere, em camadas editáveis, o estilo das referências L4_V1, PBU_V2 (Sal de Cavalo/Titan Prime), ML 01/02/04 (Horse Gelatin) e L6_V2 (Truque do Sal Marinho): corte a cada 2–3 s, inserts cobrindo ~65 % do tempo, gancho com título MOGRT + insert em círculo + tela dividida, destaques Anton com Wonder Glow, cartões 3D inclinados, fotos de famosos em cartão, celular com TikTok, glitch de abertura, zoom suave, WarpShort, light leak, vinheta com aberração cromática, granulado, trilha rock/eletrônica e os mesmos SFX. Regras obrigatórias: fala negativa sobre o homem (impotência, pênis pequeno, falhar, esposa decepcionada) leva insert de homem triste ou genitália pequena com 50 % de saturação, vinheta e VHS; insert que não existe (principalmente famoso) vira placeholder "BAIXAR" + marcador vermelho na timeline. Use sempre que o usuário pedir para editar, montar ou finalizar um lead, microlead, ML ou VSL de ED/potência/sexo do Impetus, ou aplicar "a Edição ED", "o padrão ED" ou "o estilo do L4/L6/ML", mesmo sem citar a skill.
---

# Edição ED (Impetus)

Antes de um projeto novo, passe pela skill `novo-projeto-edicao` (pasta mãe, subpastas, conferência, escolha da skill).

Leia antes de montar:
- [references/regras-material-ed.md](references/regras-material-ed.md): **regras obrigatórias** do usuário (trecho negativo → homem triste/genitália pequena com 50 % + vinheta + VHS; insert que falta → "BAIXAR"). Valem acima de qualquer outra escolha.
- [references/analise-referencias.md](references/analise-referencias.md): o estilo inteiro, com valores exatos tirados das 6 timelines (gancho, legendas, destaques, cartões, transições, música, SFX e ganhos, bibliotecas).
- [references/plano-exemplo-ed.jsx](references/plano-exemplo-ed.jsx): formato do plano que o `lib_ed.jsx` lê.
- [references/historico-ajustes.md](references/historico-ajustes.md): o porquê de cada regra e o que ainda não foi validado.

## Como o usuário trabalha
- Português do Brasil, direto. As decisões são feitas aqui; a edição acontece no Premiere, em camadas separadas e editáveis, numa cópia `<sequência> - MONTADA ED` (nunca na sequência original).
- Mudança visual nova: mostre prints do trecho apontado e espere aprovação. Se ele apontar um trecho, mexa só nele.
- Não use projeto antigo feito com o mesmo material sem perguntar.
- O material é explícito; o foco do trabalho é estilo, apresentação dos inserts, música e SFX. Escolha os inserts pela fala, sem comentar o conteúdo.

## Pergunte no começo (se não estiver claro)
1. Tipo: **lead com expert** (legenda branca sem caixa) ou **microlead** com apresentadora/selfie (legenda Poppins SemiBold em caixa magenta #D00890). Confirme qual legenda usar.
2. A legenda já vem pronta na sequência? (Nas referências ela é a faixa de legenda do Premiere; a tradução em português fica numa segunda faixa só para referência.)
3. Famosos/pessoas citadas na fala e se o usuário já tem a mídia.
4. Qual sequência de referência importar no projeto (padrão: `L4 - CORTADA` do projeto do Funil 1; para microlead, `ML4_720p` do Funil 6) – é dela que vêm glitch, light leak e títulos MOGRT.

## Fluxo (painel Premiere Chat)
`S` = `C:/Users/mlkal/.claude/skills/edicao-ed/scripts`, `S3` = `C:/Users/mlkal/.claude/skills/impetus-upsell-up3/scripts`, `SE` = `C:/Users/mlkal/.claude/skills/impetus-upsell-emagrecimento/scripts`. Arquivos de trabalho em `<pasta mãe>/_projeto`.

1. **Ler a sequência decupada** (projeto salvo): `python SE/analisar_prproj.py "<prproj>" --lista`, depois `--seq <n> seq.json` e `python S3/dump_leg.py seq.json leg.txt words.json` (palavras com tempo da legenda). Sem projeto salvo: `transcribe_sequence` no painel.
2. **Roteiro de blocos**: marque gancho, história, mecanismo, prova, oferta. Marque **todos os trechos negativos** (lista de gatilhos em `regras-material-ed.md`) e todas as pessoas citadas.
3. **Escolher inserts** frase a frase (~2 s cada, 62–69 % de cobertura, troca a cada frase/meia frase), nas bibliotecas listadas em `analise-referencias.md §9` + pasta `Inserts` do projeto. Faça folhas de miniaturas das pastas para escolher. Para cada insert decida o modo: `cheio`, `card3d` (famoso, print, depoimento, história), `cardreto` (foto de famoso/apresentação de nome), `dividida` (gancho).
   - Trecho negativo → **só** homem triste/genitália pequena, `neg: true`, e o intervalo em `P.NEG`.
   - Não achou → entra em `faltas.json` (Regra 2), nunca troque por outra pessoa/coisa.
4. **Placeholders**: `python S/gerar_placeholders.py faltas.json "<pasta mãe>/_projeto/BAIXAR" <largura> <altura>` → `baixar.json` vira `P.BAIXAR`; `BAIXAR.txt` vai para o relatório.
5. **Destaques Anton**: 8–15 frases de efeito (promessas do gancho, "Es kostet weniger als 10 €", "Jetzt pass gut auf", revelações, números). `python S3/gerar_destaques.py words.json ranges.json "<pasta mãe>/_projeto/Destaques" destaques.json <largura> <altura>`. Nesses trechos a legenda corrida é desligada (faça a lista e avise; o usuário desliga ou o painel desativa os itens da faixa de legenda).
6. **Plano** `_projeto/plano_ed.jsx` no formato do exemplo: INS, NEG, BAIXAR, TIT, ZOOM, ZBRUTA, WARP, LEAK, GRAOS, TRILHAS, SFXL, MARCADORES.
7. **Montagem** (run_extendscript, em blocos de ~40 inserts):
   ```
   $.evalFile("S3/lib.jsx"); $.evalFile("S/lib_ed.jsx"); $.evalFile("<_projeto>/plano_ed.jsx");
   E.prep();
   E.abertura(); E.titulos();
   E.inserts(0,40); E.inserts(40,999);
   E.negativos(); E.baixar();
   E.destaques("<_projeto>/destaques.json", {<grupos com fundo desfocado>: true});
   E.zooms(); E.zoomBruta(); E.warps(); E.leaks(); E.grao(); E.vinheta();
   E.trilhas(); E.sfx(); E.marcadores(MARCADORES);
   E.resumo();
   ```
   Faixas: V1 bruta, V2 inserts, V3 cartões, V4 negativo (VHS), V5 fundo desfocado, V6 destaques, V7 títulos, V8 zoom, V9 warp, V10 light leak, V11 granulado, V12 vinheta, V13 glitch. A1 voz, A2 áudio dos inserts, A3–A6 SFX, A7–A8 trilhas (alternando, nunca sobrepostas na mesma faixa).
8. **Conferir** com `view_frame`: glitch + título do gancho, tela dividida, um destaque, um cartão 3D, um trecho negativo (tem que estar com 50 %, vinheta e VHS), um placeholder BAIXAR, um light leak. Diga o que não foi conferido.
9. **Relatório**: o que foi montado por faixa, lista de BAIXAR (tempo, nome, o que baixar), títulos MOGRT cujo texto precisa ser trocado (marcadores amarelos), o que falhou no `E.resumo()`.

## Regras de estilo (resumo; valores em analise-referencias.md)
- Bruta cortada sem respiro; zoom 100↔120 % na bruta nos trechos sem insert.
- Gancho: glitch 0,4 s + Boom → título MOGRT 3–4 linhas (palavra-chave em Anton amarelo/vermelho) + insert em círculo com borda branca → tela dividida (apresentador em cima, insert embaixo) → 3–5 inserts com destaques Anton.
- Destaque: Anton branco, MAIÚSCULAS, 2–5 palavras, Wonder Glow (60/50, #FFDFB3, ambiente #FF4746), pop 0→100 % em ≤0,15 s e 100→120 % até o fim, Camera Shutter em cada bloco. Fundo: o insert, ou o apresentador desfocado (blur 30, exposição −0,62).
- Cartão 3D: 82 %, Basic 3D Swivel −21→8 / Tilt −20→−15, Drop Shadow −144°/26/114, Roughen Edges 40, sobre o apresentador desfocado.
- Famoso citado → foto/vídeo da pessoa (cartão). Sem mídia → BAIXAR.
- Vinheta com aberração cromática no vídeo todo; granulado e camada Lumetri −5 + Noise 20 nos trechos dramáticos.
- Música rock/eletrônica trocando a cada 40–90 s, presente (~6–8 LU abaixo da voz). Comece em −19 dB no clipe para Electro Fight/vibedepot e confira de ouvido; final ≈ −16 LUFS.
- SFX nos ganhos das referências (Swoosh Transition 28 −5 dB na entrada de insert/cartão, Riser −12 dB antes de revelação, Woosh 02 −13 dB, Camera Shutter 0 dB nos destaques, Boom 0 dB em abertura/revelação). Áudio dos inserts pornô ligado (0 dB, ou −11 a −18 dB sob fala).

## Armadilhas
- Herda as do UP 3 (`impetus-upsell-up3/SKILL.md`): QE põe efeito no topo da pilha (adicione na ordem inversa), Adjustment Layer precisa de escala de preenchimento, Roughen Edges não arredonda clipe cortado pelo quadro (mídia horizontal em cartão: use sequência aninhada 9:16, como nas referências), item com acento no nome falha lido do .jsx (coloque direto no código).
- O Premiere guarda volume com 15 dB de deslocamento: use `E.lv(dB)`; para ler ganhos de um projeto use `python S/niveis_audio.py "<prproj>" <n>`.
- Itens que só existem nos projetos de referência (glitch `[G]_Digital_01`, `Generated Light Leak 9`, títulos MOGRT, mockup de celular `LAYOUT + VIDEO`) exigem a sequência de referência importada no projeto (`P.REF`). O kit `G:\Clientes\IMPETUS\TESTE DE EFEITOS PRATICOS\EFEITOS PRONTOS DE ML ED` (com projeto ML 10) tem SFX, light leak e templates.
- `lib_ed.jsx` ainda não rodou num projeto real: valide no primeiro uso (ver historico-ajustes.md) e corrija aqui o que falhar.
