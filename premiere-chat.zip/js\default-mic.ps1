# Mostra o nome do microfone padrão do Windows (o que está em Configurações > Som > Entrada).
# Usa a API de áudio do Windows (Core Audio). Saída: uma linha com o nome, ou nada se não houver.
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$code = @"
using System;
using System.Runtime.InteropServices;

[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
    int EnumAudioEndpoints();
    [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
    [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
    [PreserveSig] int OpenPropertyStore(int access, out IPropertyStore store);
}
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
    int RegisterControlChangeNotify();
    int UnregisterControlChangeNotify();
    int GetChannelCount();
    int SetMasterVolumeLevel();
    int SetMasterVolumeLevelScalar();
    int GetMasterVolumeLevel();
    [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
    int SetChannelVolumeLevel();
    int SetChannelVolumeLevelScalar();
    int GetChannelVolumeLevel();
    int GetChannelVolumeLevelScalar();
    int SetMute();
    [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
}
[ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IPropertyStore {
    int GetCount();
    int GetAt();
    [PreserveSig] int GetValue(ref PropKey key, out PropVar value);
}
[StructLayout(LayoutKind.Sequential)] struct PropKey { public Guid fmtid; public int pid; }
[StructLayout(LayoutKind.Explicit)] struct PropVar { [FieldOffset(0)] public short vt; [FieldOffset(8)] public IntPtr ptr; [FieldOffset(16)] public IntPtr pad; }
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCom { }

public static class PremiereChatMic {
    // role: 0 = padrão (console), 2 = comunicações
    public static string DefaultName(int role) {
        var en = (IMMDeviceEnumerator)(new MMDeviceEnumeratorCom());
        IMMDevice dev;
        if (en.GetDefaultAudioEndpoint(1, role, out dev) != 0 || dev == null) return "";
        IPropertyStore ps;
        if (dev.OpenPropertyStore(0, out ps) != 0) return "";
        var key = new PropKey { fmtid = new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"), pid = 14 };
        PropVar v;
        if (ps.GetValue(ref key, out v) != 0 || v.ptr == IntPtr.Zero) return "";
        string name = Marshal.PtrToStringUni(v.ptr);
        // Só lê (não muda nada): está mudo? qual o volume de entrada?
        string extra = "";
        try {
            Guid iid = typeof(IAudioEndpointVolume).GUID;
            object o;
            if (dev.Activate(ref iid, 23, IntPtr.Zero, out o) == 0) {
                var vol = (IAudioEndpointVolume)o;
                bool mute; float level;
                vol.GetMute(out mute);
                vol.GetMasterVolumeLevelScalar(out level);
                extra = "|" + (mute ? "mudo" : "ok") + "|" + ((int)Math.Round(level * 100)).ToString();
            }
        } catch { }
        return name + extra;
    }
}
"@
try {
    Add-Type -TypeDefinition $code -Language CSharp
    [PremiereChatMic]::DefaultName(0)
} catch {
    Write-Error $_
    exit 1
}
