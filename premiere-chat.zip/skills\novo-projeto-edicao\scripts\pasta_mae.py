#!/usr/bin/env python
"""Prepara e confere a pasta mãe de um projeto de edição.

python pasta_mae.py criar   "G:/Clientes/CLIENTE/Reels 02"   cria Brutas, SFX, Inserts e Musicas
python pasta_mae.py conferir "G:/Clientes/CLIENTE/Reels 02"  lista o que tem em cada pasta, as vazias e as skills do cliente
"""
import json
import os
import re
import sys
import unicodedata

SUBPASTAS = ["Brutas", "SFX", "Inserts", "Musicas"]
IGNORAR = {"desktop.ini", "thumbs.db", ".ds_store"}
LISTA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "clientes.json")


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def cliente_da_pasta(pasta):
    """O cliente é a pasta logo depois de 'Clientes' no caminho. Sem isso, a pasta não diz de quem é."""
    partes = [p for p in re.split(r"[\\/]+", os.path.abspath(pasta)) if p]
    for i, p in enumerate(partes[:-1]):
        if norm(p) == "clientes":
            return partes[i + 1]
    return None


def skills_do_cliente(cliente):
    dados = json.load(open(LISTA, encoding="utf-8"))
    alvo = norm(cliente or "")
    for nome, info in dados.items():
        if norm(nome) == alvo:
            return nome, info.get("skills", [])
    return cliente, []


def mostrar_skills(pasta):
    cliente = cliente_da_pasta(pasta)
    if cliente is None:
        print("CLIENTE: não identificado pelo caminho; pergunte de qual cliente é. Não sugira skill de outro cliente.")
        return
    nome, skills = skills_do_cliente(cliente)
    print("CLIENTE:", nome)
    if not skills:
        print("SKILLS: nenhuma para este cliente ainda.")
    for s in sorted(skills, key=lambda x: not x.get("padrao")):
        print(f"SKILL: {s['nome']} (id {s['id']})" + (" [PADRÃO]" if s.get("padrao") else ""))


def arquivos(pasta):
    out = []
    for raiz, _, nomes in os.walk(pasta):
        for n in nomes:
            if n.lower() not in IGNORAR:
                out.append(os.path.relpath(os.path.join(raiz, n), pasta))
    return sorted(out)


def criar(mae):
    if not os.path.isdir(mae):
        print("NÃO EXISTE:", mae, "- confirme o caminho com o usuário antes de criar.")
        sys.exit(2)
    for s in SUBPASTAS:
        p = os.path.join(mae, s)
        print(("JÁ EXISTIA: " if os.path.isdir(p) else "CRIADA: ") + p)
        os.makedirs(p, exist_ok=True)
    mostrar_skills(mae)


def conferir(mae):
    vazias = []
    faltando = []
    for s in SUBPASTAS:
        p = os.path.join(mae, s)
        if not os.path.isdir(p):
            faltando.append(s)
            continue
        a = arquivos(p)
        print(f"{s}: {len(a)} arquivo(s)")
        for x in a[:40]:
            print("   ", x)
        if len(a) > 40:
            print(f"    ... e mais {len(a) - 40}")
        if not a:
            vazias.append(s)
    print("FALTANDO:", ", ".join(faltando) or "nenhuma")
    print("VAZIAS:", ", ".join(vazias) or "nenhuma")
    mostrar_skills(mae)


if __name__ == "__main__":
    {"criar": criar, "conferir": conferir}[sys.argv[1]](sys.argv[2])
