# Padrão UP 3 (multiproduto) – faixa por faixa

Base: "UP 1" do projeto HerzPur (lido do .prproj) + "UP 3 - MONTADA" aprovado. Sequência 1292x1604 (4:5), 24 qps.
Cobertura de inserts ~70 %, B-roll mediana ~2,6 s (1,3–4,5 s). Expert fica sozinho nos ganchos, frases olho no olho e sob a LT.

## Vídeo
| Faixa | Conteúdo | Valores |
|---|---|---|
| V1 | Expert / depoimentos (decupado) | não mexer |
| V2 | B-roll em tela cheia; fundo desfocado dos cartões; fundo das telas de produto/oferta | Motion Scale = preenchimento 4:5. Fundo de cartão e fundo de mockup HerzPur/GlucoVital = preset "Gaussian Blur + LUMETRI" (Blur 30, Repeat Edge Pixels; Lumetri Exposure −0,617, Contrast 29,97, Highlights −100, Shadows −51,13). BG do produto novo sem blur. |
| V3 | Cartão (sequência aninhada 4:5) / mockup PNG | Cartão: Motion 79 %, Transform Scale Height 100→110 % ao longo do clipe, preset "borda arredondada" (Roughen Edges: Edge Type 0, Border 40, Edge Sharpness 10, Fractal 0, Complexity 2). Mockup PNG: escala 48–56 %, Y 0,60, preset ZOOM IN 20X ou ZOOM OUT 20X (Transform Scale Height 100→120 ou 120→100 em ~9,97 s, ease), alternando. Oferta 6 potes: Y 0,60, ZOOM IN 20X. Selo 30 dias: centro, escala para ~850 px. |
| V4 | Camada de ajuste de desfoque dos destaques (uma por frase) | Motion 119,63 %; Gaussian Blur 30 + Lumetri (mesmos valores acima). |
| V5 | Destaques (PNG por trecho de legenda) | Anton Regular branco, MAIÚSCULAS, até 150 px (cabe em 1120 px), sombra preta 170/255 blur 6 deslocada (4,6), centro do quadro. Wonder Glow (Intensity 60, Highlights Only 40, Size 50, Vibrance 10, Ambient Amount 20, Chromatic Aberration 10). Transform Scale Height 0→100 em 0,16 s e 100→118 até o fim. |
| V6 | Neon e LT (MOGRT) | Neon "Text Animation_Neon_04": Motion 74,26 %, Y 0,2294, cor amarela (255,232,0), Text Scale 300 (210 para nome do produto). LT "LT_Minimal_Left_05": 0–1,67 s, Motion 51,26 %, pos (0,418; 0,605), Text 1 "Dr", Text 2 "<nome>", Text 3 vazio, Line Color laranja (255,170,0), Drop Shadow (Opacity 100, Distance 5, Softness 37). |
| V7 | Zoom suave (ajuste) e vinheta vertical dos cartões | Zoom: Adjustment Layer 1,29 s, Motion 119,63, Transform Scale Height 153→100 em 0,75 s, shutter 180. Vinheta: item "VERTICAL VIGNETT" do UP 1, Motion 148,52, efeito Vignette Scale 130 / Feather 65, na duração do cartão. |
| V8 | Transição A: Lens Blur | Duas camadas de ajuste coladas no corte T: (T−0,625 → T) e (T → T+0,375), Motion 119,63; transição Lens Blur de 15 quadros no fim da primeira. |
| V9 | Transição B: Flash | Mesmo par; Flash de 8 quadros (cortes normais) ou 15 quadros (a cada 3º corte). |
| V10 | Light leak ("Generated Light Leak 9", .aegraphic do UP 1) | Par (T−0,375 → T) + (T → T+0,46), Motion não uniforme: Scale 493,78 / Scale Width 177,78. Só no bloco de oferta e fechamento. |
| V11 | Vinheta geral ("VInheta") | Vídeo inteiro, Motion 148,52, Lumetri vinheta Amount −5, Midpoint 55. |

Cortes com transição: ~66 em 9 min (início de cada sequência de inserts e viradas de bloco), intercalando: 2 cortes "A" (Lens Blur + Flash curto + pop) para 1 corte "B" (Lens Blur + Flash longo + riser + woosh).

## Áudio (níveis = valor do parâmetro Level do Premiere; 0.1778 = 0 dB)
| Faixa | Conteúdo | Nível |
|---|---|---|
| A1 | Voz | — |
| A2 | Boom 1 no 1º destaque (6 s); Good Idea High Ding na palavra do produto novo; SFX - Swoosh 08 0,2 s antes de cada tela de oferta | 0.1778 / 0.151 / 0.1778 |
| A3 | sound-effect-519 (in 0,333, 0,96 s) 0,62 s antes de cada corte A; Riser.wav (0,67 s) no corte B (−0,3 s) e em cada zoom suave | 0.1778 / 0.0434 |
| A4 | Woosh 02 (in 0,083, 1 s) 0,58 s antes de cada corte B | 0.0397 |
| A5 | Camera Shutter Click 12 (0,2 s antes de cada light leak); cash register.wav em cada preço neon | 0.1778 |
| A6–A8 | Trilhas, uma por bloco, sobrepostas 3–4 s, fade in 1,5 s / fade out 2 s; reverse cymbal (9,46 s) terminando na apresentação do produto novo | 0.0132 (−22,6 dB) / cymbal 0.1778 |

Trilhas do UP 1 e ordem usada no UP 3: `inspire-motivation-epic-2-14997.mp3` (abertura e problema) → `Inspiring & Uplifting Cinematic Background Music For Videos.mp3` (in 1,583; apresentação e mecanismos) → `TRILHA (7).wav` (depoimentos) → `TRILHA (2).wav` (in 27,833; resultados e oferta) → `TRILHA (1).wav` (in 60,667; garantia até o fim).
Caminhos: músicas em `G:\EDIÇÃO\Musicas\Musicas Storytelling\` e `...\Copied_UP1B V1 HERZPUR\`; SFX em `G:\EDIÇÃO\Copied_TESTE EDIÇÃO\` e `G:\EFEITOS VERSAO NOVA\Copied_Efeitos praticos\` (pegue os projectItems direto dos clipes do UP 1).

## Escolha de inserts (o que funcionou)
- Produto citado → mockup animado daquele produto (`Mockup <Produto>\ANIMADOS\1/2/3/6 potes`), 1–3 s, no instante do nome.
- "os dois/três pilares", "Herzpur und Glucovital" → produtos em sequência (1,2–2 s cada); "die drei Säulen" → as três telas de mockup PNG seguidas (HerzPur, GlucoVital, produto novo).
- Apresentação do produto novo: BG do produto + mockup PNG de 1 pote + neon com o nome + ding + troca de trilha + zoom suave antes.
- Ingredientes/complexo: mockup PNG de 3 potes sobre o BG do produto novo.
- Sono/noite: `senior-man-sleeping-peacefully…`, `senior-adult-sleeping-peacefully…`, `0_Man_Bed`, `Idosos desespero`, `Escada escura`, `0_Anxiety_Man`.
- Cortisol/pressão/artérias: monitores de pressão, `High Blood Pressure.mov`, `Arteria entupida`, `Celulas. Sangue`.
- Ciência/institutos/BfArM: `5994212_Scientist_Laboratory`, `0_Microscope_Micro`, `0_Pharmaceutical_Production`, `DOCTOR.mp4`.
- "Bestellung / Paket / Karton / Labor": `Entregas` (scientists-packaging, packing-goods, worker-strapping, warehouse).
- Prazos (6 Monate): `TEMPO. CALENDARIO`.
- Depoimentos: inserts em ~50 % do tempo, sem LT se o usuário não der os nomes.
- Cartões (borda arredondada): blocos de lista/explicação de 9–17 s (sintomas do sono, cortisol, "erster Mechanismus", "Blutdruckwerte werden ausgeglichener").

## Destaques usados no UP 3 (modelo)
"und es ist vielleicht das Wichtigste von allen dreien" (com Boom), "Er findet nachts statt, während Sie sich eigentlich ausruhen sollten", "Haben Sie das schon einmal gespürt?", "Das ist nicht Ihre Schuld", "Und hier liegt das Problem, das Ihnen vielleicht noch niemand erklärt hat", "Können Sie mir folgen?", "Das macht Sinn, nicht wahr?", "Es gibt keine drei Optionen … Es gibt nur eine Sache", "Das Risiko ist null", "Und Sie sind nicht so weit gekommen, um halbe Sachen zu machen".

## Telas de oferta
- Preço: BG do produto novo + mockup PNG 6 potes (50 %, Y 0,60, ZOOM IN 20X) + neons "19 €" e "114 €" no instante falado + cash register + light leak/shutter + swoosh na entrada.
- Garantia: BG + `30days GER.png` (ZOOM IN/OUT 20X).
- CTA final ("Klicken Sie auf die Schaltfläche unten"): mesma tela de preço com neon do total.

## Marcadores
Um por bloco: Abertura, Problema, Explicação (melatonina/cortisol), Apresentação <produto>, Mecanismos, Depoimentos, Resultados, Oferta, Preço, Garantia, "Não é nova compra", Fechamento/CTA.
