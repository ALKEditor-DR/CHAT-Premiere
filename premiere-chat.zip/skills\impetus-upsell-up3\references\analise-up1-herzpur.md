# Padrão extraído do "UP 1" (HerzPur UP1A, Premiere) — base para o UP 3
Seq 1292x1604 (4:5), 24 fps, 11:40. Cobertura de inserts 73 %, B-roll mediana 2,6 s (1,3–4,5 s).

## Faixas
- V1 expert (310 cortes, mediana 2 s). Zooms: Transform Scale 110→100 ou 100→110 ao longo do clipe; punch-ins Motion 120–143 %. Quando há destaque sobre o expert: Lumetri Exposure -0,6 + Gaussian Blur 30.
- V2 B-roll principal (Motion fill ~148,5 % p/ 4K 16:9, 59,8 % p/ vertical 4K, 119,6 % p/ 1080 vertical, 74,26 % p/ 4K 4:5?). Sob destaques: Lumetri -0,6 + Blur 30. Algumas com Transform 100→115 e Edge Glow + Long Shadow.
- V3 "cartão arredondado": sequência aninhada com os inserts nítidos, Motion 76–80 %, Transform 100→110 em toda a duração, Roughen Edges (Border 40) = borda arredondada/orgânica; por baixo o mesmo insert em V2 desfocado (Blur 30, Exp -0,6) + "VERTICAL VIGNETT" (Vignette scale 130, feather 65) em V5/V6. Usado em blocos narrativos de 12–20 s (dores, história do Jürgen, ciência, indústria).
- V3/V5/V6 "Zoom suave" (adjustment): entrada 153→100 % em 0,75 s c/ shutter 180 (zoom-out de impacto) ou 100→107 lento.
- V4 destaques (Graphic, 79): palavra a palavra, Anton Regular branco caixa alta, centro, Wonder Glow branco (int 60, size 50), pop Scale 0→100 em ~0,16 s + 100→120 lento (shutter 360). Fundo = expert ou insert desfocado/escurecido. Frases de efeito ("Herzlichen Glückwunsch…", "Haben Sie jemals ein Antibiotikum genommen?", "Jetzt wissen Sie es.").
- V4 old-film-grain (blend screen, 222 %) + V3/V6 adjustment Noise 20 + Lumetri vinheta = trecho dramático/flashback (história do Jürgen).
- V2 mockups IA animados de produto (ANIMADOS/1,2,3,6 potes) a 334 % sempre que fala do produto/tratamento/oferta.
- Telas de preço: BG BLUE ASTRA (vel 70 %) + aninhadas "6 BOTTLE"/"3 BOTTLE" (85–89 %, pos Y ~0,22, zoom 100→110) + "Text Animation_Neon_04" amarelo (Text Scale 300) com o preço; mockups de 3/6 potes em escala p/ comparativos (ex.: "18 €" neon sobre mockup).
- V6–V9 Adjustment Layers curtas (0,17–0,62 s) nos cortes c/ transições Lens Blur + Flash (67 cada) = transição de corte entre inserts.
- V10 Light Leak gerado (24×, 0,33–0,8 s) nas viradas de bloco + Graphic com Tint 0→100 (mergulho/escurecer, ~0,5 s).
- V11 "VInheta" (adjustment Lumetri vignette -5, midpoint 55) o vídeo inteiro.
- LT: mogrt LT_Minimal_Left_05 (0–1,67 s) "Dr / Ulrich" branco + barra laranja, Motion 51 %, pos (0,42;0,60).
- Legenda: faixa de legenda Poppins SemiBold branca em caixa escura, 1–3 palavras (~0,5 s), embaixo (LEG1). LEG2 = tradução PT para revisão.

## Áudio
- A1 voz (crossfades Constant Power 266).
- A2 Boom na abertura (5,5 s, com o 1º destaque), Swoosh 08, Notification.
- A3 sound-effect-519 ×43 (pop dos destaques/cartões), Riser.wav ×24 (vel 9, ~0,7 s, nos zooms suaves), Swoosh 08 ×14, Camera Shutter Click ×10 (com light leak), Ding, Tearing Paper.
- A4 Woosh 02 ×24 (cortes c/ flash/lens blur).
- A5 cash register ×5 nos preços neon.
- A6 reverse cymbal antes da virada p/ oferta (313–323 s).
- Música por bloco (troca com sobreposição ~4–7 s): inspire-motivation-epic (0–322) → Inspiring & Uplifting Cinematic (319–463) → TRILHA (7) (456–523) → TRILHA (2) (519–638) → TRILHA (1) (631–fim).
