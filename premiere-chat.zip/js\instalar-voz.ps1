# Instala a voz natural (Chatterbox Multilingual, MIT) num ambiente Python separado:
#   ~/.premiere-chat/voz-natural/env     (Python + PyTorch com CUDA + chatterbox-tts)
#   ~/.premiere-chat/voz-natural/modelos (modelos baixados do Hugging Face)
# Não mexe no Python do sistema nem no runtime das skills.
param([string]$Python = "")
$ErrorActionPreference = "Stop"
$base = Join-Path $env:USERPROFILE ".premiere-chat\voz-natural"
$envDir = Join-Path $base "env"
New-Item -ItemType Directory -Force $base | Out-Null

if (-not $Python) {
    $cands = @()
    $cands += Get-ChildItem (Join-Path $env:LOCALAPPDATA "Programs\Python") -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^Python31[0-2]$' } | Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName "python.exe" }
    $Python = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $Python) { throw "Python 3.10-3.12 não encontrado. Instale com: winget install Python.Python.3.12" }
Write-Host "Python: $Python"

if (-not (Test-Path (Join-Path $envDir "Scripts\python.exe"))) {
    & $Python -m venv $envDir
}
$py = Join-Path $envDir "Scripts\python.exe"
$ErrorActionPreference = "Continue"
& $py -m pip install --upgrade pip --quiet
Write-Host "Instalando o PyTorch com CUDA (placa de vídeo)..."
& $py -m pip install "torch==2.6.0" "torchaudio==2.6.0" --index-url https://download.pytorch.org/whl/cu124
Write-Host "Instalando o Chatterbox..."
& $py -m pip install "chatterbox-tts==0.1.7"
$ErrorActionPreference = "Stop"
& $py -c "import torch, chatterbox; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())"
Write-Host "Voz natural instalada em $envDir" -ForegroundColor Green
