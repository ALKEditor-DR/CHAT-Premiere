#!/usr/bin/env python
"""Monta uma folha de prints para o usuário validar.

python prints.py pasta_com_jpgs saida.jpg [colunas=5]
"""
import glob
import os
import sys

from PIL import Image, ImageDraw, ImageFont

fs = sorted(glob.glob(os.path.join(sys.argv[1], "f_*.jpg")))
col = int(sys.argv[3]) if len(sys.argv) > 3 else 5
w, h = 324, 405
rows = (len(fs) + col - 1) // col
ft = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 22)
S = Image.new("RGB", (col * w + (col - 1) * 10, rows * (h + 36) + (rows - 1) * 10), (45, 45, 45))
d = ImageDraw.Draw(S)
for i, f in enumerate(fs):
    t = float(os.path.basename(f)[2:-4])
    x = (i % col) * (w + 10)
    y = (i // col) * (h + 46)
    d.text((x + 6, y + 6), f"{int(t // 60):02d}:{t % 60:04.1f}", fill="white", font=ft)
    S.paste(Image.open(f).resize((w, h), Image.LANCZOS), (x, y + 36))
S.save(sys.argv[2], quality=92)
