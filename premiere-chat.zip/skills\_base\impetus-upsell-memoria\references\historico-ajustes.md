# Histórico de ajustes e por quê

## 2026-11-08: criação (Cidrepeak FRA)
- O usuário pediu: upsell de emagrecimento, preset "Legendas Andre", formato 4:5, decupar e montar na ordem, músicas de `Musicas Storytelling`, SFX de `D:\EDIÇÃO\Musicas\SFX` "só de acordo com a referência… nada de SFX cartoon ou agressivo sem necessidade".
- Referência indicada: Jellyglow UP 1A V2 GER. Estilo medido nela (ver `estilo-aprovado.md`).
- Havia um projeto antigo do usuário com os mesmos brutos (Cidre Peak UP 1 A V1 FRA). O usuário pediu para **não usar**: a skill foi montada só com a referência. Em teste de skill, não abra projeto antigo do mesmo material sem perguntar.
- Brutos chegam sem decupar (vídeos de IA de duas apresentadoras + um depoimento). Ordem = número do arquivo. Pausas já eram curtas; a decupagem tirou ~7 s em 6 min.
- Whisper perdeu "accéléré" em "60 jours au rythme accéléré" (conferido no áudio): a palavra entra no roteiro com `+`. A voz de IA pronuncia o nome do produto de vários jeitos ("Sidrepeak", "CIDREPIC", "cidre épique"): a legenda sempre escreve o nome que o usuário passou (Cidrepeak).
- 1º print: usuário achou pequeno o cartão "Attendez / RELISEZ / calmement". Cartão misto passou a ter palavra grande até 270 px e linhas pequenas 92 px.

## 2026-11-08: v2, cores dos destaques
- No plano do v2, as palavras-chave ganharam cor: amarelo = atenção, vermelho = perigo/urgência, verde = benefício. Ficaram 6 destaques vermelhos (NE FERMEZ PAS, NE CLIQUEZ PAS, LE PROBLÈME, 60 JOURS, UNIQUEMENT, LE PLUS CHER).
- O usuário achou "muitos trechos com LT vermelha" e pediu amarelo. Regra: destaques só em branco, amarelo e verde. Urgência e perigo também vão em amarelo. Não use vermelho em destaque sem o usuário pedir. O preço "+15€" no neon (tela de preço) é outra coisa e continua vermelho.

## 2026-11-11: aprendizado com 4 upsells entregues (GlucoReset USA, MeltPeak GER, Jelly Glow GER, Cidre Peak FRA)
- O usuário pediu para a skill aprender o padrão de cada um ("redobre atenção na fala e no insert que aparece", "reforce os brolls: quando são orgânicos (UGC do TikTok/Instagram) e quando são de banco de imagens").
- Lido direto dos `.prproj` com `scripts/analisar_prproj.py` + `scripts/resumo_timeline.py` (cada insert com a frase dita e a origem do arquivo) e conferido nos vídeos finais.
- Resultado em `padroes-upsell-impetus.md`; listas frase → insert em `aprendizado/compacto_*.txt`; quadros de exemplo em `aprendizado/tipos_*.jpg`.
- Mudou: (1) UGC orgânico É usado (prova/resultado real, cartão sobre o fundo do produto) — antes a skill mandava evitar vídeos estilo TikTok; (2) cobertura de inserts de 64–74 % com B-roll de ~2,5 s; (3) light leak + Camera Shutter Click em todo insert; (4) LTs em Anton com glow, 1–3 palavras.

## 2026-11-14 — criação da skill UPsell Memória
- Pedido do usuário: "a ideia é bem parecida com o de emagrecimento, mas o tom do vídeo é mais dramático… alguns inserts em preto e branco, com a saturação em 50 %, o foco dos brolls é mais voltado para pessoas mais velhas, pelo menos 50 anos pra cima. Quando se tratar de materiais mais dramáticos: granulado, vinheta nas bordas, VHS, LTs maiores na tela." Exemplo: Memopower UP1A V1 GER.
- Medido no Memopower: 67 % de cobertura, inserts de 2,9 s, LTs Anton com fundo desfocado/escurecido e Boom, 8 sequências em cartão, mergulho no preto (Tint 0,5 s / 0,83 s), vinheta em todo o vídeo, Noise 20 % e vinheta com aberração cromática nos trechos fortes, música em arco (Infraction Skylight → violino triste → inspirador → worlds apart).
- No Memopower entregue os inserts ainda estão quase todos coloridos (saturação igual à original): P&B e 50 % são regra nova do usuário, não medida no vídeo. Confirmar a dose nos primeiros prints.
- render.py ganhou: `cor` (pb/50), `cartao`, `drama` (+ `vhs`), `fade_preto`, granulado e vinheta dramática; LT padrão 190 px.
- 2026-11-14, 1º print dos efeitos: usuário pediu "diminui um pouco mais do granulado e do VHS, o restante mantém". Granulado 0,06→0,04 (geral) e 0,10→0,065 (drama); VHS com separação de cor 5→3 px, linhas 10→5 %, tremor 3→2 px em 2 faixas, tracking mais fraco. P&B, 50 %, cartão, vinheta, LT 190 px e mergulho no preto aprovados como estavam.
