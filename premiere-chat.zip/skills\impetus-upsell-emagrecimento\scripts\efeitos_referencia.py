"""Mini teste de efeitos dos upsells Impetus (Cidrepeak FRA): legenda, LT, B-roll com light leak, cartões arredondados
sobre fundo branco, pitch com produto e preço em neon, SFX e música — tudo medido nos projetos entregues
(ver ~/.claude/skills/impetus-upsell-emagrecimento/references/padroes-upsell-impetus.md).

python teste_fx.py --frames 1.2,3.0 pasta/      (prints)
python teste_fx.py --full video.mp4            (render sem áudio)
python teste_fx.py --audio video.mp4 final.mp4 (mixagem)
"""
import json
import math
import os
import random
import subprocess
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H, FPS = 1080, 1350, 24
MAE = "G:/Clientes/IMPETUS/TESTES DE IA"
DEC = MAE + "/_projeto/decupado.mp4"
PAL = json.load(open(MAE + "/_projeto/palavras.json", encoding="utf-8"))
IG = "G:/Clientes/IMPETUS/Inserts gerais/"
PROD = MAE + "/Inserts/Produto/"
FONTES = "C:/Users/mlkal/AppData/Local/Microsoft/Windows/Fonts/"
SFXD = {
    "shutter": "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Cameras/Camera Shutter Click 12.wav",
    "swoosh08": "G:/EDIÇÃO/Para separar depois/SFX - Swoosh 08.mp3",
    "swoosh28": "G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/SFX/Swoosh/Swoosh Transition 28.wav",
    "acute": "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Risers/Acute Whoosh.mp3",
    "boom": "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Hits - impacts/Boom 1.mp3",
    "cash": "G:/EDIÇÃO/PACK de EDIÇÃO/SFX Viral/Diversos/Cash.wav",
    "zoombasic": "G:/Clientes/IMPETUS/Projetos finalizados e upados no drive/UPSELL  Cidre Peak  UP 1 A V1  FRA  Digistore/UP 1A_V4_MeltPeak_GER_Digistore_04m42s/[T]_Zoom - Basic.wav",
}
MUS_TIME = "G:/EDIÇÃO/Musicas/Musicas Storytelling/Novas/Cinematic Background Music by Infraction [No Copyright Music]  Time - 128.mp3"
MUS_GEMINI = "G:/EDIÇÃO/Musicas/Musicas Storytelling/Novas/Epic Powerful Motivational by Infraction [No Copyright Music]  Gemini - 128.mp3"


def fonte_arq(n):
    for d in (FONTES, "C:/Windows/Fonts/"):
        if os.path.exists(d + n):
            return d + n
    raise SystemExit(n)


F_ANTON = fonte_arq("Anton-Regular.ttf")
F_POP = fonte_arq("Poppins-SemiBold.ttf") if os.path.exists(FONTES + "Poppins-SemiBold.ttf") else fonte_arq("Poppins-SemiBold.otf")
F_MONT = fonte_arq("Montserrat-Black.ttf")

# ---------------- montagem: trechos do decupado (fonte) ----------------
TRECHOS = [(19.30, 26.70), (85.62, 97.42), (125.72, 131.32), (260.92, 278.12)]
OUT = []  # (ini_saida, fim_saida, ini_fonte)
t = 0.0
for a, b in TRECHOS:
    OUT.append((t, t + b - a, a))
    t += b - a
DUR = t


def s2o(ts):
    """tempo no decupado -> tempo no teste"""
    for o0, o1, a in OUT:
        if a - 0.01 <= ts <= a + (o1 - o0) + 0.01:
            return o0 + ts - a
    for o0, o1, a in OUT:  # palavra logo depois do fim do trecho: fica no fim do trecho
        if a + (o1 - o0) < ts <= a + (o1 - o0) + 0.5:
            return o1
    return None


def o2s(to):
    for o0, o1, a in OUT:
        if o0 <= to < o1 + 1e-6:
            return a + to - o0
    return OUT[-1][2] + (OUT[-1][1] - OUT[-1][0])


def w0(palavra, depois):
    for p in PAL:
        if p[0] >= depois - 0.01 and p[2].lower().strip(",.") .startswith(palavra.lower()):
            return s2o(p[0])
    raise SystemExit("palavra " + palavra)


# ---------------- leitura de vídeo ----------------
class Leitor:
    def __init__(self, path, inicio=0.0, modo="cobrir", larg=W, alt=H):
        self.path, self.inicio, self.modo, self.lw, self.lh = path, inicio, modo, larg, alt
        self.p = None
        self.n = -1
        self.ult = None

    def frame(self, k):
        if self.p is None or k < self.n:
            if self.p:
                self.p.kill()
            vf = (f"fps={FPS},scale={self.lw}:{self.lh}:force_original_aspect_ratio=increase,crop={self.lw}:{self.lh}" if self.modo == "cobrir"
                  else f"fps={FPS},scale={self.lw}:{self.lh}")
            self.p = subprocess.Popen(["ffmpeg", "-v", "error", "-stream_loop", "-1", "-ss", f"{self.inicio:.3f}", "-i", self.path, "-vf", vf,
                                       "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE, stdin=subprocess.DEVNULL, bufsize=10 ** 8)
            self.n = -1
        while self.n < k:
            buf = self.p.stdout.read(self.lw * self.lh * 3)
            if len(buf) < self.lw * self.lh * 3:
                break
            self.ult = np.frombuffer(buf, np.uint8).reshape(self.lh, self.lw, 3)
            self.n += 1
        return self.ult.astype(np.float32)


DECUP = Leitor(DEC)


def frame_expert(to):
    ts = o2s(to)
    return DECUP_frame(ts)


_dec_cache = {}


def DECUP_frame(ts):
    k = int(round(ts * FPS))
    if k in _dec_cache:
        return _dec_cache[k].copy()
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{k / FPS:.4f}", "-i", DEC, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                       stdout=subprocess.PIPE, stdin=subprocess.DEVNULL)
    fr = np.frombuffer(r.stdout, np.uint8).reshape(H, W, 3).astype(np.float32)
    _dec_cache.clear()
    _dec_cache[k] = fr
    return fr.copy()


# ---------------- utilidades ----------------
def ease_out(p, k=3):
    p = min(1, max(0, p))
    return 1 - (1 - p) ** k


def ease_io(p):
    p = min(1, max(0, p))
    return 0.5 - 0.5 * math.cos(math.pi * p)


def escala_centro(fr, s, cx=0.5, cy=0.5):
    if abs(s - 1) < 1e-3:
        return fr
    M = np.float32([[s, 0, (1 - s) * W * cx], [0, s, (1 - s) * H * cy]])
    return cv2.warpAffine(fr, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def colar(fr, spr, cx, cy, alfa=1.0, escala=1.0, rot=0.0, blur_v=0.0):
    """spr: RGBA float (pré-multiplicado não), centro em cx, cy."""
    if escala <= 0.01 or alfa <= 0.003:
        return fr
    h, w = spr.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), rot, escala)
    M[0, 2] += cx - w / 2
    M[1, 2] += cy - h / 2
    out = cv2.warpAffine(spr, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    if blur_v > 0.5:
        k = int(blur_v) * 2 + 1
        out = cv2.blur(out, (1, k))
    a = out[..., 3:4] / 255.0 * alfa
    fr[:] = fr * (1 - a) + out[..., :3] * a
    return fr


# ---------------- LT (texto grande): Anton, pop 0->100 % em ~0,13 s com motion blur, depois cresce 100->120 % ----------------
CACHE = {}


def sprite_lt(txt, cor):
    k = ("LT", txt, cor)
    if k in CACHE:
        return CACHE[k]
    f = ImageFont.truetype(F_ANTON, 128)
    tw = int(f.getlength(txt))
    pad = 90
    w, h = tw + 2 * pad, 128 + 2 * pad
    txtm = Image.new("L", (w, h), 0)
    ImageDraw.Draw(txtm).text((w / 2, h / 2), txt, font=f, fill=255, anchor="mm")
    m = np.asarray(txtm, np.float32) / 255
    if cor == "ouro":
        # dourado da referência: claro em cima (#F8E6AE) para mais quente embaixo (#D8AC5A), halo escuro (Wonder Glow ambiente)
        ys = np.linspace(0, 1, h)[:, None]
        top, bot = np.array([248, 230, 174]), np.array([216, 172, 90])
        rgb = (top * (1 - ys[..., None]) + bot * ys[..., None]) * np.ones((h, w, 1))
        halo = cv2.GaussianBlur(m, (0, 0), 22) * 0.85
        halo_c = np.array([60, 32, 8], np.float32)
        glow = cv2.GaussianBlur(m, (0, 0), 6) * 0.55
        out = np.zeros((h, w, 4), np.float32)
        a_halo = np.clip(halo, 0, 1)
        out[..., :3] = halo_c * a_halo[..., None]
        out[..., 3] = a_halo
        # glow dourado
        gcol = np.array([255, 200, 110], np.float32)
        ag = np.clip(glow, 0, 1)
        out[..., :3] = out[..., :3] * (1 - ag[..., None]) + gcol * ag[..., None]
        out[..., 3] = np.maximum(out[..., 3], ag)
        out[..., :3] = out[..., :3] * (1 - m[..., None]) + rgb * m[..., None]
        out[..., 3] = np.maximum(out[..., 3], m)
    else:
        # branco com brilho branco e sombra escura curta
        sh = cv2.GaussianBlur(m, (0, 0), 10) * 0.55
        glow = cv2.GaussianBlur(m, (0, 0), 7) * 0.7
        out = np.zeros((h, w, 4), np.float32)
        out[..., 3] = sh
        ag = np.clip(glow, 0, 1)
        out[..., :3] = out[..., :3] * (1 - ag[..., None]) + 255 * ag[..., None]
        out[..., 3] = np.maximum(out[..., 3], ag)
        out[..., :3] = out[..., :3] * (1 - m[..., None]) + 255 * m[..., None]
        out[..., 3] = np.maximum(out[..., 3], m)
    out[..., 3] *= 255
    CACHE[k] = out
    return out


# ---------------- legenda: Poppins SemiBold branca em caixa escura translúcida, entra com pop curto ----------------
def sprite_leg(txt):
    k = ("LEG", txt)
    if k in CACHE:
        return CACHE[k]
    f = ImageFont.truetype(F_POP, 54)
    tw = int(f.getlength(txt))
    w, h = tw + 44, 86
    im = Image.new("RGBA", (w + 30, h + 30), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([15, 15, 15 + w, 15 + h], 10, fill=(22, 34, 34, 190))
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((15 + w / 2 + 2, 15 + h / 2 + 3), txt, font=f, fill=(0, 0, 0, 170), anchor="mm")
    im = Image.alpha_composite(im, sh.filter(ImageFilter.GaussianBlur(3)))
    ImageDraw.Draw(im).text((15 + w / 2, 15 + h / 2), txt, font=f, fill=(255, 255, 255, 255), anchor="mm")
    out = np.asarray(im, np.float32)
    CACHE[k] = out
    return out


# ---------------- light leak (Generated Light Leak 9) + clarão no corte, medido quadro a quadro na referência ----------------
def light_leak(fr, dt):
    """dt = tempo relativo ao corte (s). -0,33..0: tinta rosa/laranja subindo; 0: 1 quadro branco; 0..0,5: laranja quente saindo pela esquerda."""
    if dt < -0.34 or dt > 0.55:
        return fr
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    if abs(dt) < 0.5 / FPS:
        fr[:] = fr * 0.12 + np.array([246, 244, 242], np.float32) * 0.88
        return fr
    if dt < 0:
        k = ease_io((dt + 0.34) / 0.34)
        grad = np.clip(1 - (xx / W) * 0.3 - (yy / H) * 0.2, 0, 1)[..., None]
        col = np.array([255, 150, 175], np.float32) * (1 - k) + np.array([255, 175, 120], np.float32) * k
        a = (0.15 + 0.55 * k) * grad
    else:
        k = 1 - ease_out(dt / 0.55, 2)
        grad = np.clip(1.15 - (xx / W) * 0.9 - (yy / H) * 0.6, 0, 1)[..., None]
        col = np.array([255, 170, 95], np.float32)
        a = 0.75 * k * grad
    # modo "screen"
    fr[:] = 255 - (255 - fr) * (1 - a * col / 255)
    return fr


# ---------------- transição Tile (zoom com espelho) ----------------
def tile_zoom(fr, p, saindo):
    """p 0..1 na metade da transição; saindo: afasta (1 -> 0,55), entrando: aproxima (1,6 -> 1)."""
    s = 1 - 0.45 * ease_io(p) if saindo else 1.6 - 0.6 * ease_out(p, 3)
    big = cv2.copyMakeBorder(fr, H, H, W, W, cv2.BORDER_REFLECT)
    M = np.float32([[s, 0, (1 - s) * (W * 1.5) - W], [0, s, (1 - s) * (H * 1.5) - H]])
    out = cv2.warpAffine(big, M, (W, H), flags=cv2.INTER_LINEAR)
    k = int(14 * (1 - abs(0.5 - p) * 2)) * 2 + 1
    return cv2.blur(out, (k, k)) if k > 2 else out


# ---------------- cartão arredondado (UGC) com sombra, leve rotação e camera shake ----------------
def cartao(fr_src, larg, raio=44):
    h, w = fr_src.shape[:2]
    alt = int(larg * h / w)
    img = cv2.resize(fr_src, (larg, alt), interpolation=cv2.INTER_AREA)
    mask = np.zeros((alt, larg), np.uint8)
    cv2.rectangle(mask, (raio, 0), (larg - raio, alt), 255, -1)
    cv2.rectangle(mask, (0, raio), (larg, alt - raio), 255, -1)
    for cx, cy in ((raio, raio), (larg - raio, raio), (raio, alt - raio), (larg - raio, alt - raio)):
        cv2.circle(mask, (cx, cy), raio, 255, -1, cv2.LINE_AA)
    pad = 120
    out = np.zeros((alt + 2 * pad, larg + 2 * pad, 4), np.float32)
    # sombra (Drop Shadow: direção 135°, distância 34, suavidade alta, opaca)
    sm = np.zeros(out.shape[:2], np.float32)
    sm[pad + 24:pad + 24 + alt, pad + 24:pad + 24 + larg] = mask / 255
    sm = cv2.GaussianBlur(sm, (0, 0), 30) * 0.75
    out[..., 3] = sm * 255
    m = mask.astype(np.float32)[..., None] / 255
    reg = out[pad:pad + alt, pad:pad + larg]
    reg[..., :3] = reg[..., :3] * (1 - m) + img * m
    reg[..., 3] = np.maximum(reg[..., 3], m[..., 0] * 255)
    return out


FUNDO_BRANCO = cv2.cvtColor(cv2.imread("G:/para o SSD/Fundos SINGULAR/fundo_singular_05.png"), cv2.COLOR_BGR2RGB)
FUNDO_BRANCO = cv2.resize(FUNDO_BRANCO[:, (1920 - 1536) // 2:(1920 - 1536) // 2 + 1536][:, :] if False else FUNDO_BRANCO, (W * 2, H))
FUNDO_BRANCO = FUNDO_BRANCO[:, W // 2:W // 2 + W].astype(np.float32)


def shake(t, sem=0):
    r = random.Random(sem)
    fx = [r.uniform(0.6, 1.4) for _ in range(4)]
    fs = [r.uniform(0, 6.28) for _ in range(4)]
    dx = 9 * math.sin(t * fx[0] * 2.1 + fs[0]) + 4 * math.sin(t * fx[1] * 5.3 + fs[1])
    dy = 7 * math.sin(t * fx[2] * 1.7 + fs[2]) + 3 * math.sin(t * fx[3] * 4.1 + fs[3])
    rot = 0.9 * math.sin(t * 1.3 + fs[0])
    return dx, dy, rot


# ---------------- tela de preço: fundo da marca, frascos desfocados, 12 frascos, neon ----------------
BG_PRECO = "G:/Clientes/IMPETUS/ARQUIVOS NECESSARIOS/Background/BACKGROUND - PRODUTOS/BG BLUE.mp4"


def png_rgba(path):
    im = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    im = cv2.cvtColor(im, cv2.COLOR_BGRA2RGBA if im.shape[2] == 4 else cv2.COLOR_BGR2RGBA)
    return im.astype(np.float32)


MOCK12 = png_rgba(PROD + "Mockup_CidrePeak FRA 12.png")
MOCK1 = png_rgba(PROD + "Mockup_CidrePeak FRA 01.png")


def recorte_alfa(rgba):
    ys, xs = np.nonzero(rgba[..., 3] > 8)
    return rgba[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


MOCK12 = recorte_alfa(MOCK12)
MOCK1 = recorte_alfa(MOCK1)


def neon_sprite(txt, n_vis):
    """Montserrat Black só contorno verde neon + brilho. n_vis: quantas letras acesas (ordem do Text Animation_Neon_04)."""
    k = ("NE", txt, n_vis)
    if k in CACHE:
        return CACHE[k]
    f = ImageFont.truetype(F_MONT, 230)
    tw = int(f.getlength(txt))
    pad = 70
    w, h = tw + 2 * pad, 300
    lin = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(lin)
    x = pad
    for i, ch in enumerate(txt):
        if i in n_vis:
            d.text((x, h / 2), ch, font=f, fill=0, anchor="lm", stroke_width=7, stroke_fill=255)
        x += f.getlength(ch)
    m = np.asarray(lin, np.float32) / 255
    cor = np.array([60, 255, 40], np.float32)
    g1 = cv2.GaussianBlur(m, (0, 0), 6) * 1.6
    g2 = cv2.GaussianBlur(m, (0, 0), 22) * 1.2
    a = np.clip(m + g1 * 0.7 + g2 * 0.55, 0, 1)
    out = np.zeros((h, w, 4), np.float32)
    core = np.clip(m * 1.0, 0, 1)[..., None]
    out[..., :3] = cor * (1 - core * 0.35) + np.array([200, 255, 190], np.float32) * core * 0.35
    out[..., 3] = a * 255
    CACHE[k] = out
    return out


def neon_letras(txt, dt):
    """Acende como na referência: o símbolo primeiro e os números depois, piscando, ~0,45 s."""
    ordem = [i for i, c in enumerate(txt) if c in "€$"] + [i for i, c in enumerate(txt) if c not in "€$ "]
    vis = set()
    for j, i in enumerate(ordem):
        t0 = j * 0.09
        if dt >= t0:
            pis = dt - t0
            if pis < 0.24 and int(pis * FPS) % 3 == 1:
                continue
            vis.add(i)
    return tuple(sorted(vis))


def setas(fr, t):
    """Arrow Loop (Mister Horse): duas setas laranja apontando para baixo nas laterais, indo e voltando."""
    for cx in (0.195 * W, 0.808 * W):
        off = 40 * (0.5 - 0.5 * math.cos(t * 2 * math.pi * 1.25))
        cy = 0.70 * H + off
        pts = np.array([[cx - 22, cy - 150], [cx + 22, cy - 150], [cx + 22, cy - 10], [cx + 62, cy - 10], [cx, cy + 70], [cx - 62, cy - 10],
                        [cx - 22, cy - 10]], np.int32)
        lay = fr.copy()
        cv2.fillPoly(lay, [pts], (247, 147, 30), cv2.LINE_AA)
        fr[:] = lay
    return fr


_bg_cache = {}


def fundo_preco(k):
    base = LEIT_BG.frame(k).copy()
    if "deco" not in _bg_cache:
        deco = np.zeros((H, W, 3), np.float32)
        a = np.zeros((H, W, 1), np.float32)
        tmp = np.zeros((H, W, 3), np.float32)
        for (cx, cy, esc, rot) in ((0.10 * W, 0.30 * H, 1.25, -13), (1.02 * W, 0.86 * H, 0.95, 16)):
            spr = MOCK1
            s = esc * 420 / spr.shape[1]
            M = cv2.getRotationMatrix2D((spr.shape[1] / 2, spr.shape[0] / 2), rot, s)
            M[0, 2] += cx - spr.shape[1] / 2
            M[1, 2] += cy - spr.shape[0] / 2
            o = cv2.warpAffine(spr, M, (W, H), borderValue=(0, 0, 0, 0))
            aa = o[..., 3:4] / 255
            tmp = tmp * (1 - aa) + o[..., :3] * aa
            a = np.maximum(a, aa)
        _bg_cache["deco"] = (tmp, a)
    tmp, a = _bg_cache["deco"]
    fr = base * (1 - a) + tmp * a
    fr = cv2.GaussianBlur(fr, (0, 0), 16)
    return fr


# vinheta (camada VIGNETTE) e ruído leve
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
VIN = (1 - 0.55 * np.clip(((xx - W / 2) / (W * 0.62)) ** 2 + ((yy - H / 2) / (H * 0.62)) ** 2, 0, 1) ** 1.3)[..., None]

# ---------------- roteiro visual ----------------
A0, A1 = OUT[0][0], OUT[0][1]
B0, B1 = OUT[1][0], OUT[1][1]
C0, C1 = OUT[2][0], OUT[2][1]
D0, D1 = OUT[3][0], OUT[3][1]
t_lab = w0("pendant", 24.0)
t_d_prod = w0("réserver", 262.5)
t_d_preco = w0("12", 265.0)
t_19 = w0("19", 272.5)
t_63 = w0("63", 275.9)

# B-roll / cenas (ini, fim, tipo, dados)
CENAS = [
    (t_lab, A1, "broll", {"arq": IG + "Entregas/scientists-packaging-bottles-in-a-bright-lab-2025-12-17-06-33-30-utc.mov", "in": 1.0}),
    (B0, B1, "cartoes", {}),
    (C0, C0 + 2.65, "broll", {"arq": PROD + "Animados/1 POTE/05.mp4", "in": 0.0}),
    (C0 + 2.65, C1, "broll", {"arq": PROD + "Animados/3 POTES/02.mp4", "in": 0.0}),
    (t_d_prod, t_d_preco, "broll", {"arq": PROD + "Animados/6 POTES/" + sorted(os.listdir(PROD + "Animados/6 POTES"))[0], "in": 0.0}),
    (t_d_preco, D1, "preco", {}),
]
CARTOES = [  # (ini, fim, arquivo, entrada, rotação)
    (B0, w0("vous", 88.2), IG + "mulheres/ssstik.io_@pam_frison_1766066542862.mp4", 0.5, -4),
    (w0("vous", 88.2), w0("Et", 91.5), IG + "mulheres/fotos antes e depois/ssstik.io_1772194099613.mp4", 0.3, 3.5),
    (w0("Et", 91.5), w0("avec", 94.1), IG + "mulheres/ssstik.io_@sideyou0_1769106379104.mp4", 0.3, -3),
    (w0("avec", 94.1), B1, IG + "mulheres/ssstik.io_@corpos_saudaveis_1766066059857.mp4", 0.3, 4),
]
# LTs: (ini, fim, texto, cor)
LTS = [
    (w0("s'il", 19.3), w0("ne", 20.3), "S'IL VOUS PLAÎT,", "branco"),
    (w0("ne", 20.3), w0("cette", 20.9), "NE FERMEZ PAS", "branco"),
    (w0("cette", 20.9), w0("et", 21.3), "CETTE PAGE", "branco"),
    (w0("24", 86.3), w0("vous", 88.2), "24 À 72 HEURES", "ouro"),
    (w0("20", 96.3), w0("la", 97.4), "20 À 40 KG", "ouro"),
    (w0("trois", 126.2), w0("par", 127.3), "TROIS GÉLULES", "ouro"),
    (w0("l'opportunité", 261.3), w0("de", 262.5), "L'OPPORTUNITÉ UNIQUE", "ouro"),
]
# zoom no expert (camadas "Zoom suave"): punch 126,8 -> 100 % em 0,75 s no início dos trechos de expert e 100 -> 119 % em 1 s
ZOOMS = [(A0, "punch"), (w0("et", 21.3), "in"), (C0, "punch"), (D0, "punch")]
# cortes com light leak + shutter
CORTES = [t_lab, B0] + [c[0] for c in CARTOES[1:]] + [C0, C0 + 2.65, t_d_prod]
TILES = [(D0, "tile"), (t_d_preco, "tile")]


def zoom_expert(t):
    s, cy = 1.0, 0.5
    for t0, tipo in ZOOMS:
        dt = t - t0
        if 0 <= dt < 3.5:
            if tipo == "punch":
                s = 1.268 - 0.268 * ease_out(dt / 0.75, 3) if dt < 0.75 else 1.0
                s *= 1 + 0.071 * (dt / 6.9)
            else:
                s = 1 + 0.194 * ease_io(min(1, dt / 1.0))
                cy = 0.5 + 0.011 * ease_io(min(1, dt / 1.0))
    return s, cy


LEIT = {}
LEIT_BG = Leitor(BG_PRECO, 0.0)


def leitor(arq, ini, modo="cobrir", lw=W, lh=H):
    k = (arq, ini, modo)
    if k not in LEIT:
        LEIT[k] = Leitor(arq, ini, modo, lw, lh)
    return LEIT[k]


def cena_em(t):
    for c in CENAS:
        if c[0] <= t < c[1]:
            return c
    return None


def lt_em(t):
    for l in LTS:
        if l[0] <= t < l[1]:
            return l
    return None


# legendas (1 a 3 palavras, quebra em pontuação), só quando não há LT
LEGS = []
for o0, o1, a in OUT:
    ws = [p for p in PAL if a - 0.01 <= p[0] < a + (o1 - o0) - 0.05]
    grupo = []
    for p in ws:
        grupo.append(p)
        txt = " ".join(x[2] for x in grupo)
        if len(grupo) >= 3 or len(txt) >= 15 or p[2][-1] in ",.?!":
            LEGS.append([s2o(grupo[0][0]), s2o(min(p[1], a + (o1 - o0))), txt])
            grupo = []
    if grupo:
        LEGS.append([s2o(grupo[0][0]), s2o(min(grupo[-1][1], a + (o1 - o0))), " ".join(x[2] for x in grupo)])
for i in range(len(LEGS) - 1):
    if LEGS[i + 1][0] - LEGS[i][1] < 0.6:
        LEGS[i][1] = LEGS[i + 1][0]
LEGS = [[a, b, t.replace("Sidrepeak", "Cidrepeak").replace("cidre épique", "Cidrepeak")] for a, b, t in LEGS]


def render(k):
    t = k / FPS
    c = cena_em(t)
    lt = lt_em(t)
    if c is None:
        fr = frame_expert(t)
        s, cy = zoom_expert(t)
        fr = escala_centro(fr, s, 0.5, cy)
    elif c[2] == "broll":
        L = leitor(c[3]["arq"], c[3]["in"])
        fr = L.frame(int(round((t - c[0]) * FPS))).copy()
        fr = escala_centro(fr, 1 + 0.06 * (t - c[0]) / max(0.5, c[1] - c[0]))
    elif c[2] == "cartoes":
        fr = FUNDO_BRANCO.copy()
        for (a, b, arq, cin, rot) in CARTOES:
            if a <= t < b:
                L = leitor(arq, cin, "ajustar", 720, 1280)
                src = L.frame(int(round((t - a) * FPS)))
                spr = cartao(src, 760)
                dt = t - a
                e = ease_out(dt / 0.28, 3)
                dx, dy, r2 = shake(t, int(a * 10))
                colar(fr, spr, W / 2 + dx, H / 2 + 10 + dy + (1 - e) * 60, alfa=min(1, dt / 0.12), escala=(0.86 + 0.14 * e) * 0.98, rot=rot + r2)
        fr *= VIN * 0.35 + 0.65
    elif c[2] == "preco":
        fr = fundo_preco(k)
        dt = t - c[0]
        e = ease_out(dt / 0.35, 3)
        s = 900 / MOCK12.shape[1] * (0.9 + 0.1 * e)
        bob = 6 * math.sin(t * 1.6)
        colar(fr, MOCK12, W / 2, H * 0.58 + bob, alfa=min(1, dt / 0.15), escala=s)
        for t0, txt, ate in ((t_19, "19 €", t_63 - 0.05), (t_63, "0,63 €", D1 + 1)):
            if t0 <= t < ate:
                spr = neon_sprite(txt, neon_letras(txt, t - t0))
                colar(fr, spr, W / 2, 0.21 * H, escala=1.0)
        if t_d_preco + 1.3 <= t < t_19 - 0.1:
            setas(fr, t)
        fr *= VIN
        rng = np.random.default_rng(k)
        fr += rng.normal(0, 5, fr.shape[:2])[..., None]
    # LT: fundo desfocado e escurecido, texto com pop
    if lt is not None:
        if c is None:  # LT sobre o expert: fundo desfocado e escurecido; sobre B-roll/cartão o fundo fica nítido (como na referência)
            fr = cv2.GaussianBlur(fr, (0, 0), 9)
            fr = fr * 0.62
        dt = t - lt[0]
        if dt < 0.13:
            e = ease_out(dt / 0.13, 2)
            esc, mb = max(0.04, e), 26 * (1 - e)
        else:
            esc, mb = 1 + 0.2 * min(1, (dt - 0.13) / max(0.2, lt[1] - lt[0] - 0.13)), 0
        spr = sprite_lt(lt[2], lt[3])
        sl = min(1.0, 940 / spr.shape[1] * 1.15)
        colar(fr, spr, W / 2, H * 0.49, escala=esc * sl, blur_v=mb)
    else:
        for a, b, txt in LEGS:
            if a <= t < b:
                p = min(1, (t - a) / 0.08)
                colar(fr, sprite_leg(txt), W / 2, 1190, escala=0.92 + 0.08 * p)
                break
    # transições
    for tc in CORTES:
        if -0.34 <= t - tc <= 0.55:
            light_leak(fr, t - tc)
    for tc, _ in TILES:
        dt = t - tc
        if -0.19 <= dt < 0:
            fr = tile_zoom(fr, (dt + 0.19) / 0.19, True)
        elif 0 <= dt < 0.19:
            fr = tile_zoom(fr, dt / 0.19, False)
    return np.clip(fr, 0, 255).astype(np.uint8)


SFX = []  # (t, chave, ganho_db)
for tc in CORTES:
    SFX.append((tc - 0.04, "shutter", 0))
for t0, tipo in ZOOMS:
    SFX.append((t0, "swoosh08", -2))
for l in LTS:
    SFX.append((l[0] - 0.08, "acute", -3))
SFX.append((LTS[1][0] - 0.02, "boom", -4))
SFX.append((LTS[4][0] - 0.02, "boom", -4))
for c in CARTOES:
    SFX.append((c[0] - 0.1, "swoosh28", -4))
for tc, _ in TILES:
    SFX.append((tc - 0.2, "zoombasic", -2))
SFX += [(t_19, "cash", 0), (t_63, "cash", 0)]

if __name__ == "__main__":
    if sys.argv[1] == "--info":
        print(f"duração {DUR:.1f}s", OUT)
        print("LTs", [(round(a, 2), round(b, 2), x) for a, b, x, _ in LTS])
    elif sys.argv[1] == "--frames":
        os.makedirs(sys.argv[3], exist_ok=True)
        for x in sys.argv[2].split(","):
            tt = float(x)
            cv2.imwrite(os.path.join(sys.argv[3], f"f_{tt:07.2f}.jpg"), cv2.cvtColor(render(int(round(tt * FPS))), cv2.COLOR_RGB2BGR))
            print("print", tt)
    elif sys.argv[1] == "--full":
        p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                              "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p", sys.argv[2]], stdin=subprocess.PIPE)
        n = int(DUR * FPS)
        for k in range(n):
            p.stdin.write(render(k).tobytes())
            if k % 120 == 0:
                print(f"{k / FPS:.0f}s / {DUR:.0f}s", flush=True)
        p.stdin.close()
        p.wait()
        print("OK", sys.argv[2])
    elif sys.argv[1] == "--audio":
        VID, SAI = sys.argv[2], sys.argv[3]
        ent, fil, mix = ["-i", VID], [], []
        n = 1
        # voz: os 4 trechos do decupado, com microfade
        for i, (o0, o1, a) in enumerate(OUT):
            ent += ["-ss", f"{a:.3f}", "-t", f"{o1 - o0:.3f}", "-i", DEC]
            fil.append(f"[{n}:a]aresample=48000,afade=t=in:d=0.02,afade=t=out:st={o1 - o0 - 0.03:.3f}:d=0.03,adelay={int(o0 * 1000)}|{int(o0 * 1000)}[v{i}]")
            mix.append(f"[v{i}]")
            n += 1
        # música: Infraction "Time" até o pitch, "Gemini" na oferta (como Cidre/Melt)
        for arq, ini, fim, vol in ((MUS_TIME, 0, D0 + 1.0, -21), (MUS_GEMINI, D0 - 0.5, DUR, -23)):
            ent += ["-t", f"{fim - ini:.3f}", "-i", arq]
            fil.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,volume={vol}dB,afade=t=in:d=1.0,afade=t=out:st={max(0, fim - ini - 1.5):.3f}:d=1.5,"
                       f"adelay={int(ini * 1000)}|{int(ini * 1000)}[m{n}]")
            mix.append(f"[m{n}]")
            n += 1
        for i, (tt, kk, g) in enumerate(SFX):
            ent += ["-i", SFXD[kk]]
            fil.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,volume={g}dB,adelay={int(max(0, tt) * 1000)}|{int(max(0, tt) * 1000)}[s{i}]")
            mix.append(f"[s{i}]")
            n += 1
        fil.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0:duration=longest,atrim=0:{DUR:.3f},loudnorm=I=-17:TP=-1.5:LRA=11[a]")
        subprocess.run(["ffmpeg", "-v", "error", "-y"] + ent + ["-filter_complex", ";".join(fil), "-map", "0:v", "-map", "[a]", "-c:v", "copy",
                                                               "-c:a", "aac", "-b:a", "256k", "-shortest", SAI], check=True)
        print("OK", SAI)
