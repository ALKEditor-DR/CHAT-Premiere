#!/usr/bin/env python
"""Etapa 4: mistura voz (do decupado), trilhas e efeitos e junta com o vídeo renderizado.

python mix.py projeto.json video_sem_audio.mp4 "SAIDA.mp4"

projeto.json -> "audio":
  "alvo_lufs": -17                 volume final (a referência aprovada mede -17,1)
  "trilhas": [{"arquivo", "inicio", "fim", "arquivo_in": 0, "lu": -18, "fade_in": 1.0, "fade_out": 1.5}]
             "lu" = quantos LU abaixo da voz a trilha fica (medido por loudness, não por pico)
  "sfx": [{"arquivo", "t", "ganho_db": -10, "arquivo_in": 0}]   "t" = instante em que o som começa
Arquivos relativos são procurados em <pasta mãe>/SFX e <pasta mãe>/Musicas.
"""
import json
import os
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
CFG_PATH, VIDEO, SAIDA = sys.argv[1], sys.argv[2], sys.argv[3]
CFG = json.load(open(CFG_PATH, encoding="utf-8"))
BASE = os.path.dirname(os.path.abspath(CFG_PATH))
MAE = CFG.get("mae", os.path.dirname(BASE))
A = CFG.get("audio", {})
ALVO = A.get("alvo_lufs", -17.0)


def achar(p, pasta):
    if os.path.isabs(p):
        return p
    for b in (os.path.join(MAE, pasta), MAE, BASE):
        if os.path.exists(os.path.join(b, p)):
            return os.path.join(b, p)
    raise SystemExit("não achei: " + p)


def lufs(args):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats"] + args + ["-af", "ebur128", "-f", "null", "-"], stderr=subprocess.PIPE, text=True,
                       encoding="utf-8", errors="replace")
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    return float(m[-1])


VOZ = os.path.join(BASE, CFG.get("decupado", "decupado.mp4"))
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", VIDEO], stdout=subprocess.PIPE,
                           text=True).stdout)
l_voz = lufs(["-i", VOZ, "-vn"])
g_voz = ALVO - l_voz
print(f"voz: {l_voz:.1f} LUFS -> ganho {g_voz:+.1f} dB")

# trilha sobe alguns dB onde só tem insert/tela de preço na tela (sem apresentadora), com rampa de 0,4 s
SOBE = A.get("trilha_sobe_insert_db", 0)
expr_sobe = ""
if SOBE:
    ints = sorted([(d["inicio"], d["fim"]) for d in CFG.get("inserts", [])] + [(d["inicio"], d["fim"]) for d in CFG.get("tela_preco", [])])
    junt = []
    for a, b in ints:
        if junt and a - junt[-1][1] < 0.6:
            junt[-1][1] = max(junt[-1][1], b)
        else:
            junt.append([a, b])
    termos = "+".join(f"clip((t-{a:.2f})/0.4,0,1)*clip(({b:.2f}-t)/0.4,0,1)" for a, b in junt if b - a > 1.0)
    expr_sobe = f",volume='pow(10,{SOBE}*min(1,{termos})/20)':eval=frame"

entradas = ["-i", VIDEO, "-i", VOZ]
filtros = [f"[1:a]aresample=48000,highpass=f=70,volume={g_voz:.2f}dB,acompressor=threshold=-22dB:ratio=2.5:attack=8:release=150:makeup=1[voz]"]
mix = ["[voz]"]
k = 2
for i, tr in enumerate(A.get("trilhas", [])):
    f = achar(tr["arquivo"], "Musicas")
    ai = tr.get("arquivo_in", 0)
    d = tr["fim"] - tr["inicio"]
    l_tr = lufs(["-ss", str(ai), "-t", str(min(d, 60)), "-i", f])
    g = ALVO + tr.get("lu", -18) - l_tr
    fi, fo = tr.get("fade_in", 1.0), tr.get("fade_out", 1.5)
    entradas += ["-ss", f"{ai:.3f}", "-t", f"{d:.3f}", "-i", f]
    filtros.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=stereo,volume={g:.2f}dB,afade=t=in:d={fi},afade=t=out:st={max(0, d - fo):.3f}:d={fo},"
                   f"adelay={int(tr['inicio'] * 1000)}|{int(tr['inicio'] * 1000)}{expr_sobe}[t{i}]")
    mix.append(f"[t{i}]")
    print(f"trilha {os.path.basename(f)}: {l_tr:.1f} LUFS, {g:+.1f} dB, {tr['inicio']:.1f}-{tr['fim']:.1f}s")
    k += 1
for i, s in enumerate(A.get("sfx", [])):
    f = achar(s["arquivo"], "SFX")
    entradas += ["-ss", f"{s.get('arquivo_in', 0):.3f}", "-i", f]
    t = max(0, s["t"])
    corte = ""
    if s.get("dur"):  # corta a cauda longa do arquivo com fade de 0,3 s
        corte = f"atrim=0:{s['dur']},afade=t=out:st={max(0, s['dur'] - 0.3):.3f}:d=0.3,"
    filtros.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=stereo,{corte}volume={s.get('ganho_db', -10)}dB,"
                   f"adelay={int(t * 1000)}|{int(t * 1000)}[s{i}]")
    mix.append(f"[s{i}]")
    k += 1
filtros.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0:duration=first,alimiter=limit=0.89:level=false,atrim=0:{dur:.3f}[mix]")
tmp = os.path.join(BASE, "_mix_tmp.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y"] + entradas + ["-filter_complex", ";".join(filtros), "-map", "[mix]", "-ac", "2", tmp], check=True)
l_mix = lufs(["-i", tmp])
ajuste = ALVO - l_mix
print(f"mix: {l_mix:.1f} LUFS -> ajuste {ajuste:+.1f} dB")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", VIDEO, "-i", tmp, "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                "-af", f"volume={ajuste:.2f}dB,alimiter=limit=0.89:level=false", "-c:a", "aac", "-b:a", "256k", "-shortest", SAIDA], check=True)
os.remove(tmp)
print(f"final: {lufs(['-i', SAIDA, '-vn']):.1f} LUFS ->", SAIDA)
