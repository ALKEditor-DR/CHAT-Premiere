# Histórico – Edição ED

## 2026-11-23 – criação
- Pedido: "novo estilo de edição; materiais mais picantes, mas foco em estilo, apresentação dos inserts, músicas, SFX. Literalmente tudo deve ser replicado." Referências: L4_V1 e PBU_V2 (Funil 1), ML 01/02/04 (Funil 6), L6_V2 (Funil 3).
- Análise feita nas timelines dos .prproj (valores exatos) + prints dos finais → `analise-referencias.md`.
- Regra especial do usuário: todo insert que não estiver disponível (ex.: famoso sem vídeo) é sinalizado na timeline para ele baixar → placeholder BAIXAR + marcador vermelho (`gerar_placeholders.py`, `E.baixar`).
- Regra do usuário: fala de impotência ou negativa sobre o homem → obrigatoriamente homem triste ou genitália masculina pequena, com vinheta, VHS e 50 % de saturação (`regras-material-ed.md`, `E.negativos`, `neg: true`). As referências já faziam algo parecido (soft dick + granulado + Lumetri/Noise no L4), mas sem os 50 % nem VHS: é regra nova, confirmar a dose nos primeiros prints.
- VHS: valores aprovados na skill de memória (separação ±3 px, linhas 5 %, tremor 2 px). No Premiere foi montado com Noise 20 + Wave Warp leve + Vignette com aberração cromática 51 na camada de ajuste; **não validado** – conferir no primeiro print e ajustar.
- Ganhos de áudio: o Premiere guarda Level com +15 dB de deslocamento (0,1778 = 0 dB); valores da análise já corrigidos. As trilhas de rock estão a 0 dB no clipe nas referências (ajuste fora do clipe); −19 dB é ponto de partida, conferir de ouvido.

## A validar no primeiro projeto
- `lib_ed.jsx` inteiro (escrito sobre os helpers do UP 3, sem teste no Premiere): modo `dividida`, `E.warps` (Offset/Directional Blur), `E.negativos`, cores de marcador (`setColorByIndex`: 1 = vermelho, 4 = amarelo).
- Formato da entrega (camadas no Premiere, como as outras skills Impetus) e qual legenda por tipo de vídeo.


## 2026-11-23 – primeiro uso real (MICROLEAD 3, Funil 3 sal azul)
- Pedido do usuário: "a tela dividida tem que ser dividida corretamente, sem ficar muito pra cima nem muito pra baixo". Aprovado: apresentador na metade de cima (V1 inteiro), insert escalado para cobrir 1080x960, centro em Y 0,75, **Crop (Legacy) cortando o que passa da metade** (Top = parte acima de 960 px), e uma linha branca de 8 px em Y 960 numa faixa acima. O modo `dividida` do lib_ed.jsx não recortava (insert vertical cobria 75 % da tela): corrigir o código.
- Problemas do lib_ed.jsx neste uso (corrigidos à mão no plano do projeto; levar para o código):
  - `L.audio` de um insert com `somDb` faz overwrite também no vídeo da mesma faixa: o insert perde a escala/efeitos (volta a 100 %) e, em cartão, cria uma cópia cheia na V2. Colocar o áudio antes dos efeitos ou reaplicar a escala depois.
  - `L.byPath` compara caminho com `/` e `\` sem normalizar (nada era achado/importado). `L.adj` só procura na raiz.
  - `E.fundoDesfocado` na V5 desfocava o cartão da V3: o fundo desfocado tem que ficar **abaixo** do cartão (V2).
  - Overwrite com tempos fora do quadro deixa lascas de 1 quadro entre inserts: remover lascas e fechar buracos < 0,12 s.
  - Títulos MOGRT e `Generated Light Leak 9` (.aegraphic) da referência ficaram offline (não dá para religar). Usados títulos PNG (linha destaque Anton com gradiente amarelo + linhas finas brancas em itálico, Wonder Glow 40, pop 0→100 em 0,2 s) e um light leak .mov com alfa gerado localmente; o usuário aprovou o visual.
  - A referência L6 importada traz mídias apontando para a pasta antiga (`G:\Clientes\IMPETUS\[LEADS] Funil 3 …`); religar para `Projetos finalizados e upados no drive\…` com `changeMediaPath`.
  - Pontos de entrada "validados" não garantem o conteúdo: no trecho negativo, conferir com folha de miniaturas (ffmpeg tile) antes de montar; o `uobbtmh3e75_… soft dick` em 541,5 s e o `Pau mole.mp4` mostram sexo, não pênis mole. `Impotent Penis - Impotence` (SEXO) e `Close-up no meu pau pequeno` (31,8 s) funcionaram.
- Dose do negativo (50 % + vinheta + VHS/Noise 20 + granulado) aprovada pelo usuário nos prints.


## 2026-11-24 – LTs animados reprovados (MICROLEAD 3)
- Usuário: "todos os LTs animados ficaram horríveis em termos de animação". Ele mesmo refez no projeto; registrar para melhorar no futuro.
- O que foi reprovado: títulos/nomes em PNG estático ("Gib eine / PRISE / BLAUES SALZ / in Honig", "Ich bin / JOHNNY SINS", "Ich bin / TIL SCHWEIGER", "Und raten / SIE MAL?") com Wonder Glow 40 e só um Transform de escala 0→100 % em 0,2 s e depois 100→108 %. O visual estático foi aprovado; o que ficou ruim foi a **animação**.
- A melhorar (pendente): reproduzir a entrada do MOGRT das referências (palavra a palavra, linhas entrando em tempos diferentes, destaque Anton com entrada própria), de preferência renderizada como camada com alfa (HyperFrames) ou com o MOGRT original religado, e não um "pop" de escala na imagem inteira. Antes de montar, mostrar **prova animada** (trecho curto em vídeo, não só print parado) e esperar aprovação.



## 2026-11-24 – ajustes do ML05 (padrão daqui pra frente)
- **Menos inserts de pênis**: nos trechos que não são negativos, trocar inserts focados em pênis (Majestoso_Pau_Duro, Pau_Grande, Super Hard Cock, Dotado, Pau_Enorme, Big Hard Cock, Playing with Fat Cock, The_Beast, Micro penis) por **sexo entre homem e mulher** (casal). Pênis mole/pequeno continua só nos trechos negativos (Regra 1).
- **Inserts horizontais**: sempre tela cheia (escala de preenchimento, `L.fill`) e **assunto centralizado**: olhar miniaturas (ffmpeg, frame do meio do trecho usado), estimar a posição do assunto `f` (0–1, relativo à **largura do próprio quadro**, cuidado com a coluna da folha) e aplicar Position X = 0,5 − (f − 0,5) × largura_escalada / largura_da_sequência, limitado para não aparecer borda.
- **Destaque de frase importante = LT animado (MOGRT/template do usuário), não mais PNG Anton**: frase com **2 linhas** usa o LT de 2 linhas (TEXTO 1 [Apoio] + TEXTO 2 [Destaque], template `1016ab94…`, Scale 63, Velocidade Geral 64) e frase com **3 linhas** usa o LT de 3 linhas (Apoio / Destaque / Apoio, template `ff128e55…`, Scale 60, Velocidade Geral 39). Os exemplos ficam no fim da timeline do usuário (V3) e os itens `template` estão no bin "Motion Graphics Template Media". Texto: propriedade JSON da componente `AE.ADBE Capsule` (o segundo `TEXTO n [..]`, o que começa com `{`); trocar `textEditValue` **e** `fontTextRunLength` pelo tamanho do texto; destaque em MAIÚSCULAS.
- **Transições A e B** (exemplos no fim da timeline, V4 = estilo A, V5 = estilo B, cada uma com 2 clipes "Graphic": 0,25 s + 0,71 s, corte no meio): usar **intercaladas A, B, A, B** entre os brolls e em alguns cortes de vídeo (espaçamento ≥ 3,2 s, não dentro de trecho negativo), centradas no corte (início = corte − 0,25 s). Técnica: `clone()` da sequência, apagar tudo menos os 2 clipes da trilha, **manter os clipes na posição original (114,83 s)** e colocar a sequência aninhada com in-point nesse tempo (assim as legendas da sequência não vêm junto; se mover os clipes para 0 as legendas aparecem duplicadas). Pendente: o efeito não apareceu nos frames de teste (nem no original); confirmar com o usuário.
