# Padrões dos upsells aprovados da Impetus (aprendido em 2026-11-11)

Fonte: 4 upsells finalizados e entregues, lidos pelo `.prproj` (todas as faixas, arquivo por arquivo) e pelos vídeos finais.
Use este arquivo para DECIDIR o que entra em cada frase de um upsell novo. Quando o roteiro novo for parecido com um destes,
copie a escolha do trecho equivalente (as listas frase → insert estão em `references/aprendizado/compacto_*.txt`).

| Vídeo | Nicho / mercado | Projeto (sequência principal) | Final |
|---|---|---|---|
| GlucoReset Drops UP1 V2 | diabetes tipo 2 / USA | `TDP  UPSELL  GlucoReset Drops  Upsell 1 V1  USA  CartPanda\Copied_UPSELL  GlycoCare  UP 1 V2  USA   BuyGoods_001\*.prproj` (seq "UP1-1.mp3") | 8:15 |
| MeltPeak UP1A V4 | emagrecimento GLP-1 / GER | `UPSELL I MeltPeak  UP1 A V4  GER  Digistore\Copied_UPSELL_MeltPeak_UP1A_V2_GER_Digistore\*.prproj` (seq "01-Anne-hallo-hier-ist-dr") | 11:28 |
| Jelly Glow UP1A V1 | pele / colágeno (gomas) / GER | `UPSELL  RW  Jelly Glow  UP 1A V1  GER   Digistore\Projeto\*.prproj` (seq "1 ANNE.mp3") | 9:12 |
| Cidre Peak UP1A V1 | emagrecimento GLP-1 / FRA | `UPSELL  Cidre Peak  UP 1 A V1  FRA  Digistore\Projeto\*.prproj` (seq "UPSELL  Cidre Peak...") | 10:53 |

(todos em `G:\Clientes\IMPETUS\Projetos finalizados e upados no drive`. Os nomes dos arquivos finais dizem 04m27s etc., mas a duração real é a da tabela.)
Cidre Peak e MeltPeak são o mesmo roteiro traduzido e usam praticamente os mesmos inserts: é o padrão mais consolidado.

## 1. Ritmo e cobertura
- Inserts cobrem **64–74 %** do vídeo (Gluco 64, Jelly 65, Cidre 72, Melt 74). O expert aparece nos ganchos, nas frases de olho no olho e embaixo das LTs.
- B-roll curto: **mediana 2,5–2,8 s** (mín. 0,8 s, máx. ~6 s). Uma frase longa = 2 ou 3 inserts seguidos, trocando no ritmo das palavras.
- Todo corte para insert entra com **light leak** (`Generated Light Leak 9`, gráfico nativo do Premiere/Mister Horse, 0,4–0,9 s)
  **+ SFX `Camera Shutter Click 12`**. Cidre/Melt: >100 vezes cada. Gluco: idem, um pouco menos.
- Expert: camadas de ajuste "Zoom suave" / `Zoom_IN` / `Zoom_OUT` com Transform: punch de 127 %→100 % em 0,75 s ou 100 %→119 % em 1 s;
  cada punch leva **`SFX - Swoosh 08`**. ~30 por vídeo.

## 2. B-ROLL — quando é ORGÂNICO (UGC de TikTok/Instagram/WhatsApp) e quando é BANCO DE IMAGENS
Contagem por vídeo (inserts de vídeo): Gluco 40 banco Storyblocks + 15 Envato + 6 Pexels, 5 orgânicos, 33 IA; Jelly 33 banco, 25 orgânicos; Melt 43 banco, 27 orgânicos, 54 IA; Cidre 44 banco, 26 orgânicos.
Como reconhecer pelo nome: orgânico = `ssstik.io_@perfil_...`, `snaptik_...`, `...-ssstik.pt.mp4`, `WhatsApp Video ...`, `Download-vmake`, títulos de TikTok com `#shorts`;
banco = `0_Nome_3840x2160` / `123456_Coll_wavebreak_...` (Storyblocks), `nome-descritivo-2025-12-17-...-utc.mov` (Envato), `1234567-uhd_3840_2160_25fps` (Pexels), `GettyImages-...`;
IA = `magnific_...`, `freepik_..._kling_...`, `grok-video-...`.

### ORGÂNICO (UGC) — usar quando a fala é PROVA REAL, RESULTADO DE GENTE COMUM ou "VIDA REAL"
- **Resultado / transformação no corpo**: "mulheres relatam perda de 20 a 40 kg", "o inchaço diminui", "resultados em poucos dias", "sem efeito ioiô", "vai surpreender todos com um corpo e roupas desinchados" →
  TikToks de mulheres mostrando barriga, cintura, calça folgada, antes/depois, foto no espelho (`IG/mulheres`, `IG/mulheres/fotos antes e depois`, `IG/EMAGRECIMENTO`). Ex.: `ssstik.io_@pam_frison`, `@amyswanweightloss`, `@sideyou0`, `@corpos_saudaveis`, `@ellie_and_thetwins`, `@lilianmarcelino2`.
- **Resultado na pele** (Jelly): "a pele parecia muito mais firme ao toque", "você sentirá sua pele se contraindo", "querer resultados mais rápidos" → TikToks de mulheres tocando o rosto/pescoço, skincare (`IG/Rejuvenecimento`: `@allanavieiraac`, `@chxrry.glowy`, `@oficialeticia`, `@natcosta.daily`).
- **Medição real**: "as leituras de açúcar voltaram ao normal", "cada queda na glicose desaparece" → glicosímetro em vídeo caseiro (`IG/DIABETES`: `@type1jessica`, WhatsApp).
- **Especialista explicando em rede social / animação 3D de TikTok**: "nosso corpo usa mais colágeno quando...", "multiplica a velocidade com que seu corpo absorve" → médicos/dermatos em vídeo vertical (`@caressmd`, `@toucheclinic`, `@sciepro`, "Eczema 3D Animation #shorts").
- **Coisa "nojenta"/crua que convence**: parasita, verme ("dar uma trégua ao parasita") → vídeo de WhatsApp/TikTok (`IG/Parasita`).
- **Receita / bebida caseira** (bônus de receitas): `IG/TRUQUES/Homemade drink` (`@benjixavier`).
- **Concorrente / canetas / remédio**: "sem efeitos colaterais, sem dependência" → vídeo/print de Mounjaro/Ozempic (`IG/Mounjaro`, `IG/CANETAS`: ozempic-face, notícia de WhatsApp) **com X vermelho por cima**.
- **Abertura de parabéns**: "gostaríamos de parabenizá-lo pessoalmente por sua decisão" → UGC de mulher mostrando o corpo (`@cardibia`) — já mostra o desejo.
- Formato: no padrão Melt/Cidre/Jelly o UGC vertical entra **como cartão com cantos arredondados no centro (~80 % da largura) sobre o "Fundo" do produto**
  (sequência aninhada "Fundo LIPOJARO"/"fundo jelly": fundo na cor da marca com frascos desfocados nas laterais). No Gluco o UGC entra em tela cheia com escala alta (163–187 %).

### BANCO DE IMAGENS (stock) — usar quando a fala é NARRATIVA, EMOÇÃO, PROCESSO ou CIÊNCIA
- **Emoção/decisão genérica**: parabéns, "decisão mais inteligente", "mudar sua vida" → mulher/homem sorrindo, em casa, no notebook (`IG/mulheres`, `IG/Homens`, `IG/IDOSO E PÉ EM GERAL` para público idoso). Ex.: `5797706_Coll_wavebreak_Home`, `GettyImages-1396800381`, `0_Girl_Slim`, `6038015_Woman_Happy`.
- **Pedido / caixa / envio / "o laboratório fecha a caixa"**: `IG/Entregas` — `packing-goods-in-a-cardboard-box...`, `worker-strapping-and-labeling-cardboard-box...`, `scientists-packaging-bottles-in-a-bright-lab...`, `person-taping-box-for-priority-shipping...`, `man-employee-of-warehouse...`, `5791001_Coll_wavebreak_Warehouse`. Aparece TODA vez que fala de pedido/remessa/frete.
- **"Só existe enquanto esta tela estiver aberta"**: mão segurando celular (`IG/Celular/0_Person_Hand`), pessoa no notebook.
- **Reembolso / e-mail / suporte**: call center (`IG/Atendimento ao cliente`), mulher no notebook, cartão de crédito no notebook.
- **Ciência / hormônio / célula / corpo**: 3D de banco (`IG/Celulas. Sangue`, `IG/Corpo humano`, `IG/EMAGRECIMENTO/adipocytes...`, `IG/Arteria entupida`, `0_Cell_Division`), cientista no microscópio (`IG/Medico(a)`).
- **Problema/emoção negativa**: mulher triste na balança, dor na barriga, estresse (`sad-woman-sits-on-floor-with-scales`, `4844389_Stomach_Pain`, `5294630_Woman_Emotional_Stress`, `0_Pain_Belly`). Idoso preocupado no Gluco (`contemplative-senior-man...`, `senior-man-resting-hands-on-walking-stick`).
- **Comida / bônus de receitas / dieta**: `IG/Comidas` (`0_Cooking_Pasta`, `0_Salad_Dressing`, `0_Food_Healthy_Food`), `597955_Food_Drink`.
- **Roupa folgada / fita métrica / resultado "limpo"**: `5388349_Coll_wavebreak_Measuring_Tape`, `0_Woman_Weight_Loss`, `woman-examining-herself-in-mirror`.
- **Metáfora** (Gluco): "calçada de concreto recém-colocada, qualquer pegada afunda" → concreto sendo despejado + pegadas na areia (Envato). Quando o roteiro faz analogia, ilustre a analogia literalmente.
- Tela cheia, sempre.

### IA (gerado) — produto e "cliente com produto"
- **Produto falado** (nome, dose, "3 cápsulas por dia", "ingredientes premium", "100 % natural", "o laboratório agrupa seu pedido") → mockup animado do frasco (`magnific_slow-zoom-in...`, `..._orbital...`) de `MOCKUPS/<produto>/Mockups Animados/Horizontal/1, 3, 6 POTES` (Gluco: `Vertical/1 FRASCO`).
  É o insert mais repetido nos trechos de oferta: 1 pote para dose, 3/6 potes para tratamento completo.
- **Mulher sorrindo mostrando o produto** (`magnific_ela-sorrindo-mostrando-o-...`): frases de benefício/garantia/"30 dias são suficientes" — funciona como UGC de cliente.
- **Depoimento escrito** ("perdi 43 kg", "na primeira semana já tinha perdido 4 kg"): IA de selfie no espelho (`magnific__ela-gorda-tirando-fotos-no-espelho` → `..._ela-tirando-fotos-no-espelho-usa`) ou cartões antes/depois (sequências aninhadas 10/11).
- **Estudo científico** (Gluco): "dividimos 400 pacientes em 2 grupos", "99,6 %" → print de artigo/gráfico gerado (`magnific_task-scientificproofinser...png`) sobre `fundo_singular_05.png`.

## 3. Telas montadas (sequências aninhadas e gráficos)
- **Tela de preço**: fundo da marca (Gluco `BG DEEP BLUE.mp4`; Jelly "fundo jelly" marrom; Melt "Fundo LIPOJARO" verde; Cidre verde-azulado) + PNG dos frascos da quantidade falada (6/9/12)
  + preço em neon (`Text Animation_Neon_04`, ex. "243 €") + **SFX `Cash.wav`** no número. "Botão abaixo / escolha o pacote" → sequência **"setas de compra"** (setas laranja/verdes apontando para baixo).
- **Garantia 30 dias**: selo dourado "30 days money back guaranteed" (`IG/IMAGENS/LOGO 30 ALEMAO .png` na Alemanha; sequência aninhada no Gluco) sobre os frascos.
- **Selo FDA** (USA) quando fala "FDA-confirmed/registered".
- **"Sem efeitos colaterais / sem agulhas"**: X vermelho em círculo sobre a seringa/caneta/rosto.
- **Bônus**: capa do e-book/programa (PNG) como cartão sobre o expert desfocado ou sobre `fundo_singular_05.png`, valor em verde ("$47"), seguido de 2–3 B-rolls do tema do bônus.
- **Cartão de vinheta branca** ("VIGNETTE"/"VERTICAL VIGNETT"): fundo branco com vinheta e texto dourado grande — para "presentes que valem 160 €", "materiais", "3 apoios".
- **DRAMA COLOR + VERTICAL VIGNETT** (Gluco): camada de ajuste que dessatura/escurece com vinheta nos trechos de ameaça ("parasita", "parar o tratamento é o maior perigo").
- **Instituto/estudo citado**: foto do lugar/documento como cartão (Jelly: "Instituto de Pesquisa da Pele em Berlim").
- **Depoimento**: cartões de antes/depois (selfie no espelho) sobre o depoimento desfocado.
- Grão de filme (`Inserts gerais/old-film-grain-overlay-4k-snowman-digital.mp4`) por cima em 1–2 trechos de bônus/fechamento.

## 4. LTs (textos grandes) e legendas
- Legenda base: Poppins SemiBold branca em caixa escura translúcida, 1–3 palavras, embaixo. Some quando entra LT.
- LT = a própria frase dita, **1–3 palavras por vez**, fonte **Anton** (Gluco/Melt/Cidre; Jelly igual estilo), dourado/amarelo-gradiente ou branco, **Wonder Glow**, sobre fundo desfocado (expert ou B-roll).
  Usada em sequências de 4–8 cartões nas frases-chave: "não feche esta página", "fique até o fim", "o maior erro...", "100 % natural, sem...", "grupo A / grupo B", "a diferença era...", "você quer reverter em meses ou em semanas?", "esta página é uma oportunidade única".
- LTs especiais com 2 fontes (itálico branco + negrito vermelho/amarelo): "oder ob du **ALL DAS** verstreichen lässt", "Attendez... relisez, **CALMEMENT**", "die **INTELLIGENTESTE** Entscheidung".
- Entrada de LT: SFX `Acute Whoosh` ou `Boom 1` (frase de impacto); `Riser` antes de LT importante.

## 5. Transições
- Light leak + `Camera Shutter Click 12` em quase todo insert (ver §1).
- Jelly: também `Flash` e `Lens Blur` (camadas de ajuste) entre blocos, com `Riser`.
- Entrada de tela de preço/fundo: zoom out + `Tile` ou `Swoosh Transition 28`.

## 6. Música (arco)
- Abertura/problema → trilha cinematográfica de fundo; ciência/drama → violino dramático; oferta/bônus/garantia → trilha motivacional/épica crescente.
  - Gluco (USA): `Musicas Storytelling\Novas\Cinematic Background Music by Infraction ... Time` (0–2:24 e até 3:10) → `KINGS GAMBIT Epic Dramatic Violin` (3:06–6:06) → `Novas\Cinematic Action Trailer by Infraction ... Skylight` (6:08–fim).
  - Melt/Cidre: `magnific-duke.mp3` (IA, 0–2:08) → `Infraction ... Time` (2:06–7:30) → `Novas\Epic Powerful Motivational by Infraction ... Gemini` (7:30–fim).
  - Jelly: `Inserts gerais\MÚSICAS\freemusicforvideo-advertising-background-music-434692.mp3` quase todo + `ARQUIVOS NECESSARIOS\TRILHAS\TRILHA (1).mp3` no depoimento.
- Trocas com crossfade (Constant Power / Custom Fade). Duas trilhas que se cruzam vão em faixas diferentes.

## 7. SFX (onde estão e quando entram)
| SFX | Arquivo | Quando |
|---|---|---|
| Camera Shutter Click 12 | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Cameras\Camera Shutter Click 12.wav` | todo light leak / entrada de insert |
| SFX - Swoosh 08 | `G:\EDIÇÃO\Para separar depois\SFX - Swoosh 08.mp3` | punch de zoom no expert |
| Swoosh Transition 28 | `ARQUIVOS NECESSARIOS\SFX\Swoosh\Swoosh Transition 28.wav` | entrada de cartão/tela aninhada |
| Acute Whoosh | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Risers\Acute Whoosh.mp3` | entrada de LT |
| Boom 1 | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Hits - impacts\Boom 1.mp3` | LT/frase de impacto ("I need", "But remember") |
| Riser | `G:\EDIÇÃO\Musicas\SFX\Riser.wav` (acelerado 9x no Jelly) | antes de LT/transição forte |
| Cash | `G:\EDIÇÃO\PACK de EDIÇÃO\SFX Viral\Diversos\Cash.wav` | preço, valor de bônus ("$47", "160 €") |
| Woosh 02 | `ARQUIVOS NECESSARIOS\SFX\WOOSH\Woosh 02.mp3` | Jelly: entrada de LT/cartão |
| Tile | só nos projetos Melt/Cidre | entrada de tela de preço |
| Notification | `-Notification t1_03/07.wav` | pop de ícone/selo |

## 8. Estrutura típica do roteiro de upsell e o visual de cada bloco
1. Gancho "não feche / não clique em voltar / fique até o fim" → expert + LT palavra por palavra; 1–2 stock de pessoa no notebook/celular.
2. Parabéns pela decisão → stock emocional + UGC de resultado (cartão sobre o fundo do produto).
3. "Seu pedido está sendo processado / o laboratório fecha a caixa" → stock de Entregas.
4. Presentes/bônus anunciados → cartão de vinheta branca com texto dourado + Cash.
5. Timeline de resultados / como funciona → 3D de banco (corpo/células) + UGC de resultado.
6. Protocolo acelerado (3 doses) → mockup IA do produto (1 e 3 potes) + mulher IA mostrando o produto.
7. Segurança ("100 % natural, sem efeitos colaterais") → mockups + X vermelho sobre caneta/seringa + LT.
8. Estudo/ciência/metáfora → documentos/gráficos, 3D, analogia ilustrada; DRAMA COLOR nas ameaças.
9. Depoimento → antes/depois (selfie no espelho), cartões sobre o depoimento desfocado; música própria.
10. Problema do estoque ("vai acabar 3x mais rápido") → mockup + pílulas + stock de mulher preocupada.
11. Oferta (12/9/6 frascos, preços) → telas de preço com neon + Cash; "leia de novo com calma" LT especial; setas de compra.
12. Bônus 1/2/3 → capa do bônus + 2–3 stocks do tema.
13. Garantia → selo 30 dias + call center/notebook (reembolso).
14. Fechamento/urgência ("página única, não há link para voltar") → stock de pessoa fechando aba/notebook, mockup 6 potes, setas de compra.

## 9. Receitas dos efeitos (medidas quadro a quadro e nos parâmetros do .prproj)
Implementadas em `scripts/efeitos_referencia.py` (mini teste aprovado para render em 2026-11-12: `G:\Clientes\IMPETUS\TESTES DE IA\Teste de efeitos - Cidrepeak v1.mp4`). Comparação com a referência: `aprendizado/efeitos/lado_a_lado.jpg`.
- **LT**: Anton ~128 px, centro em y≈0,49. Entrada: escala 0→100 % em 0,12–0,16 s (Transform, shutter 360 = borrão de movimento), depois 100→120 % até o fim do cartão. Branco com brilho branco; dourado = degradê #F8E6AE→#D8AC5A com halo escuro marrom (Wonder Glow 60/40/50, ambiente escuro). Sobre o expert: fundo desfocado e escurecido (Lumetri exposição −0,62, realces −100, sombras −51). Sobre B-roll/cartão: fundo fica nítido. Legenda some enquanto a LT está na tela.
- **Legenda**: Poppins SemiBold ~54 px branca, caixa escura arredondada (raio 10, ~75 %), centro y≈1190; nas referências entra seca (no teste: pop 92→100 % em 0,08 s porque o usuário pediu animada).
- **Light leak no corte** (Generated Light Leak 9, 0,5 s depois + 0,33 s antes): ~0,33 s antes do corte tinta rosa→laranja subindo; **1 quadro branco** no corte; ~0,5 s depois laranja quente saindo pelo canto de cima/esquerda. `Camera Shutter Click 12` 0,04 s antes do corte.
- **Zoom no expert** (camadas "Zoom suave"): punch 126,8→100 % em 0,75 s no início do trecho + 100→107 % em ~7 s; ou 100→119,4 % em 1 s com posição y +1,1 %. `SFX - Swoosh 08` junto.
- **Cartão arredondado**: UGC vertical em cartão com cantos de ~44 px, sombra (direção 135°, distância 34, bem suave), inclinação de 3–5°, Camera Shake suave; entra de 86→100 % com subida de 60 px em 0,28 s + `Swoosh Transition 28`. Fundo: da marca (frascos desfocados nos cantos, vinheta, ruído 20) ou branco `G:\para o SSD\Fundos SINGULAR\fundo_singular_05.png`. No Cidre/Melt o UGC entra em altura total (largura ~760 px) sem cantos.
- **Tela de preço**: `BACKGROUND - PRODUTOS\BG BLUE.mp4` (Cidre; cor da marca em outros) + frascos 1 pote desfocados (blur 25) no canto de cima/esquerda (−13°) e embaixo/direita (16°) + vinheta + ruído; mockup de 12 frascos ~900 px no centro (y 0,58) flutuando; preço em neon (Montserrat Black, só contorno verde #3CFF28 com brilho) em y≈0,21, acendendo letra a letra piscando em ~0,45 s; `Cash.wav` no preço; setas de compra laranja #F7931E nas laterais na altura dos frascos, indo e voltando (Arrow Loop, velocidade 5).
- **Tile** (entrada de tela de preço/bloco): camada de ajuste com espelhos + replicate, zoom out/in rápido de 0,375 s com borrão; som `[T]_Zoom - Basic.wav` (está em `Projetos finalizados e upados no drive\UPSELL  Cidre Peak  UP 1 A V1  FRA  Digistore\UP 1A_V4_MeltPeak_GER_Digistore_04m42s\`).
- SFX das referências entram no volume do próprio arquivo (sem ajuste no clipe). Música ~20 LU abaixo da voz; final em −17 LUFS.
