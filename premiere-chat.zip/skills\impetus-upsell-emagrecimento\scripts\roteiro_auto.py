#!/usr/bin/env python
"""Etapa 2a: gera um roteiro.json inicial só com legendas normais, a partir de palavras.json.

python roteiro_auto.py "<pasta mãe>/_projeto" [--trocas "sidrepeak=Cidrepeak,galpen=GLP-1"]

Regra da legenda (preset "Legendas Andre"): 1 a 3 palavras por bloco, até ~18 caracteres,
quebrando na pontuação. Depois, troque à mão os trechos de destaque por blocos "D" (ver formato-projeto.md).
"""
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
P = sys.argv[1]
TROCAS = {}
if "--trocas" in sys.argv:
    for par in sys.argv[sys.argv.index("--trocas") + 1].split(","):
        a, b = par.split("=")
        TROCAS[a.lower()] = b
pal = json.load(open(os.path.join(P, "palavras.json"), encoding="utf-8"))
MAXC, MAXW = 18, 3

blocos = []
atual = []


def fecha():
    global atual
    if atual:
        blocos.append(["L", " ".join(atual)])
    atual = []


for i, (s, e, w, _) in enumerate(pal):
    limpo = re.sub(r"[^\w%€'-]", "", w.lower())
    if limpo in TROCAS:
        w = TROCAS[limpo] + re.sub(r"^[\w%€'-]+", "", w)
    prox_gap = pal[i + 1][0] - e if i + 1 < len(pal) else 9
    cand = " ".join(atual + [w])
    if atual and (len(cand) > MAXC or len(atual) >= MAXW):
        fecha()
    atual.append(w)
    if re.search(r"[.,!?;:]$", w) or prox_gap > 0.25:
        fecha()
fecha()
# junta palavra solta muito curta ao bloco seguinte ("de", "à")
json.dump(blocos, open(os.path.join(P, "roteiro.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print(len(blocos), "blocos ->", os.path.join(P, "roteiro.json"))
