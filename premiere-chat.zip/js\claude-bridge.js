/*
 * Ponte entre o painel e o Claude Code (CLI) usando a assinatura Claude do usuário.
 *
 * - Localiza o executável do Claude Code (instalação própria ou a que vem com o Claude Desktop).
 * - Roda `claude -p` em segundo plano, com stream-json, sem nenhuma chave de API no ambiente:
 *   a autenticação é sempre o login da conta Claude (Pro/Max).
 * - Sobe um servidor MCP HTTP local (127.0.0.1 + token aleatório) para o Claude chamar as
 *   ferramentas do Premiere Pro (ExtendScript, estado do projeto, transcrição local, legendas).
 *
 * Funciona no painel CEP (Node habilitado) e em Node puro (para testes).
 */
(function (root) {
  "use strict";

  const req = typeof require === "function" ? require : root.require;
  if (typeof req !== "function") {
    // Sem Node (ex.: pré-visualização no navegador): o painel mostra o aviso.
    root.ClaudeBridge = null;
    return;
  }
  const fs = req("fs");
  const os = req("os");
  const path = req("path");
  const http = req("http");
  const crypto = req("crypto");
  const { spawn } = req("child_process");

  const IS_WIN = process.platform === "win32";
  const api = {};

  // ---------------------------------------------------------------- localizar o CLI

  function compareVersions(a, b) {
    const pa = a.split(".").map((n) => parseInt(n, 10) || 0);
    const pb = b.split(".").map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    }
    return 0;
  }

  function safeReaddir(dir) {
    try {
      return fs.readdirSync(dir);
    } catch {
      return [];
    }
  }

  function exists(p) {
    try {
      return fs.statSync(p).isFile();
    } catch {
      return false;
    }
  }

  // Cópias do Claude Code que o app Claude Desktop mantém em <base>/<versão>/<hash>/claude.exe
  function desktopBundledCandidates() {
    if (!IS_WIN) return [];
    const bases = [];
    if (process.env.APPDATA) bases.push(path.join(process.env.APPDATA, "Claude", "claude-code"));
    // O Claude Desktop da Microsoft Store grava numa pasta virtualizada do pacote.
    const pkgRoot = process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Packages");
    if (pkgRoot) {
      for (const pkg of safeReaddir(pkgRoot)) {
        if (/^Claude_/i.test(pkg)) {
          bases.push(path.join(pkgRoot, pkg, "LocalCache", "Roaming", "Claude", "claude-code"));
        }
      }
    }
    // Versões novas do Claude Desktop: %LOCALAPPDATA%\Claude-Data\<perfil>\claude-code
    const dataRoot = process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Claude-Data");
    if (dataRoot) {
      for (const prof of safeReaddir(dataRoot)) {
        bases.push(path.join(dataRoot, prof, "claude-code"));
      }
    }
    const found = [];
    for (const base of bases) {
      for (const ver of safeReaddir(base)) {
        for (const hash of safeReaddir(path.join(base, ver))) {
          const exe = path.join(base, ver, hash, "claude.exe");
          if (exists(exe)) found.push({ exe, ver });
        }
      }
    }
    found.sort((a, b) => compareVersions(b.ver, a.ver));
    return found.map((f) => f.exe);
  }

  function findClaude(customPath) {
    if (customPath && exists(customPath)) return customPath;
    const home = os.homedir();
    const names = IS_WIN ? ["claude.exe", "claude.cmd"] : ["claude"];
    const candidates = [];
    if (IS_WIN) {
      candidates.push(path.join(home, ".local", "bin", "claude.exe"));
      if (process.env.APPDATA) candidates.push(path.join(process.env.APPDATA, "npm", "claude.cmd"));
    } else {
      candidates.push(
        path.join(home, ".local", "bin", "claude"),
        path.join(home, ".claude", "local", "claude"),
        "/opt/homebrew/bin/claude",
        "/usr/local/bin/claude"
      );
    }
    for (const dir of (process.env.PATH || "").split(path.delimiter)) {
      if (!dir) continue;
      for (const n of names) candidates.push(path.join(dir, n));
    }
    candidates.push(...desktopBundledCandidates());
    return candidates.find(exists) || null;
  }

  // ---------------------------------------------------------------- execução

  // Ambiente sem chaves de API: garante que o uso sai da assinatura, nunca da API paga.
  function subscriptionEnv() {
    if (api.keepEnvForTests) return { ...process.env };
    const env = {};
    for (const [k, v] of Object.entries(process.env)) {
      if (/^(ANTHROPIC_|CLAUDE_CODE_|CLAUDECODE$|CLAUDE_AGENT_SDK)/.test(k)) continue;
      env[k] = v;
    }
    return env;
  }

  function workspaceDir() {
    const dir = path.join(os.homedir(), ".premiere-chat", "workspace");
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  function spawnClaude(exe, args, opts) {
    const isCmd = /\.cmd$/i.test(exe);
    return spawn(isCmd ? `"${exe}"` : exe, args.map((a) => (isCmd ? JSON.stringify(a) : a)), {
      cwd: workspaceDir(),
      env: { ...subscriptionEnv(), MCP_TOOL_TIMEOUT: "3600000" },
      windowsHide: true,
      shell: isCmd,
      ...opts,
    });
  }

  function runSimple(exe, args, timeoutMs) {
    return new Promise((resolve) => {
      let out = "";
      let err = "";
      const child = spawnClaude(exe, args, { stdio: ["ignore", "pipe", "pipe"] });
      const timer = setTimeout(() => child.kill(), timeoutMs || 30000);
      child.stdout.on("data", (d) => (out += d));
      child.stderr.on("data", (d) => (err += d));
      child.on("error", (e) => {
        clearTimeout(timer);
        resolve({ code: -1, out, err: String(e.message || e) });
      });
      child.on("close", (code) => {
        clearTimeout(timer);
        resolve({ code, out, err });
      });
    });
  }

  async function authStatus(exe) {
    const r = await runSimple(exe, ["auth", "status", "--json"], 30000);
    try {
      return JSON.parse(r.out);
    } catch {
      return { loggedIn: false, error: (r.err || r.out || "sem resposta").trim() };
    }
  }

  // Abre uma janela de terminal para o login com a conta Claude (assinatura).
  function openLogin(exe) {
    if (IS_WIN) {
      const child = spawn("cmd.exe", ["/c", "start", '"Login Claude"', `"${exe}"`, "auth", "login", "--claudeai"], {
        env: subscriptionEnv(),
        detached: true,
        windowsVerbatimArguments: true,
        stdio: "ignore",
      });
      child.unref();
    } else {
      const script = `tell application "Terminal" to do script "${exe.replace(/"/g, '\\"')} auth login --claudeai"`;
      spawn("osascript", ["-e", script], { detached: true, stdio: "ignore" }).unref();
    }
  }

  // ---------------------------------------------------------------- servidor MCP local

  // Servidor MCP mínimo (Streamable HTTP com respostas JSON). `tools` é uma lista de
  // { name, description, inputSchema, handler(args) -> Promise<{ text, isError }> }.
  // srvOpts.allow(perfil, nome): com ?perfil=etapa na URL, só as ferramentas daquela etapa aparecem e rodam.
  function startMcpServer(tools, srvOpts) {
    const allow = (srvOpts && srvOpts.allow) || (() => true);
    const token = crypto.randomBytes(24).toString("hex");
    const byName = new Map(tools.map((t) => [t.name, t]));

    async function handle(msg, profile) {
      const { id, method, params } = msg;
      if (id === undefined || id === null) return null; // notificação
      const ok = (result) => ({ jsonrpc: "2.0", id, result });
      const fail = (code, message) => ({ jsonrpc: "2.0", id, error: { code, message } });

      switch (method) {
        case "initialize":
          return ok({
            protocolVersion: (params && params.protocolVersion) || "2025-06-18",
            capabilities: { tools: { listChanged: false } },
            serverInfo: { name: "premiere-pro", version: "1.0.0" },
          });
        case "ping":
          return ok({});
        case "tools/list":
          return ok({
            tools: tools.filter((t) => allow(profile, t.name)).map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })),
          });
        case "tools/call": {
          const tool = byName.get(params && params.name);
          if (!tool || !allow(profile, tool.name)) return fail(-32602, "Ferramenta desconhecida: " + (params && params.name));
          try {
            const r = await tool.handler((params && params.arguments) || {});
            const content = r.content || [{ type: "text", text: String(r.text) }];
            return ok({ content, isError: !!r.isError });
          } catch (e) {
            return ok({ content: [{ type: "text", text: "Erro: " + (e.message || e) }], isError: true });
          }
        }
        default:
          return fail(-32601, "Método não suportado: " + method);
      }
    }

    const server = http.createServer((reqIn, res) => {
      if (reqIn.headers.authorization !== "Bearer " + token) {
        res.writeHead(401).end();
        return;
      }
      if (reqIn.method !== "POST") {
        res.writeHead(reqIn.method === "DELETE" ? 200 : 405).end();
        return;
      }
      let body = "";
      reqIn.on("data", (d) => (body += d));
      reqIn.on("end", async () => {
        let parsed;
        try {
          parsed = JSON.parse(body);
        } catch {
          res.writeHead(400).end();
          return;
        }
        const batch = Array.isArray(parsed) ? parsed : [parsed];
        const profile = (/[?&]perfil=([\w-]+)/.exec(reqIn.url || "") || [])[1] || "";
        const replies = (await Promise.all(batch.map((m) => handle(m, profile)))).filter(Boolean);
        if (replies.length === 0) {
          res.writeHead(202).end();
          return;
        }
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(Array.isArray(parsed) ? replies : replies[0]));
      });
    });

    server.requestTimeout = 0; // transcrições longas: a resposta pode demorar minutos
    server.timeout = 0;
    server.keepAliveTimeout = 0;

    return new Promise((resolve, reject) => {
      server.on("error", reject);
      server.listen(0, "127.0.0.1", () => {
        const { port } = server.address();
        resolve({
          url: `http://127.0.0.1:${port}/mcp`,
          token,
          close: () => server.close(),
        });
      });
    });
  }

  /*
   * Conversa longa: o próprio Claude Code resume sozinho quando o contexto chega perto de 300 mil tokens
   * (30% da janela de 1 milhão; em modelos de janela menor vale o limite deles). O resumo é escrito pelo
   * modelo, com a instrução abaixo, e também acontece no meio de um pedido longo.
   */
  const COMPACT_WINDOW = 300000;
  const COMPACT_HINT =
    "Mantenha as decisoes tomadas, os nomes e caminhos dos arquivos, os pedidos do usuario, os planos e valores aprovados, o que ja foi feito na timeline e os erros pendentes";
  function claudeSettingsFile() {
    try {
      const file = path.join(os.homedir(), ".premiere-chat", "claude-settings.json");
      const text = JSON.stringify(
        {
          autoCompactEnabled: true,
          autoCompactWindow: api.compactWindowForTests || COMPACT_WINDOW,
          // Só texto sem acento: o comando roda no shell de cada computador.
          hooks: { PreCompact: [{ matcher: "auto", hooks: [{ type: "command", command: `echo "${COMPACT_HINT}"`, timeout: 10 }] }] },
        },
        null,
        2
      );
      let old = "";
      try {
        old = fs.readFileSync(file, "utf8");
      } catch {}
      if (old !== text) {
        fs.mkdirSync(path.dirname(file), { recursive: true });
        fs.writeFileSync(file, text, "utf8");
      }
      return file;
    } catch {
      return ""; // sem o arquivo, segue sem a compactação antecipada
    }
  }

  // ---------------------------------------------------------------- um turno de conversa

  /*
   * Executa um turno: envia `prompt` ao Claude Code e repassa os eventos.
   * opts: { exe, mcp, systemPrompt, model, effort, sessionId, onText(delta), onTextStart(),
   *         onInit(info), onCompact(info) }
   * Retorna { promise, cancel } — promise resolve com o evento "result" do CLI.
   */
  function runTurn(prompt, opts) {
    const toolNames = (opts.toolNames || []).map((n) => "mcp__ppro__" + n);
    const args = [
      "-p",
      "--output-format", "stream-json",
      "--verbose",
      "--include-partial-messages",
      "--system-prompt", opts.systemPrompt,
      // Ferramentas internas do Claude Code liberadas (ex.: Skill, Read). Vazio = nenhuma.
      "--tools", (opts.builtinTools || []).join(","),
      "--mcp-config", JSON.stringify({
        mcpServers: { ppro: { type: "http", url: opts.mcp.url, headers: { Authorization: "Bearer " + opts.mcp.token } } },
      }),
      "--strict-mcp-config",
      "--allowedTools", toolNames.concat(opts.builtinTools || []).join(","),
      "--permission-mode", "dontAsk",
      // A mensagem vai como JSON: permite anexar imagens e PDFs junto com o texto.
      "--input-format", "stream-json",
    ];
    if (opts.model) args.push("--model", opts.model);
    if (opts.effort) args.push("--effort", opts.effort);
    if (opts.sessionId) args.push("--resume", opts.sessionId);
    const settingsFile = claudeSettingsFile();
    if (settingsFile) args.push("--settings", settingsFile);

    const child = spawnClaude(opts.exe, args, { stdio: ["pipe", "pipe", "pipe"] });
    let cancelled = false;

    const promise = new Promise((resolve, reject) => {
      let buf = "";
      let stderr = "";
      let result = null;
      let sessionId = opts.sessionId || null;
      const calls = []; // gasto de cada chamada à IA: { model, in, write, read, out }

      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (chunk) => {
        buf += chunk;
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (!line) continue;
          let ev;
          try {
            ev = JSON.parse(line);
          } catch {
            continue;
          }
          if (ev.session_id) sessionId = ev.session_id;
          if (ev.type === "system" && ev.subtype === "init" && opts.onInit) opts.onInit(ev);
          else if (ev.type === "system" && ev.subtype === "compact_boundary") {
            if (opts.onCompact) opts.onCompact(ev.compact_metadata || {});
          }
          else if (ev.type === "stream_event" && ev.event) {
            const e = ev.event;
            if (e.type === "message_start" && e.message) {
              const u = e.message.usage || {};
              calls.push({ model: e.message.model || "", in: u.input_tokens || 0, write: u.cache_creation_input_tokens || 0, read: u.cache_read_input_tokens || 0, out: 0 });
              if (opts.onCall) opts.onCall(calls);
            } else if (e.type === "message_delta" && e.usage && calls.length) {
              calls[calls.length - 1].out = e.usage.output_tokens || 0;
              if (opts.onCall) opts.onCall(calls);
            }
            if (e.type === "content_block_start" && e.content_block && e.content_block.type === "text") {
              if (opts.onTextStart) opts.onTextStart();
            } else if (e.type === "content_block_delta" && e.delta && e.delta.type === "text_delta") {
              if (opts.onText) opts.onText(e.delta.text);
            }
          } else if (ev.type === "result") result = ev;
        }
      });
      child.stderr.on("data", (d) => (stderr += d));
      child.on("error", (e) => reject(new Error("Não foi possível iniciar o Claude Code: " + (e.message || e))));
      child.on("close", (code) => {
        if (cancelled) return resolve({ cancelled: true, session_id: sessionId, calls });
        if (result) return resolve({ ...result, calls, session_id: result.session_id || sessionId });
        reject(new Error((stderr || `Claude Code saiu com código ${code}`).trim()));
      });

      // `prompt` pode ser texto ou uma lista de blocos (texto, imagem, documento).
      const content = typeof prompt === "string" ? [{ type: "text", text: prompt }] : prompt;
      child.stdin.end(JSON.stringify({ type: "user", message: { role: "user", content } }) + "\n", "utf8");
    });

    return {
      promise,
      cancel() {
        cancelled = true;
        child.kill();
      },
    };
  }

  Object.assign(api, { findClaude, runSimple, authStatus, openLogin, startMcpServer, runTurn });
  root.ClaudeBridge = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
