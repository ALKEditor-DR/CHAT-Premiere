# Arquivos do projeto (em `<pasta mãe>/_projeto`)

Exemplo real e completo em `../exemplo-cidrepeak/` (`montar.py` gera os dois JSON a partir das escolhas).

## Gerados por `decupar.py`
- `decupado.mp4`: fala inteira já cortada, 1080x1350, com áudio.
- `segmentos.json`: `{bruto, orador, src_in, src_out, tl_in, tl_out, w, h}` por pedaço. `orador` sai do nome do arquivo (lisa, lucile, depoimento).
- `palavras.json`: `[inicio, fim, palavra, bruto]` no tempo do decupado. Elisões e hífens já juntos ("s'il", "Laissez-moi").
- `transc/`: transcrição de cada bruto (cache; apague para transcrever de novo).
- `avisos.txt`: palavras com baixa confiança e frases repetidas.

## roteiro.json
Lista de blocos `[modo, texto]` na ordem da fala.
- `"L"`: legenda normal (1 a 3 palavras).
- `"D"`: destaque em Bebas. Linhas separadas por ` / `, cada uma com `w:` (branco), `y:` (amarelo) ou `g:` (pequeno, Poppins). Ex.: `["D", "g:Attendez, / y:RELISEZ / g:calmement,"]`.
- `"D!"`: destaque que desfoca o fundo mesmo sobre B-roll.

O roteiro precisa ter todas as palavras de `palavras.json`, em ordem. `render.py --check` acusa o que não bate.
- `Cidrepeak.{2}`: uma palavra da legenda que consome 2 da transcrição ("cidre épique").
- `+accéléré.`: palavra que a transcrição perdeu (confira no áudio antes); entra na legenda sem consumir nada.
- Grafia diferente da transcrição vai em `trocas` do projeto.

## projeto.json
```json
{
  "mae": "G:/Clientes/IMPETUS/TESTES DE IA",
  "decupado": "decupado.mp4",
  "roteiro": "roteiro.json",
  "trocas": [["Cidrepeak", "Sidrepeak"], ["GLP-1", "Galpen"]],
  "nomes": [{"inicio": 0.74, "fim": 4.43, "linha1": "Lisa Salis", "linha2": "Responsable du laboratoire", "lado": "direita"}],
  "inserts": [{"inicio": 7.7, "fim": 9.9, "arquivo": "Inserts/broll/x.mp4", "clip_in": 0.5, "push": [1.0, 1.06], "pos": [0.5, 0.5], "escala": 1.0, "vel": 1.0}],
  "tela_preco": [{"inicio": 263.3, "fim": 278.3, "fundo": ".../BG YELLOW.mp4",
                  "mockups": [{"arquivo": "Inserts/Produto/Mockup_CidrePeak FRA 12.png", "inicio": 263.3, "fim": 278.3, "pos": [0.5, 0.28], "larg": 820}],
                  "precos": [{"texto": "19€", "cor": "verde", "inicio": 272.7, "fim": 274.5, "pos": [0.5, 0.56]}]}],
  "flashes": [19.42, 65.71],
  "zoom_fixo": [[100.0, 104.5, 1.0]],
  "foco": {"lisa": [0.30, 0.20]},
  "estilo": {"leg_tam": 60},
  "audio": {"alvo_lufs": -17,
            "trilhas": [{"arquivo": "trilha.mp3", "inicio": 0, "fim": 199.2, "arquivo_in": 0, "lu": -18, "fade_in": 0.5, "fade_out": 1.2}],
            "sfx": [{"arquivo": "mid whoosh.mp3", "t": 19.16, "ganho_db": -12}]}
}
```
Observações:
- Tempos em segundos do decupado. `inserts` não podem se sobrepor; a tela de preço tem prioridade sobre insert.
- `pos` e `escala` do insert: centro do recorte (fração) e zoom extra. Fotos (png/jpg/webp) também servem.
- `zoom_fixo` força um zoom num trecho (1.0 = aberto). `foco` muda o ponto do rosto de cada orador no plano fechado.
- `estilo` sobrescreve qualquer valor do dicionário `E` de `render.py`; use só para exceção aprovada.
- No `sfx`, `t` é o início do arquivo; para o pico cair no clarão, desconte o tempo do pico (`mid whoosh` 0,26 s; `swhoosh` 0,56 s).
